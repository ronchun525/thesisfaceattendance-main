# SAVAGE-RSUCAJ Smart Attendance Admin Portal — System Architecture

**Institution:** Romblon State University – Cajidiocan Campus  
**Version:** `1.4.0` (BUILD 06)  
**Stack:** React 19 + TypeScript + Tailwind CSS v4 + Vite 8 + Node.js/Express 4 + SQLite (`better-sqlite3`, WAL mode)

---

## 1. Architectural Overview

The SAVAGE-RSUCAJ Admin Portal is a single-server full-stack web application running on port `3000`. In development (`npm run dev`), Express mounts Vite's middleware server alongside the `/api` REST router. In production (`npm run build && npm start`), Express serves the static bundle from `dist/` and mounts the `/api` REST router backed by a persistent host-mounted SQLite database (`DATABASE_PATH`, outside ephemeral app build directories).

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    Browser Client (React 19 SPA)                        │
│  16 Reference-Aligned Screens (Login + 15 Sidebar Modules)              │
│  No Admin Biometrics Sidebar Module (Mandatory Rule)                    │
│  Authentic Empty States in Production (Zero Synthetic Auto-Seeding)     │
│  Auth: HttpOnly Session Cookie + Double-Submit X-CSRF-Token Header      │
│  ZERO sensitive tokens in localStorage or sessionStorage                │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │ HTTP / HTTPS (JSON REST + Cookies)
                                ▼
┌─────────────────────────────────────────────────────────────────────────┐
│             Node.js / Express Server (server.ts, Port 3000)             │
│  • Fail-Secure Env & Mode Separation (server/env.ts: prod|demo|test)    │
│  • Security Headers & Trusted Proxy Handling (server/security.ts)       │
│  • Rate Limiting + Account Brute-Force Lockout + Origin Allowlist       │
│  • Revocable Server-Backed Sessions + Key Rotation (server/auth.ts)     │
│  • Server-Side 6-Role / 35-Permission RBAC Policy (server/rbac.ts)      │
│  • Online Backup, AES-256-GCM Archive & Restore Engine (server/backup)  │
│  • HTTP 503 Database-Unavailable Error Boundary                         │
│  • Graceful SIGINT/SIGTERM Shutdown (WAL TRUNCATE checkpoint + close)   │
└──────────────┬───────────────────────────────────────┬──────────────────┘
               │                                       │
               ▼                                       ▼
┌─────────────────────────────────┐     ┌─────────────────────────────────┐
│   SQLite Database (WAL Mode)    │     │  Campus Kiosk Terminals         │
│   server/db.ts (better-sqlite3) │     │  (Raspberry Pi 3B / Android)    │
│   Persistent Host Storage       │     │  Auth: x-kiosk-token header     │
│   foreign_keys=ON, sync=FULL    │     │  POST /api/kiosk/heartbeat      │
│   Versioned Migrations 001->003 │     │  POST /api/kiosk/punch          │
│   Event Identity + DB Triggers  │     │  (Idempotent event_uid replay)  │
└─────────────────────────────────┘     └─────────────────────────────────┘
```

---

## 2. Mode Separation (`APP_MODE`: `production` | `demo` | `test`)

BUILD 06 strictly separates operational environments in `server/env.ts` and `server/db.ts`:

| Mode | Allowed with `NODE_ENV=production`? | Auto-Seeds Sample Data? | `DATABASE_PATH` Policy |
|---|---|---|---|
| **`production`** | Yes (required) | **NEVER** (`DemoSeedForbiddenError` thrown if attempted) | Must be explicit absolute persistent path outside `dist/`, `build/`, `node_modules/`, `.git/`, never `:memory:` |
| **`demo`** | **FORBIDDEN** (boot aborted) | Only via explicit isolated CLI `npm run db:seed-demo -- --db <sandbox.db>` | Non-production sandbox path only (refuses live `./data/savage_rsucaj.db`) |
| **`test`** | **FORBIDDEN** (boot aborted) | Controlled per isolated test suite | `:memory:` or ephemeral OS `tmpdir()` |

Production installations with zero business records render authentic empty states across Dashboard, Employees, Attendance, Devices, Payroll, Notifications, and Audit Logs until real campus data is entered or imported from a verified source.

---

## 3. Frontend Architecture (`src/`)

- **Entry & Shell**: `index.html`, `src/main.tsx`, `src/index.css`, `src/App.tsx`, `src/components/ModuleFrame.tsx`, `src/components/SavageLogo.tsx` (official RSU emblem).
- **API Client (`src/lib/api.ts`)**: Cookie-only (`credentials: 'include'`), automatic `X-CSRF-Token` injection on mutating requests, zero `localStorage`/`sessionStorage` secrets, global `401` session expiry redirect.
- **16 Approved Reference Screens (Preserved)**:
  - `AdminDashboardView.tsx` & `DevicesView` (`SystemAdminViews.tsx`) render explicit authentic empty states when no kiosks/records exist in production.
  - `SettingsView` (`SystemAdminViews.tsx` — Backup & Recovery tab) exposes live SQLite WAL/schema status, **Create Online SQLite Backup** (`VACUUM INTO`), **Run Restore Drill (Dry Run)**, **Checkpoint WAL**, JSON export, and recent backup history table (Administrator `backup:export` only).

---

## 4. Backend Security, RBAC & Durability Architecture (`server.ts`, `server/`)

### 4.1 Auth, Sessions, CSRF & RBAC (`server/auth.ts`, `server/rbac.ts`, `server/security.ts`)
- Unconditional `SESSION_SECRET` (>=32 chars, non-placeholder) in production; zero-downtime rotation via `SESSION_SECRET_PREVIOUS`.
- Fresh empty `users` table fails securely with `InitialAdminCredentialsMissingError` unless `ADMIN_INITIAL_*` credentials are provided; forces initial password rotation (`must_change_password = 1`).
- Server-backed `user_sessions` (`HttpOnly` cookie) + double-submit CSRF + `Origin`/`Referer` allowlist + session fixation prevention + logout & password-change revocation + sliding-window rate limiting + 5-strike brute-force lockout (`429` + `Retry-After`).
- 6 canonical roles (`Administrator`, `HR Officer`, `Payroll Officer`, `Department Head`, `Employee`, `Kiosk Device`) and 35 fine-grained permissions enforced server-side across all API endpoints.

### 4.2 Database Durability, Migrations & Integrity (`server/db.ts`)
- Enforces `PRAGMA foreign_keys = ON`, `PRAGMA journal_mode = WAL`, `PRAGMA synchronous = FULL`, `PRAGMA busy_timeout`, `PRAGMA wal_autocheckpoint`, `PRAGMA temp_store = MEMORY`, and explicit filesystem directory/file read-write permission checks on open.
- **Idempotent Transactional Migrations (`schema_migrations`):**
  - `001` (`baseline_schema`): 15 core domain tables.
  - `002` (`build05_security_sessions_rbac`): RBAC tables (`roles`, `permissions`, `role_permissions`), `user_sessions`, and `users` security columns.
  - `003` (`build06_event_identity_and_integrity_constraints`):
    - `attendance_events` with `event_uid UNIQUE` and `UNIQUE(employee_id, attendance_date, punch_type, punch_time)` for idempotent atomic kiosk punch processing.
    - `backup_history` tracking online snapshots, checksums, encryption state, and restore drills.
    - Unique & query indexes (`idx_holidays_date_name`, `idx_payroll_items_run_emp`, `idx_devices_api_token`, attendance/event/backup lookup indexes).
    - 12 database-level `BEFORE INSERT` / `BEFORE UPDATE` constraint triggers validating non-negative salary/allowance, employee/attendance/device status enums, and leave/payroll date ordering.
- **Database-Unavailable Error Boundary:** `GET /api/health` and Express error middleware catch `DatabaseUnavailableError` / SQLite I/O/closed errors and return HTTP `503` `{ code: 'DATABASE_UNAVAILABLE' }`.

### 4.3 Online Backup, Encryption & Restore Engine (`server/backup.ts`)
- Uses SQLite `VACUUM INTO` for consistent online single-file snapshots, followed by `PRAGMA integrity_check`, `PRAGMA foreign_key_check`, SHA-256 `.manifest.json` generation, optional AES-256-GCM (`scrypt` + `SVB1` header + random salt/IV + auth tag) offsite encryption, and retention pruning.
- `restoreSqliteBackup` validates archive checksums/integrity/FKs/row-counts BEFORE touching the target DB, supports safe `--dry-run`, captures a `.pre-restore-*.bak` snapshot via `VACUUM INTO`, removes stale `-wal`/`-shm` sidecars, swaps atomically, and automatically rolls back on post-restore verification failure.
- `runMigrationRollbackDryRun` snapshots -> migrates -> restores -> asserts exact table row-count parity in an isolated temp directory without modifying the live DB.

---

## 5. Cross-Platform Operational Scripts (`scripts/`)

| Script | npm Command | Purpose |
|---|---|---|
| `scripts/start.mjs` | `npm start` | Cross-platform production server (`NODE_ENV=production`) with signal forwarding. |
| `scripts/clean.mjs` | `npm run clean` | Safely removes `dist/` and `server.js`; preserves `data/`. |
| `scripts/check-env.ts` | `npm run check:env` | Fail-secure env & production storage validator with secret redaction (`--strict` requires `ADMIN_INITIAL_*`). |
| `scripts/admin-recover.ts` | `npm run admin:recover` | Non-destructive MIS CLI to rotate/recover an existing account password and revoke prior sessions. |
| `scripts/db-migrate.ts` | `npm run db:migrate` | Runs idempotent migrations (`--dry-run` runs isolated snapshot-migrate-rollback parity drill). |
| `scripts/db-backup.ts` | `npm run db:backup` | Creates consistent online `VACUUM INTO` snapshot + SHA-256 manifest + optional AES-256-GCM archive. |
| `scripts/db-restore.ts` | `npm run db:restore` | Verifies & restores backups (safe dry-run by default; `--apply` creates pre-restore snapshot + rollback protection). |
| `scripts/db-seed-demo.ts` | `npm run db:seed-demo` | Seeds an isolated non-production sandbox DB only (strictly refuses `NODE_ENV=production` & live `./data/`). |
| `scripts/healthcheck.mjs` | `npm run health` | Repeatable `GET /api/health` probe asserting HTTP 200 and SQLite status. |
| `scripts/verify-startup.mjs` | `npm run test:startup` | Isolated production startup + health + SPA + emblem + authentic empty-state + E2E auth/revocation smoke test. |
| `scripts/run-tests.mjs` | `npm test` | Runs Unit (15) + DB Durability (10) + API/Security/RBAC (20) suites and reports unexecuted categories honestly. |

---

## 6. Known Architectural Limitations (BUILD 06)

- **Offsite Transfer Automation:** Encrypted `.sqlite.enc` archives are generated locally; campus cron/Task Scheduler replication to NAS/cloud storage must be provisioned on the host server.
- **Rate Limiter Storage:** In-memory sliding-window limiter resets on process restart (pair with Nginx/Caddy reverse-proxy rate limits in production).
- **HTTPS / HSTS:** TLS termination and `Strict-Transport-Security` header must be provided by a campus reverse proxy (`TRUST_PROXY=true`).
- **Google SSO OAuth & Outbound SMTP:** Visibly disabled until institutional credentials are configured and verified.
- **Physical Kiosk Hardware:** On-device camera acquisition, face recognition, and anti-spoofing liveness remain blocked pending physical Raspberry Pi 3B / Android kiosk testing.
