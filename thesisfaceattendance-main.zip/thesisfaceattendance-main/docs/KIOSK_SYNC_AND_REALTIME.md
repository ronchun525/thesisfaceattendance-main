# KIOSK OFFLINE SYNC, HEARTBEAT TELEMETRY & REAL-TIME SSE ARCHITECTURE (BUILD 10 / Schema 005)

**Institution:** Romblon State University – Cajidiocan Campus (`SAVAGE-RSUCAJ Smart Attendance System`)  
**Core Modules:** `server/kioskOfflineQueue.ts`, `server/realtime.ts`, `server/api.ts`  
**Schema Migration:** `005` (`build10_kiosk_sync_batches_heartbeat_and_evidence_binding`)

---

## 1. Encrypted Kiosk Offline Queue (`server/kioskOfflineQueue.ts`)

- Persists offline kiosk punches in an encrypted **AES-256-GCM** local queue (`SVQ1` authenticated ciphertext format) so raw biometric/punch payloads are never left in plaintext on kiosk storage.
- Survives simulated device reboots and multi-minute network outages, tracking monotonic sequence numbers (`monotonic_seq`), `device_boot_id`, and `event_uid`.
- Flushes chronologically via `POST /api/kiosk/sync` with batch-level deduplication and per-event outcome reporting (`kiosk_sync_batches`).

## 2. Cryptographic Biometric Evidence Envelope (Hook for BUILD 09)

- Supports optional HMAC-SHA256 evidence envelope validation binding `(device_id, device_boot_id, monotonic_seq, event_uid, employee_code, punch_type, captured_at_utc, evidence_hash)`.
- Any tampered envelope is rejected with **HTTP `422` (`BIOMETRIC_EVIDENCE_INVALID`)**.
- **Honest Boundary:** BUILD 10 provides the transport/binding envelope and replay durability; actual biometric sensor capture, liveness detection, and anti-spoofing remain **BLOCKED** pending BUILD 09 and physical kiosk hardware.

## 3. Device Heartbeat Lifecycle & Revocation

- `POST /api/kiosk/heartbeat` updates `devices.last_heartbeat_at_utc`, telemetry metadata (`app_version`, `queue_depth`, `clock_drift_seconds`), and transitions device status deterministically:
  - **Online** -> **Stale** -> **Offline** based on elapsed heartbeat age.
- Revoked devices (`status = 'Revoked'`) are immediately blocked from heartbeat and sync endpoints with **HTTP `403` (`DEVICE_REVOKED`)**.

## 4. Authenticated Real-Time SSE Stream (`GET /api/realtime/stream`)

- Enforces server-backed session authentication (`401` when unauthenticated) and strict RBAC + department/self scoping on emitted `attendance:updated`, `device:updated`, and `notification:created` events.
- Employee accounts receive only their own attendance updates and see read-only "Today Attendance" status.
- Verified end-to-end authenticated SSE delivery latency in automated tests (`tests/sync.test.ts`, 6/6 PASS): ~25–30ms locally.
