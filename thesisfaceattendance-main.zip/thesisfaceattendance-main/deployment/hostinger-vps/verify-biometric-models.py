"""SAVAGE-RSUCAJ: independently verify TFLite files and test interpreter startup.

Usage:
  python verify-biometric-models.py --models-dir models
  python -m pip install ai-edge-litert numpy

Exit 0 only if all three hashes match and real LiteRT interpreter can allocate
and invoke them. Synthetic zero tensors are a runtime SMOKE TEST, not evidence
that actual face recognition, accuracy, PAD, or real-world liveness work.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys

SPECS = {
    'anti_spoofing_pad.tflite': ('5d573d20b795a19d7b2a0f67cc4c1130ce8ec30d5f6aa06b2c788a344a49d4dd', (1, 80, 80, 3), (1, 3)),
    'liveness_detection.tflite': ('4ff758f470b757d9005b418c9978693f09b8f2a5e7b7ee848c160db21208e1b2', (1, 3, 80, 80), (1, 3)),
    'face_recognition.tflite': ('be4bc7cfc53f7bc336d0f28b1ab92535f618c913a422b683210750f6b5354854', (1, 112, 112, 3), (1, 192)),
}


def verify_one(path, spec):
    expected_hash, expected_input, expected_output = spec
    result = {'file': path.name, 'status': None, 'sha256': None, 'runtime': None}
    if not path.is_file():
        result['status'] = 'MISSING'
        return result
    blob = path.read_bytes()
    sha = hashlib.sha256(blob).hexdigest()
    result['sha256'] = sha
    if len(blob) < 8 or blob[4:8] != b'TFL3':
        result['status'] = 'INVALID_TFL3_HEADER'
        return result
    if sha != expected_hash:
        result['status'] = 'HASH_MISMATCH'
        return result
    result['status'] = 'VERIFIED_ON_DISK'
    try:
        import numpy as np
        from ai_edge_litert.interpreter import Interpreter
    except (ImportError, OSError) as e:
        result['runtime'] = f'NOT_INSTALLED_OR_UNAVAILABLE: {type(e).__name__}: {e}'
        return result
    try:
        interpreter = Interpreter(model_path=str(path))
        interpreter.allocate_tensors()
        ins = interpreter.get_input_details()
        outs = interpreter.get_output_details()
        if len(ins) != 1 or len(outs) != 1:
            raise RuntimeError(f'Expected one input and one output, got {len(ins)} and {len(outs)}')
        shape_in = tuple(map(int, ins[0]['shape']))
        shape_out = tuple(map(int, outs[0]['shape']))
        if shape_in != expected_input or shape_out != expected_output:
            raise RuntimeError(f'Tensor shapes mismatch: input {shape_in}, output {shape_out}')
        if ins[0]['dtype'] != np.float32 or outs[0]['dtype'] != np.float32:
            raise RuntimeError(f'Unexpected tensor dtypes: {ins[0]["dtype"]}, {outs[0]["dtype"]}')
        fake_input = np.zeros(shape_in, dtype=np.float32)
        interpreter.set_tensor(ins[0]['index'], fake_input)
        interpreter.invoke()
        out = interpreter.get_tensor(outs[0]['index'])
        if not np.all(np.isfinite(out)):
            raise RuntimeError('Non-finite output from interpreter smoke test')
        result['runtime'] = 'INFERENCE_SMOKE_PASS (synthetic input only)'
    except Exception as exc:
        result['runtime'] = f'INFERENCE_SMOKE_FAIL: {type(exc).__name__}: {exc}'
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--models-dir', default='models')
    args = parser.parse_args()
    base = Path(args.models_dir)
    results = [verify_one(base / name, spec) for name, spec in SPECS.items()]
    print(json.dumps({'models_dir': str(base.resolve()), 'models': results}, indent=2))
    return 0 if all(r['status'] == 'VERIFIED_ON_DISK' and r['runtime'] == 'INFERENCE_SMOKE_PASS (synthetic input only)' for r in results) else 1


if __name__ == '__main__':
    sys.exit(main())
