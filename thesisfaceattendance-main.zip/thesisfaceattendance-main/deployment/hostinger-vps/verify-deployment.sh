#!/usr/bin/env bash
# Read-only deployment smoke checks. Does not attest biometric accuracy.
set -euo pipefail
base="${1:-https://attendance.rsu-cajidiocan.tech}"
base="${base%/}"
for path in / /kiosk /audio/thank-you.mp3 /audio/try-again.mp3 /audio/speaker-test.mp3 /api/health /api/kiosk/web/models/status; do
  printf '%-38s ' "$path"
  curl -sS -o /dev/null --max-time 15 -w '%{http_code} %{content_type}\n' "$base$path" || true
done
echo 'Check all responses. A 200 models/status response DOES NOT mean biometric inference is ready.'
echo "Inspect model readiness: curl -fsS '$base/api/kiosk/web/models/status'"
