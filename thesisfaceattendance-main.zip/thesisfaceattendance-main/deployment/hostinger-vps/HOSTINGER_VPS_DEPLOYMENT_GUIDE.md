# SAVAGE-RSUCAJ Web Kiosk — Hostinger VPS Deployment (source-specific)

**Basis:** inspected `thesisfaceattendance-SPEAKER-FIX-AUDITED.zip` on 2026-11-22. **NOT PRODUCTION READY:** missing exact PAD/recognition models and real server-side TFLite inference, and full E2E hardware tests are still required. This guide deploys the current source without pretending that biometric attendance works.

## 1. Architecture and plan decision

- **Hostinger Single Web Hosting:** keep current `rsu-cajidiocan.tech` site. It cannot run this project's persistent Express API, SQLite backend, SSE and Python inference as a managed app.
- **Hostinger Ubuntu 24.04 VPS:** host the **entire existing React + Express application on one origin** `https://attendance.rsu-cajidiocan.tech`, behind Nginx. This avoids cross-origin issues: source uses relative `/api/*`, same-origin cookies and `/api/events/stream` SSE.
- Browser runs the webcam + speaker on physical kiosk device. VPS does not output physical sound and does not need a webcam.
- Use >=2 vCPU/4 GB RAM only as an initial sizing hypothesis; benchmark real AI frame throughput and concurrency.

## 2. Build prerequisites / Hostinger DNS

1. Create a Hostinger VPS with **Ubuntu 24.04 LTS**. Set up SSH keys, OS updates and VPS firewall. Do NOT SSH to the Single shared hosting account for these Node/Python commands.
2. In Hostinger DNS for `rsu-cajidiocan.tech`, create **A** record: `attendance` -> **actual VPS public IPv4**. Keep existing `@`/`www` records unchanged. If nameservers are at Cloudflare/another provider, edit there instead. Wait for DNS to resolve: `dig +short attendance.rsu-cajidiocan.tech`.
3. SSH: `ssh root@YOUR_VPS_IP` (or your existing sudo-enabled VPS user).
4. Install prerequisites:

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl ca-certificates unzip rsync git nginx build-essential python3 python3-venv python3-pip certbot python3-certbot-nginx ufw
curl -fsSLo /tmp/nodesource-setup.sh https://deb.nodesource.com/setup_22.x
# Review the downloaded vendor script before executing it:
less /tmp/nodesource-setup.sh
sudo bash /tmp/nodesource-setup.sh
sudo apt install -y nodejs
node --version && npm --version && python3 --version
```

The source requires Node `^20.19.0 || >=22.12.0`; Node 22 meets this. Native `better-sqlite3` may need compiler toolchain.

## 3. Secure and persistent application directories

```bash
id savage || sudo useradd --system --user-group --home-dir /opt/savage-rsucaj --shell /usr/sbin/nologin savage
sudo mkdir -p /opt/savage-rsucaj/{app,models} /var/lib/savage-rsucaj/data /var/backups/savage-rsucaj /var/log/savage-rsucaj
sudo chown -R savage:savage /opt/savage-rsucaj /var/lib/savage-rsucaj /var/backups/savage-rsucaj /var/log/savage-rsucaj
sudo chmod 0750 /opt/savage-rsucaj/models /var/lib/savage-rsucaj/data /var/backups/savage-rsucaj
sudo install -d -o root -g savage -m 0750 /etc/savage-rsucaj
```

This package deliberately excludes the uploaded SQLite DB/WAL files and the nested archived admin portal ZIP. A fresh deployment gets a fresh DB. **To migrate actual employee data**, use an approved online SQLite snapshot/backup procedure on the old backend, restore on VPS while stopped, preserve the biometric encryption key, and run migration/restore tests. Never copy a live SQLite WAL database file alone or publish personal records.

## 4. Transfer sanitized source ZIP from Windows

On **Windows PowerShell**, in your download folder:

```powershell
scp .\SAVAGE-RSUCAJ-HOSTINGER-DEPLOY-SOURCE.zip root@YOUR_VPS_IP:/root/
```

Back in **VPS SSH**:

```bash
mkdir -p /tmp/rsucaj-upload
unzip -q /root/SAVAGE-RSUCAJ-HOSTINGER-DEPLOY-SOURCE.zip -d /tmp/rsucaj-upload
sudo rsync -a --exclude=.env /tmp/rsucaj-upload/thesisfaceattendance-main/ /opt/savage-rsucaj/app/
sudo chown -R savage:savage /opt/savage-rsucaj/app
```

The ZIP contains `deployment/hostinger-vps/` with the ready-to-edit service, Nginx, model verifier and deployment check files.

## 5. Configure production secrets and database path

```bash
sudo install -o root -g savage -m 0640 /opt/savage-rsucaj/app/deployment/hostinger-vps/production.env.example /etc/savage-rsucaj/production.env
sudo nano /etc/savage-rsucaj/production.env
```

**Replace all** `REPLACE_*` placeholders with genuinely generated values. Generate values on VPS (do not share them in chat or commit to git):

```bash
openssl rand -hex 48   # SESSION_SECRET: paste the 96 hex characters
openssl rand -hex 48   # BACKUP_ENCRYPTION_KEY: paste the 96 hex characters
openssl rand -hex 32   # KIOSK_TEMPLATE_ENCRYPTION_KEY: paste the 64 hex characters
```

Use an institution-owned admin email, username, and strong unique password. Keep the admin bootstrap settings for the very first startup only; rotate the admin password at first login, then remove bootstrap variables (do not delete or rotate session/template keys without a migration plan). Prefer `.env` values with no unquoted spaces; use the exact `key=value` format of the example.

Make app tools load the protected file, without storing secrets twice:

```bash
sudo ln -s /etc/savage-rsucaj/production.env /opt/savage-rsucaj/app/.env
sudo ls -l /opt/savage-rsucaj/app/.env
```

You should see `.env` pointing to `/etc/savage-rsucaj/production.env`. File mode should stay `0640 root:savage`. Since this is a *fresh* database, the initial admin credentials are mandatory for server startup.

## 6. Install dependencies, run tests, compile React, initialize SQLite

```bash
cd /opt/savage-rsucaj/app
sudo -u savage -H npm install --include=dev
sudo -u savage -H npm run check:env -- --strict
sudo -u savage -H npm run lint
sudo -u savage -H npm run test:speaker
sudo -u savage -H npm run build
sudo -u savage -H npm run test:startup
sudo -u savage -H npm run db:migrate
```

This exact source package **does not contain a package-lock.json**. `npm install` creates one; retain and review it for repeatable subsequent releases. Since `tsx` is a devDependency required by `scripts/start.mjs`, **do not** use `npm install --omit=dev` as-is. For full tests, run `sudo -u savage -H npm test` and `sudo -u savage -H npm run release:gate`; **stop release when they fail**. Model readiness will fail until the biometric backend is truly implemented.

## 7. systemd service and Nginx / HTTPS

```bash
sudo cp /opt/savage-rsucaj/app/deployment/hostinger-vps/savage-rsucaj.service /etc/systemd/system/savage-rsucaj.service
sudo systemctl daemon-reload
sudo systemctl enable --now savage-rsucaj
sudo systemctl status savage-rsucaj --no-pager
sudo journalctl -u savage-rsucaj -n 100 --no-pager
curl -fsS http://127.0.0.1:3000/api/health

sudo cp /opt/savage-rsucaj/app/deployment/hostinger-vps/attendance.nginx.conf /etc/nginx/sites-available/savage-rsucaj
sudo ln -s /etc/nginx/sites-available/savage-rsucaj /etc/nginx/sites-enabled/savage-rsucaj
sudo nginx -t
sudo systemctl reload nginx

# Make sure your SSH port is allowed BEFORE enabling firewall. Replace OpenSSH if custom SSH port.
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw deny 3000/tcp
sudo ufw enable

# DNS A record MUST already resolve to this VPS before Certbot.
sudo certbot --nginx -d attendance.rsu-cajidiocan.tech
sudo certbot renew --dry-run
```

Certbot updates the Nginx site to HTTPS. Do **not** expose port 3000 through the firewall (leave it as internal reverse-proxy traffic). The Express server currently listens on `0.0.0.0:3000`; confirm your VPS provider firewall blocks public port 3000, or change server binding to localhost and retest.

## 8. Install/verifying real biometric model binaries

The source expects exactly:

| Filename | SHA-256 |
|---|---|
| `anti_spoofing_pad.tflite` | `5d573d20b795a19d7b2a0f67cc4c1130ce8ec30d5f6aa06b2c788a344a49d4dd` |
| `liveness_detection.tflite` | `4ff758f470b757d9005b418c9978693f09b8f2a5e7b7ee848c160db21208e1b2` |
| `face_recognition.tflite` | `be4bc7cfc53f7bc336d0f28b1ab92535f618c913a422b683210750f6b5354854` |

Download the ONE already-found exact-matching liveness model and verify its hash *before* installation:

```bash
curl -fL https://huggingface.co/litert-community/Silent-Face-Anti-Spoofing-LiteRT/resolve/main/silentface.tflite -o /tmp/liveness_detection.tflite
echo '4ff758f470b757d9005b418c9978693f09b8f2a5e7b7ee848c160db21208e1b2  /tmp/liveness_detection.tflite' | sha256sum -c -
sudo install -o savage -g savage -m 0640 /tmp/liveness_detection.tflite /opt/savage-rsucaj/models/liveness_detection.tflite
rm -f /tmp/liveness_detection.tflite
```

Do **not** rename other models to satisfy the checks. Once you legitimately obtain the exact other two files, upload them securely and validate their hashes separately using `sha256sum`. Ensure license rights and review source's model-download endpoint (`/api/kiosk/web/models/:filename`) before distributing proprietary artifacts.

Install **verification-only** Python LiteRT runtime:

```bash
sudo -u savage -H python3 -m venv /opt/savage-rsucaj/venv
sudo -u savage -H /opt/savage-rsucaj/venv/bin/pip install --upgrade pip
sudo -u savage -H /opt/savage-rsucaj/venv/bin/pip install ai-edge-litert numpy
sudo -u savage -H /opt/savage-rsucaj/venv/bin/python /opt/savage-rsucaj/app/deployment/hostinger-vps/verify-biometric-models.py --models-dir /opt/savage-rsucaj/models
curl -fsS https://attendance.rsu-cajidiocan.tech/api/kiosk/web/models/status
```

**CRITICAL BLOCKER:** This does **not** make the Node API execute these models! `server/webKioskBiometrics.ts` literally sets `serverInferenceAvailable = false`, and `src/components/WebKioskPortal.tsx` still lacks a real verified frame-to-model request/evidence pipeline. A real server-side inference service, authenticated service-to-service integration, safe preprocessing, biometric matching, liveness/PAD, calibration, and real-device tests still need implementation. Never merely flip the boolean or fake success. Real employee enrollment/attendance will remain blocked until this work is completed.

## 9. Validate HTTPS kiosk, speaker, browser and hardware

```bash
bash /opt/savage-rsucaj/app/deployment/hostinger-vps/verify-deployment.sh
curl -I https://attendance.rsu-cajidiocan.tech/audio/thank-you.mp3
curl -fsS https://attendance.rsu-cajidiocan.tech/api/health
curl -fsS https://attendance.rsu-cajidiocan.tech/api/kiosk/web/models/status
```

On Raspberry Pi OS desktop:

```bash
aplay -l
speaker-test -c 2 -t wav
# Use the kiosk's EXISTING launcher/autostart and replace KIOSK_URL appropriately:
KIOSK_URL=https://attendance.rsu-cajidiocan.tech/kiosk bash /path/to/start-kiosk-pi.sh
```

The **physical device** runs Chromium fullscreen and plays speaker audio; the Hostinger server only serves MP3 assets. In kiosk admin PIN settings, enable Voice Prompt and click Test Speaker. Let camera permission through for the HTTPS URL, then test real approved employee enrollment and attendance only after all biometric gates and release checks pass.

## 10. Error analysis, testing and final status

| Failure | Most likely root cause / action |
|---|---|
| VPS shows `502 Bad Gateway` | service stopped / invalid environment / SQLite directory permission / missing native `better-sqlite3`; use `journalctl -u savage-rsucaj -n 100` |
| `npm` build fails | inspect Node version `>=22.12` and `npm install`, keep dev dependencies including `tsx` |
| `sqlite3` cannot open DB | verify `DATABASE_PATH`, non-root user ownership and persistent local disk |
| HTTP works but Chrome camera fails | HTTPS/camera permission/device/browser profile |
| Speaker silent | test OS sink (`speaker-test`) then `.../audio/speaker-test.mp3` then kiosk Test Speaker |
| `models status` reports missing | missing files / checksum mismatch |
| `server_inference_available: false` | **expected blocker in current code**; Python package alone is not runtime integration |
| Unauthorized / kiosk activation fails | check activation code, cookies, HTTPS, role permissions; do not bypass auth |
| `/api` returns 404 on Single shared static site | frontend needs same-origin Express or tested reverse proxy, cannot just upload `dist/` |

**Actual checks performed on the deployment kit locally:** `bash -n` for verification script; `python -m py_compile` for model verifier; ZIP integrity and source-content packaging. **NOT executed:** real VPS provisioning, npm dependency installation, full frontend build, live DNS/TLS test, SQLite production migration, model inference and hardware speaker/camera. Deployment is not certified production-ready.
