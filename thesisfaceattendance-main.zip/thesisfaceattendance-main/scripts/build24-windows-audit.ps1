# BUILD 24: source-file audit, backend SSE tests, web typecheck/build and optional Android tests.
# Does not modify a live website or create attendance records.
param([switch]$RunAndroidTests, [switch]$ProbeLive)
$ErrorActionPreference = 'Stop'
$web = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$root = (Resolve-Path (Join-Path $web '..')).Path
$android = Join-Path $root 'finalngfacerecogantion-main'
$logs = Join-Path $root 'build24_artifacts'
New-Item -ItemType Directory -Path $logs -Force | Out-Null

function Invoke-Checked([string]$Name, [string]$Folder, [scriptblock]$Action) {
  Write-Host "=== BUILD 24 $Name ==="
  Push-Location $Folder
  try {
    $global:LASTEXITCODE = 0
    & $Action 2>&1 | Tee-Object -FilePath (Join-Path $logs "$Name.log")
    if ($LASTEXITCODE -ne 0) { throw "FAILED: $Name ($LASTEXITCODE), see $logs" }
  } finally { Pop-Location }
}

Invoke-Checked 'file-inventory' $web { python .\tools\build24_audit_all.py }
Invoke-Checked 'web-ts-syntax' $web { node .\scripts\build24-syntax-audit.mjs }
Invoke-Checked 'backend-sse-api-tests' $web { npm run test:build24 }
Invoke-Checked 'android-source-integrity' $android { python .\tools\verify_build23_source.py }

# Run complete TypeScript typecheck / Vite build. Node modules must be installed first.
# The ZIP includes bun.lock, not package-lock.json; on Windows run npm install
# OR bun install --frozen-lockfile before invoking this audit.
Invoke-Checked 'web-typecheck' $web { npm run lint }
Invoke-Checked 'web-build' $web { npm run build }

if ($RunAndroidTests) {
  # Requires Android Studio SDK, configured Gradle wrapper, and a connected test device.
  Invoke-Checked 'android-build-and-device' $android {
    powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\build22-android-acceptance.ps1 -RunDeviceTests -BootstrapWrapper
  }
}
if ($ProbeLive) {
  Invoke-Checked 'live-website-readonly-probe' $web {
    node .\scripts\build23-probe-live-api.mjs --base-url https://rsu-cajidiocan.tech
  }
}
Write-Host 'BUILD 24 commands completed. Production is NOT approved until live device and hosting tests pass.'
