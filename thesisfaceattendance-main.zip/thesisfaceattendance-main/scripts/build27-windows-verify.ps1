[CmdletBinding()]
param([switch]$InstallDependencies, [switch]$BuildAndroidApk, [switch]$RunAndroidDeviceTests)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$project = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$android = (Resolve-Path (Join-Path $project '..\finalngfacerecogantion-main')).Path
$logs = Join-Path $project 'build27_artifacts'
New-Item -ItemType Directory -Force -Path $logs | Out-Null
function Run-Checked([string]$Name, [scriptblock]$Block) {
  Write-Host "`n== $Name ==" -ForegroundColor Cyan
  & $Block
  if ($LASTEXITCODE -ne 0) { throw "$Name FAILED ($LASTEXITCODE). Fix this before proceeding." }
}
Push-Location $project
try {
  Run-Checked 'Source/model/UI integrity' { python .\tools\verify_build27_source.py }
  Run-Checked 'Realtime and employee security regression tests' {
    node --experimental-strip-types --test .\tests\android-bridge-contract.test.mjs .\tests\build19-hardening.test.mjs .\tests\build23-live-api-probe.test.mjs .\tests\build24-realtime.test.mjs .\tests\build26-employee-accounts.test.mjs .\tests\build27-integration.test.mjs
  }
  Run-Checked 'Syntax and relative imports' { node .\scripts\build24-syntax-audit.mjs }
  if ($InstallDependencies) { Run-Checked 'npm dependencies' { npm install } }
  if (-not (Test-Path .\node_modules)) {
    Write-Warning 'FULL TYPECHECK AND FRONTEND BUILD BLOCKED: Run npm install and rerun this verifier.'
  } else {
    Run-Checked 'Full TypeScript typecheck' { npm run lint }
    Run-Checked 'Web production build' { npm run build }
  }
  Push-Location $android
  try {
    Run-Checked 'Previous Android source regressions' { python .\tools\verify_build25_source.py }
    if (Get-Command kotlinc -ErrorAction SilentlyContinue) {
      $jar = Join-Path $logs 'verified-device-cache-contract.jar'
      Run-Checked 'Kotlin cache smoke compile' {
        kotlinc '.\app\src\main\java\com\example\kiosk\data\VerifiedDeviceCache.kt' '.\tools\jvm_smoke\Build27VerifiedDeviceCacheSmoke.kt' -include-runtime -d $jar
      }
      Run-Checked 'Kotlin cache smoke execution' { java -jar $jar }
    } else { Write-Warning 'Kotlin command-line compiler not available; standalone cache smoke tests NOT RUN here.' }
    if ($RunAndroidDeviceTests) { $BuildAndroidApk = $true }
    if ($BuildAndroidApk) {
      & powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\build22-android-acceptance.ps1 -BootstrapWrapper -RunDeviceTests:$RunAndroidDeviceTests
      if ($LASTEXITCODE -ne 0) { throw "Android Gradle/device acceptance FAILED ($LASTEXITCODE)." }
    } else { Write-Warning 'APK BUILD AND REAL CAMERA/DEVICE TESTS NOT RUN. Use -BuildAndroidApk -RunAndroidDeviceTests.' }
  } finally { Pop-Location }
  Write-Host 'BUILD27 available checks finished; deployment/biometric release still require human-verified acceptance.' -ForegroundColor Yellow
} finally { Pop-Location }
