import fs from 'node:fs';
import path from 'node:path';

// Only remove build artifacts. NEVER delete ./data/ or SQLite database files.
const targets = ['dist', 'server.js'];
const rootDir = process.cwd();

for (const relTarget of targets) {
  const fullPath = path.resolve(rootDir, relTarget);
  if (fs.existsSync(fullPath)) {
    fs.rmSync(fullPath, { recursive: true, force: true });
    console.log(`Cleaned: ${relTarget}`);
  } else {
    console.log(`Skipped (not present): ${relTarget}`);
  }
}

console.log('Clean complete. Database files under data/ were preserved.');
