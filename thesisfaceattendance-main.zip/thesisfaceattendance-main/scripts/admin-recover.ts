import 'dotenv/config';
import Database from 'better-sqlite3';
import path from 'node:path';
import fs from 'node:fs';
import { initDatabase, recoverAdminAccount } from '../server/db.ts';

function parseArg(prefix: string): string | undefined {
  const match = process.argv.find((a) => a.startsWith(`${prefix}=`));
  return match ? match.slice(prefix.length + 1) : undefined;
}

const username = parseArg('--username') || process.env.RECOVERY_USERNAME || 'admin';
const newPassword = process.env.RECOVERY_NEW_PASSWORD?.trim() || '';
const forceRotate = process.argv.includes('--force-rotate');
const dbPath =
  parseArg('--db') || process.env.DATABASE_PATH?.trim() || path.resolve(process.cwd(), 'data', 'savage_rsucaj.db');

if (!fs.existsSync(dbPath)) {
  console.error(`Recovery aborted: database file not found at ${dbPath}`);
  process.exit(1);
}

if (!newPassword) {
  console.error(
    'Recovery aborted: set RECOVERY_NEW_PASSWORD in your shell environment (min 10 chars with upper, lower, digit, and symbol).'
  );
  console.error(
    'Example (Linux):      RECOVERY_NEW_PASSWORD="Strong!Password2026" npm run admin:recover -- --username=admin --force-rotate'
  );
  console.error(
    'Example (PowerShell): $env:RECOVERY_NEW_PASSWORD="Strong!Password2026"; npm run admin:recover -- --username=admin --force-rotate'
  );
  process.exit(1);
}

// Run idempotent migrations first without touching existing data
const migratedDb = initDatabase(dbPath, { seedDemoData: false });
try {
  const result = recoverAdminAccount(migratedDb, username, newPassword, {
    requireChangeOnNextLogin: forceRotate,
  });
  console.log(
    `RECOVERY PASS: Updated credentials for "${result.username}" (id=${result.userId}), revoked ${result.revokedSessions} active session(s), must_change_password=${forceRotate ? 1 : 0}.`
  );
  console.log('All existing employee, attendance, leave, payroll, and audit records were preserved.');
} finally {
  migratedDb.close();
}

// Sanity check WAL integrity
const verifyDb = new Database(dbPath, { readonly: true });
try {
  const check = verifyDb.prepare('PRAGMA integrity_check').get() as { integrity_check: string };
  console.log(`SQLite integrity_check: ${check.integrity_check}`);
} finally {
  verifyDb.close();
}
