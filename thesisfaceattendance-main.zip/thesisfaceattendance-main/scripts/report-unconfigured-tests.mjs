const mode = process.argv[2] || 'browser';

if (mode === 'browser') {
  console.log('STATUS: NOT TESTED — Browser E2E Suite');
  console.log('Reason: Playwright/Cypress is not installed in BUILD 04.');
  console.log('Scope Required: 16-screen visual/interaction checks, responsive layout, cookie/auth flows.');
  console.log('Next Step: Add Playwright E2E coverage in BUILD 05+ after base build/install stability is verified.');
  process.exit(0);
}

if (mode === 'hardware') {
  console.log('STATUS: BLOCKED — Physical Biometric Kiosk Hardware Tests');
  console.log('Reason: Physical Raspberry Pi 3B / Android kiosk hardware and camera/liveness modules are not attached.');
  console.log('Verified Layer Only: HTTP token-authenticated API endpoints (/api/kiosk/heartbeat, /api/kiosk/punch) via `npm run test:api`.');
  console.log('Next Step: Execute on-campus hardware validation with physical kiosk devices before production release.');
  process.exit(0);
}

console.error(`Unknown test category: ${mode}. Use "browser" or "hardware".`);
process.exit(1);
