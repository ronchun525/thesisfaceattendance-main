import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { validateEnv } from '../server/env.ts';

type GateStatus = 'PASS' | 'FAIL' | 'BLOCKED';

interface ReleaseGateItem {
  id: string;
  category: string;
  gate: string;
  status: GateStatus;
  evidence: string;
  owner: string;
  remediation: string;
}

const rootDir = process.cwd();
const pkg = JSON.parse(fs.readFileSync(path.join(rootDir, 'package.json'), 'utf8')) as {
  name: string;
  version: string;
};

const gates: ReleaseGateItem[] = [];

// 1. Build artifact check
const distIndex = path.join(rootDir, 'dist', 'index.html');
gates.push({
  id: 'RG-01',
  category: 'Build Integrity',
  gate: 'Production SPA bundle (dist/index.html) compiled cleanly',
  status: fs.existsSync(distIndex) ? 'PASS' : 'FAIL',
  evidence: fs.existsSync(distIndex) ? 'dist/index.html present' : 'dist/index.html missing — run `npm run build`',
  owner: 'Release Engineer',
  remediation: 'Run `npm ci && npm run lint && npm run build`.',
});

// 2. Staging evidence artifact
const stagingEvidencePath = path.join(rootDir, 'test-results', 'staging-evidence.json');
if (fs.existsSync(stagingEvidencePath)) {
  const stg = JSON.parse(fs.readFileSync(stagingEvidencePath, 'utf8')) as {
    passed?: number;
    failed?: number;
    loadBenchmark?: { readP95Ms?: number; punchP95Ms?: number; http5xxCount?: number };
    backupRestoreBenchmark?: { auditChainValid?: boolean; integrityCheck?: string; fkViolations?: number };
  };
  const ok = (stg.failed ?? 1) === 0 && (stg.passed ?? 0) >= 7 && stg.backupRestoreBenchmark?.auditChainValid === true;
  gates.push({
    id: 'RG-02',
    category: 'Security, Staging & DR',
    gate: 'Automated staging, security, network impairment, load & backup-restore suite',
    status: ok ? 'PASS' : 'FAIL',
    evidence: `${stg.passed ?? 0} passed, ${stg.failed ?? 0} failed; readP95=${stg.loadBenchmark?.readP95Ms ?? '?'}ms; punchP95=${stg.loadBenchmark?.punchP95Ms ?? '?'}ms; auditChainValid=${String(stg.backupRestoreBenchmark?.auditChainValid)}`,
    owner: 'Security & QA Lead',
    remediation: 'Run `npm run test:staging` and resolve any failures.',
  });
} else {
  gates.push({
    id: 'RG-02',
    category: 'Security, Staging & DR',
    gate: 'Automated staging, security, network impairment, load & backup-restore suite',
    status: 'BLOCKED',
    evidence: 'test-results/staging-evidence.json not found',
    owner: 'Security & QA Lead',
    remediation: 'Run `npm run test:staging`.',
  });
}

// 3. Browser E2E evidence artifact
const e2eSummaryPath = path.join(rootDir, 'test-results', 'e2e-screenshots', 'e2e-audit-summary.json');
if (fs.existsSync(e2eSummaryPath)) {
  const e2e = JSON.parse(fs.readFileSync(e2eSummaryPath, 'utf8')) as {
    passed?: number;
    failed?: number;
    pageErrors?: string[];
    blockingConsoleErrors?: string[];
    screenshotsCaptured?: number;
  };
  const ok =
    (e2e.failed ?? 1) === 0 &&
    (e2e.passed ?? 0) >= 16 &&
    (e2e.pageErrors?.length ?? 0) === 0 &&
    (e2e.blockingConsoleErrors?.length ?? 0) === 0;
  gates.push({
    id: 'RG-03',
    category: 'Browser E2E & Accessibility',
    gate: 'Playwright Chromium 16-screen & 4-viewport E2E + WCAG/overflow audit',
    status: ok ? 'PASS' : 'FAIL',
    evidence: `${e2e.passed ?? 0} passed, ${e2e.failed ?? 0} failed; pageErrors=${e2e.pageErrors?.length ?? 0}; screenshots=${e2e.screenshotsCaptured ?? 0}`,
    owner: 'Frontend & QA Lead',
    remediation: 'Run `npm run build && npm run test:browser` and fix UI/WCAG regressions.',
  });
} else {
  gates.push({
    id: 'RG-03',
    category: 'Browser E2E & Accessibility',
    gate: 'Playwright Chromium 16-screen & 4-viewport E2E + WCAG/overflow audit',
    status: 'BLOCKED',
    evidence: 'test-results/e2e-screenshots/e2e-audit-summary.json not found',
    owner: 'Frontend & QA Lead',
    remediation: 'Run `npm run build && npm run test:browser`.',
  });
}

// 4. Live SQLite DB inspection (read-only) for Schema 009, CS Form 48 verification & Finance-approved payroll policy
const dbPath = path.resolve(process.env.DATABASE_PATH?.trim() || path.join(rootDir, 'data', 'savage_rsucaj.db'));
let csForm48Verified = false;
let approvedPayrollPolicies = 0;
let schemaVersion = 'unknown';
let dbIntegrity = 'unknown';

if (fs.existsSync(dbPath)) {
  const db = new Database(dbPath, { readonly: true });
  try {
    dbIntegrity = String(db.pragma('integrity_check', { simple: true }));
    const mig = db.prepare('SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1').get() as
      | { version: string }
      | undefined;
    schemaVersion = mig?.version ?? '000';
    const csRow = db
      .prepare(`SELECT value FROM settings WHERE key = 'cs_form_48_reference_verified'`)
      .get() as { value: string } | undefined;
    csForm48Verified = csRow?.value === 'true';
    const polCount = db
      .prepare(`SELECT COUNT(*) as c FROM payroll_policies WHERE approval_status = 'APPROVED_BY_FINANCE'`)
      .get() as { c: number };
    approvedPayrollPolicies = polCount.c;
  } finally {
    db.close();
  }
}

gates.push({
  id: 'RG-04',
  category: 'Database Integrity',
  gate: 'SQLite schema at 009 and PRAGMA integrity_check = ok',
  status: schemaVersion === '009' && dbIntegrity === 'ok' ? 'PASS' : 'FAIL',
  evidence: `schemaVersion=${schemaVersion}, integrity=${dbIntegrity} (read-only check on ${path.basename(dbPath)})`,
  owner: 'Database Engineer',
  remediation: 'Backup database and run `npm run db:migrate`.',
});

// 5. Production environment readiness (secrets, persistent path, HTTPS proxy)
const prodEnv = validateEnv(process.env, { strict: true });
const prodEnvReady = prodEnv.valid && prodEnv.config.nodeEnv === 'production' && prodEnv.config.appMode === 'production';
gates.push({
  id: 'RG-05',
  category: 'Production Host & Secrets',
  gate: 'Verified production host .env (NODE_ENV=production, persistent DATABASE_PATH, SESSION_SECRET, BACKUP_ENCRYPTION_KEY, TLS/HTTPS proxy)',
  status: prodEnvReady ? 'PASS' : 'BLOCKED',
  evidence: prodEnvReady
    ? 'Strict production env validated'
    : `Not configured on live production host (${prodEnv.errors.slice(0, 2).join('; ') || 'NODE_ENV!=production'})`,
  owner: 'DevOps / RSU MIS',
  remediation: 'Provision production VPS .env from approved secret store and validate with `NODE_ENV=production npm run check:env -- --strict`.',
});

// 6. Official CS Form 48 layout confirmation
gates.push({
  id: 'RG-06',
  category: 'Institutional Policy (HR)',
  gate: 'Official RSU Cajidiocan Civil Service Form 48 layout verified (`cs_form_48_reference_verified=true`)',
  status: csForm48Verified ? 'PASS' : 'BLOCKED',
  evidence: `cs_form_48_reference_verified=${String(csForm48Verified)}`,
  owner: 'RSU Cajidiocan HRMO',
  remediation: 'Obtain written RSU HRMO sign-off against official CS Form 48 template before enabling official label.',
});

// 7. Finance payroll policy & golden output sign-off
gates.push({
  id: 'RG-07',
  category: 'Institutional Policy (Finance)',
  gate: 'RSU Cajidiocan Finance written payroll policy & golden scenario output sign-off',
  status: approvedPayrollPolicies > 0 ? 'PASS' : 'BLOCKED',
  evidence: `Finance-approved institutional policies in live DB: ${approvedPayrollPolicies}`,
  owner: 'RSU Cajidiocan Finance Office',
  remediation: 'Import official GSIS/PhilHealth/Pag-IBIG/BIR tables, verify golden outputs, and record Finance approval reference.',
});

// 8. Real biometric verification & anti-spoofing (BUILD 09)
gates.push({
  id: 'RG-08',
  category: 'Biometric Trust (BUILD 09)',
  gate: 'Real neural face recognition + anti-spoof liveness verified end-to-end',
  status: 'BLOCKED',
  evidence: 'BUILD 09 real biometric verification & anti-spoofing not yet integrated; envelope liveness_verified/match_verified remain false by design.',
  owner: 'Biometrics Integration Lead',
  remediation: 'Complete BUILD 09 biometric model & anti-spoof liveness verification and attach measured FAR/FRR/PAD evidence.',
});

// 9. Physical kiosk & external app staging acceptance
gates.push({
  id: 'RG-09',
  category: 'Physical Hardware & External Apps',
  gate: 'Staging acceptance from physical Raspberry Pi kiosk, Android kiosk, Android employee app & Windows browser',
  status: 'BLOCKED',
  evidence: 'Separate Raspberry Pi kiosk, Android kiosk APK, Android employee APK, and Windows browser test devices were not supplied.',
  owner: 'Hardware / Mobile & Campus QA Leads',
  remediation: 'Connect real Raspberry Pi, Android kiosk, Android employee app, and Windows client to HTTPS staging host and complete docs/STAGING_ACCEPTANCE_MATRIX.md.',
});

// 10. External Auth/SMTP & Offsite Backup Replication + Owner Sign-Off
gates.push({
  id: 'RG-10',
  category: 'Operations & Go-Live Governance',
  gate: 'Offsite encrypted backup replication, verified DNS/TLS (e.g., attendance.rsu-cajidiocan.tech), RPO/RTO sign-off, on-call roster & Project Owner formal Go-Live approval',
  status: 'BLOCKED',
  evidence: 'No live production server/DNS/offsite NAS or signed Project Owner Go-Live authorization attached.',
  owner: 'Project Owner & RSU Cajidiocan MIS',
  remediation: 'Complete DEPLOYMENT.md maintenance-window rehearsal, confirm DNS/TLS ownership, sign RPO/RTO & on-call roster, and record formal Go-Live sign-off.',
});

const passCount = gates.filter((g) => g.status === 'PASS').length;
const failCount = gates.filter((g) => g.status === 'FAIL').length;
const blockedCount = gates.filter((g) => g.status === 'BLOCKED').length;
const decision = failCount === 0 && blockedCount === 0 ? 'GO' : 'NO-GO';

console.log(`\n========================================================================`);
console.log(`SAVAGE-RSUCAJ RELEASE GATE EVALUATION — ${pkg.name} v${pkg.version} (BUILD 17)`);
console.log(`========================================================================`);
for (const g of gates) {
  console.log(`[${g.status.padEnd(7)}] ${g.id} (${g.category}): ${g.gate}`);
  console.log(`          Evidence:    ${g.evidence}`);
  if (g.status !== 'PASS') {
    console.log(`          Owner:       ${g.owner}`);
    console.log(`          Remediation: ${g.remediation}`);
  }
}
console.log(`------------------------------------------------------------------------`);
console.log(`SUMMARY:  PASS=${passCount} | FAIL=${failCount} | BLOCKED=${blockedCount}`);
console.log(`DECISION: ${decision} (${decision === 'NO-GO' ? 'PRODUCTION DEPLOYMENT BLOCKED' : 'APPROVED FOR PRODUCTION'})`);
console.log(`========================================================================\n`);

const outPath = path.join(rootDir, 'test-results', 'release-gate-report.json');
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(
  outPath,
  JSON.stringify(
    {
      project: pkg.name,
      version: pkg.version,
      build: 'BUILD 17',
      evaluatedAtUtc: new Date().toISOString(),
      decision,
      summary: { pass: passCount, fail: failCount, blocked: blockedCount },
      gates,
    },
    null,
    2
  )
);

if (decision !== 'GO') {
  process.exit(2);
}
