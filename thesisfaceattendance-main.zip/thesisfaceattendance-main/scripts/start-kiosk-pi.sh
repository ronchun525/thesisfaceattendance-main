#!/usr/bin/env bash
# SAVAGE-RSUCAJ Web Kiosk (Raspberry Pi OS desktop / Wayland or X11).
# Run from the logged-in desktop user, NOT sudo/root. This does not install a
# speech engine: packaged MP3s are served directly by the web application.
set -euo pipefail
KIOSK_URL="${KIOSK_URL:-http://127.0.0.1:3000/kiosk}"
case "$KIOSK_URL" in
  http://localhost/*|http://localhost:*/*|http://127.0.0.1/*|http://127.0.0.1:*/*|https://*) ;;
  *) echo 'ERROR: KIOSK_URL must be HTTPS or localhost for getUserMedia camera access.' >&2; exit 2 ;;
esac
if [ -z "${DISPLAY:-}" ] && [ -z "${WAYLAND_DISPLAY:-}" ]; then
  echo 'ERROR: Start this launcher from the Raspberry Pi desktop session (Wayland/X11).' >&2
  exit 2
fi
CHROMIUM_BIN="${CHROMIUM_BIN:-}"
if [ -z "$CHROMIUM_BIN" ]; then
  for bin in chromium chromium-browser google-chrome; do
    if command -v "$bin" >/dev/null 2>&1; then CHROMIUM_BIN="$(command -v "$bin")"; break; fi
  done
fi
if [ -z "$CHROMIUM_BIN" ] || ! command -v "$CHROMIUM_BIN" >/dev/null 2>&1; then
  echo 'ERROR: Chromium is not installed. Install Chromium from Raspberry Pi OS packages.' >&2
  exit 2
fi
# This autoplay override belongs ONLY on a physically controlled attendance kiosk;
# camera permissions are never bypassed, and HTTPS remains mandatory off-host.
exec "$CHROMIUM_BIN" \
  --kiosk \
  --no-first-run \
  --disable-session-crashed-bubble \
  --autoplay-policy=no-user-gesture-required \
  --user-data-dir="${KIOSK_PROFILE_DIR:-$HOME/.config/savage-web-kiosk}" \
  "$KIOSK_URL"
