import 'dotenv/config';
import path from 'node:path';
import { closeDatabaseSafely, initDatabase, seedDemoDataExplicit } from '../server/db.ts';

function getArg(flag: string): string | undefined {
  const idx = process.argv.indexOf(flag);
  if (idx !== -1 && idx + 1 < process.argv.length) {
    return process.argv[idx + 1];
  }
  return undefined;
}

function main(): void {
  const nodeEnv = (process.env.NODE_ENV ?? 'development').trim();
  const appMode = (process.env.APP_MODE ?? 'production').trim().toLowerCase();

  if (nodeEnv === 'production' || appMode !== 'demo') {
    console.error(
      'REFUSED: Explicit demo seeding is strictly prohibited in production mode. Set NODE_ENV=development and APP_MODE=demo against a non-production database path.'
    );
    process.exit(1);
  }

  const dbPath = getArg('--db') || process.env.DATABASE_PATH?.trim();
  if (!dbPath) {
    console.error('REFUSED: Specify an explicit non-production target database via --db <path> or DATABASE_PATH.');
    process.exit(1);
  }

  const resolved = path.resolve(dbPath);
  const liveDefault = path.resolve(process.cwd(), 'data', 'savage_rsucaj.db');
  if (resolved === liveDefault && process.env.CONFIRM_DEMO_SEED !== 'yes') {
    console.error(
      'REFUSED: Will not seed default ./data/savage_rsucaj.db without explicit CONFIRM_DEMO_SEED=yes. Use an isolated demo database path (e.g., --db ./data/demo_sandbox.db).'
    );
    process.exit(1);
  }

  const db = initDatabase(resolved, {
    mode: 'demo',
    seedDemoData: false,
    skipAdminBootstrap: true,
  });

  try {
    const res = seedDemoDataExplicit(db, 'demo');
    console.log(
      res.seeded
        ? `Explicit isolated DEMO dataset seeded into ${resolved} (non-production sandbox).`
        : `Target database ${resolved} already contains department records; skipped seeding to preserve existing data.`
    );
  } finally {
    closeDatabaseSafely(db);
  }
}

try {
  main();
} catch (err) {
  console.error('Demo seeding failed:', err instanceof Error ? err.message : err);
  process.exit(1);
}
