# SAVAGE-RSUCAJ browser-based Kiosk Launcher (Windows 10/11)
# Run from the logged-in Windows desktop. Configure -KioskUrl for remote HTTPS.
param([string]$KioskUrl = 'http://127.0.0.1:3000/kiosk')
if ($KioskUrl -notmatch '^https://|^http://(localhost|127\.0\.0\.1)(:\d+)?/') {
  throw 'Kiosk URL must use HTTPS or local loopback to permit camera access.'
}
$candidates = @(
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe"
)
$browser = $candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
if (-not $browser) { throw 'Microsoft Edge or Google Chrome is not installed.' }
# This policy switch is suitable only for a locked-down physical kiosk terminal.
# First launch still requires granting browser camera permission to the website.
$arguments = @(
  '--kiosk',
  '--no-first-run',
  '--disable-session-crashed-bubble',
  '--autoplay-policy=no-user-gesture-required',
  ('--user-data-dir="' + (Join-Path $env:LOCALAPPDATA 'SAVAGE-RSUCAJ-Web-Kiosk') + '"'),
  ('"' + $KioskUrl + '"')
)
Start-Process -FilePath $browser -ArgumentList $arguments
