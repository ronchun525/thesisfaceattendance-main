param([switch]$InstallDependencies)
$ErrorActionPreference = 'Stop'
Set-Location (Resolve-Path (Join-Path $PSScriptRoot '..'))
New-Item -ItemType Directory -Force -Path 'build26_artifacts' | Out-Null
function Invoke-Checked([string]$Title, [string]$Command) {
    Write-Host "`n== $Title ==" -ForegroundColor Cyan
    $logFile = Join-Path -Path 'build26_artifacts' -ChildPath (($Title -replace '[^a-zA-Z0-9]', '_') + '.log')
    & cmd.exe /d /s /c "$Command" 2>&1 | Tee-Object -FilePath $logFile
    if ($LASTEXITCODE -ne 0) { throw "$Title failed with exit code $LASTEXITCODE. Review build26_artifacts logs." }
}
Invoke-Checked 'Source audit' 'python tools\verify_build26_source.py'
Invoke-Checked 'Security tests' 'node --experimental-strip-types --test tests\build26-employee-accounts.test.mjs tests\build24-realtime.test.mjs'
if ($InstallDependencies) { Invoke-Checked 'Install npm dependencies' 'npm install' }
if (!(Test-Path 'node_modules')) { throw 'Missing node_modules. Run: npm install (or use -InstallDependencies)' }
Invoke-Checked 'TypeScript typecheck' 'npm run lint'
Invoke-Checked 'Frontend production build' 'npm run build'
Write-Host 'Web source verified and built. Live server/Android browser testing is still required.' -ForegroundColor Green
