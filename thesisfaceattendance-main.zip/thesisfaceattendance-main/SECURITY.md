# SAVAGE-RSUCAJ Smart Attendance Admin Portal — Security Policy & Architecture

**Build:** `BUILD 17` (`v1.13.0`, Schema `009`)  
**Release Gate Status:** **NO-GO / PRODUCTION BLOCKED** *(pending BUILD 09 real biometric liveness/anti-spoofing, physical kiosk staging acceptance, and live production host TLS/secrets verification)*

---

## 1. Verified Security Controls (Implemented & Tested)

1. **Authentication & Session Management (`server/auth.ts`, `server/api.ts`)**
   - Passwords hashed with per-user CSPRNG salt + `crypto.scrypt` / PBKDF2-SHA512 verified via `crypto.timingSafeEqual`.
   - Zero hardcoded default credentials; fresh databases require `ADMIN_INITIAL_*` env vars and enforce mandatory first-login password rotation (`must_change_password = 1`).
   - Server-backed revocable sessions (`user_sessions`) issued via HMAC-SHA256 signed `HttpOnly` cookies (zero `localStorage`/`sessionStorage` token storage).
   - Session fixation defense (rotates prior session on login), password-change global session revocation, brute-force account lockout (`429 ACCOUNT_LOCKED`), and sliding-window IP rate limiting (`429 RATE_LIMITED`).
   - Zero-downtime session key rotation supported via `SESSION_SECRET_PREVIOUS`.

2. **Cross-Site Request Forgery (CSRF) & Origin Enforcement (`server/security.ts`)**
   - Double-submit CSRF token (`X-CSRF-Token` header validated against session CSRF token) required on all authenticated state-changing requests (`POST`, `PUT`, `PATCH`, `DELETE`).
   - Strict `Origin` / `Referer` validation against `ALLOWED_ORIGINS` (or same-origin `Host` / `X-Forwarded-Host` when `TRUST_PROXY=true`).

3. **Role-Based Access Control (RBAC) & Maker-Checker Governance (`server/rbac.ts`, `server/payrollEngine.ts`)**
   - 6 enforced server-side roles (`Administrator`, `HR Officer`, `Payroll Officer`, `Department Head`, `Employee`, `Kiosk Device`) across 38 granular permissions.
   - Department Head scope isolation (`checkEmployeeScope`) blocks cross-department employee/DTR access (`403`).
   - Employee self-service (`payroll:read_self`, `/api/reports/my-dtr`) strictly restricted to own employee record and `Released` payslips only.
   - Payroll maker-checker separation prohibits the run creator from finalizing, signing off, or releasing their own run (`403 MAKER_CHECKER_VIOLATION`).

4. **Kiosk Device Authentication & Anti-Tamper Evidence (`server/api.ts`, `server/kioskOfflineQueue.ts`, `server/adminOpsEngine.ts`)**
   - Provisioned kiosk credentials displayed **once** (`one_time_secret: true`) on creation/rotation, stored as SHA-256 `token_hash` + masked display string, and omitted from all read APIs and JSON backup exports.
   - Immediate credential revocation (`403 DEVICE_REVOKED`) and key rotation invalidating prior tokens.
   - Offline queue encrypted at rest with AES-256-GCM (`EncryptedKioskQueue`) and bound via HMAC-SHA256 `BiometricEvidenceEnvelope` (device ID, boot ID, monotonic sequence, `event_uid`, employee code, action, UTC timestamp).
   - Replay protection via `event_uid` uniqueness, ±120s live clock-drift enforcement (`422 CLOCK_DRIFT_EXCEEDED`), and 72-hour offline replay bound (`422 OFFLINE_REPLAY_EXPIRED`).

5. **Tamper-Evident Audit Ledger & Secret Redaction (`server/auditHelpers.ts`, `server/stagingRuntime.ts`)**
   - `audit_logs` protected by SQLite `BEFORE UPDATE` / `BEFORE DELETE` immutability triggers (`IMMUTABLE_AUDIT_VIOLATION`) and SHA-256 hash chaining (`prev_hash` -> `entry_hash`), verifiable via `GET /api/audit-logs/verify`.
   - Automatic secret redaction across audit `before_json`/`after_json` diffs, `GET /api/settings` (`secretStatus`), and structured JSON request logs (`X-Request-Id`).
   - Staging network impairment and log inspection routes (`/api/staging/*`) strictly return `403 STAGING_ONLY_ENDPOINT` in `APP_MODE=production`.

6. **Injection, XSS, Path Traversal & Financial Integrity Defenses**
   - 100% parameterized SQLite prepared statements (`better-sqlite3`).
   - React safe text bindings (no unsafe raw HTML rendering), `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`, `Permissions-Policy`, and `Cache-Control: no-store` on `/api/*`.
   - Spreadsheet formula neutralization (`=`, `+`, `-`, `@`, tab/CR prefixed with `'`) across all CSV exports.
   - Strict `path.resolve` + base-directory prefix confinement on all backup verification and restore archive paths.
   - SQLite immutability triggers preventing modification/deletion of finalized/released payroll runs, `attendance_events`, `correction_audit_log`, `leave_audit_log`, `payroll_audit_log`, and `audit_logs`.

7. **Dependency Security Audit**
   - Executed read-only `bun audit` across 277 resolved packages: **0 known vulnerabilities**.

---

## 2. Explicit Remaining Security & Trust Blockers

| Blocker | Risk | Required Remediation |
|---|---|---|
| **Real Biometric Verification & Anti-Spoofing (BUILD 09)** | Currently kiosk cryptographic envelopes verify transport integrity only (`liveness_verified=false`, `match_verified=false`). Photo/video spoofing is NOT prevented until real ML liveness/recognition is integrated. | Implement BUILD 09 real face recognition + passive/active PAD liveness on authorized kiosk hardware and verify measured FAR/FRR/APCER/BPCER. |
| **Live Production Host TLS, Firewall & Secret Store** | Local verification uses HTTP loopback; production requires TLS 1.2+, HSTS, UFW, and external secret injection. | Provision Linux VPS per `DEPLOYMENT.md` and run `NODE_ENV=production npm run check:env -- --strict`. |
| **External Google SSO OAuth & Outbound SMTP** | Disabled by default (honest UI + HTTP `503`). | Configure institutional credentials or formally approve local-auth + MIS CLI recovery SOP. |
| **Physical Kiosk & Mobile App Security Review** | Separate Raspberry Pi kiosk, Android kiosk, and Android employee repositories/APKs were not supplied. | Audit external device codebases and complete staging acceptance on real devices. |

---

## 3. Responsible Security Incident Reporting

Report suspected vulnerabilities or tamper-verification alerts immediately to the **RSU Cajidiocan MIS Office** and **Institutional Data Privacy Officer (DPO)** — never post credentials, database dumps, or raw tokens in issue trackers or chat logs.
