# Release Notes — SAVAGE-RSUCAJ Smart Attendance Admin Portal

## v1.13.0 — BUILD 17 (2026-11-21)

### Mandatory Go/No-Go Release Decision: **NO-GO (PRODUCTION RELEASE STATUS: BLOCKED)**
All automated software engineering, accessibility, browser E2E, staging security, network impairment, load/concurrency, and encrypted backup/restore tests in this repository pass, **HOWEVER production deployment remains formally BLOCKED (`NO-GO`)** due to open institutional, biometric, hardware, and host gates:
1. Real Biometric Verification & Anti-Spoofing (**BUILD 09**) not yet integrated.
2. Physical hardware & separate external app repos/APKs (Raspberry Pi Kiosk, Android Kiosk, Android Employee App, Windows Desktop Browser) not supplied or staging-verified.
3. RSU Cajidiocan Finance written payroll policy & golden scenario output sign-off pending.
4. Official RSU Cajidiocan Civil Service Form 48 layout confirmation pending (`cs_form_48_reference_verified='false'`).
5. Production Linux VPS host, DNS/TLS verification (`attendance.rsu-cajidiocan.tech`), offsite encrypted backup replication, on-call contacts, and formal Project Owner Go-Live sign-off pending.

---

### Summary of Cumulative Changes (BUILD 15 + BUILD 16 + BUILD 17)

#### BUILD 17 (`v1.13.0`) — Mandatory Go/No-Go Release Gate & Production Operations Pack
- Added automated Go/No-Go release gate evaluator (`scripts/release-gate.ts`, `npm run release:gate`) producing machine-verifiable `test-results/release-gate-report.json` and enforcing non-zero exit (`NO-GO`) whenever any security, DB, institutional, biometric, or hardware gate is blocked.
- Authored complete production operations & governance pack: `DEPLOYMENT.md` (Linux VPS systemd/Nginx/Caddy/UFW/logrotate/backups, Hostinger Single shared hosting alternative, Windows PowerShell SOP, rollback rehearsal), `OPERATIONS_RUNBOOK.md` (measured SLO/RPO/RTO proposals, checklists, incident playbooks, on-call roster), `SECURITY.md`, `RELEASE_NOTES.md`, `docs/STAGING_ACCEPTANCE_MATRIX.md`, and updated `docs/RELEASE_CHECKLIST.md`.
- Aligned application version metadata to `1.13.0` (`BUILD 17`, Schema `009`).

#### BUILD 16 (`v1.12.0`) — Production-Like Staging Runtime, Security Audit, Impairment & Load Verification
- Added `server/stagingRuntime.ts` with `X-Request-Id` correlation headers, structured JSON logging with strict secret redaction, live p50/p95/p99 latency metrics, and a **staging-only** controllable network impairment controller (`GET/PUT /api/staging/impairment`, `GET /api/staging/logs`) strictly blocked with HTTP `403 STAGING_ONLY_ENDPOINT` in `APP_MODE=production`.
- Extended `server/env.ts` and `.env.example` with `APP_MODE=staging`, `LOG_FORMAT`, `STAGING_PUBLIC_URL`, `STAGING_LOG_FILE`, and fail-secure rejection of `STAGING_IMPAIRMENT_ENABLED=true` in production.
- Added server-authoritative `backend_confirmed: true` and `voice_cue` fields (`DUPLICATE_ALREADY_RECORDED`, `TIME_IN_RECORDED`, `TIME_OUT_RECORDED`, `ESCALATED_TO_HR`, `PUNCH_REJECTED`) to `/api/kiosk/punch` so kiosks trigger duplicate voice prompts strictly after backend confirmation.
- Added sanitized staging bootstrapper (`scripts/staging-setup.ts`, `npm run staging:setup`) that refuses to touch `./data/savage_rsucaj.db` or copy production data and marks all staging payroll fixtures `[STAGING TEST-ONLY — FAKE CURRENCY]`.
- **Critical Cross-Module Audit Bug Fixed:** Discovered during end-to-end staging restore verification that `recordGeneralAudit` in `server/correctionsLeavesEngine.ts` bypassed `logAudit()`, inserting legacy rows without SHA-256 `prev_hash`/`entry_hash` and breaking `GET /api/audit-logs/verify` after correction/leave reviews. Replaced with `logAudit()`, restoring 100% hash-chain integrity across all modules.
- Added `tests/staging-security-load.test.ts` (`npm run test:staging`, 7/7 PASS) verifying staging env guardrails, 6-role RBAC, CSRF, auth lockout, replay protection, zero secret leakage, SQLi/XSS defenses, controllable network drop -> encrypted offline queue -> recovery sync -> SSE broadcast, 200 concurrent API reads + 50 concurrent kiosk punches, and encrypted backup + guarded live restore timing.

#### BUILD 15 (`v1.11.0`) — 16-Screen Playwright E2E, Accessibility & Responsive Polish
- Upgraded WCAG 2.1 AA keyboard focus (`:focus-visible`), skip-to-main-content link, modal focus/Escape management, explicit `htmlFor`/`id` form labels, ARIA landmarks/labels, and mobile/tablet responsive wrapping across all 16 reference screens without redesigning any approved screen or adding Admin Biometrics.
- Added full Playwright Chromium 16-screen, 4-viewport (`1366×768`, `1920×1080`, `768×1024`, `390×844`) E2E test suite (`tests/e2e.browser.test.ts`, `npm run test:browser`) against the real compiled SPA, real Express API, and isolated temporary SQLite database.

---

### Compatibility & Upgrade Notes
- **Database Schema:** Preserved cleanly at Schema `009` (no destructive migration required from BUILD 14). Live `./data/savage_rsucaj.db` verified untouched via isolated rollback dry run.
- **Standalone ZIP Archive Notice:** Source files are updated directly in the project workspace; no standalone `.zip` file was generated inside this runtime environment.
