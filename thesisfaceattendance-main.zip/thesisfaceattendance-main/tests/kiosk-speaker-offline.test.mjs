import assert from 'node:assert/strict';
import { test, afterEach } from 'node:test';
import { KioskVoiceController } from '../src/lib/kioskBiometrics.ts';

let previousWindow = globalThis.window;
let previousAudio = globalThis.Audio;
let previousUtterance = globalThis.SpeechSynthesisUtterance;
let previousDateNow = Date.now;
let constructed;
let synthSpoken;
let audioBlocked;

class MockAudio {
  constructor(src) {
    this.src = src;
    this.volume = 1;
    this.preload = 'none';
    this.paused = true;
    this.currentTime = 0;
    constructed.push(this);
  }
  play() {
    if (audioBlocked) return Promise.reject(new Error('NotAllowedError'));
    this.paused = false;
    return Promise.resolve();
  }
  pause() { this.paused = true; }
}

function setup() {
  constructed = [];
  synthSpoken = [];
  audioBlocked = false;
  Date.now = () => 1000000;
  globalThis.Audio = MockAudio;
  globalThis.SpeechSynthesisUtterance = class {
    constructor(text) { this.text = text; }
  };
  globalThis.window = {
    speechSynthesis: {
      cancel() {},
      speak(utterance) { synthSpoken.push(utterance.text); },
    },
  };
}

const settle = () => new Promise((resolve) => setImmediate(resolve));
afterEach(() => {
  globalThis.window = previousWindow;
  globalThis.Audio = previousAudio;
  globalThis.SpeechSynthesisUtterance = previousUtterance;
  Date.now = previousDateNow;
});

test('Disabled attendance voice does not create audio or speak', async () => {
  setup();
  const voice = new KioskVoiceController();
  voice.speakAttendanceResult('success', false);
  await settle();
  assert.equal(constructed.length, 0);
  assert.equal(synthSpoken.length, 0);
});

test('Confirmed attendance and failed attendance use correct offline voice files', async () => {
  setup();
  const voice = new KioskVoiceController();
  voice.speakAttendanceResult('success', true);
  await settle();
  assert.equal(constructed.at(-1).src, '/audio/thank-you.mp3');
  Date.now = () => 1002000;
  voice.speakAttendanceResult('failure', true);
  await settle();
  assert.equal(constructed.at(-1).src, '/audio/try-again.mp3');
  assert.deepEqual(synthSpoken, []);
});

test('Admin speaker diagnostic uses a non-voice tone only', async () => {
  setup();
  const voice = new KioskVoiceController();
  const started = await voice.testSpeaker();
  assert.equal(started, true);
  assert.equal(constructed.at(-1).src, '/audio/speaker-test.mp3');
  assert.ok(constructed.some((a) => a.src === '/audio/prime.mp3'));
  assert.deepEqual(synthSpoken, []);
});

test('Blocked MP3 playback falls back to browser speech engine, without claiming attendance', async () => {
  setup();
  audioBlocked = true;
  const voice = new KioskVoiceController();
  voice.speakAttendanceResult('failure', true);
  await settle();
  assert.deepEqual(synthSpoken, ['Try again.']);
  assert.equal(await voice.testSpeaker(), false);
});

test('Voice controller cancels playback on stop, with cooldown preventing duplicate cues', async () => {
  setup();
  const voice = new KioskVoiceController();
  voice.speakAttendanceResult('success', true);
  await settle();
  voice.speakAttendanceResult('success', true);
  await settle();
  assert.equal(constructed.filter((a) => a.src === '/audio/thank-you.mp3').length, 1);
  const clip = constructed.at(-1);
  voice.stop();
  assert.equal(clip.paused, true);
});
