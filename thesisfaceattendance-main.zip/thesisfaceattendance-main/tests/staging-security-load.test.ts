import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import { initDatabase, closeDatabaseSafely } from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import { validateEnv } from '../server/env.ts';
import { securityHeadersMiddleware } from '../server/security.ts';
import { RealtimeHub } from '../server/realtimeHub.ts';
import {
  createBiometricEvidenceEnvelope,
  EncryptedKioskQueue,
} from '../server/kioskOfflineQueue.ts';
import {
  computePercentile,
  StagingImpairmentController,
  StructuredLogStore,
} from '../server/stagingRuntime.ts';
import { getManilaDateString, parseManilaWallClockToUtcMs, addDaysIso } from '../server/attendanceEngine.ts';

const TEST_SESSION_SECRET = 'staging-test-secret-do-not-use-prod-0123456789abcdef0123456789';
const TEST_BACKUP_ENC_KEY = 'staging-backup-encryption-key-0123456789abcdef0123456789abcd';
process.env.SESSION_SECRET = TEST_SESSION_SECRET;
process.env.BACKUP_ENCRYPTION_KEY = TEST_BACKUP_ENC_KEY;

interface EvidenceRecord {
  id: string;
  device: string;
  action: string;
  endpoint: string;
  timestamp_utc: string;
  request_id: string | null;
  status_code: number;
  response_summary: string;
  result: 'PASS' | 'FAIL';
}

class CookieJar {
  private readonly cookies = new Map<string, string>();
  csrfToken = '';

  capture(res: Response) {
    const setCookies =
      typeof (res.headers as Headers & { getSetCookie?: () => string[] }).getSetCookie === 'function'
        ? (res.headers as Headers & { getSetCookie: () => string[] }).getSetCookie()
        : [res.headers.get('set-cookie')].filter(Boolean) as string[];
    for (const raw of setCookies) {
      const [pair] = raw.split(';');
      const eq = pair.indexOf('=');
      if (eq > 0) {
        const k = pair.slice(0, eq).trim();
        const v = pair.slice(eq + 1).trim();
        if (v === '') this.cookies.delete(k);
        else this.cookies.set(k, v);
      }
    }
  }

  header(): string {
    return Array.from(this.cookies.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join('; ');
  }
}

async function apiJson(
  baseUrl: string,
  endpoint: string,
  options: {
    method?: string;
    body?: unknown;
    jar?: CookieJar;
    headers?: Record<string, string>;
  } = {}
): Promise<{ status: number; body: Record<string, unknown>; rawText: string; headers: Headers; requestId: string | null }> {
  const headers: Record<string, string> = {
    ...(options.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
    ...(options.headers || {}),
  };
  if (options.jar) {
    const cookieHeader = options.jar.header();
    if (cookieHeader) headers.Cookie = cookieHeader;
    if (options.jar.csrfToken && options.method && options.method !== 'GET') {
      headers['X-CSRF-Token'] = options.jar.csrfToken;
    }
  }
  const res = await fetch(`${baseUrl}${endpoint}`, {
    method: options.method || 'GET',
    headers,
    body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
  });
  if (options.jar) options.jar.capture(res);
  const rawText = await res.text();
  let parsed: Record<string, unknown> = {};
  try {
    parsed = JSON.parse(rawText) as Record<string, unknown>;
  } catch {
    parsed = { rawText };
  }
  return {
    status: res.status,
    body: parsed,
    rawText,
    headers: res.headers,
    requestId: res.headers.get('x-request-id'),
  };
}

async function run() {
  const evidence: EvidenceRecord[] = [];
  let passed = 0;
  let failed = 0;

  const recordEvidence = (
    id: string,
    device: string,
    action: string,
    endpoint: string,
    res: { status: number; requestId: string | null },
    responseSummary: string
  ) => {
    evidence.push({
      id,
      device,
      action,
      endpoint,
      timestamp_utc: new Date().toISOString(),
      request_id: res.requestId,
      status_code: res.status,
      response_summary: responseSummary,
      result: 'PASS',
    });
  };

  const test = async (name: string, fn: () => Promise<void>) => {
    try {
      await fn();
      passed++;
      console.log(`PASS  ${name}`);
    } catch (err) {
      failed++;
      console.error(`FAIL  ${name}`);
      console.error('      ', err instanceof Error ? err.stack || err.message : err);
    }
  };

  // Fixed deterministic Manila clock inside a weekday work morning: 2026-06-15 08:05:00+08:00 (Monday)
  let fakeNowMs = parseManilaWallClockToUtcMs('2026-06-15', 8 * 60 + 5, 0);
  const nowProvider = () => fakeNowMs;

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-b16-staging-'));
  const dbPath = path.join(tmpDir, 'staging.db');
  const backupDir = path.join(tmpDir, 'backups');
  const logFile = path.join(tmpDir, 'staging-structured.jsonl');
  const queueFile = path.join(tmpDir, 'kiosk-offline-queue.enc');
  fs.mkdirSync(backupDir, { recursive: true });

  const ADMIN_INIT_PW = 'StgInitAdmin!2026#16';
  const ADMIN_PW = 'StgAdminRot!2026#99';
  const ROLE_PW = 'StgRoleUser!2026#88';

  let activeDb = initDatabase(dbPath, {
    mode: 'staging',
    seedDemoData: false,
    initialAdmin: {
      username: 'stg_admin',
      email: 'stg_admin@staging.rsucaj.local',
      password: ADMIN_INIT_PW,
    },
  });

  const realtimeHub = new RealtimeHub({ nowProvider });
  const structuredLogStore = new StructuredLogStore({ logFilePath: logFile, emitStdout: false });
  const impairmentController = new StagingImpairmentController('staging', true, nowProvider);

  const app = express();
  app.disable('x-powered-by');
  app.use(securityHeadersMiddleware);
  app.use(
    '/api',
    createApiRouter(activeDb, {
      dbPath,
      backupDir,
      appMode: 'staging',
      stagingImpairmentEnabled: true,
      structuredLogStore,
      impairmentController,
      nowProvider,
      realtimeHub,
      maxFailedLoginAttempts: 3,
      lockoutDurationMinutes: 5,
      loginRateLimitMax: 50,
      onDatabaseReplaced: (nextDb) => {
        activeDb = nextDb;
      },
    })
  );

  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  const addr = server.address();
  assert.ok(addr && typeof addr !== 'string');
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  // Secondary Production-mode server to prove staging endpoints are strictly blocked in production
  const prodDb = initDatabase(':memory:', {
    mode: 'production',
    seedDemoData: false,
    initialAdmin: {
      username: 'prod_admin',
      email: 'prod_admin@rsucaj.edu.ph',
      password: ADMIN_PW,
    },
  });
  prodDb.prepare(`UPDATE users SET must_change_password = 0 WHERE username = 'prod_admin'`).run();
  const prodApp = express();
  prodApp.use(securityHeadersMiddleware);
  prodApp.use('/api', createApiRouter(prodDb, { appMode: 'production', stagingImpairmentEnabled: true }));
  const prodServer = http.createServer(prodApp);
  await new Promise<void>((resolve) => prodServer.listen(0, '127.0.0.1', () => resolve()));
  const prodAddr = prodServer.address();
  assert.ok(prodAddr && typeof prodAddr !== 'string');
  const prodBaseUrl = `http://127.0.0.1:${prodAddr.port}`;

  const adminJar = new CookieJar();
  const checkerJar = new CookieJar();
  const hrJar = new CookieJar();
  const payrollJar = new CookieJar();
  const deptHeadJar = new CookieJar();
  const employeeJar = new CookieJar();

  let deptItId = 0;
  let deptHrId = 0;
  let posItId = 0;
  let shiftId = 0;
  let emp1Id = 0;
  let emp2Id = 0;
  let rpiDeviceId = 0;
  let rpiToken = '';
  let loadBenchSummary: Record<string, unknown> = {};
  let restoreBenchSummary: Record<string, unknown> = {};

  try {
    // =========================================================================
    // 1. STAGING ENV VALIDATION & PRODUCTION GUARDRAILS
    // =========================================================================
    await test('01. Staging env validation & hard production block on network impairment', async () => {
      const validStaging = validateEnv({
        NODE_ENV: 'production',
        APP_MODE: 'staging',
        DATABASE_PATH: '/var/lib/savage-rsucaj-staging/staging.db',
        SESSION_SECRET: TEST_SESSION_SECRET,
        STAGING_IMPAIRMENT_ENABLED: 'true',
        STAGING_PUBLIC_URL: 'https://staging-attendance.rsucaj.edu.ph',
        LOG_FORMAT: 'json',
      });
      assert.equal(validStaging.valid, true, validStaging.errors.join('; '));
      assert.equal(validStaging.config.appMode, 'staging');
      assert.equal(validStaging.config.stagingImpairmentEnabled, true);

      const forbiddenProdImpairment = validateEnv({
        NODE_ENV: 'production',
        APP_MODE: 'production',
        DATABASE_PATH: '/var/lib/savage-rsucaj/prod.db',
        SESSION_SECRET: TEST_SESSION_SECRET,
        STAGING_IMPAIRMENT_ENABLED: 'true',
      });
      assert.equal(forbiddenProdImpairment.valid, false);
      assert.ok(forbiddenProdImpairment.errors.some((e) => e.includes('STAGING_IMPAIRMENT_ENABLED')));

      // Verify production server rejects /api/staging/impairment & /api/staging/logs with 403
      const prodJar = new CookieJar();
      const prodLogin = await apiJson(prodBaseUrl, '/api/auth/login', {
        method: 'POST',
        body: { identifier: 'prod_admin', password: ADMIN_PW },
        jar: prodJar,
      });
      assert.equal(prodLogin.status, 200);
      prodJar.csrfToken = String(prodLogin.body.csrfToken);

      const impGet = await apiJson(prodBaseUrl, '/api/staging/impairment', { jar: prodJar });
      assert.equal(impGet.status, 403);
      assert.equal(impGet.body.code, 'STAGING_ONLY_ENDPOINT');

      const logsGet = await apiJson(prodBaseUrl, '/api/staging/logs', { jar: prodJar });
      assert.equal(logsGet.status, 403);
      assert.equal(logsGet.body.code, 'STAGING_ONLY_ENDPOINT');

      const health = await apiJson(baseUrl, '/api/health');
      assert.equal(health.status, 200);
      assert.equal(health.body.mode, 'staging');
      assert.equal(health.body.version, '1.13.0');
      assert.equal(health.body.build, 'BUILD 17');
      assert.ok(health.requestId && health.requestId.startsWith('req_'));
      recordEvidence(
        'EV-01',
        'Staging API Host (Linux/Node v22)',
        'Health check & production impairment block',
        '/api/health',
        health,
        `HTTP 200 mode=staging build=BUILD 17; prod /api/staging/* -> 403 STAGING_ONLY_ENDPOINT`
      );
    });

    // =========================================================================
    // 2. AUTHENTICATION, FORCED PASSWORD ROTATION & LEAST-PRIVILEGE ROLE SETUP
    // =========================================================================
    await test('02. Staging auth, forced initial password rotation & 6-role least-privilege provisioning', async () => {
      const loginRes = await apiJson(baseUrl, '/api/auth/login', {
        method: 'POST',
        body: { identifier: 'stg_admin', password: ADMIN_INIT_PW },
        jar: adminJar,
      });
      assert.equal(loginRes.status, 200);
      assert.equal((loginRes.body.user as Record<string, unknown>).must_change_password, true);
      adminJar.csrfToken = String(loginRes.body.csrfToken);

      // Verify HttpOnly cookie header is set
      const setCookie = loginRes.headers.get('set-cookie') || '';
      assert.ok(setCookie.toLowerCase().includes('httponly'), 'Session cookie must be HttpOnly');

      // Rotate forced initial password (rotates session & CSRF token)
      const rotRes = await apiJson(baseUrl, '/api/auth/change-password', {
        method: 'POST',
        body: { currentPassword: ADMIN_INIT_PW, newPassword: ADMIN_PW },
        jar: adminJar,
      });
      assert.equal(rotRes.status, 200);
      adminJar.csrfToken = String(rotRes.body.csrfToken);

      // Org setup
      const d1 = await apiJson(baseUrl, '/api/departments', {
        method: 'POST',
        body: { code: 'STG-IT', name: '[STAGING-TEST-ONLY] Info Tech', head_name: 'Dean IT' },
        jar: adminJar,
      });
      assert.equal(d1.status, 201);
      deptItId = Number(d1.body.id);

      const d2 = await apiJson(baseUrl, '/api/departments', {
        method: 'POST',
        body: { code: 'STG-HR', name: '[STAGING-TEST-ONLY] Human Resources', head_name: 'HR Head' },
        jar: adminJar,
      });
      assert.equal(d2.status, 201);
      deptHrId = Number(d2.body.id);

      const p1 = await apiJson(baseUrl, '/api/positions', {
        method: 'POST',
        body: { code: 'STG-INST1', name: '[STAGING-TEST-ONLY] Instructor I', type: 'Regular', base_salary: 28000, allowance: 0 },
        jar: adminJar,
      });
      assert.equal(p1.status, 201, p1.rawText);
      posItId = Number(p1.body.id);

      const s1 = await apiJson(baseUrl, '/api/shifts', {
        method: 'POST',
        body: { name: 'Staging Day Shift', time_in: '08:00 AM', time_out: '05:00 PM', grace_minutes: 15, rest_days: 'Sat,Sun' },
        jar: adminJar,
      });
      assert.equal(s1.status, 201);
      shiftId = Number(s1.body.id);

      const e1 = await apiJson(baseUrl, '/api/employees', {
        method: 'POST',
        body: {
          employee_code: 'STG-EMP-001',
          full_name: '[STAGING-TEST-ONLY] Juan Dela Cruz',
          email: 'stg_emp001@staging.rsucaj.local',
          department_id: deptItId,
          position_id: posItId,
          shift_id: shiftId,
          employment_type: 'Regular',
          status: 'Active',
          hired_date: '2026-01-01',
          monthly_salary: 28000,
          allowance: 0,
        },
        jar: adminJar,
      });
      assert.equal(e1.status, 201);
      emp1Id = Number(e1.body.id);

      const e2 = await apiJson(baseUrl, '/api/employees', {
        method: 'POST',
        body: {
          employee_code: 'STG-EMP-002',
          full_name: '[STAGING-TEST-ONLY] Maria Santos',
          email: 'stg_emp002@staging.rsucaj.local',
          department_id: deptHrId,
          position_id: posItId,
          shift_id: shiftId,
          employment_type: 'Regular',
          status: 'Active',
          hired_date: '2026-01-01',
          monthly_salary: 22000,
          allowance: 0,
        },
        jar: adminJar,
      });
      assert.equal(e2.status, 201);
      emp2Id = Number(e2.body.id);

      // Provision least-privilege role users
      const createUser = async (payload: Record<string, unknown>) => {
        const r = await apiJson(baseUrl, '/api/users', { method: 'POST', body: payload, jar: adminJar });
        assert.equal(r.status, 201, `Create user failed: ${r.rawText}`);
      };
      await createUser({ username: 'stg_checker', email: 'stg_checker@staging.rsucaj.local', full_name: 'Staging Checker', role: 'Administrator', password: ROLE_PW });
      await createUser({ username: 'stg_hr', email: 'stg_hr@staging.rsucaj.local', full_name: 'Staging HR', role: 'HR Officer', department_id: deptHrId, password: ROLE_PW });
      await createUser({ username: 'stg_payroll', email: 'stg_payroll@staging.rsucaj.local', full_name: 'Staging Payroll', role: 'Payroll Officer', password: ROLE_PW });
      await createUser({ username: 'stg_depthead', email: 'stg_depthead@staging.rsucaj.local', full_name: 'Staging Dept Head', role: 'Department Head', department_id: deptItId, password: ROLE_PW });
      await createUser({ username: 'stg_employee', email: 'stg_emp001@staging.rsucaj.local', full_name: 'Juan Dela Cruz', role: 'Employee', department_id: deptItId, employee_id: emp1Id, password: ROLE_PW });

      const loginRole = async (username: string, jar: CookieJar) => {
        const lr = await apiJson(baseUrl, '/api/auth/login', {
          method: 'POST',
          body: { identifier: username, password: ROLE_PW },
          jar,
        });
        assert.equal(lr.status, 200);
        jar.csrfToken = String(lr.body.csrfToken);
        if ((lr.body.user as Record<string, unknown>).must_change_password) {
          const cp = await apiJson(baseUrl, '/api/auth/change-password', {
            method: 'POST',
            body: { currentPassword: ROLE_PW, newPassword: `${ROLE_PW}x` },
            jar,
          });
          assert.equal(cp.status, 200);
          jar.csrfToken = String(cp.body.csrfToken);
        }
      };

      await loginRole('stg_checker', checkerJar);
      await loginRole('stg_hr', hrJar);
      await loginRole('stg_payroll', payrollJar);
      await loginRole('stg_depthead', deptHeadJar);
      await loginRole('stg_employee', employeeJar);

      recordEvidence(
        'EV-02',
        'Staging Web / API Client',
        'Admin login, password rotation, and 6-role RBAC provisioning',
        '/api/auth/login',
        rotRes,
        'HttpOnly cookie verified; 6 RBAC roles authenticated'
      );
    });

    // =========================================================================
    // 3. KIOSK API CONTRACT: HEARTBEAT, AUTO TIME IN/OUT, BACKEND-CONFIRMED DUPLICATE VOICE, <=3AM CUTOFF & BIOMETRIC TAMPER BLOCK
    // =========================================================================
    await test('03. Kiosk API contract: heartbeat, TIME_IN, backend-confirmed duplicate voice cue, biometric tamper block & <=03:00 AM next-day cutoff', async () => {
      const reg = await apiJson(baseUrl, '/api/devices', {
        method: 'POST',
        body: {
          name: 'STG-RPI-01',
          device_type: 'Raspberry Pi',
          model_info: 'API-Contract Kiosk Simulator (Physical RPi NOT attached)',
          ip_address: '10.10.0.21',
          location: 'Staging Gate A',
        },
        jar: adminJar,
      });
      assert.equal(reg.status, 201);
      rpiDeviceId = Number(reg.body.id);
      rpiToken = String(reg.body.api_token);
      assert.equal(reg.body.one_time_secret, true);
      assert.equal(reg.body.status, 'Offline');

      // Heartbeat -> Online
      const hb = await apiJson(baseUrl, '/api/kiosk/heartbeat', {
        method: 'POST',
        headers: { 'x-kiosk-token': rpiToken },
        body: { device_timestamp: new Date(fakeNowMs).toISOString(), device_boot_id: 'stg-boot-1', pending_queue_count: 0 },
      });
      assert.equal(hb.status, 200);

      // Tampered biometric evidence envelope MUST be rejected (422) — zero fake biometric pass
      const badEnv = createBiometricEvidenceEnvelope({
        apiToken: 'wrong-key-tampered',
        deviceId: rpiDeviceId,
        deviceBootId: 'stg-boot-1',
        monotonicSeq: 1,
        eventUid: 'stg-tampered-1',
        employeeCode: 'STG-EMP-001',
        punchType: 'TIME_IN',
        capturedAtUtc: new Date(fakeNowMs).toISOString(),
      });
      const tamperRes = await apiJson(baseUrl, '/api/kiosk/punch', {
        method: 'POST',
        headers: { 'x-kiosk-token': rpiToken },
        body: {
          employee_code: 'STG-EMP-001',
          punch_type: 'TIME_IN',
          event_uid: 'stg-tampered-1',
          device_timestamp: new Date(fakeNowMs).toISOString(),
          monotonic_seq: 1,
          device_boot_id: 'stg-boot-1',
          biometric_evidence: badEnv,
        },
      });
      assert.equal(tamperRes.status, 422);
      assert.equal(tamperRes.body.code, 'BIOMETRIC_EVIDENCE_INVALID');

      // Valid cryptographic-envelope TIME_IN
      const validEnv = createBiometricEvidenceEnvelope({
        apiToken: rpiToken,
        deviceId: rpiDeviceId,
        deviceBootId: 'stg-boot-1',
        monotonicSeq: 1,
        eventUid: 'stg-in-001',
        employeeCode: 'STG-EMP-001',
        punchType: 'TIME_IN',
        capturedAtUtc: new Date(fakeNowMs).toISOString(),
      });
      const punchIn = await apiJson(baseUrl, '/api/kiosk/punch', {
        method: 'POST',
        headers: { 'x-kiosk-token': rpiToken },
        body: {
          employee_code: 'STG-EMP-001',
          punch_type: 'TIME_IN',
          event_uid: 'stg-in-001',
          device_timestamp: new Date(fakeNowMs).toISOString(),
          monotonic_seq: 1,
          device_boot_id: 'stg-boot-1',
          biometric_evidence: validEnv,
        },
      });
      assert.equal(punchIn.status, 201);
      assert.equal(punchIn.body.backend_confirmed, true);
      assert.equal(punchIn.body.voice_cue, 'TIME_IN_RECORDED');
      assert.equal(punchIn.body.shift_date, '2026-06-15');

      // Duplicate punch -> backend confirms duplicate & emits DUPLICATE_ALREADY_RECORDED voice cue
      const dupReplay = await apiJson(baseUrl, '/api/kiosk/punch', {
        method: 'POST',
        headers: { 'x-kiosk-token': rpiToken },
        body: {
          employee_code: 'STG-EMP-001',
          punch_type: 'TIME_IN',
          event_uid: 'stg-in-001',
          device_timestamp: new Date(fakeNowMs).toISOString(),
        },
      });
      assert.equal(dupReplay.status, 200);
      assert.equal(dupReplay.body.action, 'duplicate_ignored');
      assert.equal(dupReplay.body.backend_confirmed, true);
      assert.equal(dupReplay.body.voice_cue, 'DUPLICATE_ALREADY_RECORDED');

      // <= 03:00 AM next-day TIME_OUT (2026-06-16 02:59 Asia/Manila) -> attaches to 2026-06-15!
      fakeNowMs = parseManilaWallClockToUtcMs('2026-06-16', 2 * 60 + 59, 0);
      const lateOut = await apiJson(baseUrl, '/api/kiosk/punch', {
        method: 'POST',
        headers: { 'x-kiosk-token': rpiToken },
        body: {
          employee_code: 'STG-EMP-001',
          punch_type: 'TIME_OUT',
          event_uid: 'stg-out-0259',
          device_timestamp: new Date(fakeNowMs).toISOString(),
        },
      });
      assert.equal(lateOut.status, 200);
      assert.equal(lateOut.body.shift_date, '2026-06-15');
      assert.equal(lateOut.body.voice_cue, 'TIME_OUT_RECORDED');

      // > 03:00 AM next-day TIME_OUT for STG-EMP-002 (TIME_IN on 2026-06-15, TIME_OUT at 2026-06-16 03:01 AM -> escalated!)
      fakeNowMs = parseManilaWallClockToUtcMs('2026-06-15', 8 * 60 + 10, 0);
      const emp2In = await apiJson(baseUrl, '/api/kiosk/punch', {
        method: 'POST',
        headers: { 'x-kiosk-token': rpiToken },
        body: {
          employee_code: 'STG-EMP-002',
          punch_type: 'TIME_IN',
          event_uid: 'stg-emp2-in-001',
          device_timestamp: new Date(fakeNowMs).toISOString(),
        },
      });
      assert.equal(emp2In.status, 201);

      fakeNowMs = parseManilaWallClockToUtcMs('2026-06-16', 3 * 60 + 1, 0);
      const emp2AfterCutoff = await apiJson(baseUrl, '/api/kiosk/punch', {
        method: 'POST',
        headers: { 'x-kiosk-token': rpiToken },
        body: {
          employee_code: 'STG-EMP-002',
          punch_type: 'TIME_OUT',
          event_uid: 'stg-emp2-out-0301',
          device_timestamp: new Date(fakeNowMs).toISOString(),
        },
      });
      assert.equal(emp2AfterCutoff.status, 422);
      assert.equal(emp2AfterCutoff.body.escalated, true);
      assert.equal(emp2AfterCutoff.body.voice_cue, 'ESCALATED_TO_HR');

      recordEvidence(
        'EV-03',
        'Kiosk API Contract Client (Simulated — Physical RPi/Android NOT attached)',
        'TIME_IN, duplicate voice cue, biometric tamper block, <=03:00 AM cutoff & >03:00 AM HR escalation',
        '/api/kiosk/punch',
        lateOut,
        `TIME_IN->TIME_IN_RECORDED; Dup->DUPLICATE_ALREADY_RECORDED; 02:59->2026-06-15; 03:01->422 ESCALATED_TO_HR`
      );
    });

    // =========================================================================
    // 4. CONTROLLABLE NETWORK IMPAIRMENT -> ENCRYPTED OFFLINE QUEUE -> RECOVERY BATCH SYNC -> LIVE SSE
    // =========================================================================
    await test('04. Controllable staging network impairment -> encrypted offline queue -> recovery sync & live SSE dashboard', async () => {
      // Advance staging clock to 2026-06-16 08:02 Asia/Manila
      fakeNowMs = parseManilaWallClockToUtcMs('2026-06-16', 8 * 60 + 2, 0);

      // Open SSE live dashboard listener as Administrator
      const sseController = new AbortController();
      const sseEvents: string[] = [];
      const sseResponse = await fetch(`${baseUrl}/api/events/stream`, {
        headers: { Cookie: adminJar.header() },
        signal: sseController.signal,
      });
      assert.equal(sseResponse.status, 200);
      const sseReader = sseResponse.body!.getReader();
      const decoder = new TextDecoder();
      const readLoop = (async () => {
        try {
          while (true) {
            const { value, done } = await sseReader.read();
            if (done) break;
            sseEvents.push(decoder.decode(value, { stream: true }));
          }
        } catch {
          // aborted cleanly
        }
      })();

      // Enable 100% network drop on /api/kiosk/
      const impOn = await apiJson(baseUrl, '/api/staging/impairment', {
        method: 'PUT',
        body: { enabled: true, latencyMs: 15, dropRatePercent: 100, targetPrefixes: ['/api/kiosk/'], ttlSeconds: 120 },
        jar: adminJar,
      });
      assert.equal(impOn.status, 200);
      assert.equal((impOn.body.impairment as Record<string, unknown>).enabled, true);

      // Kiosk attempts punch -> receives 503 STAGING_IMPAIRMENT_DROP
      const failedLive = await apiJson(baseUrl, '/api/kiosk/punch', {
        method: 'POST',
        headers: { 'x-kiosk-token': rpiToken },
        body: {
          employee_code: 'STG-EMP-001',
          punch_type: 'TIME_IN',
          event_uid: 'stg-offline-0616-in',
          device_timestamp: new Date(fakeNowMs).toISOString(),
        },
      });
      assert.equal(failedLive.status, 503);
      assert.equal(failedLive.body.code, 'STAGING_IMPAIRMENT_DROP');
      assert.equal(failedLive.headers.get('x-staging-impaired'), 'drop');

      // Kiosk persists offline punches in AES-256-GCM encrypted queue on disk
      const queue = new EncryptedKioskQueue({
        queueFilePath: queueFile,
        encryptionKey: 'staging-kiosk-queue-key-0123456789abcdef',
        apiToken: rpiToken,
        deviceId: rpiDeviceId,
        deviceName: 'STG-RPI-01',
        deviceBootId: 'stg-boot-1',
        nowProvider,
      });
      queue.enqueuePunch({
        eventUid: 'stg-offline-0616-in',
        employeeCode: 'STG-EMP-001',
        punchType: 'TIME_IN',
        capturedAtUtc: new Date(fakeNowMs).toISOString(),
        offlineReplay: true,
      });
      const outTimeMs = parseManilaWallClockToUtcMs('2026-06-16', 17 * 60 + 5, 0);
      queue.enqueuePunch({
        eventUid: 'stg-offline-0616-out',
        employeeCode: 'STG-EMP-001',
        punchType: 'TIME_OUT',
        capturedAtUtc: new Date(outTimeMs).toISOString(),
        offlineReplay: true,
      });
      assert.equal(queue.getPendingCount(), 2);

      // Network recovers -> disable impairment & advance server clock to 17:06
      fakeNowMs = parseManilaWallClockToUtcMs('2026-06-16', 17 * 60 + 6, 0);
      const impOff = await apiJson(baseUrl, '/api/staging/impairment', {
        method: 'PUT',
        body: { enabled: false, latencyMs: 0, dropRatePercent: 0 },
        jar: adminJar,
      });
      assert.equal(impOff.status, 200);

      // Flush offline queue chronologically via POST /api/kiosk/sync
      const batch = queue.getPendingEvents();
      const syncRes = await apiJson(baseUrl, '/api/kiosk/sync', {
        method: 'POST',
        headers: { 'x-kiosk-token': rpiToken },
        body: {
          batch_uid: 'stg-batch-recovery-1',
          device_boot_id: 'stg-boot-1',
          device_timestamp: new Date(fakeNowMs).toISOString(),
          pending_queue_count: 0,
          events: batch,
        },
      });
      assert.equal(syncRes.status, 200);
      const syncSummary = syncRes.body.summary as Record<string, number>;
      assert.equal(syncSummary.accepted, 2, syncRes.rawText);
      assert.equal(syncSummary.rejected, 0, syncRes.rawText);

      // Wait briefly for SSE flush and verify attendance_updated broadcast arrived
      await new Promise((r) => setTimeout(r, 120));
      sseController.abort();
      await readLoop;
      const joinedSse = sseEvents.join('');
      assert.ok(joinedSse.includes('attendance:updated'), 'Expected live SSE attendance:updated broadcast on recovery sync');

      recordEvidence(
        'EV-04',
        'Kiosk Offline Queue + Admin SSE Stream',
        'Network impairment (503 drop) -> AES-256-GCM queue -> chronological recovery sync -> SSE broadcast',
        '/api/kiosk/sync',
        syncRes,
        `503 drop verified; 2/2 encrypted queued events synced; SSE attendance_updated delivered`
      );
    });

    // =========================================================================
    // 5. DTR, APPROVALS, INCIDENT NOTIFICATIONS & PAYROLL APPROVALS (TEST-ONLY FAKE CURRENCY)
    // =========================================================================
    await test('05. DTR, approvals, incident notifications & maker-checker payroll release (TEST-ONLY FAKE CURRENCY)', async () => {
      // Verify HR escalation notification was persisted from >03:00 AM punch
      const notifs = await apiJson(baseUrl, '/api/notifications?limit=20', { jar: hrJar });
      assert.equal(notifs.status, 200);
      const notifRows = (notifs.body.data as Array<{ title: string }>) || [];
      assert.ok(notifRows.length >= 1, 'Expected persisted HR incident notification from >03:00 AM cutoff escalation');

      // Resolve STG-EMP-002 escalated correction (approve via HR Officer) so payroll precheck is clean
      const corrs = await apiJson(baseUrl, '/api/corrections', { jar: hrJar });
      assert.equal(corrs.status, 200);
      const pendingCorrs = ((corrs.body.data as Array<{ id: number; status: string }>) || []).filter((c) => c.status === 'Pending');
      for (const c of pendingCorrs) {
        const appr = await apiJson(baseUrl, `/api/corrections/${c.id}/status`, {
          method: 'PATCH',
          body: { status: 'Approved', approved_time: '05:00 PM', reviewer_notes: 'Staging HR verified' },
          jar: hrJar,
        });
        assert.equal(appr.status, 200, appr.rawText);
      }

      // Monthly DTR & PDF check
      const dtrRes = await apiJson(baseUrl, `/api/reports/dtr/monthly?month=2026-06&employee_id=${emp1Id}`, { jar: adminJar });
      assert.equal(dtrRes.status, 200);
      const pdfFetch = await fetch(`${baseUrl}/api/reports/dtr/pdf?month=2026-06&employee_id=${emp1Id}`, {
        headers: { Cookie: adminJar.header() },
      });
      assert.equal(pdfFetch.status, 200);
      const pdfBuf = Buffer.from(await pdfFetch.arrayBuffer());
      assert.equal(pdfBuf.subarray(0, 5).toString('ascii'), '%PDF-');

      // Create & Finance-Approve TEST-ONLY FAKE CURRENCY payroll policy
      const tpl = await apiJson(baseUrl, '/api/payroll/policy-template', { jar: adminJar });
      assert.equal(tpl.status, 200);
      const tplFields = tpl.body.fields as Record<string, unknown>;
      const polRes = await apiJson(baseUrl, '/api/payroll/policies', {
        method: 'POST',
        body: {
          ...tplFields,
          policy_code: 'STG-FAKE-PHP-2026',
          policy_name: '[STAGING TEST-ONLY — FAKE CURRENCY, NOT APPROVED FOR PRODUCTION PAYROLL]',
          effective_from: '2026-01-01',
          notes: 'STAGING-FAKE-CURRENCY-TEST-ONLY',
        },
        jar: adminJar,
      });
      assert.equal(polRes.status, 201, polRes.rawText);
      const policyId = Number((polRes.body.policy as { id?: number } | undefined)?.id ?? polRes.body.id);

      const polAppr = await apiJson(baseUrl, `/api/payroll/policies/${policyId}/finance-approve`, {
        method: 'POST',
        body: { approval_reference: 'STG-TEST-ONLY-FAKE-FIN-001' },
        jar: checkerJar,
      });
      assert.equal(polAppr.status, 200, polAppr.rawText);

      // Compute payroll as stg_admin -> same maker blocked from finalizing -> checker finalizes, signs off, releases
      const compRes = await apiJson(baseUrl, '/api/payroll/compute', {
        method: 'POST',
        body: {
          period_label: 'Jun 1–15, 2026 [STAGING TEST-ONLY FAKE CURRENCY]',
          start_date: '2026-06-01',
          end_date: '2026-06-15',
          policy_id: policyId,
        },
        jar: adminJar,
      });
      assert.equal(compRes.status, 201, compRes.rawText);
      const runId = Number(compRes.body.run_id ?? compRes.body.id);

      const sameMakerBlock = await apiJson(baseUrl, `/api/payroll/${runId}/finalize`, { method: 'PATCH', jar: adminJar });
      assert.equal(sameMakerBlock.status, 403);
      assert.equal(sameMakerBlock.body.code, 'MAKER_CHECKER_VIOLATION');

      const finRes = await apiJson(baseUrl, `/api/payroll/${runId}/finalize`, { method: 'PATCH', jar: checkerJar });
      assert.equal(finRes.status, 200, finRes.rawText);

      const signRes = await apiJson(baseUrl, `/api/payroll/${runId}/finance-signoff`, {
        method: 'POST',
        body: { finance_signoff_ref: 'STG-FAKE-FIN-SIGNOFF-001' },
        jar: checkerJar,
      });
      assert.equal(signRes.status, 200, signRes.rawText);

      const relRes = await apiJson(baseUrl, `/api/payroll/${runId}/release`, { method: 'PATCH', jar: checkerJar });
      assert.equal(relRes.status, 200);

      // Employee self-service reads own DTR & Released payslip
      const myDtr = await apiJson(baseUrl, '/api/reports/my-dtr?month=2026-06', { jar: employeeJar });
      assert.equal(myDtr.status, 200);
      const myPayslips = await apiJson(baseUrl, '/api/payroll/my-payslips', { jar: employeeJar });
      assert.equal(myPayslips.status, 200);
      assert.ok(((myPayslips.body.payslips as unknown[]) || []).length >= 1, myPayslips.rawText);

      recordEvidence(
        'EV-05',
        'Staging Admin / HR / Checker / Employee Clients',
        'DTR PDF, HR escalation approval, maker-checker payroll release (TEST-ONLY FAKE CURRENCY), employee payslip',
        '/api/payroll/:id/release',
        relRes,
        'PDF verified; same-maker blocked (403); checker released; employee fetched own DTR & payslip'
      );
    });

    // =========================================================================
    // 6. SECURITY AUDIT: PERMISSIONS, CSRF, AUTH/LOCKOUT, REPLAY, SECRET LEAKAGE, SQLi & XSS
    // =========================================================================
    await test('06. Security Audit: RBAC, CSRF cross-origin block, brute-force lockout, replay, zero secret leakage, SQLi & XSS', async () => {
      // 6a. RBAC / Permissions matrix
      assert.equal((await apiJson(baseUrl, '/api/settings', { jar: employeeJar })).status, 403);
      assert.equal((await apiJson(baseUrl, '/api/employees', { jar: employeeJar })).status, 403);
      assert.equal((await apiJson(baseUrl, `/api/payroll/1/payslip/${emp2Id}`, { jar: employeeJar })).status, 403);
      assert.equal((await apiJson(baseUrl, '/api/staging/impairment', { jar: hrJar })).status, 403);
      assert.equal((await apiJson(baseUrl, '/api/notifications/mark-all-read', { method: 'POST', jar: payrollJar })).status, 403);
      // Department Head cross-department isolation
      const dhCross = await apiJson(baseUrl, `/api/reports/dtr/monthly?month=2026-06&employee_id=${emp2Id}`, { jar: deptHeadJar });
      assert.equal(dhCross.status, 403);

      // 6b. CSRF cross-origin Origin & Referer rejection on mutations
      const csrfOrigin = await apiJson(baseUrl, '/api/departments', {
        method: 'POST',
        body: { code: 'EVIL', name: 'Evil Dept' },
        jar: adminJar,
        headers: { Origin: 'https://attacker.example' },
      });
      assert.equal(csrfOrigin.status, 403);

      const csrfMissingToken = await fetch(`${baseUrl}/api/departments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Cookie: adminJar.header() },
        body: JSON.stringify({ code: 'NOCSRF', name: 'No CSRF' }),
      });
      assert.equal(csrfMissingToken.status, 403);

      // 6c. Auth hardening: forged cookie, brute-force lockout, logout revocation
      const forged = await apiJson(baseUrl, '/api/dashboard', {
        headers: { Cookie: 'savage_sid=forged.invalid.signature' },
      });
      assert.equal(forged.status, 401);

      // Brute-force lockout on stg_hr (maxFailedLoginAttempts=3)
      for (let i = 0; i < 3; i++) {
        await apiJson(baseUrl, '/api/auth/login', {
          method: 'POST',
          body: { identifier: 'stg_hr', password: 'WrongPassword!123' },
        });
      }
      const locked = await apiJson(baseUrl, '/api/auth/login', {
        method: 'POST',
        body: { identifier: 'stg_hr', password: `${ROLE_PW}x` },
      });
      assert.equal(locked.status, 429);
      assert.equal(locked.body.code, 'ACCOUNT_LOCKED');

      // 6d. Replay protection: clock drift >120s, expired offline replay >72h, rotated token & revoked token
      const driftRes = await apiJson(baseUrl, '/api/kiosk/punch', {
        method: 'POST',
        headers: { 'x-kiosk-token': rpiToken },
        body: {
          employee_code: 'STG-EMP-001',
          punch_type: 'TIME_IN',
          event_uid: 'stg-drift-001',
          device_timestamp: new Date(fakeNowMs + 600_000).toISOString(),
        },
      });
      assert.equal(driftRes.status, 422);
      assert.equal(driftRes.body.code, 'CLOCK_DRIFT_EXCEEDED');

      // Rotate device key -> old token MUST be rejected
      const oldToken = rpiToken;
      const rotKey = await apiJson(baseUrl, `/api/devices/${rpiDeviceId}/rotate-token`, { method: 'POST', jar: adminJar });
      assert.equal(rotKey.status, 200);
      rpiToken = String(rotKey.body.api_token);
      const oldTokenPunch = await apiJson(baseUrl, '/api/kiosk/heartbeat', {
        method: 'POST',
        headers: { 'x-kiosk-token': oldToken },
        body: {},
      });
      assert.equal(oldTokenPunch.status, 403);

      // 6e. SQL Injection resistance across login, search, reports & ID params
      const sqliPayloads = [
        `' OR '1'='1`,
        `1; DROP TABLE users;--`,
        `' UNION SELECT username, password_hash FROM users --`,
      ];
      for (const payload of sqliPayloads) {
        const l = await apiJson(baseUrl, '/api/auth/login', {
          method: 'POST',
          body: { identifier: payload, password: payload },
        });
        assert.equal(l.status, 401);
        const s = await apiJson(baseUrl, `/api/employees?search=${encodeURIComponent(payload)}`, { jar: adminJar });
        assert.equal(s.status, 200);
        const a = await apiJson(baseUrl, `/api/audit-logs?search=${encodeURIComponent(payload)}`, { jar: adminJar });
        assert.equal(a.status, 200);
      }
      const badId = await apiJson(baseUrl, `/api/employees/${encodeURIComponent('1;DROP TABLE users')}`, {
        method: 'DELETE',
        jar: adminJar,
      });
      assert.equal(badId.status, 400);
      const userCountAfterSqli = (activeDb.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number }).c;
      assert.ok(userCountAfterSqli >= 6, 'users table must remain intact after SQLi probes');

      // 6f. XSS payload safety, security headers & CSV formula injection neutralization
      const xssDept = await apiJson(baseUrl, '/api/departments', {
        method: 'POST',
        body: { code: 'XSS-TST', name: `=CMD|' /C calc'!A0 <script>alert(1)</script>`, head_name: `<img src=x onerror=alert(1)>` },
        jar: adminJar,
      });
      assert.equal(xssDept.status, 201);
      assert.equal(xssDept.headers.get('x-content-type-options'), 'nosniff');
      assert.ok((xssDept.headers.get('cache-control') || '').includes('no-store'));

      const csvRes = await fetch(`${baseUrl}/api/reports/employees/export.csv`, {
        headers: { Cookie: adminJar.header() },
      });
      assert.equal(csvRes.status, 200);
      assert.equal(csvRes.headers.get('x-content-type-options'), 'nosniff');

      // 6g. Zero Secret Leakage across all API reads + structured logs
      const endpointsToScan = [
        '/api/health',
        '/api/settings',
        '/api/devices',
        '/api/dashboard',
        '/api/backup/export',
        '/api/audit-logs?page=1&limit=50',
        '/api/staging/logs?limit=200',
      ];
      const forbiddenSecrets = [TEST_SESSION_SECRET, TEST_BACKUP_ENC_KEY, rpiToken, oldToken, ADMIN_PW, ROLE_PW];
      for (const ep of endpointsToScan) {
        const scanRes = await apiJson(baseUrl, ep, { jar: adminJar });
        assert.equal(scanRes.status, 200, `Secret scan failed on ${ep}`);
        for (const secret of forbiddenSecrets) {
          assert.equal(scanRes.rawText.includes(secret), false, `SECRET LEAK DETECTED on ${ep}`);
        }
        assert.equal(scanRes.rawText.includes('"password_hash"'), false, `password_hash leaked on ${ep}`);
      }
      const jsonlDisk = fs.readFileSync(logFile, 'utf8');
      for (const secret of forbiddenSecrets) {
        assert.equal(jsonlDisk.includes(secret), false, 'SECRET LEAK DETECTED in staging structured JSONL log file');
      }

      recordEvidence(
        'EV-06',
        'Security Audit Harness (Live Staging HTTP)',
        'RBAC, CSRF, Auth Lockout, Replay, SQLi, XSS/Headers & Zero Secret Leakage Scan',
        '/api/* (7 audit endpoints + JSONL logs)',
        locked,
        'All 7 security control domains passed; 0 secrets leaked; users table intact'
      );
    });

    // =========================================================================
    // 7. LOAD, CONCURRENCY, BACKUP-RESTORE & MEASURED PERFORMANCE BENCHMARK
    // =========================================================================
    await test('07. Load & concurrency benchmark (200 API reads + 50 concurrent kiosk punches) + encrypted backup & guarded live restore recovery', async () => {
      // Create 25 staging employees for concurrent kiosk punches on 2026-06-17
      const loadDay = '2026-06-17';
      fakeNowMs = parseManilaWallClockToUtcMs(loadDay, 8 * 60 + 3, 0);
      const empCodes: string[] = [];
      for (let i = 1; i <= 25; i++) {
        const code = `STG-LOAD-${String(i).padStart(3, '0')}`;
        const cr = await apiJson(baseUrl, '/api/employees', {
          method: 'POST',
          body: {
            employee_code: code,
            full_name: `[STAGING-LOAD] Employee ${i}`,
            email: `load${i}@staging.rsucaj.local`,
            department_id: deptItId,
            position_id: posItId,
            shift_id: shiftId,
            employment_type: 'Regular',
            status: 'Active',
            hired_date: '2026-01-01',
            monthly_salary: 20000,
          },
          jar: adminJar,
        });
        assert.equal(cr.status, 201);
        empCodes.push(code);
      }

      // Burst 1: 200 concurrent mixed read API requests (40 batches x 5 endpoints)
      const readLatencies: number[] = [];
      const readStart = process.hrtime.bigint();
      const readEndpoints = ['/api/health', '/api/dashboard', '/api/employees', '/api/attendance', '/api/devices'];
      const readPromises: Promise<number>[] = [];
      for (let i = 0; i < 200; i++) {
        const ep = readEndpoints[i % readEndpoints.length];
        readPromises.push(
          (async () => {
            const t0 = process.hrtime.bigint();
            const r = await fetch(`${baseUrl}${ep}`, { headers: { Cookie: adminJar.header() } });
            await r.text();
            const ms = Number(process.hrtime.bigint() - t0) / 1_000_000;
            readLatencies.push(ms);
            return r.status;
          })()
        );
      }
      const readStatuses = await Promise.all(readPromises);
      const readWallMs = Number(process.hrtime.bigint() - readStart) / 1_000_000;
      const readErrors = readStatuses.filter((s) => s !== 200).length;
      assert.equal(readErrors, 0, `Expected 0 errors in 200 concurrent API reads, got ${readErrors}`);

      // Burst 2: 50 concurrent kiosk punches (25 TIME_IN + 25 duplicate replays simultaneously)
      const punchLatencies: number[] = [];
      const punchStart = process.hrtime.bigint();
      const punchPromises = empCodes.flatMap((code, idx) => [
        (async () => {
          const t0 = process.hrtime.bigint();
          const r = await apiJson(baseUrl, '/api/kiosk/punch', {
            method: 'POST',
            headers: { 'x-kiosk-token': rpiToken },
            body: {
              employee_code: code,
              punch_type: 'TIME_IN',
              event_uid: `load-in-${idx}`,
              device_timestamp: new Date(fakeNowMs).toISOString(),
            },
          });
          punchLatencies.push(Number(process.hrtime.bigint() - t0) / 1_000_000);
          return r.status;
        })(),
        (async () => {
          const t0 = process.hrtime.bigint();
          const r = await apiJson(baseUrl, '/api/kiosk/punch', {
            method: 'POST',
            headers: { 'x-kiosk-token': rpiToken },
            body: {
              employee_code: code,
              punch_type: 'TIME_IN',
              event_uid: `load-in-${idx}`,
              device_timestamp: new Date(fakeNowMs).toISOString(),
            },
          });
          punchLatencies.push(Number(process.hrtime.bigint() - t0) / 1_000_000);
          return r.status;
        })(),
      ]);
      const punchStatuses = await Promise.all(punchPromises);
      const punchWallMs = Number(process.hrtime.bigint() - punchStart) / 1_000_000;
      const punch5xx = punchStatuses.filter((s) => s >= 500).length;
      assert.equal(punch5xx, 0, `Expected 0 HTTP 5xx in 50 concurrent kiosk punches, got ${punch5xx}`);

      const attCount = (
        activeDb.prepare(`SELECT COUNT(*) as c FROM attendance_records WHERE date = ?`).get(loadDay) as { c: number }
      ).c;
      assert.equal(attCount, 25, `Expected exactly 25 deduplicated attendance records, got ${attCount}`);

      readLatencies.sort((a, b) => a - b);
      punchLatencies.sort((a, b) => a - b);
      loadBenchSummary = {
        concurrentReadCount: 200,
        readWallMs: Number(readWallMs.toFixed(2)),
        readThroughputRps: Number(((200 / readWallMs) * 1000).toFixed(1)),
        readP50Ms: computePercentile(readLatencies, 50),
        readP95Ms: computePercentile(readLatencies, 95),
        readP99Ms: computePercentile(readLatencies, 99),
        concurrentKioskPunches: 50,
        deduplicatedRecords: attCount,
        punchWallMs: Number(punchWallMs.toFixed(2)),
        punchP50Ms: computePercentile(punchLatencies, 50),
        punchP95Ms: computePercentile(punchLatencies, 95),
        punchP99Ms: computePercentile(punchLatencies, 99),
        http5xxCount: readErrors + punch5xx,
      };

      // Encrypted online backup + mutation + guarded live restore timing & integrity verification
      const snapStart = process.hrtime.bigint();
      const snapRes = await apiJson(baseUrl, '/api/backup/snapshot', { method: 'POST', jar: adminJar });
      const snapMs = Number(process.hrtime.bigint() - snapStart) / 1_000_000;
      assert.equal(snapRes.status, 201);
      const manifest = snapRes.body.manifest as Record<string, unknown>;
      const archiveFilename = String(manifest.encryptedFile || manifest.sqliteFile);
      assert.ok(archiveFilename.endsWith('.sqlite.enc'), `Expected .sqlite.enc archive, got ${archiveFilename}`);

      // Mutate setting after snapshot
      const mutRes = await apiJson(baseUrl, '/api/settings', {
        method: 'PUT',
        body: { updates: { campus_name: 'Temporary Pre-Restore Mutation' } },
        jar: adminJar,
      });
      assert.equal(mutRes.status, 200, mutRes.rawText);

      // Guarded live restore back to snapshot
      const restStart = process.hrtime.bigint();
      const restRes = await apiJson(baseUrl, '/api/backup/restore', {
        method: 'POST',
        body: {
          fileName: archiveFilename,
          currentPassword: ADMIN_PW,
          confirmText: 'RESTORE LIVE DATABASE',
        },
        jar: adminJar,
      });
      const restMs = Number(process.hrtime.bigint() - restStart) / 1_000_000;
      assert.equal(restRes.status, 200, restRes.rawText);

      // Verify restored state + SHA-256 audit chain valid + SQLite integrity ok
      const verifyChain = await apiJson(baseUrl, '/api/audit-logs/verify', { jar: adminJar });
      assert.equal(verifyChain.status, 200, verifyChain.rawText);
      assert.equal(verifyChain.body.valid, true, verifyChain.rawText);

      const postSettings = await apiJson(baseUrl, '/api/settings', { jar: adminJar });
      assert.equal(postSettings.status, 200);
      assert.notEqual(
        (postSettings.body.settings as Record<string, string>).campus_name,
        'Temporary Pre-Restore Mutation'
      );

      restoreBenchSummary = {
        archiveFilename,
        encryptedBackupMs: Number(snapMs.toFixed(2)),
        guardedLiveRestoreMs: Number(restMs.toFixed(2)),
        auditChainValid: verifyChain.body.valid,
        integrityCheck: String(activeDb.pragma('integrity_check', { simple: true })),
        fkViolations: (activeDb.pragma('foreign_key_check') as unknown[]).length,
      };
      assert.equal(restoreBenchSummary.integrityCheck, 'ok');
      assert.equal(restoreBenchSummary.fkViolations, 0);

      recordEvidence(
        'EV-07',
        'Staging Load & DR Harness',
        '200 concurrent API reads + 50 concurrent kiosk punches + AES-256-GCM backup & guarded live restore',
        '/api/backup/restore',
        restRes,
        `Reads p95=${loadBenchSummary.readP95Ms}ms (${loadBenchSummary.readThroughputRps} req/s); Punches p95=${loadBenchSummary.punchP95Ms}ms (25/25 dedup); Backup=${restoreBenchSummary.encryptedBackupMs}ms; Restore=${restoreBenchSummary.guardedLiveRestoreMs}ms`
      );
    });
  } finally {
    realtimeHub.closeAll();
    await new Promise<void>((resolve) => server.close(() => resolve()));
    await new Promise<void>((resolve) => prodServer.close(() => resolve()));
    closeDatabaseSafely(activeDb);
    closeDatabaseSafely(prodDb);
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }

  // Write real machine-generated evidence artifact
  const outDir = path.join(process.cwd(), 'test-results');
  fs.mkdirSync(outDir, { recursive: true });
  const evidencePath = path.join(outDir, 'staging-evidence.json');
  fs.writeFileSync(
    evidencePath,
    JSON.stringify(
      {
        build: 'BUILD 17',
        version: '1.13.0',
        executedAtUtc: new Date().toISOString(),
        manilaDate: getManilaDateString(),
        passed,
        failed,
        loadBenchmark: loadBenchSummary,
        backupRestoreBenchmark: restoreBenchSummary,
        structuredLogMetrics: structuredLogStore.getMetrics(),
        evidence,
        unverifiedExternalHardware: [
          'Raspberry Pi 3B+ Kiosk (separate repo/hardware NOT supplied -> NOT TESTED / BLOCKED)',
          'Android Kiosk App (separate repo/APK/device NOT supplied -> NOT TESTED / BLOCKED)',
          'Android Employee Mobile App (separate repo/APK/device NOT supplied -> NOT TESTED / BLOCKED)',
          'Windows Desktop Browser (Linux Chromium headless verified; Windows OS browser NOT tested -> NOT TESTED)',
        ],
      },
      null,
      2
    )
  );

  console.log(`\nBUILD 16 Staging, Security, Impairment & Load Summary: ${passed} passed, ${failed} failed.`);
  console.log(`Load Benchmark: ${JSON.stringify(loadBenchSummary)}`);
  console.log(`Backup/Restore Benchmark: ${JSON.stringify(restoreBenchSummary)}`);
  console.log(`Evidence artifact written to: ${evidencePath}`);
  if (failed > 0) process.exit(1);
}

run().catch((err) => {
  console.error('FATAL Staging suite error:', err);
  process.exit(1);
});
