import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import { initDatabase, closeDatabaseSafely } from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import { hashPassword } from '../server/auth.ts';
import {
  computeOrRecomputePayrollRun,
  getPayrollPolicyTemplate,
  roundAmount,
  type PayrollPolicyRules,
} from '../server/payrollEngine.ts';
import { RealtimeHub } from '../server/realtimeHub.ts';

process.env.NODE_ENV = 'test';
process.env.SESSION_SECRET = crypto.randomBytes(48).toString('hex');

interface SessionJar {
  sessionCookie: string;
  csrfToken: string;
}

function parseSetCookies(res: Response): string[] {
  const anyHeaders = res.headers as unknown as { getSetCookie?: () => string[] };
  if (typeof anyHeaders.getSetCookie === 'function') {
    return anyHeaders.getSetCookie();
  }
  const single = res.headers.get('set-cookie');
  return single ? [single] : [];
}

function extractSessionCookie(setCookies: string[]): string {
  for (const c of setCookies) {
    const first = c.split(';')[0].trim();
    if (first.startsWith('savage_rsucaj_session=')) return first;
  }
  return '';
}

/**
 * SYNTHETIC GOLDEN TEST FIXTURE POLICY (FOR AUTOMATED VERIFICATION ONLY).
 * Explicitly NOT an official RSU Cajidiocan Finance-signed statutory schedule.
 * Institutional Finance must review, replace rates, and sign off prior to production release.
 */
function buildSyntheticGoldenPolicyRules(): PayrollPolicyRules {
  return {
    payFrequency: 'SEMI_MONTHLY',
    standardWorkHoursPerDay: 8,
    prorationBasis: 'SCHEDULED_WORKING_DAYS_IN_MONTH',
    fixedWorkingDaysPerMonth: null,
    allowanceProrationMode: 'PRORATE_BY_SCHEDULED_DAYS',
    employeeTypes: {
      Regular: {
        payBasis: 'MONTHLY',
        overtimeEligible: true,
        holidayPayEligible: true,
        statutoryEligible: true,
        taxEligible: true,
        paidLeaveEligible: true,
        allowanceEligible: true,
      },
      Contractual: {
        payBasis: 'MONTHLY',
        overtimeEligible: true,
        holidayPayEligible: true,
        statutoryEligible: true,
        taxEligible: true,
        paidLeaveEligible: false,
        allowanceEligible: true,
      },
      'Part-Time': {
        payBasis: 'MONTHLY',
        overtimeEligible: false,
        holidayPayEligible: false,
        statutoryEligible: false,
        taxEligible: true,
        paidLeaveEligible: false,
        allowanceEligible: false,
      },
    },
    tardiness: {
      enabled: true,
      roundingIncrementMinutes: 1,
      rateMultiplier: 1.0,
    },
    undertime: {
      enabled: true,
      roundingIncrementMinutes: 1,
      rateMultiplier: 1.0,
    },
    absences: {
      deductPerDayMultiplier: 1.0,
      deductMissingRecordAsAbsent: true,
    },
    leaves: {
      paidLeaveRateMultiplier: 1.0,
      unpaidLeaveDeductionMultiplier: 1.0,
    },
    overtime: {
      enabled: true,
      minimumOvertimeMinutes: 30,
      ordinaryDayMultiplier: 1.25,
      restDayMultiplier: 1.69,
      specialHolidayMultiplier: 1.69,
      regularHolidayMultiplier: 2.6,
    },
    holidaysAndRestDays: {
      regularHolidayWorkedPremiumMultiplier: 1.0,
      specialHolidayUnworkedPaid: false,
      specialHolidayWorkedPremiumMultiplier: 0.3,
      restDayWorkedMultiplier: 1.3,
    },
    statutoryContributions: [
      {
        code: 'TEST-GSIS',
        name: 'Synthetic Test Retirement Share (9% monthly / 2)',
        basis: 'MONTHLY_SALARY',
        mode: 'PERCENTAGE',
        ratePercent: 9,
        periodDivisor: 2,
      },
      {
        code: 'TEST-PAGIBIG',
        name: 'Synthetic Test Housing Fund (Fixed 100/period)',
        basis: 'MONTHLY_SALARY',
        mode: 'FIXED_PER_PERIOD',
        fixedAmount: 100,
      },
    ],
    withholdingTax: {
      enabled: true,
      taxExemptAllowances: true,
      brackets: [
        { min: 0, max: 10000, baseTax: 0, excessRatePercent: 0 },
        { min: 10000.01, max: 25000, baseTax: 0, excessRatePercent: 15 },
        { min: 25000.01, max: null, baseTax: 2250, excessRatePercent: 20 },
      ],
    },
    rounding: {
      currencyDecimals: 2,
      mode: 'HALF_UP',
    },
    specialExceptions: [
      {
        employeeCode: 'EMP-GOLD-001',
        adjustmentType: 'EARNING',
        label: 'Test Taxable Honorarium',
        amount: 500,
        taxable: true,
      },
      {
        employeeCode: 'EMP-GOLD-002',
        adjustmentType: 'DEDUCTION',
        label: 'Test Uniform Deduction',
        amount: 250,
        taxable: false,
      },
    ],
  };
}

async function run() {
  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void> | void) {
    try {
      await fn();
      console.log(`PASS  ${name}`);
      passed++;
    } catch (err) {
      console.error(`FAIL  ${name}`);
      console.error('     ', err instanceof Error ? err.stack || err.message : err);
      failed++;
    }
  }

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-rsucaj-payroll-test-'));
  const dbPath = path.join(tmpDir, 'payroll.db');
  const adminPass = `Adm!${crypto.randomBytes(6).toString('hex')}9A`;
  const makerPass = `Mkr!${crypto.randomBytes(6).toString('hex')}8B`;
  const hrPass = `Hro!${crypto.randomBytes(6).toString('hex')}7C`;
  const empAPass = `Emp!${crypto.randomBytes(6).toString('hex')}6D`;

  let virtualNowMs = Date.parse('2026-05-11T01:00:00.000Z'); // 2026-05-11 09:00 AM Asia/Manila

  const db = initDatabase(dbPath, {
    mode: 'test',
    seedDemoData: false,
    initialAdmin: {
      username: 'finance_checker_admin',
      email: 'finance_checker@rsucaj.edu.ph',
      password: adminPass,
    },
  });

  db.prepare("UPDATE users SET must_change_password = 0 WHERE username = 'finance_checker_admin'").run();

  // Seed deterministic campus org & 3 employees (avoiding any silent demo data)
  const deptId = Number(
    db
      .prepare("INSERT INTO departments (code, name, head_name) VALUES ('BSIT', 'Information Technology', 'Dr. Reyes')")
      .run().lastInsertRowid
  );
  const posRegId = Number(
    db
      .prepare("INSERT INTO positions (code, name, type, base_salary, allowance) VALUES ('INST1', 'Instructor I', 'Regular', 22000, 2200)")
      .run().lastInsertRowid
  );
  const shiftId = Number(
    db
      .prepare("INSERT INTO shifts (name, time_in, time_out, grace_minutes, rest_days, status) VALUES ('Regular Mon-Fri', '08:00 AM', '05:00 PM', 15, 'Sat,Sun', 'Active')")
      .run().lastInsertRowid
  );

  // Add Unpaid Leave policy ('Leave Without Pay', is_paid = 0)
  db.prepare(
    `INSERT OR IGNORE INTO leave_policies
      (leave_type, code, annual_entitlement, track_balance, allow_half_day,
       exclude_weekends_rest_days, exclude_holidays, allow_negative_balance,
       requires_document_after_days, attendance_status, is_paid, is_active, updated_by)
     VALUES ('Leave Without Pay', 'LWOP', 30, 1, 1, 1, 1, 1, 0, 'On Leave', 0, 1, 'test')`
  ).run();

  const empAId = Number(
    db
      .prepare(
        `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status, hired_date, monthly_salary, monthly_allowance)
         VALUES ('EMP-GOLD-001', 'Dela Cruz, Juan', 'juan@rsucaj.edu.ph', ?, ?, ?, 'Active', '2024-01-15', 22000, 2200)`
      )
      .run(deptId, posRegId, shiftId).lastInsertRowid
  );

  // Employee B has a CSV formula-injection payload in full_name to test formula neutralization!
  const empBId = Number(
    db
      .prepare(
        `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status, hired_date, monthly_salary, monthly_allowance)
         VALUES ('EMP-GOLD-002', '=CMD|'' /C calc''!A0', 'formula@rsucaj.edu.ph', ?, ?, ?, 'Active', '2024-01-15', 21000, 2100)`
      )
      .run(deptId, posRegId, shiftId).lastInsertRowid
  );

  // Create Payroll Officer (maker), HR Officer (unauthorized for payroll), and Employee A (self-service payslip)
  const createUser = (username: string, email: string, fullName: string, role: string, pass: string, employeeId: number | null = null) => {
    const { hash, salt } = hashPassword(pass);
    return Number(
      db
        .prepare(
          `INSERT INTO users (username, email, full_name, role, employee_id, password_hash, salt, must_change_password, is_active)
           VALUES (?, ?, ?, ?, ?, ?, ?, 0, 1)`
        )
        .run(username, email, fullName, role, employeeId, hash, salt).lastInsertRowid
    );
  };

  createUser('payroll_maker', 'maker@rsucaj.edu.ph', 'Payroll Maker', 'Payroll Officer', makerPass);
  createUser('hr_viewer', 'hr@rsucaj.edu.ph', 'HR Officer', 'HR Officer', hrPass);
  createUser('emp_juan', 'juan@rsucaj.edu.ph', 'Dela Cruz, Juan', 'Employee', empAPass, empAId);

  // Holidays for split-month golden period 2026-04-27 to 2026-05-08:
  // 2026-05-01 (Fri) Regular Holiday; 2026-05-04 (Mon) Special Non-Working Holiday
  db.prepare("INSERT INTO holidays (date, name, type) VALUES ('2026-05-01', 'Labor Day', 'Regular')").run();
  db.prepare("INSERT INTO holidays (date, name, type) VALUES ('2026-05-04', 'Campus Foundation Day', 'Special Non-Working')").run();

  const hub = new RealtimeHub({ keepaliveIntervalMs: 60_000 });
  const app = express();
  app.use('/api', createApiRouter(db, { dbPath, nowProvider: () => virtualNowMs, realtimeHub: hub }));
  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  const addr = server.address();
  const port = typeof addr === 'object' && addr ? addr.port : 0;
  const baseUrl = `http://127.0.0.1:${port}`;

  async function req(
    urlPath: string,
    init: RequestInit = {},
    jar?: SessionJar
  ): Promise<{ status: number; body: Record<string, unknown>; text: string; headers: Headers; setCookies: string[] }> {
    const headers: Record<string, string> = { ...(init.headers as Record<string, string> | undefined) };
    if (init.body && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
    if (jar?.sessionCookie) headers['Cookie'] = jar.sessionCookie;
    const method = (init.method || 'GET').toUpperCase();
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method) && jar?.csrfToken && !headers['X-CSRF-Token']) {
      headers['X-CSRF-Token'] = jar.csrfToken;
    }
    const res = await fetch(`${baseUrl}${urlPath}`, { ...init, method, headers });
    const text = await res.text();
    let body: Record<string, unknown> = {};
    try {
      body = text ? (JSON.parse(text) as Record<string, unknown>) : {};
    } catch {
      body = { raw: text };
    }
    return { status: res.status, body, text, headers: res.headers, setCookies: parseSetCookies(res) };
  }

  async function login(username: string, password: string): Promise<SessionJar> {
    const r = await req('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier: username, password }),
    });
    assert.equal(r.status, 200, `Login failed for ${username}: ${JSON.stringify(r.body)}`);
    return {
      sessionCookie: extractSessionCookie(r.setCookies),
      csrfToken: String(r.body.csrfToken || ''),
    };
  }

  let adminJar!: SessionJar;
  let makerJar!: SessionJar;
  let hrJar!: SessionJar;
  let empAJar!: SessionJar;
  let draftPolicyId = 0;
  let approvedPolicyId = 0;
  let draftRunId = 0;
  let goldenRunId = 0;

  try {
    adminJar = await login('finance_checker_admin', adminPass);
    makerJar = await login('payroll_maker', makerPass);
    hrJar = await login('hr_viewer', hrPass);
    empAJar = await login('emp_juan', empAPass);

    // -------------------------------------------------------------------------
    // TEST 1: No Policy Blocks Compute (422) & Serves Policy Input Template (Zero Hardcoded Rates)
    // -------------------------------------------------------------------------
    await test('Missing payroll policy blocks compute (422 PAYROLL_POLICY_REQUIRED) and serves Policy Input Template with zero hardcoded tables', async () => {
      const tpl = await req('/api/payroll/policy-template', {}, makerJar);
      assert.equal(tpl.status, 200);
      assert.equal(tpl.body.status, 'TEMPLATE_REQUIRES_FINANCE_INPUT');
      const fields = tpl.body.fields as { rules: PayrollPolicyRules };
      assert.equal(fields.rules.statutoryContributions.length, 0, 'Template must not invent statutory percentages');
      assert.equal(fields.rules.withholdingTax.brackets.length, 0, 'Template must not invent tax brackets');

      const blocked = await req(
        '/api/payroll/compute',
        {
          method: 'POST',
          body: JSON.stringify({
            period_label: 'No Policy Attempt',
            start_date: '2026-04-01',
            end_date: '2026-04-15',
          }),
        },
        makerJar
      );
      assert.equal(blocked.status, 422);
      assert.equal(blocked.body.code, 'PAYROLL_POLICY_REQUIRED');
    });

    // -------------------------------------------------------------------------
    // TEST 2: Draft Unapproved Policy Stamps NOT APPROVED FOR PRODUCTION & Blocks Finalize/Release
    // -------------------------------------------------------------------------
    await test('Draft unapproved policy stamps run NOT APPROVED FOR PRODUCTION and strictly blocks Finalize & Release (409)', async () => {
      const createdPol = await req(
        '/api/payroll/policies',
        {
          method: 'POST',
          body: JSON.stringify({
            policy_code: 'RSU-DRAFT-2026-V0',
            policy_name: 'Unapproved Draft Policy',
            effective_from: '2026-01-01',
            rules: buildSyntheticGoldenPolicyRules(),
          }),
        },
        makerJar
      );
      assert.equal(createdPol.status, 201);
      draftPolicyId = (createdPol.body.policy as { id: number }).id;

      // Compute draft run for clean period 2026-03-01 to 2026-03-15
      const computed = await req(
        '/api/payroll/compute',
        {
          method: 'POST',
          body: JSON.stringify({
            period_label: 'March 2026 Draft Preview',
            start_date: '2026-03-01',
            end_date: '2026-03-15',
            policy_id: draftPolicyId,
          }),
        },
        makerJar
      );
      assert.equal(computed.status, 201);
      assert.equal(computed.body.is_production_approved, false);
      assert.equal(computed.body.policy_approval_status, 'DRAFT_NOT_APPROVED');
      draftRunId = computed.body.id as number;

      // Even a second checker user (Admin) MUST be blocked from finalizing a draft-policy run
      const finBlocked = await req(`/api/payroll/${draftRunId}/finalize`, { method: 'PATCH' }, adminJar);
      assert.equal(finBlocked.status, 409);
      assert.equal(finBlocked.body.code, 'PAYROLL_POLICY_NOT_APPROVED');

      const relBlocked = await req(`/api/payroll/${draftRunId}/release`, { method: 'PATCH' }, adminJar);
      assert.equal(relBlocked.status, 409);
    });

    // -------------------------------------------------------------------------
    // TEST 3: Pre-Compute Reconciliation Blocks on Pending Corrections, Pending Leaves & Unresolved Missing Punches
    // -------------------------------------------------------------------------
    await test('Pre-compute reconciliation blocks on pending corrections, pending leaves, and unresolved Missing Time In/Out', async () => {
      // Create & Finance-approve our synthetic golden policy (explicitly synthetic test fixture)
      const polRes = await req(
        '/api/payroll/policies',
        {
          method: 'POST',
          body: JSON.stringify({
            policy_code: 'RSU-SYNTHETIC-GOLDEN-2026',
            policy_name: 'Synthetic Verification Policy (Pending Institutional Finance Sign-Off)',
            effective_from: '2026-04-01',
            rules: buildSyntheticGoldenPolicyRules(),
          }),
        },
        makerJar
      );
      assert.equal(polRes.status, 201);
      approvedPolicyId = (polRes.body.policy as { id: number }).id;

      const appRes = await req(
        `/api/payroll/policies/${approvedPolicyId}/finance-approve`,
        {
          method: 'POST',
          body: JSON.stringify({
            approval_reference: 'TEST-FIN-MEMO-2026-001',
            notes: 'Synthetic test vector approval for automated verification only.',
          }),
        },
        adminJar
      );
      assert.equal(appRes.status, 200);
      assert.equal((appRes.body.policy as { approval_status: string }).approval_status, 'APPROVED_BY_FINANCE');

      // Populate attendance for split-month period 2026-04-27 to 2026-05-08
      const insAtt = db.prepare(
        `INSERT INTO attendance_records
          (employee_id, date, time_in, time_out, work_hours, late_minutes, undertime_minutes, overtime_minutes, status, device_name)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Kiosk Test')`
      );
      // Emp A records:
      insAtt.run(empAId, '2026-04-27', '08:00 AM', '05:00 PM', '8h 00m', 0, 0, 0, 'Present');
      insAtt.run(empAId, '2026-04-28', '08:30 AM', '05:00 PM', '7h 30m', 30, 0, 0, 'Late');
      insAtt.run(empAId, '2026-04-29', '08:00 AM', '04:00 PM', '7h 00m', 0, 60, 0, 'Undertime');
      insAtt.run(empAId, '2026-04-30', '08:00 AM', '07:00 PM', '10h 00m', 0, 0, 120, 'Present'); // 120m OT
      insAtt.run(empAId, '2026-05-01', '08:00 AM', '05:00 PM', '8h 00m', 0, 0, 0, 'Holiday'); // Regular Holiday WORKED
      insAtt.run(empAId, '2026-05-02', '08:00 AM', '05:00 PM', '8h 00m', 0, 0, 0, 'Rest Day'); // Saturday Rest Day WORKED
      // 2026-05-04 Special Non-Working Holiday UNWORKED (no punch -> specialHolidayUnworkedPaid=false -> deducts 1 May day)
      // 2026-05-05 Approved Paid Vacation Leave
      // 2026-05-06 Half-day Approved Unpaid Leave (LWOP 0.5) + worked other half
      insAtt.run(empAId, '2026-05-06', '01:00 PM', '05:00 PM', '4h 00m', 0, 0, 0, 'Present');
      // 2026-05-07 Absent
      insAtt.run(empAId, '2026-05-07', null, null, '-', 0, 0, 0, 'Absent');
      // 2026-05-08 initially Missing Time Out (unresolved missing punch blocker!)
      insAtt.run(empAId, '2026-05-08', '08:00 AM', null, '-', 0, 0, 0, 'Missing Time Out');

      // Emp B records: perfect attendance on all ordinary days (Apr 27-30, May 5-8) + unworked holidays May 1 & May 4
      for (const d of ['2026-04-27', '2026-04-28', '2026-04-29', '2026-04-30', '2026-05-05', '2026-05-06', '2026-05-07', '2026-05-08']) {
        insAtt.run(empBId, d, '08:00 AM', '05:00 PM', '8h 00m', 0, 0, 0, 'Present');
      }

      // 1) Block on Unresolved Missing Time Out
      const missBlocked = await req(
        '/api/payroll/compute',
        {
          method: 'POST',
          body: JSON.stringify({
            period_label: 'Apr 27 – May 8, 2026 Split Period',
            start_date: '2026-04-27',
            end_date: '2026-05-08',
            policy_id: approvedPolicyId,
          }),
        },
        makerJar
      );
      assert.equal(missBlocked.status, 409);
      assert.equal(missBlocked.body.code, 'UNRESOLVED_MISSING_PUNCHES');

      // Submit a correction for Emp A on 2026-05-08 (creates a PENDING correction!)
      const corrCreate = await req(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empAId,
            attendance_date: '2026-05-08',
            request_type: 'Time Out',
            requested_time: '05:00 PM',
            reason: 'Forgot to scan Time Out',
          }),
        },
        adminJar
      );
      assert.equal(corrCreate.status, 201);
      const corrId = corrCreate.body.id as number;

      // 2) Block on Pending Correction
      const corrBlocked = await req(
        '/api/payroll/compute',
        {
          method: 'POST',
          body: JSON.stringify({
            period_label: 'Apr 27 – May 8, 2026 Split Period',
            start_date: '2026-04-27',
            end_date: '2026-05-08',
            policy_id: approvedPolicyId,
          }),
        },
        makerJar
      );
      assert.equal(corrBlocked.status, 409);
      assert.equal(corrBlocked.body.code, 'PENDING_CORRECTIONS_EXIST');

      // Approve the correction (resolves BOTH pending correction AND Missing Time Out!)
      const corrApp = await req(
        `/api/corrections/${corrId}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved', reviewer_notes: 'Verified with logbook' }) },
        adminJar
      );
      assert.equal(corrApp.status, 200);

      // Submit Paid VL (2026-05-05) and Half-Day Unpaid LWOP (2026-05-06) -> initially Pending!
      const vlCreate = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empAId,
            leave_type: 'Vacation Leave',
            start_date: '2026-05-05',
            end_date: '2026-05-05',
            day_portion: 'FULL',
            reason: 'Family commitment',
          }),
        },
        adminJar
      );
      assert.equal(vlCreate.status, 201);
      const vlId = vlCreate.body.id as number;

      // 3) Block on Pending Leave
      const leaveBlocked = await req(
        '/api/payroll/compute',
        {
          method: 'POST',
          body: JSON.stringify({
            period_label: 'Apr 27 – May 8, 2026 Split Period',
            start_date: '2026-04-27',
            end_date: '2026-05-08',
            policy_id: approvedPolicyId,
          }),
        },
        makerJar
      );
      assert.equal(leaveBlocked.status, 409);
      assert.equal(leaveBlocked.body.code, 'PENDING_LEAVES_EXIST');

      // Approve Paid VL and create + approve Half-Day Unpaid LWOP
      assert.equal(
        (await req(`/api/leaves/${vlId}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, adminJar)).status,
        200
      );

      const lwopCreate = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empAId,
            leave_type: 'Leave Without Pay',
            start_date: '2026-05-06',
            end_date: '2026-05-06',
            day_portion: 'HALF_AM',
            reason: 'Personal errand AM',
          }),
        },
        adminJar
      );
      assert.equal(lwopCreate.status, 201);
      assert.equal(
        (
          await req(
            `/api/leaves/${lwopCreate.body.id}/status`,
            { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) },
            adminJar
          )
        ).status,
        200
      );
    });

    // -------------------------------------------------------------------------
    // TEST 4: Exact Golden Test Vector Verification (Split-Month Proration, Late/UT, OT, Holidays, Rest Day, Paid/Unpaid Leaves, Statutory, Tax, Exceptions)
    // -------------------------------------------------------------------------
    await test('Golden test vectors match independent arithmetic down to 0.01 across split months, OT, holidays, rest day, leaves, statutory & tax', async () => {
      const compRes = await req(
        '/api/payroll/compute',
        {
          method: 'POST',
          body: JSON.stringify({
            period_label: 'Apr 27 – May 8, 2026 Split Period',
            start_date: '2026-04-27',
            end_date: '2026-05-08',
            policy_id: approvedPolicyId,
          }),
        },
        makerJar
      );
      assert.equal(compRes.status, 201);
      assert.equal(compRes.body.is_production_approved, true);
      assert.equal(compRes.body.calculation_version, 1);
      goldenRunId = compRes.body.id as number;

      const ledger = await req(`/api/payroll?run_id=${goldenRunId}`, {}, makerJar);
      assert.equal(ledger.status, 200);
      const items = ledger.body.items as Array<Record<string, number | string>>;
      const itemA = items.find((i) => i.employee_code === 'EMP-GOLD-001')!;
      const itemB = items.find((i) => i.employee_code === 'EMP-GOLD-002')!;
      assert.ok(itemA && itemB);

      // Independent hand-verified Golden Vector math for EMP-GOLD-001 (salary=22,000, allowance=2,200):
      // April 2026 has 22 Mon-Fri scheduled days -> aprDaily = 22000/22 = 1000.00, aprHourly = 125.00
      // May 2026 has 21 Mon-Fri scheduled days   -> mayDaily = 22000/21 = 1047.6190476..., mayHourly = 130.95238095...
      // Period has 4 April weekdays (Apr 27-30) + 6 May weekdays (May 1,4,5,6,7,8) = 10 scheduled days
      const aprDailyA = 22000 / 22;
      const aprHourlyA = aprDailyA / 8;
      const mayDailyA = 22000 / 21;

      const expBasicA = roundAmount(4 * aprDailyA + 6 * mayDailyA); // 4000 + 6285.714286 = 10285.71
      const expAllowA = roundAmount(4 * (2200 / 22) + 6 * (2200 / 21)); // 400 + 628.571429 = 1028.57
      const expOtA = roundAmount((120 / 60) * aprHourlyA * 1.25); // 2 * 125 * 1.25 = 312.50
      // Regular Holiday worked May 1 (+1.0 * mayDaily) + Rest Day worked May 2 (+1.30 * mayDaily)
      const expHolRestA = roundAmount(mayDailyA * 1.0 + mayDailyA * 1.3); // 2.3 * 1047.6190476 = 2409.52
      const expOtherEarnA = 500.0; // special exception honorarium
      const expGrossA = roundAmount(expBasicA + expAllowA + expOtA + expHolRestA + expOtherEarnA);

      const expLateA = roundAmount((30 / 60) * aprHourlyA * 1.0); // 62.50
      const expUtA = roundAmount((60 / 60) * aprHourlyA * 1.0); // 125.00
      // Unworked Special Holiday May 4 (1 mayDaily) + Absent May 7 (1 mayDaily) = 2 * mayDaily
      const expAbsA = roundAmount(2 * mayDailyA); // 2095.24
      // Half-day LWOP May 6 (0.5 * mayDaily)
      const expUnpaidLeaveA = roundAmount(0.5 * mayDailyA); // 523.81
      // Statutory: 9% of 22000 / 2 = 990.00 + 100.00 = 1090.00
      const expStatA = 1090.0;
      // Taxable income (taxExemptAllowances=true):
      // (basic + ot + holRest + taxableOtherEarn) - (late + ut + abs + unpaidLeave + stat)
      const expTaxableA = roundAmount(
        expBasicA + expOtA + expHolRestA + expOtherEarnA - (expLateA + expUtA + expAbsA + expUnpaidLeaveA + expStatA)
      );
      const expTaxA = expTaxableA > 10000 ? roundAmount((expTaxableA - 10000.01) * 0.15) : 0;
      const expDeductA = roundAmount(expLateA + expUtA + expAbsA + expUnpaidLeaveA + expStatA + expTaxA);
      const expNetA = roundAmount(expGrossA - expDeductA);

      assert.equal(itemA.scheduled_working_days, 10);
      assert.equal(itemA.days_paid_leave, 1);
      assert.equal(itemA.days_unpaid_leave, 0.5);
      assert.equal(itemA.days_holiday, 2);
      assert.equal(itemA.days_rest_worked, 1);
      assert.equal(itemA.basic_pay, expBasicA);
      assert.equal(itemA.allowances, expAllowA);
      assert.equal(itemA.overtime_pay, expOtA);
      assert.equal(itemA.holiday_rest_pay, expHolRestA);
      assert.equal(itemA.other_earnings, expOtherEarnA);
      assert.equal(itemA.late_deduction, expLateA);
      assert.equal(itemA.undertime_deduction, expUtA);
      assert.equal(itemA.absence_deduction, expAbsA);
      assert.equal(itemA.unpaid_leave_deduction, expUnpaidLeaveA);
      assert.equal(itemA.statutory_deductions, expStatA);
      assert.equal(itemA.tax_deduction, expTaxA);
      assert.equal(itemA.gross_pay, expGrossA);
      assert.equal(itemA.deductions, expDeductA);
      assert.equal(itemA.net_pay, expNetA);

      // Verify EMP-GOLD-002 special exception deduction (250.00)
      assert.equal(itemB.other_deductions, 250);
    });

    // -------------------------------------------------------------------------
    // TEST 5: Duplicate/Overlapping Period Blocking + Idempotent Recompute + Backdated Correction Version Bump
    // -------------------------------------------------------------------------
    await test('Duplicate & overlapping periods are rejected (409), idempotent recompute is no-op, and backdated correction bumps version cleanly', async () => {
      // Duplicate exact period without recompute=true -> 409 DUPLICATE_PAYROLL_PERIOD
      const dup = await req(
        '/api/payroll/compute',
        {
          method: 'POST',
          body: JSON.stringify({
            period_label: 'Duplicate Period Attempt',
            start_date: '2026-04-27',
            end_date: '2026-05-08',
            policy_id: approvedPolicyId,
          }),
        },
        makerJar
      );
      assert.equal(dup.status, 409);
      assert.equal(dup.body.code, 'DUPLICATE_PAYROLL_PERIOD');

      // Overlapping partial period -> 409 OVERLAPPING_PAYROLL_PERIOD
      const overlap = await req(
        '/api/payroll/compute',
        {
          method: 'POST',
          body: JSON.stringify({
            period_label: 'Overlapping Attempt',
            start_date: '2026-05-04',
            end_date: '2026-05-15',
            policy_id: approvedPolicyId,
          }),
        },
        makerJar
      );
      assert.equal(overlap.status, 409);
      assert.equal(overlap.body.code, 'OVERLAPPING_PAYROLL_PERIOD');

      // Idempotent recompute with ZERO changes -> HTTP 200, idempotentNoOp: true, version remains 1
      const noop = await req(
        '/api/payroll/compute',
        {
          method: 'POST',
          body: JSON.stringify({
            period_label: 'Apr 27 – May 8, 2026 Split Period',
            start_date: '2026-04-27',
            end_date: '2026-05-08',
            policy_id: approvedPolicyId,
            recompute: true,
          }),
        },
        makerJar
      );
      assert.equal(noop.status, 200);
      assert.equal(noop.body.idempotentNoOp, true);
      assert.equal(noop.body.calculation_version, 1);
      const prevSha = String(noop.body.snapshot_sha256);
      const prevNetTotal = (noop.body.totals as { total_net_pay: number }).total_net_pay;

      // Apply backdated approved Full Day correction for Emp A's Absent day on 2026-05-07
      const backCorr = await req(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empAId,
            attendance_date: '2026-05-07',
            request_type: 'Full Day',
            requested_time: '08:00 AM',
            requested_time_out: '05:00 PM',
            reason: 'Field assignment verified by dean',
            document_reference: 'MEMO-DEAN-2026-0507',
          }),
        },
        adminJar
      );
      assert.equal(backCorr.status, 201);
      assert.equal(
        (
          await req(
            `/api/corrections/${backCorr.body.id}/status`,
            { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) },
            adminJar
          )
        ).status,
        200
      );

      // Recompute after backdated correction -> version bumps to 2, SHA changes, total_net_pay increases!
      const recomp = await req(
        '/api/payroll/compute',
        {
          method: 'POST',
          body: JSON.stringify({
            period_label: 'Apr 27 – May 8, 2026 Split Period',
            start_date: '2026-04-27',
            end_date: '2026-05-08',
            policy_id: approvedPolicyId,
            recompute: true,
          }),
        },
        makerJar
      );
      assert.equal(recomp.status, 201);
      assert.equal(recomp.body.idempotentNoOp, false);
      assert.equal(recomp.body.calculation_version, 2);
      assert.notEqual(recomp.body.snapshot_sha256, prevSha);
      assert.ok((recomp.body.totals as { total_net_pay: number }).total_net_pay > prevNetTotal);
    });

    // -------------------------------------------------------------------------
    // TEST 6: Unauthorized RBAC, Maker-Checker Role Separation & Finance Sign-Off Gate
    // -------------------------------------------------------------------------
    await test('Enforces RBAC denial, maker-checker separation, and Finance sign-off gate before release', async () => {
      // HR Officer and Employee are forbidden from compute/finalize/signoff/release
      assert.equal((await req(`/api/payroll/${goldenRunId}/finalize`, { method: 'PATCH' }, hrJar)).status, 403);
      assert.equal((await req(`/api/payroll/${goldenRunId}/release`, { method: 'PATCH' }, hrJar)).status, 403);
      assert.equal((await req(`/api/payroll/${goldenRunId}/finalize`, { method: 'PATCH' }, empAJar)).status, 403);

      // Maker (payroll_maker) CANNOT finalize own computed run -> 403 MAKER_CHECKER_VIOLATION
      const makerFinalize = await req(`/api/payroll/${goldenRunId}/finalize`, { method: 'PATCH' }, makerJar);
      assert.equal(makerFinalize.status, 403);
      assert.equal(makerFinalize.body.code, 'MAKER_CHECKER_VIOLATION');

      // Checker (finance_checker_admin) finalizes run -> 200
      const checkerFinalize = await req(`/api/payroll/${goldenRunId}/finalize`, { method: 'PATCH' }, adminJar);
      assert.equal(checkerFinalize.status, 200);

      // Release BEFORE Finance Sign-Off MUST fail -> 409 FINANCE_SIGNOFF_REQUIRED
      const prematureRelease = await req(`/api/payroll/${goldenRunId}/release`, { method: 'PATCH' }, adminJar);
      assert.equal(prematureRelease.status, 409);
      assert.equal(prematureRelease.body.code, 'FINANCE_SIGNOFF_REQUIRED');

      // Maker CANNOT record Finance sign-off on own run -> 403 MAKER_CHECKER_VIOLATION
      const makerSignoff = await req(
        `/api/payroll/${goldenRunId}/finance-signoff`,
        { method: 'POST', body: JSON.stringify({ finance_signoff_ref: 'DV-2026-05-0099' }) },
        makerJar
      );
      assert.equal(makerSignoff.status, 403);
      assert.equal(makerSignoff.body.code, 'MAKER_CHECKER_VIOLATION');

      // Checker records Finance sign-off -> 200
      const checkerSignoff = await req(
        `/api/payroll/${goldenRunId}/finance-signoff`,
        {
          method: 'POST',
          body: JSON.stringify({
            finance_signoff_ref: 'DV-2026-05-0099',
            notes: 'Verified ledger and disbursement voucher.',
          }),
        },
        adminJar
      );
      assert.equal(checkerSignoff.status, 200);

      // Maker CANNOT release own run -> 403 MAKER_CHECKER_VIOLATION
      const makerRelease = await req(`/api/payroll/${goldenRunId}/release`, { method: 'PATCH' }, makerJar);
      assert.equal(makerRelease.status, 403);
      assert.equal(makerRelease.body.code, 'MAKER_CHECKER_VIOLATION');

      // Checker releases run -> 200
      const checkerRelease = await req(`/api/payroll/${goldenRunId}/release`, { method: 'PATCH' }, adminJar);
      assert.equal(checkerRelease.status, 200);
    });

    // -------------------------------------------------------------------------
    // TEST 7: Strict Immutability (Application + Direct SQLite Triggers on payroll_runs, payroll_items, payroll_audit_log)
    // -------------------------------------------------------------------------
    await test('Finalized/Released runs, items, and payroll_audit_log are strictly immutable via API and SQLite triggers', async () => {
      // Recompute on Released run -> 409 PAYROLL_RUN_LOCKED
      const lockedRecomp = await req(
        '/api/payroll/compute',
        {
          method: 'POST',
          body: JSON.stringify({
            period_label: 'Apr 27 – May 8, 2026 Split Period',
            start_date: '2026-04-27',
            end_date: '2026-05-08',
            policy_id: approvedPolicyId,
            recompute: true,
          }),
        },
        makerJar
      );
      assert.equal(lockedRecomp.status, 409);
      assert.equal(lockedRecomp.body.code, 'PAYROLL_RUN_LOCKED');

      // Direct SQL tamper attempts MUST abort with trigger errors
      assert.throws(
        () => db.prepare('UPDATE payroll_runs SET total_net_pay = 999999 WHERE id = ?').run(goldenRunId),
        /PAYROLL_LOCKED_VIOLATION/
      );
      assert.throws(
        () => db.prepare('DELETE FROM payroll_runs WHERE id = ?').run(goldenRunId),
        /PAYROLL_LOCKED_VIOLATION/
      );
      assert.throws(
        () => db.prepare('UPDATE payroll_items SET net_pay = 1 WHERE payroll_run_id = ?').run(goldenRunId),
        /PAYROLL_LOCKED_VIOLATION/
      );
      assert.throws(
        () => db.prepare('DELETE FROM payroll_items WHERE payroll_run_id = ?').run(goldenRunId),
        /PAYROLL_LOCKED_VIOLATION/
      );
      assert.throws(
        () => db.prepare("UPDATE payroll_audit_log SET action = 'TAMPERED'").run(),
        /IMMUTABLE_AUDIT_VIOLATION/
      );
      assert.throws(
        () => db.prepare('DELETE FROM payroll_audit_log').run(),
        /IMMUTABLE_AUDIT_VIOLATION/
      );

      const auditRes = await req(`/api/payroll/${goldenRunId}/audit`, {}, adminJar);
      assert.equal(auditRes.status, 200);
      const actions = (auditRes.body.entries as Array<{ action: string }>).map((e) => e.action);
      assert.deepEqual(actions, ['COMPUTED', 'RECOMPUTED', 'FINALIZED', 'FINANCE_SIGNED_OFF', 'RELEASED']);
    });

    // -------------------------------------------------------------------------
    // TEST 8: Atomic Transaction Rollback on Simulated Partial Write Failure
    // -------------------------------------------------------------------------
    await test('Atomic BEGIN IMMEDIATE transaction rolls back completely on partial write failure (zero orphaned rows)', async () => {
      const beforeRuns = (db.prepare('SELECT COUNT(*) as c FROM payroll_runs').get() as { c: number }).c;
      const beforeItems = (db.prepare('SELECT COUNT(*) as c FROM payroll_items').get() as { c: number }).c;
      const beforeAudit = (db.prepare('SELECT COUNT(*) as c FROM payroll_audit_log').get() as { c: number }).c;

      assert.throws(
        () =>
          computeOrRecomputePayrollRun(
            db,
            {
              period_label: 'Atomic Rollback Test Period',
              start_date: '2026-06-01',
              end_date: '2026-06-15',
              policy_id: approvedPolicyId,
              _simulateWriteFailureAfterItemIndex: 1,
            },
            { userId: 2, username: 'payroll_maker', role: 'Payroll Officer', ipAddress: '127.0.0.1' },
            virtualNowMs
          ),
        /SIMULATED_PARTIAL_WRITE_FAILURE/
      );

      assert.equal((db.prepare('SELECT COUNT(*) as c FROM payroll_runs').get() as { c: number }).c, beforeRuns);
      assert.equal((db.prepare('SELECT COUNT(*) as c FROM payroll_items').get() as { c: number }).c, beforeItems);
      assert.equal((db.prepare('SELECT COUNT(*) as c FROM payroll_audit_log').get() as { c: number }).c, beforeAudit);
    });

    // -------------------------------------------------------------------------
    // TEST 9: Secure Released Payslips & CSV Formula Injection Neutralization Without Secret Leakage
    // -------------------------------------------------------------------------
    await test('Employee sees ONLY own Released payslip (403 on draft/other employee) and CSV export neutralizes formula injection with zero secret leak', async () => {
      // Employee A /my-payslips returns ONLY the Released goldenRunId (NOT draftRunId!)
      const myRes = await req('/api/payroll/my-payslips', {}, empAJar);
      assert.equal(myRes.status, 200);
      const payslips = myRes.body.payslips as Array<{ payroll_run_id: number; employee_id: number; run_status: string }>;
      assert.equal(payslips.length, 1);
      assert.equal(payslips[0].payroll_run_id, goldenRunId);
      assert.equal(payslips[0].employee_id, empAId);
      assert.equal(payslips[0].run_status, 'Released');

      // Employee A CANNOT view draft/computed run payslip -> 403 PAYSLIP_NOT_RELEASED
      const draftDenied = await req(`/api/payroll/${draftRunId}/payslip/${empAId}`, {}, empAJar);
      assert.equal(draftDenied.status, 403);
      assert.equal(draftDenied.body.code, 'PAYSLIP_NOT_RELEASED');

      // Employee A CANNOT view Employee B's released payslip -> 403 FORBIDDEN
      const otherDenied = await req(`/api/payroll/${goldenRunId}/payslip/${empBId}`, {}, empAJar);
      assert.equal(otherDenied.status, 403);

      // Employee A CAN view own Released payslip -> 200
      const ownAllowed = await req(`/api/payroll/${goldenRunId}/payslip/${empAId}`, {}, empAJar);
      assert.equal(ownAllowed.status, 200);

      // Employee A CANNOT export full payroll CSV -> 403
      assert.equal((await req(`/api/payroll/${goldenRunId}/export.csv`, {}, empAJar)).status, 403);

      // Authorized CSV export neutralizes formula injection (=CMD...) and leaks no secrets
      const csvRes = await req(`/api/payroll/${goldenRunId}/export.csv`, {}, adminJar);
      assert.equal(csvRes.status, 200);
      assert.ok((csvRes.headers.get('content-type') || '').includes('text/csv'));
      assert.ok((csvRes.headers.get('cache-control') || '').includes('no-store'));
      assert.ok(csvRes.text.includes("'=CMD|"), 'CSV export must neutralize leading = formula characters');
      assert.equal(csvRes.text.includes('password_hash'), false);
      assert.equal(csvRes.text.includes('api_token'), false);
      assert.equal(csvRes.text.includes(process.env.SESSION_SECRET!), false);
    });

    // -------------------------------------------------------------------------
    // TEST 10: End-to-End DB & Payroll Report Reconciliation
    // -------------------------------------------------------------------------
    await test('End-to-end reconciliation: sum(payroll_items) === payroll_runs totals === GET /api/reports/payroll', async () => {
      const runRow = db.prepare('SELECT * FROM payroll_runs WHERE id = ?').get(goldenRunId) as {
        total_basic_pay: number;
        total_allowances: number;
        total_overtime_pay: number;
        total_holiday_rest_pay: number;
        total_gross_pay: number;
        total_deductions: number;
        total_net_pay: number;
      };
      const sumRow = db
        .prepare(
          `SELECT ROUND(SUM(basic_pay), 2) as s_basic,
                  ROUND(SUM(allowances), 2) as s_allow,
                  ROUND(SUM(overtime_pay), 2) as s_ot,
                  ROUND(SUM(holiday_rest_pay), 2) as s_hol,
                  ROUND(SUM(gross_pay), 2) as s_gross,
                  ROUND(SUM(deductions), 2) as s_deduct,
                  ROUND(SUM(net_pay), 2) as s_net
           FROM payroll_items WHERE payroll_run_id = ?`
        )
        .get(goldenRunId) as Record<string, number>;

      assert.equal(sumRow.s_basic, runRow.total_basic_pay);
      assert.equal(sumRow.s_allow, runRow.total_allowances);
      assert.equal(sumRow.s_ot, runRow.total_overtime_pay);
      assert.equal(sumRow.s_hol, runRow.total_holiday_rest_pay);
      assert.equal(sumRow.s_gross, runRow.total_gross_pay);
      assert.equal(sumRow.s_deduct, runRow.total_deductions);
      assert.equal(sumRow.s_net, runRow.total_net_pay);

      const report = await req(`/api/reports/payroll?run_id=${goldenRunId}`, {}, adminJar);
      assert.equal(report.status, 200);
      const reportRows = report.body.rows as Array<{ basic_pay: number; net_pay: number; deductions: number }>;
      assert.equal(reportRows.length, 2);
      const repNet = roundAmount(reportRows.reduce((s, r) => s + Number(r.net_pay), 0));
      const repDeduct = roundAmount(reportRows.reduce((s, r) => s + Number(r.deductions), 0));
      assert.equal(repNet, runRow.total_net_pay);
      assert.equal(repDeduct, runRow.total_deductions);
    });
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    hub.closeAll();
    closeDatabaseSafely(db);
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }

  console.log(`\nPayroll Engine & Controls Tests Summary: ${passed} passed, ${failed} failed.`);
  if (failed > 0) process.exit(1);
}

run();
