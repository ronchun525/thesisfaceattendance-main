import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { resolveEmployeeTodayShiftDate } from '../server/employeeToday.ts';
import { resolveEmployeeAccountLink } from '../server/employeeAccounts.ts';
import { RealtimeHub } from '../server/realtimeHub.ts';
import { createRefreshCoalescer } from '../src/lib/refreshCoalescer.ts';

const day = (iso) => Date.parse(iso);
const shift = {time_in: '08:00', time_out: '17:00'};
const previous = {date:'2026-11-22',time_in:'08:00',time_out:null};

test('employee today uses previous open DAY shift through 03:00 Manila cutoff', () => {
  assert.equal(resolveEmployeeTodayShiftDate(day('2026-11-23T00:15:00+08:00'), '2026-11-23', shift, previous, false),'2026-11-22');
  assert.equal(resolveEmployeeTodayShiftDate(day('2026-11-23T03:00:00+08:00'), '2026-11-23', shift, previous, false),'2026-11-22');
  assert.equal(resolveEmployeeTodayShiftDate(day('2026-11-23T03:00:01+08:00'), '2026-11-23', shift, previous, false),'2026-11-23');
});
test('overnight employee shift stays on work date until real shift cutoff', () => {
  const night = {time_in:'22:00',time_out:'07:00'};
  assert.equal(resolveEmployeeTodayShiftDate(day('2026-11-23T02:45:00+08:00'), '2026-11-23', night, {...previous,time_in:'22:00'}, false),'2026-11-22');
  assert.equal(resolveEmployeeTodayShiftDate(day('2026-11-23T14:00:00+08:00'), '2026-11-23', night, {...previous,time_in:'22:00'}, false),'2026-11-23');
});
test('today present wins; closed/absent prior record cannot override day', () => {
  const ts=day('2026-11-23T01:45:00+08:00');
  assert.equal(resolveEmployeeTodayShiftDate(ts,'2026-11-23',shift,previous,true),'2026-11-23');
  assert.equal(resolveEmployeeTodayShiftDate(ts,'2026-11-23',shift,{...previous,time_out:'17:01'},false),'2026-11-23');
  assert.equal(resolveEmployeeTodayShiftDate(ts,'2026-11-23',shift,{...previous,time_in:null},false),'2026-11-23');
  assert.equal(resolveEmployeeTodayShiftDate(ts,'2026-11-23',shift,{...previous,date:'2026-11-21'},false),'2026-11-23');
});

function mockDbWithLinkedAccount(linkedRole = 'Administrator') {
  return {prepare(sql) {
    if (sql.includes('FROM employees WHERE id')) return {get:()=>({id:41,employee_code:'E041',full_name:'Employee 41',department_id:3,status:'Active'})};
    if (sql.includes('FROM users WHERE employee_id')) {
      assert.ok(!sql.includes("role = 'Employee'"),'All roles must be checked for duplicate linked identities');
      return {get:()=>({id:99,role:linkedRole})};
    }
    throw new Error('Unexpected SQL');
  }};
}
test('existing linked Admin/HR account blocks second employee identity login', () => {
  for (const role of ['Administrator','HR Officer','Employee']) {
    const result=resolveEmployeeAccountLink(mockDbWithLinkedAccount(role),41);
    assert.equal(result.ok,false);
    assert.equal(result.code,'EMPLOYEE_ACCOUNT_EXISTS');
  }
});

class ResponseMock extends EventEmitter {
  constructor() { super(); this.frames=[]; this.writableEnded=false; this.destroyed=false; }
  status() {return this;}
  setHeader(){}
  flushHeaders(){}
  write(frame){this.frames.push(frame);return true;}
  end(){this.writableEnded=true;}
}
test('revoked session drops active attendance SSE before event delivery', () => {
  const hub=new RealtimeHub();
  try {
    let active=true;
    const res=new ResponseMock();
    const attached=hub.attachClient(new EventEmitter(),res,{userId:1,username:'emp',role:'Employee',departmentId:3,employeeId:41,permissions:new Set(['attendance:read_self'])},['attendance:updated'],()=>active);
    assert.equal(attached.accepted,true);
    assert.equal(hub.clientCount(),1);
    active=false;
    assert.equal(hub.emitAttendanceUpdated({event_uid:'event',employee_id:41,department_id:3,shift_date:'2026-11-22',action:'TIME_IN',source:'kiosk'}), 0);
    assert.equal(hub.clientCount(),0);
    assert.equal(res.writableEnded,true);
    assert.ok(!res.frames.join('').includes('event: attendance:updated'));
  } finally {hub.closeAll();}
});
test('department SSE receives kiosk attendance only within department', () => {
  const hub=new RealtimeHub();
  try {
    const res=new ResponseMock();
    hub.attachClient(new EventEmitter(),res,{userId:2,username:'head',role:'Department Head',departmentId:3,employeeId:null,permissions:new Set(['attendance:read'])},['attendance:updated']);
    assert.equal(hub.emitAttendanceUpdated({employee_id:41,department_id:3,shift_date:'2026-11-22',action:'TIME_IN',source:'kiosk'}),1);
    assert.equal(hub.emitAttendanceUpdated({employee_id:42,department_id:4,shift_date:'2026-11-22',action:'TIME_IN',source:'kiosk'}),0);
    assert.equal(res.frames.filter(x=>x.includes('event: attendance:updated')).length,1);
  } finally {hub.closeAll();}
});
test('burst realtime updates become first fetch plus at most one trailing refresh', async () => {
  let counter=0;
  let unblock;
  const gate = new Promise(resolve => {unblock=resolve;});
  const coalesced=createRefreshCoalescer(async()=> { counter++; if(counter===1) await gate; });
  const first=coalesced();
  const second=coalesced();
  const third=coalesced();
  assert.equal(counter,1);
  unblock();
  await Promise.all([first,second,third]);
  assert.equal(counter,2);
  await coalesced();
  assert.equal(counter,3);
});
test('rejected refresh is recoverable and does not leave coalescer locked', async () => {
  let runs=0;
  const run=createRefreshCoalescer(async()=>{runs++; if(runs===1) throw Error('offline');});
  await assert.rejects(run(),/offline/);
  await run();
  assert.equal(runs,2);
});
