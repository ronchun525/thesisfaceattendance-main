import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { verifyBuild30Evidence } from '../scripts/build30-release-gate.mjs';

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const template = JSON.parse(fs.readFileSync(path.join(repo, 'BUILD30_EVIDENCE_TEMPLATE.json'), 'utf8'));
const gates = Object.keys(template.gates);
function create() { const root = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-b30-')); return { root, json: path.join(root,'status.json') }; }
function write(root, data) { fs.writeFileSync(root.json, JSON.stringify(data)); }
function populate(d) {
  const m = structuredClone(template);
  gates.forEach((key,i) => {
    const evidence_file = `${key}.log`;
    const content = `Independent gate ${key}: fixture #${i}. This is not real test evidence.`;
    fs.writeFileSync(path.join(d.root, evidence_file), content);
    m.gates[key] = {status:'PASS', evidence_file, evidence_sha256:crypto.createHash('sha256').update(content).digest('hex'), reviewer:'Test Fixture Only'};
  });
  return m;
}
test('30.1 evidence absent fails closed',()=>{
 assert.equal(verifyBuild30Evidence('/this/does/not/exist/status.json').status,'NO_GO');
});
test('30.2 release evidence template is NO_GO',()=>{
 const d=create(); try {write(d,template); assert.equal(verifyBuild30Evidence(d.json).status,'NO_GO');}
 finally {fs.rmSync(d.root,{recursive:true,force:true});}
});
test('30.3 file hash mismatch blocks release',()=>{
 const d=create(); try {const m=populate(d); m.gates[gates[0]].evidence_sha256='0'.repeat(64); write(d,m);
 assert.ok(verifyBuild30Evidence(d.json).problems.some(x=>x.includes('mismatched evidence SHA256')));}
 finally {fs.rmSync(d.root,{recursive:true,force:true});}
});
test('30.4 reused artifact file blocks release',()=>{
 const d=create(); try {const m=populate(d); m.gates[gates[1]].evidence_file=m.gates[gates[0]].evidence_file;
 m.gates[gates[1]].evidence_sha256=m.gates[gates[0]].evidence_sha256; write(d,m);
 assert.ok(verifyBuild30Evidence(d.json).problems.some(x=>x.includes('reused')));}
 finally {fs.rmSync(d.root,{recursive:true,force:true});}
});
test('30.5 symlink is not test evidence',()=>{
 const d=create(); try {const m=populate(d); const k=gates[0]; const actual=path.join(d.root,m.gates[k].evidence_file);
 fs.renameSync(actual,actual+'.real'); fs.symlinkSync(actual+'.real', actual); write(d,m);
 assert.ok(verifyBuild30Evidence(d.json).problems.some(x=>x.includes('linked evidence')));}
 finally {fs.rmSync(d.root,{recursive:true,force:true});}
});
test('30.6 unknown gate blocks release',()=>{
 const d=create(); try {const m=populate(d); m.gates.not_an_approved_gate={status:'PASS'}; write(d,m);
 assert.ok(verifyBuild30Evidence(d.json).problems.some(x=>x.includes('Unknown gate')));}
 finally {fs.rmSync(d.root,{recursive:true,force:true});}
});
test('30.7 missing reviewer blocks release',()=>{
 const d=create(); try {const m=populate(d); m.gates[gates[0]].reviewer=''; write(d,m);
 assert.ok(verifyBuild30Evidence(d.json).problems.some(x=>x.includes('missing named reviewer')));}
 finally {fs.rmSync(d.root,{recursive:true,force:true});}
});
test('30.8 complete synthetic inventory remains review-required, never production-certified',()=>{
 const d=create(); try {const m=populate(d); write(d,m);
 assert.equal(verifyBuild30Evidence(d.json).status,'EVIDENCE_PRESENT_REVIEW_REQUIRED');}
 finally {fs.rmSync(d.root,{recursive:true,force:true});}
});
test('30.9 evidence traversal blocks release',()=>{
 const d=create(); try {const m=populate(d); m.gates[gates[0]].evidence_file='../outside.log'; write(d,m);
 assert.ok(verifyBuild30Evidence(d.json).problems.some(x=>x.includes('invalid evidence relative path')));}
 finally {fs.rmSync(d.root,{recursive:true,force:true});}
});
