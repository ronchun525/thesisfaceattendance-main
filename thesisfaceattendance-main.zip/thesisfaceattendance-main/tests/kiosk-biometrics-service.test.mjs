import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import test from 'node:test';
import {
  classifyCameraError,
  computeExpandedFaceCropBox,
  decodeClassifierLiveScore,
  KIOSK_EMBEDDING_DIMENSION,
  KIOSK_MODEL_SPECS,
  KioskBiometricsService,
  KioskTfliteModelLoader,
  l2NormalizeEmbedding,
  preprocessLivenessTensor,
  preprocessPadTensor,
  preprocessRecognitionTensor,
  resolveKioskModelsDir,
  resolveModelArtifactUrl,
  verifyModelBufferIntegrity,
} from '../src/lib/kioskBiometrics.ts';
import {
  encodeLivenessBgrNchw,
  encodePadRgbNhwc,
  encodeRecognitionRgbNhwc,
} from '../server/webKioskBiometrics.ts';

test('resolveKioskModelsDir reads KIOSK_MODELS_DIR env var and resolveModelArtifactUrl maps paths cleanly', () => {
  const prev = process.env.KIOSK_MODELS_DIR;
  try {
    process.env.KIOSK_MODELS_DIR = '/var/lib/savage-rsucaj/models';
    assert.equal(resolveKioskModelsDir(), '/var/lib/savage-rsucaj/models');
    assert.equal(resolveKioskModelsDir('./custom-models'), './custom-models');

    // Filesystem dirs route through the verified Express artifact endpoint
    assert.equal(
      resolveModelArtifactUrl('anti_spoofing_pad.tflite', '/var/lib/savage-rsucaj/models'),
      '/api/kiosk/web/models/anti_spoofing_pad.tflite'
    );
    assert.equal(
      resolveModelArtifactUrl('liveness_detection.tflite', './models'),
      '/api/kiosk/web/models/liveness_detection.tflite'
    );

    // Explicit web-relative or HTTPS URLs map directly
    assert.equal(
      resolveModelArtifactUrl('face_recognition.tflite', '/models'),
      '/models/face_recognition.tflite'
    );
    assert.equal(
      resolveModelArtifactUrl('face_recognition.tflite', 'https://rsu-cajidiocan.tech/models/'),
      'https://rsu-cajidiocan.tech/models/face_recognition.tflite'
    );
  } finally {
    if (prev === undefined) delete process.env.KIOSK_MODELS_DIR;
    else process.env.KIOSK_MODELS_DIR = prev;
  }
});

test('Browser PAD, Liveness, and Recognition tensor encoders match server BUILD 20 contracts exactly', () => {
  // 80x80 synthetic RGBA image
  const rgba80 = new Uint8ClampedArray(80 * 80 * 4);
  for (let i = 0; i < 80 * 80; i++) {
    rgba80[i * 4] = (i * 13) % 256; // R
    rgba80[i * 4 + 1] = (i * 29) % 256; // G
    rgba80[i * 4 + 2] = (i * 47) % 256; // B
    rgba80[i * 4 + 3] = 255; // A
  }

  const browserPad = preprocessPadTensor(rgba80, 80, 80);
  const serverPad = encodePadRgbNhwc(rgba80, 80, 80);
  assert.deepEqual(browserPad.shape, [1, 80, 80, 3]);
  assert.equal(browserPad.layout, 'NHWC');
  assert.equal(browserPad.colorOrder, 'RGB');
  assert.equal(browserPad.data.length, serverPad.length);
  for (let i = 0; i < serverPad.length; i++) {
    assert.equal(browserPad.data[i], serverPad[i]);
  }

  const browserLiv = preprocessLivenessTensor(rgba80, 80, 80);
  const serverLiv = encodeLivenessBgrNchw(rgba80, 80, 80);
  assert.deepEqual(browserLiv.shape, [1, 3, 80, 80]);
  assert.equal(browserLiv.layout, 'NCHW');
  assert.equal(browserLiv.colorOrder, 'BGR');
  assert.equal(browserLiv.data.length, serverLiv.length);
  for (let i = 0; i < serverLiv.length; i++) {
    assert.equal(browserLiv.data[i], serverLiv[i]);
  }

  // 112x112 synthetic RGBA image
  const rgba112 = new Uint8ClampedArray(112 * 112 * 4);
  for (let i = 0; i < 112 * 112; i++) {
    rgba112[i * 4] = (i * 17) % 256;
    rgba112[i * 4 + 1] = (i * 31) % 256;
    rgba112[i * 4 + 2] = (i * 53) % 256;
    rgba112[i * 4 + 3] = 255;
  }

  const browserRec = preprocessRecognitionTensor(rgba112, 112, 112);
  const serverRec = encodeRecognitionRgbNhwc(rgba112, 112, 112);
  assert.deepEqual(browserRec.shape, [1, 112, 112, 3]);
  assert.equal(browserRec.layout, 'NHWC');
  assert.equal(browserRec.colorOrder, 'RGB');
  assert.equal(browserRec.data.length, serverRec.length);
  for (let i = 0; i < serverRec.length; i++) {
    assert.equal(browserRec.data[i], serverRec[i]);
  }
});

test('computeExpandedFaceCropBox, decodeClassifierLiveScore, and l2NormalizeEmbedding behave deterministically and fail-closed', () => {
  // Centered box near edge must clamp inside frame bounds
  const edgeCrop = computeExpandedFaceCropBox({ x: 0.02, y: 0.02, width: 0.2, height: 0.25 }, 640, 480, 2.7);
  assert.ok(edgeCrop.sx >= 0 && edgeCrop.sy >= 0);
  assert.ok(edgeCrop.sx + edgeCrop.sw <= 640);
  assert.ok(edgeCrop.sy + edgeCrop.sh <= 480);

  // Fallback when FaceDetector boundingBox is null
  const fallbackCrop = computeExpandedFaceCropBox(null, 640, 480, 1.25);
  assert.ok(fallbackCrop.sw > 0 && fallbackCrop.sh > 0);
  assert.ok(fallbackCrop.sx + fallbackCrop.sw <= 640);
  assert.ok(fallbackCrop.sy + fallbackCrop.sh <= 480);

  // Classifier decoding: logits, pre-normalized probs, and NaN fail-closed
  const fromLogits = decodeClassifierLiveScore([4.2, -1.0, -2.0], 0);
  assert.equal(fromLogits.valid, true);
  assert.equal(fromLogits.wasAlreadyProbability, false);
  assert.ok(fromLogits.liveProbability > 0.98);

  const fromProbs = decodeClassifierLiveScore([0.05, 0.91, 0.04], 1);
  assert.equal(fromProbs.valid, true);
  assert.equal(fromProbs.wasAlreadyProbability, true);
  assert.ok(Math.abs(fromProbs.liveProbability - 0.91) < 1e-6);

  const fromNaN = decodeClassifierLiveScore([0.1, Number.NaN, 0.2], 1);
  assert.equal(fromNaN.valid, false);
  assert.equal(fromNaN.liveProbability, 0);

  // 192D L2 normalization
  const rawVec = Array.from({ length: KIOSK_EMBEDDING_DIMENSION }, (_, idx) => (idx % 5) - 2);
  const unit = l2NormalizeEmbedding(rawVec);
  assert.ok(unit instanceof Float32Array);
  let normSq = 0;
  for (let i = 0; i < unit.length; i++) normSq += unit[i] * unit[i];
  assert.ok(Math.abs(Math.sqrt(normSq) - 1.0) < 1e-5);

  // Zero-vector and wrong-dimension fail closed
  assert.equal(l2NormalizeEmbedding(new Float32Array(KIOSK_EMBEDDING_DIMENSION)), null);
  assert.equal(l2NormalizeEmbedding([1, 2, 3]), null);
});

test('verifyModelBufferIntegrity and KioskTfliteModelLoader enforce TFL3 magic, SHA-256, and honest missing states', async () => {
  // Valid synthetic TFL3 buffer with matching SHA-256
  const validBuf = new Uint8Array([0x20, 0x00, 0x00, 0x00, 0x54, 0x46, 0x4c, 0x33, 0x01, 0x02, 0x03, 0x04]);
  const validSha = crypto.createHash('sha256').update(validBuf).digest('hex');
  const okCheck = await verifyModelBufferIntegrity(validBuf.buffer, validSha);
  assert.equal(okCheck.valid, true);
  assert.equal(okCheck.sha256, validSha);

  // Wrong magic header fails closed
  const badMagic = new Uint8Array([0x20, 0x00, 0x00, 0x00, 0x42, 0x41, 0x44, 0x30, 0x01, 0x02]);
  const badMagicCheck = await verifyModelBufferIntegrity(badMagic.buffer, validSha);
  assert.equal(badMagicCheck.valid, false);
  assert.equal(badMagicCheck.errorCode, 'INVALID_HEADER');

  // Wrong SHA-256 fails closed
  const badHashCheck = await verifyModelBufferIntegrity(validBuf.buffer, '0'.repeat(64));
  assert.equal(badHashCheck.valid, false);
  assert.equal(badHashCheck.errorCode, 'HASH_MISMATCH');

  // KioskTfliteModelLoader with mocked fetch simulating status + 404 + invalid header + hash mismatch
  const mockFetch = async (input) => {
    const url = String(input);
    if (url.endsWith('/api/kiosk/web/models/status')) {
      return new Response(
        JSON.stringify({
          models_dir: '/opt/savage/models',
          all_models_verified_on_disk: false,
          server_inference_available: false,
          production_attendance_ready: false,
          blocking_reasons: ['Missing models'],
          models: {
            anti_spoofing_pad: {
              key: 'anti_spoofing_pad',
              filename: KIOSK_MODEL_SPECS.anti_spoofing_pad.filename,
              architecture: 'MiniFASNetV1',
              status: 'MISSING',
              size_bytes: null,
              expected_sha256: KIOSK_MODEL_SPECS.anti_spoofing_pad.expectedSha256,
              actual_sha256: null,
              reason: 'Missing on disk',
            },
            liveness_detection: {
              key: 'liveness_detection',
              filename: KIOSK_MODEL_SPECS.liveness_detection.filename,
              architecture: 'MiniFASNetV2',
              status: 'INVALID_HEADER',
              size_bytes: 10,
              expected_sha256: KIOSK_MODEL_SPECS.liveness_detection.expectedSha256,
              actual_sha256: null,
              reason: 'Invalid header',
            },
            face_recognition: {
              key: 'face_recognition',
              filename: KIOSK_MODEL_SPECS.face_recognition.filename,
              architecture: 'MobileFaceNet',
              status: 'HASH_MISMATCH',
              size_bytes: 12,
              expected_sha256: KIOSK_MODEL_SPECS.face_recognition.expectedSha256,
              actual_sha256: validSha,
              reason: 'Hash mismatch',
            },
          },
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    }
    if (url.endsWith('anti_spoofing_pad.tflite')) {
      return new Response(JSON.stringify({ error: 'Not found on server' }), { status: 404 });
    }
    if (url.endsWith('liveness_detection.tflite')) {
      return new Response(badMagic, { status: 200 });
    }
    if (url.endsWith('face_recognition.tflite')) {
      return new Response(validBuf, { status: 200 });
    }
    return new Response('Not found', { status: 404 });
  };

  const loader = new KioskTfliteModelLoader({ fetchImpl: mockFetch });
  const records = await loader.loadAllModels({ inspectStatusFirst: true });

  assert.equal(loader.getModelsDir(), '/opt/savage/models');
  assert.equal(records.anti_spoofing_pad.state, 'MISSING');
  assert.equal(records.liveness_detection.state, 'INVALID_HEADER');
  assert.equal(records.face_recognition.state, 'HASH_MISMATCH');
  assert.equal(loader.getLoadedBuffer('face_recognition'), null);
  loader.dispose();
});

test('KioskBiometricsService initializes camera with OverconstrainedError fallback and tracks disconnect cleanly', async () => {
  const prevNavigator = globalThis.navigator;
  let attempts = 0;
  let endedCb = null;
  let stopped = false;

  const mockTrack = {
    readyState: 'live',
    stop() {
      stopped = true;
      this.readyState = 'ended';
    },
    addEventListener(event, cb) {
      if (event === 'ended') endedCb = cb;
    },
  };
  const mockStream = {
    getTracks: () => [mockTrack],
    getVideoTracks: () => [mockTrack],
  };

  Object.defineProperty(globalThis, 'navigator', {
    configurable: true,
    value: {
      mediaDevices: {
        getUserMedia: async () => {
          attempts += 1;
          if (attempts === 1) {
            const err = new Error('Overconstrained');
            err.name = 'OverconstrainedError';
            throw err;
          }
          return mockStream;
        },
      },
    },
  });

  try {
    const service = new KioskBiometricsService({ modelsDir: './models' });
    let disconnectNotified = false;
    const stream = await service.initializeCamera(null, {
      onTrackEnded: () => {
        disconnectNotified = true;
      },
    });
    assert.equal(stream, mockStream);
    assert.equal(attempts, 2);
    assert.equal(service.getCameraState().active, true);

    // Simulate camera unplug event
    assert.ok(typeof endedCb === 'function');
    endedCb();
    assert.equal(disconnectNotified, true);
    assert.equal(service.getCameraState().error?.code, 'DISCONNECTED');

    service.dispose();
    assert.equal(stopped, true);
    assert.equal(service.getCameraState().active, false);

    // Error classification check
    const permErr = new Error('Denied');
    permErr.name = 'NotAllowedError';
    assert.equal(classifyCameraError(permErr).code, 'PERMISSION_DENIED');
  } finally {
    Object.defineProperty(globalThis, 'navigator', {
      configurable: true,
      value: prevNavigator,
    });
  }
});
