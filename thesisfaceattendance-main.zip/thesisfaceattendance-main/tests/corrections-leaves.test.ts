import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import { closeDatabaseSafely, initDatabase } from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import { RealtimeHub } from '../server/realtimeHub.ts';

let passed = 0;
let failed = 0;

async function test(name: string, fn: () => Promise<void> | void) {
  try {
    await fn();
    passed++;
    console.log(`PASS  ${name}`);
  } catch (err) {
    failed++;
    console.error(`FAIL  ${name}`);
    console.error('     ', err instanceof Error ? err.stack || err.message : err);
  }
}

interface SessionJar {
  sessionCookie: string;
  csrfToken: string;
}

function parseCookies(setCookieHeaders: string[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const raw of setCookieHeaders) {
    const first = raw.split(';')[0];
    const eq = first.indexOf('=');
    if (eq > 0) out[first.slice(0, eq).trim()] = first.slice(eq + 1).trim();
  }
  return out;
}

async function run() {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-b11-cl-'));
  const dbPath = path.join(tmpDir, 'cl.db');
  const sessionSecret = crypto.randomBytes(48).toString('hex');
  const adminPass = `Adm!${crypto.randomBytes(6).toString('hex')}9A`;
  const hrPass = `Hro!${crypto.randomBytes(6).toString('hex')}8B`;
  const payrollPass = `Pay!${crypto.randomBytes(6).toString('hex')}7C`;
  const deptHeadPass = `Dhd!${crypto.randomBytes(6).toString('hex')}6D`;
  const empPass = `Emp!${crypto.randomBytes(6).toString('hex')}5E`;

  // Controllable virtual clock: Wednesday 2026-05-13 10:00:00 Asia/Manila (02:00:00 UTC)
  let virtualNowMs = Date.parse('2026-05-13T02:00:00.000Z');
  const nowProvider = () => virtualNowMs;

  process.env.SESSION_SECRET = sessionSecret;

  const db = initDatabase(dbPath, {
    mode: 'test',
    seedDemoData: true,
    initialAdmin: {
      username: 'b11_admin',
      email: 'b11_admin@rsucaj.edu.ph',
      password: adminPass,
    },
  });
  db.prepare(`UPDATE users SET must_change_password = 0 WHERE username = 'b11_admin'`).run();

  const hub = new RealtimeHub({ keepaliveIntervalMs: 60_000 });
  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '5mb' }));
  app.use('/api', createApiRouter(db, { nowProvider, realtimeHub: hub }));

  const server = await new Promise<http.Server>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const addr = server.address();
  assert.ok(addr && typeof addr !== 'string');
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  async function req(
    urlPath: string,
    options: RequestInit = {},
    jar?: SessionJar
  ): Promise<{ status: number; body: Record<string, unknown>; headers: Headers }> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...((options.headers as Record<string, string>) || {}),
    };
    if (jar?.sessionCookie) headers.Cookie = jar.sessionCookie;
    if (jar?.csrfToken && options.method && !['GET', 'HEAD', 'OPTIONS'].includes(options.method.toUpperCase())) {
      headers['X-CSRF-Token'] = jar.csrfToken;
    }
    const res = await fetch(`${baseUrl}${urlPath}`, { ...options, headers });
    const text = await res.text();
    let body: Record<string, unknown> = {};
    try {
      body = text ? JSON.parse(text) : {};
    } catch {
      body = { raw: text };
    }
    return { status: res.status, body, headers: res.headers };
  }

  async function login(identifier: string, password: string): Promise<SessionJar> {
    const res = await req('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier, password }),
    });
    assert.equal(res.status, 200, `Login failed for ${identifier}: ${JSON.stringify(res.body)}`);
    const setCookies = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    const cookies = parseCookies(setCookies);
    assert.ok(cookies.savage_rsucaj_session);
    return {
      sessionCookie: `savage_rsucaj_session=${cookies.savage_rsucaj_session}`,
      csrfToken: String(res.body.csrfToken || ''),
    };
  }

  try {
    const adminJar = await login('b11_admin', adminPass);

    // Fetch active employees across at least 2 distinct departments + kiosk token
    const empsRes = await req('/api/employees?limit=50', {}, adminJar);
    const employees = empsRes.body.data as Array<{
      id: number;
      employee_code: string;
      full_name: string;
      department_id: number;
    }>;
    assert.ok(employees.length >= 6);

    const empA = employees[0];
    const empB = employees.find((e) => e.department_id !== empA.department_id) || employees[1];
    const empC = employees.find((e) => e.id !== empA.id && e.id !== empB.id)!;
    const empD = employees.find((e) => e.id !== empA.id && e.id !== empB.id && e.id !== empC.id)!;
    const empE = employees.find((e) => e.id !== empA.id && e.id !== empB.id && e.id !== empC.id && e.id !== empD.id)!;
    const empF = employees.find(
      (e) => ![empA.id, empB.id, empC.id, empD.id, empE.id].includes(e.id)
    )!;

    const devs = (await req('/api/devices', {}, adminJar)).body.data as Array<{ id: number }>;
    const rotDevs = await req(`/api/devices/${devs[0].id}/rotate-token`, { method: 'POST', body: JSON.stringify({}) }, adminJar);
    assert.equal(rotDevs.status, 200);
    const kioskToken = String(rotDevs.body.api_token);

    // Provision role accounts for RBAC authorization tests
    const createUser = async (payload: Record<string, unknown>) => {
      const r = await req('/api/users', { method: 'POST', body: JSON.stringify(payload) }, adminJar);
      assert.equal(r.status, 201, `Create user failed: ${JSON.stringify(r.body)}`);
    };
    await createUser({
      username: 'b11_hr',
      email: 'b11_hr@rsucaj.edu.ph',
      full_name: 'HR Reviewer',
      role: 'HR Officer',
      password: hrPass,
      must_change_password: false,
    });
    await createUser({
      username: 'b11_payroll',
      email: 'b11_payroll@rsucaj.edu.ph',
      full_name: 'Payroll Reviewer',
      role: 'Payroll Officer',
      password: payrollPass,
      must_change_password: false,
    });
    await createUser({
      username: 'b11_depthead',
      email: 'b11_depthead@rsucaj.edu.ph',
      full_name: 'Dept A Head',
      role: 'Department Head',
      department_id: empA.department_id,
      password: deptHeadPass,
      must_change_password: false,
    });
    await createUser({
      username: 'b11_emp',
      email: 'b11_emp@rsucaj.edu.ph',
      full_name: empA.full_name,
      role: 'Employee',
      employee_id: empA.id,
      password: empPass,
      must_change_password: false,
    });

    const hrJar = await login('b11_hr', hrPass);
    const payrollJar = await login('b11_payroll', payrollPass);
    const deptHeadJar = await login('b11_depthead', deptHeadPass);
    const empJar = await login('b11_emp', empPass);

    // =========================================================================
    // PART A — CORRECTIONS TESTS (ZERO FABRICATED PUNCHES, IMMUTABLE AUDIT, REVERSAL)
    // =========================================================================

    await test('Unpaired Time In correction NEVER fabricates 05:00 PM Time Out (explicit Missing Time Out)', async () => {
      const pastDate = '2026-04-14'; // Tuesday (past relative to 2026-05-13)
      const created = await req(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empA.id,
            attendance_date: pastDate,
            request_type: 'Time In',
            requested_time: '07:58 AM',
            reason: 'Kiosk camera briefly obstructed during morning arrival',
          }),
        },
        empJar
      );
      assert.equal(created.status, 201);

      const approved = await req(
        `/api/corrections/${created.body.id}/status`,
        {
          method: 'PATCH',
          body: JSON.stringify({ status: 'Approved', reviewer_notes: 'Verified in guard logbook' }),
        },
        hrJar
      );
      assert.equal(approved.status, 200);
      assert.equal(approved.body.resulting_status, 'Missing Time Out');
      assert.equal(approved.body.resulting_time_in, '07:58 AM');
      assert.equal(approved.body.resulting_time_out, null);
      assert.ok(approved.body.incomplete_punch_warning);

      // Verify in attendance_records: NO fabricated 05:00 PM
      const att = await req(`/api/attendance?date=${pastDate}`, {}, adminJar);
      const row = (att.body.data as Array<{ employee_id: number; time_in: string | null; time_out: string | null; status: string }>)
        .find((r) => r.employee_id === empA.id);
      assert.ok(row);
      assert.equal(row.time_in, '07:58 AM');
      assert.equal(row.time_out, null);
      assert.equal(row.status, 'Missing Time Out');

      // Duplicate approve / reject must be rejected with 409 ALREADY_REVIEWED
      const dupApprove = await req(
        `/api/corrections/${created.body.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) },
        hrJar
      );
      assert.equal(dupApprove.status, 409);
      assert.equal(dupApprove.body.code, 'ALREADY_REVIEWED');

      const dupReject = await req(
        `/api/corrections/${created.body.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Rejected' }) },
        hrJar
      );
      assert.equal(dupReject.status, 409);
      assert.equal(dupReject.body.code, 'ALREADY_REVIEWED');
    });

    await test('Unpaired Time Out correction NEVER fabricates 08:00 AM Time In (explicit Missing Time In)', async () => {
      const pastDate = '2026-04-15'; // Wednesday
      const created = await req(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empA.id,
            attendance_date: pastDate,
            request_type: 'Time Out',
            requested_time: '05:05 PM',
            reason: 'Forgot morning scan; verified afternoon departure',
          }),
        },
        adminJar
      );
      assert.equal(created.status, 201);

      const approved = await req(
        `/api/corrections/${created.body.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) },
        adminJar
      );
      assert.equal(approved.status, 200);
      assert.equal(approved.body.resulting_time_in, null);
      assert.equal(approved.body.resulting_time_out, '05:05 PM');
      assert.equal(approved.body.resulting_status, 'Missing Time In');
    });

    await test('Pairing existing kiosk Time In with Time Out correction preserves kiosk event, logs immutable audit, and supports audit-safe reversal', async () => {
      // Capture authentic kiosk TIME_IN on 2026-05-13 08:04 AM Manila (00:04 UTC)
      virtualNowMs = Date.parse('2026-05-13T00:04:00.000Z');
      const kioskPunch = await req('/api/kiosk/punch', {
        method: 'POST',
        headers: { 'x-kiosk-token': kioskToken },
        body: JSON.stringify({
          employee_code: empA.employee_code,
          punch_type: 'TIME_IN',
          event_uid: 'b11-orig-kiosk-in-001',
          device_timestamp: new Date(virtualNowMs).toISOString(),
        }),
      });
      assert.equal(kioskPunch.status, 201);

      // Advance clock to 17:30 Manila
      virtualNowMs = Date.parse('2026-05-13T09:30:00.000Z');

      // File Time Out correction
      const corr = await req(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empA.id,
            attendance_date: '2026-05-13',
            request_type: 'Time Out',
            requested_time: '05:02 PM',
            reason: 'Kiosk power outage during dismissal',
            document_reference: 'MEMO-B11-001',
          }),
        },
        empJar
      );
      assert.equal(corr.status, 201);

      // HR approves with slight verified adjustment (05:00 PM)
      const approved = await req(
        `/api/corrections/${corr.body.id}/status`,
        {
          method: 'PATCH',
          body: JSON.stringify({
            status: 'Approved',
            approved_time: '05:00 PM',
            reviewer_notes: 'Matched against building CCTV log',
          }),
        },
        hrJar
      );
      assert.equal(approved.status, 200);
      assert.equal(approved.body.resulting_time_in, '08:04 AM');
      assert.equal(approved.body.resulting_time_out, '05:00 PM');
      assert.equal(approved.body.resulting_status, 'Present');

      // Inspect original vs requested vs approved & immutable audit trail
      const auditRes = await req(`/api/corrections/${corr.body.id}/audit`, {}, hrJar);
      assert.equal(auditRes.status, 200);
      const corrDetail = auditRes.body.correction as Record<string, unknown>;
      assert.equal(corrDetail.original_time_in, '08:04 AM');
      assert.equal(corrDetail.original_time_out, null);
      assert.equal(corrDetail.requested_time, '05:02 PM');
      assert.equal(corrDetail.approved_time, '05:00 PM');
      assert.equal(corrDetail.reviewed_by, 'b11_hr');

      const auditRows = auditRes.body.audit as Array<{ action: string; actor_username: string; actor_role: string }>;
      assert.equal(auditRows.length, 2);
      assert.equal(auditRows[0].action, 'CREATED');
      assert.equal(auditRows[1].action, 'APPROVED');
      assert.equal(auditRows[1].actor_username, 'b11_hr');
      assert.equal(auditRows[1].actor_role, 'HR Officer');

      // Prove DB-level immutability triggers block UPDATE & DELETE on correction_audit_log
      assert.throws(
        () => db.prepare(`UPDATE correction_audit_log SET reason = 'tampered' WHERE correction_id = ?`).run(corr.body.id),
        /IMMUTABLE_AUDIT_VIOLATION/i
      );
      assert.throws(
        () => db.prepare(`DELETE FROM correction_audit_log WHERE correction_id = ?`).run(corr.body.id),
        /IMMUTABLE_AUDIT_VIOLATION/i
      );

      // Original kiosk attendance_events row remains completely untouched
      const origEvent = db
        .prepare(`SELECT punch_type, punch_time FROM attendance_events WHERE event_uid = 'b11-orig-kiosk-in-001'`)
        .get() as { punch_type: string; punch_time: string } | undefined;
      assert.ok(origEvent);
      assert.equal(origEvent.punch_type, 'TIME_IN');
      assert.equal(origEvent.punch_time, '08:04 AM');

      // Authorized Reversal restores pre-correction attendance state & writes REVERSED audit entry
      const reversed = await req(
        `/api/corrections/${corr.body.id}/reverse`,
        {
          method: 'POST',
          body: JSON.stringify({ reversal_reason: 'Duplicate entry superseded by corrected official memo' }),
        },
        hrJar
      );
      assert.equal(reversed.status, 200);
      assert.equal(reversed.body.restored_time_in, '08:04 AM');
      assert.equal(reversed.body.restored_time_out, null);

      const postRevAtt = await req('/api/attendance?date=2026-05-13', {}, hrJar);
      const restoredRow = (postRevAtt.body.data as Array<{ employee_id: number; time_in: string | null; time_out: string | null }>)
        .find((r) => r.employee_id === empA.id);
      assert.ok(restoredRow);
      assert.equal(restoredRow.time_in, '08:04 AM');
      assert.equal(restoredRow.time_out, null);

      // Reversing twice must return 409
      const dupRev = await req(
        `/api/corrections/${corr.body.id}/reverse`,
        { method: 'POST', body: JSON.stringify({ reversal_reason: 'Second attempt' }) },
        hrJar
      );
      assert.equal(dupRev.status, 409);

      const postRevAudit = await req(`/api/corrections/${corr.body.id}/audit`, {}, hrJar);
      assert.equal((postRevAudit.body.audit as unknown[]).length, 3);
    });

    await test('Full Day corrections enforce both times + documentation; missing reason or doc rejected', async () => {
      // Short reason rejected
      const shortReason = await req(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empA.id,
            attendance_date: '2026-04-16',
            request_type: 'Time In',
            requested_time: '08:00 AM',
            reason: 'bad',
          }),
        },
        adminJar
      );
      assert.equal(shortReason.status, 400);
      assert.equal(shortReason.body.code, 'REASON_REQUIRED');

      // Full Day without requested_time_out rejected
      const noOut = await req(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empA.id,
            attendance_date: '2026-04-16',
            request_type: 'Full Day',
            requested_time: '08:00 AM',
            reason: 'Off-campus field assignment all day',
            document_reference: 'TO-2026-099',
          }),
        },
        adminJar
      );
      assert.equal(noOut.status, 400);
      assert.equal(noOut.body.code, 'FULL_DAY_BOTH_TIMES_REQUIRED');

      // Full Day without supporting documentation rejected
      const noDoc = await req(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empA.id,
            attendance_date: '2026-04-16',
            request_type: 'Full Day',
            requested_time: '08:00 AM',
            requested_time_out: '05:00 PM',
            reason: 'Off-campus field assignment all day',
          }),
        },
        adminJar
      );
      assert.equal(noDoc.status, 400);
      assert.equal(noDoc.body.code, 'DOCUMENTATION_REQUIRED');

      // Full Day with both times + supporting attachment succeeds
      const validFull = await req(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empA.id,
            attendance_date: '2026-04-16',
            request_type: 'Full Day',
            requested_time: '08:00 AM',
            requested_time_out: '05:00 PM',
            reason: 'Off-campus CHED accreditation workshop',
            attachment_name: 'travel_order.txt',
            attachment_mime: 'text/plain',
            attachment_data: Buffer.from('RSU Travel Order #099').toString('base64'),
          }),
        },
        adminJar
      );
      assert.equal(validFull.status, 201);
      const approveFull = await req(
        `/api/corrections/${validFull.body.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) },
        adminJar
      );
      assert.equal(approveFull.status, 200);
      assert.equal(approveFull.body.resulting_time_in, '08:00 AM');
      assert.equal(approveFull.body.resulting_time_out, '05:00 PM');
      assert.equal(approveFull.body.resulting_status, 'Present');
    });

    // =========================================================================
    // PART B — LEAVES TESTS (CONFIGURABLE POLICIES, MULTI-DAY PROPAGATION, WEEKENDS/HOLIDAYS,
    // HALF-DAYS, CROSS-YEAR, UNDERFLOW, OVERLAPS, CONFLICTING PUNCHES, CANCELLATION)
    // =========================================================================

    await test('Multi-day leave spans past, today & future dates, excludes weekends & holidays, and propagates to ALL eligible attendance rows', async () => {
      // Insert a campus holiday on Thursday 2026-05-14
      const hol = await req(
        '/api/holidays',
        {
          method: 'POST',
          body: JSON.stringify({ date: '2026-05-14', name: 'RSU Cajidiocan Foundation Test Day', type: 'Regular' }),
        },
        adminJar
      );
      assert.equal(hol.status, 201);

      // Request Vacation Leave for empC from Tue 2026-05-12 (past) through Mon 2026-05-18 (future):
      // Calendar days: Tue 12, Wed 13 (today), Thu 14 (Holiday!), Fri 15, Sat 16 (Weekend!), Sun 17 (Weekend!), Mon 18
      // Eligible working days MUST be 4: 05-12, 05-13, 05-15, 05-18
      const preview = await req(
        `/api/leaves/preview?employee_id=${empC.id}&leave_type=Vacation%20Leave&start_date=2026-05-12&end_date=2026-05-18`,
        {},
        hrJar
      );
      assert.equal(preview.status, 200);
      assert.equal(preview.body.calendar_days, 7);
      assert.equal(preview.body.total_eligible_credits, 4);
      assert.equal((preview.body.excluded_days as unknown[]).length, 3);

      const created = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empC.id,
            leave_type: 'Vacation Leave',
            start_date: '2026-05-12',
            end_date: '2026-05-18',
            reason: 'Approved multi-day annual family vacation',
          }),
        },
        hrJar
      );
      assert.equal(created.status, 201);
      assert.equal(created.body.days_count, 4);

      const approved = await req(
        `/api/leaves/${created.body.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) },
        hrJar
      );
      assert.equal(approved.status, 200);
      assert.deepEqual(approved.body.applied_dates, ['2026-05-12', '2026-05-13', '2026-05-15', '2026-05-18']);

      // Confirm ALL 4 eligible dates (past, today, future) have 'On Leave' in attendance_records
      for (const dt of ['2026-05-12', '2026-05-13', '2026-05-15', '2026-05-18']) {
        const rec = db
          .prepare('SELECT status FROM attendance_records WHERE employee_id = ? AND date = ?')
          .get(empC.id, dt) as { status: string } | undefined;
        assert.equal(rec?.status, 'On Leave', `Expected On Leave for ${dt}`);
      }
      // Excluded holiday & weekend dates must NOT be marked On Leave
      for (const exDt of ['2026-05-14', '2026-05-16', '2026-05-17']) {
        const rec = db
          .prepare('SELECT status FROM attendance_records WHERE employee_id = ? AND date = ?')
          .get(empC.id, exDt) as { status: string } | undefined;
        assert.notEqual(rec?.status, 'On Leave', `Excluded date ${exDt} must not be marked On Leave`);
      }

      // Duplicate approve/reject on leave must return 409 ALREADY_REVIEWED
      const dupLeave = await req(
        `/api/leaves/${created.body.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) },
        hrJar
      );
      assert.equal(dupLeave.status, 409);
      assert.equal(dupLeave.body.code, 'ALREADY_REVIEWED');
    });

    await test('Half-day leaves (HALF_AM + HALF_PM = 0.5 each), complementary overlap allowance, and multi-day half-day rejection', async () => {
      // Multi-day half-day must be rejected
      const badMultiHalf = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empD.id,
            leave_type: 'Vacation Leave',
            start_date: '2026-05-19',
            end_date: '2026-05-20',
            day_portion: 'HALF_AM',
            reason: 'Invalid multi-day half-day test',
          }),
        },
        hrJar
      );
      assert.equal(badMultiHalf.status, 400);

      // File HALF_AM on 2026-05-19 (0.5d)
      const am = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empD.id,
            leave_type: 'Vacation Leave',
            start_date: '2026-05-19',
            end_date: '2026-05-19',
            day_portion: 'HALF_AM',
            reason: 'Morning medical appointment',
          }),
        },
        hrJar
      );
      assert.equal(am.status, 201);
      assert.equal(am.body.days_count, 0.5);

      // Duplicate HALF_AM on same day -> 409 OVERLAPPING_LEAVE
      const dupAm = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empD.id,
            leave_type: 'Vacation Leave',
            start_date: '2026-05-19',
            end_date: '2026-05-19',
            day_portion: 'HALF_AM',
            reason: 'Duplicate AM request',
          }),
        },
        hrJar
      );
      assert.equal(dupAm.status, 409);
      assert.equal(dupAm.body.code, 'OVERLAPPING_LEAVE');

      // Complementary HALF_PM on same day -> allowed!
      const pm = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empD.id,
            leave_type: 'Vacation Leave',
            start_date: '2026-05-19',
            end_date: '2026-05-19',
            day_portion: 'HALF_PM',
            reason: 'Afternoon follow-up visit',
          }),
        },
        hrJar
      );
      assert.equal(pm.status, 201);
      assert.equal(pm.body.days_count, 0.5);

      assert.equal(
        (await req(`/api/leaves/${am.body.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, hrJar)).status,
        200
      );
      assert.equal(
        (await req(`/api/leaves/${pm.body.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, hrJar)).status,
        200
      );

      // Verify exact 1.0 credit deducted in 2026 balances for empD
      const balRes = await req('/api/leaves?year=2026', {}, hrJar);
      const empDBal = (balRes.body.balances as Array<{ employee_id: number; vl_used: number; vl_remaining: number }>)
        .find((b) => b.employee_id === empD.id);
      assert.ok(empDBal);
      assert.equal(empDBal.vl_used, 1);
      assert.equal(empDBal.vl_remaining, 14);
    });

    await test('Cross-year leave range splits credits cleanly between 2026 and 2027 excluding Jan 1 holiday & weekend', async () => {
      // Seed 2027-01-01 New Year holiday
      await req(
        '/api/holidays',
        { method: 'POST', body: JSON.stringify({ date: '2027-01-01', name: "New Year's Day 2027", type: 'Regular' }) },
        adminJar
      );

      // 2026-12-30 (Wed), 2026-12-31 (Thu) -> 2 days in 2026 (unless 12-30 Rizal Day is already a holiday!)
      // Check existing holidays in Dec 2026 so assertion is deterministic
      const dec30Hol = db.prepare(`SELECT id FROM holidays WHERE date = '2026-12-30'`).get();
      const expected2026 = dec30Hol ? 1 : 2;
      // 2027-01-01 (Fri Holiday), 2027-01-02 (Sat), 2027-01-03 (Sun), 2027-01-04 (Mon) -> 1 day in 2027
      const expectedTotal = expected2026 + 1;

      const crossYear = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empE.id,
            leave_type: 'Vacation Leave',
            start_date: '2026-12-30',
            end_date: '2027-01-04',
            reason: 'Year-end holiday travel across calendar boundary',
          }),
        },
        hrJar
      );
      assert.equal(crossYear.status, 201);
      assert.equal(crossYear.body.days_count, expectedTotal);

      const appCross = await req(
        `/api/leaves/${crossYear.body.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) },
        hrJar
      );
      assert.equal(appCross.status, 200);

      // Verify per-year split in balances
      const bal2026 = (await req('/api/leaves?year=2026', {}, hrJar)).body.balances as Array<{
        employee_id: number;
        vl_used: number;
      }>;
      const bal2027 = (await req('/api/leaves?year=2027', {}, hrJar)).body.balances as Array<{
        employee_id: number;
        vl_used: number;
      }>;
      assert.equal(bal2026.find((b) => b.employee_id === empE.id)?.vl_used, expected2026);
      assert.equal(bal2027.find((b) => b.employee_id === empE.id)?.vl_used, 1);
    });

    await test('Configurable HR leave policy update + leave balance underflow rejection (409 INSUFFICIENT_LEAVE_BALANCE)', async () => {
      const policiesRes = await req('/api/leaves/policies', {}, hrJar);
      assert.equal(policiesRes.status, 200);
      const policies = policiesRes.body.data as Array<{ id: number; leave_type: string; annual_entitlement: number }>;
      const elPolicy = policies.find((p) => p.leave_type === 'Emergency Leave')!;
      assert.equal(elPolicy.annual_entitlement, 5);

      // Update Emergency Leave annual entitlement to 2 days via HR API
      const upd = await req(
        `/api/leaves/policies/${elPolicy.id}`,
        {
          method: 'PUT',
          body: JSON.stringify({
            annual_entitlement: 2,
            track_balance: true,
            allow_half_day: true,
            exclude_weekends_rest_days: true,
            exclude_holidays: true,
            allow_negative_balance: false,
            requires_document_after_days: 0,
          }),
        },
        hrJar
      );
      assert.equal(upd.status, 200);

      // Attempting a 3-day Emergency Leave must now be rejected with 409 INSUFFICIENT_LEAVE_BALANCE
      const underflow = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empE.id,
            leave_type: 'Emergency Leave',
            start_date: '2026-06-08',
            end_date: '2026-06-10',
            reason: 'Three-day family emergency exceeding 2-day policy cap',
          }),
        },
        hrJar
      );
      assert.equal(underflow.status, 409);
      assert.equal(underflow.body.code, 'INSUFFICIENT_LEAVE_BALANCE');

      // Restore Emergency Leave back to 5 days
      await req(
        `/api/leaves/policies/${elPolicy.id}`,
        {
          method: 'PUT',
          body: JSON.stringify({
            annual_entitlement: 5,
            track_balance: true,
            allow_half_day: true,
            exclude_weekends_rest_days: true,
            exclude_holidays: true,
            allow_negative_balance: false,
            requires_document_after_days: 0,
          }),
        },
        hrJar
      );
    });

    await test('Sick Leave >= 3 days requires documentation (400 DOCUMENTATION_REQUIRED) and succeeds when provided', async () => {
      const noDoc = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empF.id,
            leave_type: 'Sick Leave',
            start_date: '2026-06-01',
            end_date: '2026-06-03',
            reason: 'Flu recovery requiring medical certificate',
          }),
        },
        hrJar
      );
      assert.equal(noDoc.status, 400);
      assert.equal(noDoc.body.code, 'DOCUMENTATION_REQUIRED');

      const withDoc = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empF.id,
            leave_type: 'Sick Leave',
            start_date: '2026-06-01',
            end_date: '2026-06-03',
            reason: 'Flu recovery with clinic certificate',
            document_reference: 'CLINIC-MED-2026-77',
          }),
        },
        hrJar
      );
      assert.equal(withDoc.status, 201);
    });

    await test('Conflicting valid punches block leave approval by default (409) and PRESERVE_PUNCHES keeps punched dates intact', async () => {
      // Insert a valid attendance punch for empF on 2026-06-15 (Monday)
      const logPunch = await req(
        '/api/attendance',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empF.id,
            date: '2026-06-15',
            time_in: '07:55 AM',
            time_out: '05:05 PM',
            status: 'Present',
            device_name: 'Kiosk - Main Gate',
            remarks: 'Valid kiosk attendance',
          }),
        },
        adminJar
      );
      assert.equal(logPunch.status, 201);

      // File 2-day Vacation Leave covering Mon 2026-06-15 (punched) + Tue 2026-06-16 (unpunched)
      const lv = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empF.id,
            leave_type: 'Vacation Leave',
            start_date: '2026-06-15',
            end_date: '2026-06-16',
            reason: 'Testing conflict protection over existing valid punch',
          }),
        },
        hrJar
      );
      assert.equal(lv.status, 201);

      // Strict default approval MUST block with 409 CONFLICTING_VALID_PUNCHES
      const blocked = await req(
        `/api/leaves/${lv.body.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) },
        hrJar
      );
      assert.equal(blocked.status, 409);
      assert.equal(blocked.body.code, 'CONFLICTING_VALID_PUNCHES');

      // Explicit PRESERVE_PUNCHES preserves 2026-06-15 Present record & applies On Leave only to 2026-06-16 (charging 1 day)
      const resolved = await req(
        `/api/leaves/${lv.body.id}/status`,
        {
          method: 'PATCH',
          body: JSON.stringify({ status: 'Approved', conflict_resolution: 'PRESERVE_PUNCHES' }),
        },
        hrJar
      );
      assert.equal(resolved.status, 200);
      assert.deepEqual(resolved.body.applied_dates, ['2026-06-16']);
      assert.deepEqual(resolved.body.preserved_punch_dates, ['2026-06-15']);
      assert.equal(resolved.body.charged_days, 1);

      const kept = db
        .prepare(`SELECT status, time_in, time_out FROM attendance_records WHERE employee_id = ? AND date = '2026-06-15'`)
        .get(empF.id) as { status: string; time_in: string; time_out: string };
      assert.equal(kept.status, 'Present');
      assert.equal(kept.time_in, '07:55 AM');

      const applied = db
        .prepare(`SELECT status FROM attendance_records WHERE employee_id = ? AND date = '2026-06-16'`)
        .get(empF.id) as { status: string };
      assert.equal(applied.status, 'On Leave');
    });

    await test('Rejected leaves do not deduct balance; cancelling Approved leave restores attendance & balance atomically with immutable leave_audit_log', async () => {
      // 1. Rejected leave leaves attendance & balance untouched
      const toReject = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empD.id,
            leave_type: 'Vacation Leave',
            start_date: '2026-07-06',
            end_date: '2026-07-07',
            reason: 'Request to be rejected during peak enrollment',
          }),
        },
        hrJar
      );
      assert.equal(toReject.status, 201);
      const rej = await req(
        `/api/leaves/${toReject.body.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status: 'Rejected', reviewer_notes: 'Peak enrollment week' }) },
        hrJar
      );
      assert.equal(rej.status, 200);
      const noRow = db
        .prepare(`SELECT id FROM attendance_records WHERE employee_id = ? AND date = '2026-07-06'`)
        .get(empD.id);
      assert.equal(noRow, undefined);

      // 2. Approved leave then cancelled atomically restores attendance rows & balance credits
      const toCancel = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empD.id,
            leave_type: 'Vacation Leave',
            start_date: '2026-07-13',
            end_date: '2026-07-14',
            reason: 'Planned trip later cancelled',
          }),
        },
        hrJar
      );
      assert.equal(toCancel.status, 201);
      assert.equal(
        (await req(`/api/leaves/${toCancel.body.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, hrJar)).status,
        200
      );

      // Balance increased by 2 (1 + 2 = 3)
      let bal = ((await req('/api/leaves?year=2026', {}, hrJar)).body.balances as Array<{ employee_id: number; vl_used: number }>)
        .find((b) => b.employee_id === empD.id)!;
      assert.equal(bal.vl_used, 3);

      // Cancel approved leave
      const cancelled = await req(
        `/api/leaves/${toCancel.body.id}/cancel`,
        { method: 'POST', body: JSON.stringify({ cancel_reason: 'Travel schedule cancelled by employee' }) },
        hrJar
      );
      assert.equal(cancelled.status, 200);

      // Attendance rows removed & balance restored back to 1
      for (const dt of ['2026-07-13', '2026-07-14']) {
        const gone = db
          .prepare('SELECT id FROM attendance_records WHERE employee_id = ? AND date = ?')
          .get(empD.id, dt);
        assert.equal(gone, undefined, `Cancelled leave date ${dt} should be restored`);
      }
      bal = ((await req('/api/leaves?year=2026', {}, hrJar)).body.balances as Array<{ employee_id: number; vl_used: number }>)
        .find((b) => b.employee_id === empD.id)!;
      assert.equal(bal.vl_used, 1);

      // Verify immutable leave_audit_log entries & immutability triggers
      const details = await req(`/api/leaves/${toCancel.body.id}/details`, {}, hrJar);
      assert.equal(details.status, 200);
      const auditActions = (details.body.audit as Array<{ action: string }>).map((a) => a.action);
      assert.deepEqual(auditActions, ['CREATED', 'APPROVED', 'CANCELLED']);

      assert.throws(
        () => db.prepare(`UPDATE leave_audit_log SET reason = 'hacked' WHERE leave_id = ?`).run(toCancel.body.id),
        /IMMUTABLE_AUDIT_VIOLATION/i
      );
      assert.throws(
        () => db.prepare(`DELETE FROM leave_audit_log WHERE leave_id = ?`).run(toCancel.body.id),
        /IMMUTABLE_AUDIT_VIOLATION/i
      );
    });

    // =========================================================================
    // PART C — UNAUTHORIZED RBAC ACTIONS
    // =========================================================================

    await test('RBAC blocks unauthorized correction/leave approvals, reversals, policy edits, and cross-department actions', async () => {
      // Create a pending correction & pending leave for empB (Department B, outside deptHeadJar's Department A)
      const corrB = await req(
        '/api/corrections',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empB.id,
            attendance_date: '2026-04-20',
            request_type: 'Time In',
            requested_time: '08:00 AM',
            reason: 'Cross-department RBAC scope check',
          }),
        },
        adminJar
      );
      assert.equal(corrB.status, 201);

      const leaveB = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empB.id,
            leave_type: 'Vacation Leave',
            start_date: '2026-08-03',
            end_date: '2026-08-04',
            reason: 'Cross-department RBAC leave scope check',
          }),
        },
        adminJar
      );
      assert.equal(leaveB.status, 201);

      // 1. Employee cannot approve corrections, reverse corrections, approve leaves, or edit leave policies
      assert.equal(
        (await req(`/api/corrections/${corrB.body.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, empJar)).status,
        403
      );
      assert.equal(
        (await req(`/api/corrections/${corrB.body.id}/reverse`, { method: 'POST', body: JSON.stringify({ reversal_reason: 'Unauthorized' }) }, empJar)).status,
        403
      );
      assert.equal(
        (await req(`/api/leaves/${leaveB.body.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, empJar)).status,
        403
      );
      assert.equal(
        (await req('/api/leaves/policies/1', { method: 'PUT', body: JSON.stringify({ annual_entitlement: 99 }) }, empJar)).status,
        403
      );

      // 2. Payroll Officer cannot approve corrections or leaves
      assert.equal(
        (await req(`/api/corrections/${corrB.body.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, payrollJar)).status,
        403
      );
      assert.equal(
        (await req(`/api/leaves/${leaveB.body.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, payrollJar)).status,
        403
      );

      // 3. Department Head (Dept A) cannot approve Dept B's correction or leave
      if (empB.department_id !== empA.department_id) {
        assert.equal(
          (await req(`/api/corrections/${corrB.body.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, deptHeadJar)).status,
          403
        );
        assert.equal(
          (await req(`/api/leaves/${leaveB.body.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, deptHeadJar)).status,
          403
        );
      }

      // 4. Employee CAN cancel own Pending leave, but CANNOT cancel own Approved leave
      const selfLv = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empA.id,
            leave_type: 'Vacation Leave',
            start_date: '2026-08-10',
            end_date: '2026-08-10',
            reason: 'Self-filed pending leave cancellation check',
          }),
        },
        empJar
      );
      assert.equal(selfLv.status, 201);
      assert.equal(
        (await req(`/api/leaves/${selfLv.body.id}/cancel`, { method: 'POST', body: JSON.stringify({ cancel_reason: 'Changed personal plans' }) }, empJar)).status,
        200
      );

      const selfAppLv = await req(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            employee_id: empA.id,
            leave_type: 'Vacation Leave',
            start_date: '2026-08-12',
            end_date: '2026-08-12',
            reason: 'Approved leave employee cancel restriction check',
          }),
        },
        empJar
      );
      assert.equal(selfAppLv.status, 201);
      assert.equal(
        (await req(`/api/leaves/${selfAppLv.body.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'Approved' }) }, hrJar)).status,
        200
      );
      assert.equal(
        (await req(`/api/leaves/${selfAppLv.body.id}/cancel`, { method: 'POST', body: JSON.stringify({ cancel_reason: 'Employee cannot self-cancel approved' }) }, empJar)).status,
        403
      );
    });

    // =========================================================================
    // PART D — MONTHLY REPORTS PROPAGATION
    // =========================================================================

    await test('Monthly Reports (attendance, dtr, leaves) accurately propagate multi-day leaves, cross-year overlaps, and approved corrections', async () => {
      // May 2026 attendance & DTR reports must include ALL 4 On Leave days for empC (12, 13, 15, 18)
      const attRep = await req(
        `/api/reports/attendance?startDate=2026-05-01&endDate=2026-05-31&empId=${empC.id}`,
        {},
        hrJar
      );
      assert.equal(attRep.status, 200);
      const attRows = attRep.body.rows as Array<{ date: string; status: string }>;
      const leaveDatesInAtt = attRows.filter((r) => r.status === 'On Leave').map((r) => r.date).sort();
      assert.deepEqual(leaveDatesInAtt, ['2026-05-12', '2026-05-13', '2026-05-15', '2026-05-18']);

      const dtrRep = await req(
        `/api/reports/dtr?startDate=2026-04-01&endDate=2026-04-30&empId=${empA.id}`,
        {},
        hrJar
      );
      assert.equal(dtrRep.status, 200);
      const dtrRows = dtrRep.body.rows as Array<{ date: string; time_in: string | null; time_out: string | null; status: string }>;
      // April 14 unpaired Time In -> Missing Time Out; April 15 unpaired Time Out -> Missing Time In; April 16 Full Day -> Present
      assert.equal(dtrRows.find((r) => r.date === '2026-04-14')?.status, 'Missing Time Out');
      assert.equal(dtrRows.find((r) => r.date === '2026-04-14')?.time_out, '-');
      assert.equal(dtrRows.find((r) => r.date === '2026-04-15')?.status, 'Missing Time In');
      assert.equal(dtrRows.find((r) => r.date === '2026-04-15')?.time_in, '-');
      assert.equal(dtrRows.find((r) => r.date === '2026-04-16')?.status, 'Present');

      // January 2027 leaves report MUST include empE's cross-year leave (2026-12-30 to 2027-01-04) via overlap filter
      const jan2027Leaves = await req(
        `/api/reports/leaves?startDate=2027-01-01&endDate=2027-01-31&empId=${empE.id}`,
        {},
        hrJar
      );
      assert.equal(jan2027Leaves.status, 200);
      const overlapRows = jan2027Leaves.body.rows as Array<{ start_date: string; end_date: string; status: string }>;
      assert.ok(
        overlapRows.some((r) => r.start_date === '2026-12-30' && r.end_date === '2027-01-04' && r.status === 'Approved'),
        'January 2027 leaves report must include cross-year leave overlapping Jan 1-4'
      );
    });
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    hub.closeAll();
    closeDatabaseSafely(db);
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }

  console.log(`\nCorrections & Leaves Tests Summary: ${passed} passed, ${failed} failed.`);
  if (failed > 0) process.exit(1);
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
