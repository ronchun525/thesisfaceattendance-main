import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { RealtimeHub } from '../server/realtimeHub.ts';

class MockResponse extends EventEmitter {
  statusCode = 200;
  writableEnded = false;
  destroyed = false;
  frames = [];
  headers = {};
  status(code) { this.statusCode = code; return this; }
  setHeader(k, v) { this.headers[k.toLowerCase()] = v; }
  flushHeaders() { }
  write(frame) { this.frames.push(frame); return true; }
  end() { this.writableEnded = true; }
}
function openStream(hub, opts = {}) {
  const req = new EventEmitter();
  const res = new MockResponse();
  const auth = {
    userId: 9, username: 'testing', role: 'Administrator', departmentId: null,
    employeeId: null,
    permissions: new Set(['attendance:read', 'devices:read', 'notifications:read']),
    ...opts.auth,
  };
  const accepted = hub.attachClient(req, res, auth, opts.channels);
  assert.equal(accepted.accepted, true);
  return {req, res};
}
const attendance = {
  event_uid: 'e1', employee_id: 10, employee_code: 'E001', department_id: 6,
  shift_date: '2026-11-22', action: 'TIME_IN', status: 'Present', source: 'Android',
};

test('SSE subscriber is NOT closed when HTTP request emits close; response close tears down', () => {
  const hub = new RealtimeHub({keepaliveIntervalMs: 60_000});
  try {
    const {req, res} = openStream(hub);
    assert.equal(hub.clientCount(), 1);
    req.emit('close');
    assert.equal(hub.clientCount(), 1, 'request completion must not kill streaming response');
    assert.equal(hub.emitAttendanceUpdated(attendance), 1);
    assert.ok(res.frames.join('').includes('event: attendance:updated'));
    res.emit('close');
    assert.equal(hub.clientCount(), 0);
    assert.equal(res.writableEnded, true);
  } finally { hub.closeAll(); }
});

test('employee and department scopes filter attendance SSE events', () => {
  const hub = new RealtimeHub();
  try {
    const own = openStream(hub, {auth: {role:'Employee', employeeId: 10, permissions:new Set(['attendance:read_self'])}});
    const other = openStream(hub, {auth: {role:'Employee', employeeId: 12, permissions:new Set(['attendance:read_self'])}});
    const dept = openStream(hub, {auth: {role:'Department Head', departmentId: 6, permissions:new Set(['attendance:read'])}});
    const wrongDept = openStream(hub, {auth: {role:'Department Head', departmentId: 8, permissions:new Set(['attendance:read'])}});
    assert.equal(hub.emitAttendanceUpdated(attendance), 2);
    assert.ok(own.res.frames.join('').includes('event: attendance:updated'));
    assert.ok(dept.res.frames.join('').includes('event: attendance:updated'));
    assert.ok(!other.res.frames.join('').includes('event: attendance:updated'));
    assert.ok(!wrongDept.res.frames.join('').includes('event: attendance:updated'));
  } finally { hub.closeAll(); }
});

test('device telemetry is sanitized and delivered only to authorized roles', () => {
  const hub = new RealtimeHub();
  try {
    const admin = openStream(hub);
    const unauthorized = openStream(hub, {auth:{role:'Employee',permissions:new Set(['attendance:read_self'])}});
    assert.equal(hub.emitDeviceTelemetry({
      device_id:1, name:'KIOSK01',status:'Online',connectivity:'Online',last_heartbeat:'now',
      last_heartbeat_utc:null,last_sync_utc:null,pending_queue_count:0,stale_warning:false,
      last_clock_drift_seconds:null,last_sync_status:'OK',last_sync_error:'',is_revoked:0,
      api_token:'SHOULD_NOT_LEAK'
    }),1);
    assert.ok(admin.res.frames.join('').includes('event: device:telemetry'));
    assert.ok(!admin.res.frames.join('').includes('SHOULD_NOT_LEAK'));
    assert.ok(!unauthorized.res.frames.join('').includes('event: device:telemetry'));
  } finally { hub.closeAll(); }
});

test('max client limit refuses additional clients before writing SSE headers', () => {
  const hub = new RealtimeHub({maxClients:1});
  try {
    openStream(hub);
    const req = new EventEmitter(); const res = new MockResponse();
    const result = hub.attachClient(req, res, {userId:1,username:'another',role:'Administrator',permissions:new Set(),employeeId:null,departmentId:null});
    assert.equal(result.accepted, false);
    assert.equal(res.frames.length, 0);
  } finally { hub.closeAll(); }
});
