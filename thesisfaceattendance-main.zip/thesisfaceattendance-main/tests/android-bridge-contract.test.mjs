import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createHash, createHmac } from 'node:crypto';
import {
  computeAndroidAttendanceDigest,
  computeAndroidEnrollmentHash,
  proofBindingHmac,
} from '../server/androidBridgeProtocol.ts';

test('Android attendance digest uses exactly Kotlin 5-field canonical serialization', () => {
  const args = ['evt-0111223344', 'RSU-009', 'TIME_IN', 1795291200000, 'SAVAGE-RSUCAJ-KIOSK-01'];
  const expected = createHash('sha256').update(args.join('|')).digest('hex');
  assert.equal(computeAndroidAttendanceDigest(...args), expected);
  assert.notEqual(computeAndroidAttendanceDigest(args[0], args[1], 'TIME_OUT', args[3], args[4]), expected);
});

test('Android Float32LE enrollment hash matches independent binary specification', () => {
  const id = 'EMP-001';
  const name = 'Maria Test';
  const values = [0.125, -0.625, 0.375];
  const buf = Buffer.alloc(12);
  values.forEach((v, i) => buf.writeFloatLE(v, i * 4));
  const expected = createHash('sha256').update(id).update(Buffer.from([0])).update(name)
    .update(Buffer.from([0])).update(buf).digest('hex');
  assert.equal(computeAndroidEnrollmentHash(id, name, values), expected);
});

test('biometric HMAC binds action, event, timestamp, device and liveness', () => {
  const fields = {
    deviceId: 17, bootId: 'boot-uuid-2026', sequence: 1795291200000,
    eventId: 'evt-001', employeeCode: 'RSU-009', punchType: 'TIME_IN',
    isoTimestamp: '2026-11-22T00:00:00.000Z', evidenceHash: 'a'.repeat(64),
    nonce: '3cd6afe218eb44b99366bb89d33d19df', liveness: true, match: true,
  };
  const token = 'properly-provisioned-device-token';
  const derived = createHmac('sha256', token)
    .update('savage-rsucaj-kiosk-biometric-binding-v1').digest();
  const payload = ['savage-rsucaj-kiosk-biometric-binding-v1', '17', fields.bootId,
    String(fields.sequence), fields.eventId, fields.employeeCode, fields.punchType,
    fields.isoTimestamp, fields.evidenceHash, fields.nonce, '1', '1'].join('|');
  const expected = createHmac('sha256', derived).update(payload).digest('hex');
  assert.equal(proofBindingHmac(token, fields), expected);
  assert.notEqual(proofBindingHmac(token, { ...fields, liveness: false }), expected);
  assert.notEqual(proofBindingHmac(token, { ...fields, punchType: 'TIME_OUT' }), expected);
  assert.notEqual(proofBindingHmac('wrong-token', fields), expected);
});

// Static API surface compatibility: catches accidental endpoint drift without
// claiming live Android device or Express server execution.
test('Android Retrofit endpoint paths match backend bridge registrations', async () => {
  const { readFileSync } = await import('node:fs');
  const { resolve } = await import('node:path');
  const root = resolve(import.meta.dirname, '..');
  const android = readFileSync(resolve(root, '..', 'finalngfacerecogantion-main',
    'app/src/main/java/com/example/kiosk/data/AttendanceApiService.kt'), 'utf8');
  const server = readFileSync(resolve(root, 'server/androidBridge.ts'), 'utf8');
  const paths = [
    ['device-info', 'GET'], ['employees', 'GET'], ['employees/enroll-template', 'POST'],
    ['attendance', 'POST'], ['realtime/attendance-events', 'POST'],
  ];
  for (const [suffix, method] of paths) {
    assert.ok(android.includes(`@${method}("api/v1/kiosk/${suffix}")`), `Android ${suffix}`);
    assert.ok(server.includes(`router.${method.toLowerCase()}('/v1/kiosk/${suffix}'`), `Backend ${suffix}`);
  }
});
