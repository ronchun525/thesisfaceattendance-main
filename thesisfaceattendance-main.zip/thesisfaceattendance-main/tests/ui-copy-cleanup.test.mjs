import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFileSync(resolve(projectRoot, p), 'utf8');

test('No visible v1.13.0 build label in active UI source', () => {
  for (const file of [
    'src/App.tsx',
    'src/components/LoginView.tsx',
    'src/components/SystemAdminViews.tsx',
    'src/components/employee/ProfileAndUtilityScreens.tsx',
  ]) {
    assert.doesNotMatch(read(file), /(?:v1\.13\.0|Version 1\.13\.0|Version \{meta\?\.version)/, file);
  }
});

test('Sidebar keeps campus label but has no version label', () => {
  const content = read('src/App.tsx');
  assert.match(content, /RSU – Cajidiocan Campus/);
  assert.match(content, /aria-label="Primary sidebar navigation"/);
  assert.doesNotMatch(content, /RSU – Cajidiocan Campus · v/);
});

test('Employee login no longer displays Portal Guide or Admin Portal Login', () => {
  const content = read('src/components/employee/EmployeeEntryFlow.tsx');
  assert.doesNotMatch(content, /Portal Guide|Admin Portal Login|onSwitchToAdminLogin|onShowOnboarding/);
  assert.match(content, /EmployeeLoginScreen/);
  assert.match(content, /Forgot Password\?/);
  assert.match(content, /Log In/);
});

test('Onboarding and separate admin login route still exist', () => {
  const employee = read('src/components/employee/EmployeeEntryFlow.tsx');
  const app = read('src/App.tsx');
  assert.match(employee, /EmployeeOnboardingFlow/);
  assert.match(employee, /hasCompletedEmployeeOnboarding\(\)/);
  assert.match(app, /if \(path\.startsWith\('\/employee'\)/);
  assert.match(app, /<LoginView/);
  assert.match(app, /<EmployeeEntryFlow/);
});
