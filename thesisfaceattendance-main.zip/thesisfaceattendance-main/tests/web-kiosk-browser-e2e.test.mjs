/**
 * SAVAGE-RSUCAJ BUILD 36 — Playwright 16-Screen Visual, Functional, Responsive & Front-Face-Only E2E Audit
 *
 * Run with: npx tsx tests/web-kiosk-browser-e2e.test.mjs
 */
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import { chromium } from 'playwright-core';
import { initDatabase } from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import { securityHeadersMiddleware } from '../server/security.ts';

process.env.SESSION_SECRET = crypto.randomBytes(48).toString('hex');
process.env.KIOSK_TEMPLATE_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');

const FORBIDDEN_LEFT_RIGHT_REGEX = /\b(turn left|turn right|left face|right face|rotate face|look left|look right)\b/i;

async function findChromiumExecutable() {
  const candidates = [
    process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    '/usr/bin/google-chrome',
  ].filter(Boolean);
  for (const c of candidates) {
    if (fs.existsSync(c)) return c;
  }
  const msRoot = '/ms-playwright';
  if (fs.existsSync(msRoot)) {
    const dirs = fs.readdirSync(msRoot).filter((d) => d.startsWith('chromium')).sort().reverse();
    for (const dir of dirs) {
      for (const rel of [
        'chrome-headless-shell-linux64/chrome-headless-shell',
        'chrome-linux/chrome',
        'chrome-linux64/chrome',
      ]) {
        const full = path.join(msRoot, dir, rel);
        if (fs.existsSync(full)) return full;
      }
    }
  }
  return undefined;
}

async function run() {
  const distDir = path.resolve(process.cwd(), 'dist');
  assert.ok(fs.existsSync(path.join(distDir, 'index.html')), 'dist/index.html must exist — run npm run build first.');

  const outDir = path.resolve(process.cwd(), 'test-results', 'kiosk-build36-screenshots');
  fs.mkdirSync(outDir, { recursive: true });

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-b36-e2e-'));
  const dbPath = path.join(tmpDir, 'e2e.db');
  const db = initDatabase(dbPath, {
    mode: 'test',
    initialAdmin: {
      username: 'sysadmin',
      email: 'admin@rsu-cajidiocan.tech',
      password: 'StrongPassword#2026!',
    },
  });

  db.prepare(`UPDATE users SET must_change_password = 0 WHERE username = 'sysadmin'`).run();
  db.prepare(`INSERT OR IGNORE INTO departments (code, name) VALUES ('DCS', 'Computer Studies')`).run();
  db.prepare(`INSERT OR IGNORE INTO positions (code, name, base_salary) VALUES ('INST1', 'Instructor I', 28000)`).run();
  db.prepare(`INSERT OR IGNORE INTO shifts (name, time_in, time_out, grace_minutes, status) VALUES ('Regular Day', '08:00', '17:00', 15, 'Active')`).run();
  const dept = db.prepare(`SELECT id FROM departments LIMIT 1`).get();
  const pos = db.prepare(`SELECT id FROM positions LIMIT 1`).get();
  const shift = db.prepare(`SELECT id FROM shifts LIMIT 1`).get();

  db.prepare(
    `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status)
     VALUES ('RSU-0001', 'Juan Dela Cruz', 'juan@rsu.edu.ph', ?, ?, ?, 'Active'),
            ('RSU-0002', 'Maria Santos', 'maria@rsu.edu.ph', ?, ?, ?, 'Active'),
            ('RSU-0003', 'Carlo Reyes', 'carlo@rsu.edu.ph', ?, ?, ?, 'Active')`
  ).run(dept.id, pos.id, shift.id, dept.id, pos.id, shift.id, dept.id, pos.id, shift.id);

  const app = express();
  app.use(securityHeadersMiddleware);
  app.use(express.json({ limit: '2mb' }));
  app.use('/api', createApiRouter(db, { appMode: 'test' }));
  app.use(express.static(distDir));
  app.get('*', (_req, res) => res.sendFile(path.join(distDir, 'index.html')));

  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const baseUrl = `http://127.0.0.1:${server.address().port}`;

  // Provision device, activation code, and Kiosk Admin PIN via real Admin API
  const loginRes = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'sysadmin', password: 'StrongPassword#2026!' }),
  });
  const adminCookies = (loginRes.headers.getSetCookie?.() || [loginRes.headers.get('set-cookie')])
    .filter(Boolean)
    .map((c) => c.split(';')[0])
    .join('; ');
  const { csrfToken } = await loginRes.json();
  const aHeaders = { 'Content-Type': 'application/json', Cookie: adminCookies, 'X-CSRF-Token': csrfToken };

  const dev = await (
    await fetch(`${baseUrl}/api/devices`, {
      method: 'POST',
      headers: aHeaders,
      body: JSON.stringify({ name: 'RSUCAJ-KIOSK-01', device_type: 'Raspberry Pi', ip_address: '192.168.1.50', location: 'Main Entrance' }),
    })
  ).json();

  const { activation_code } = await (
    await fetch(`${baseUrl}/api/devices/${dev.id}/activation-code`, {
      method: 'POST',
      headers: aHeaders,
      body: JSON.stringify({}),
    })
  ).json();

  await fetch(`${baseUrl}/api/kiosk/web/admin-pin`, {
    method: 'PUT',
    headers: aHeaders,
    body: JSON.stringify({ pin: '849271' }),
  });

  const executablePath = await findChromiumExecutable();
  const browser = await chromium.launch({
    executablePath,
    headless: true,
    args: ['--no-sandbox', '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream'],
  });

  const pageErrors = [];
  try {
    const context = await browser.newContext({ viewport: { width: 1024, height: 600 } });
    const page = await context.newPage();
    page.on('pageerror', (err) => pageErrors.push(err.message));

    const auditScreen = async (label, fileName) => {
      await page.waitForTimeout(200);
      const metrics = await page.evaluate(() => {
        const overflowX = document.documentElement.scrollWidth - window.innerWidth;
        const brokenImgs = Array.from(document.querySelectorAll('img')).filter((img) => !img.complete || img.naturalWidth === 0).length;
        const bodyText = document.body.innerText || '';
        return { overflowX, brokenImgs, bodyText };
      });
      assert.equal(metrics.brokenImgs, 0, `${label}: broken images detected`);
      assert.ok(metrics.overflowX <= 2, `${label}: horizontal overflow ${metrics.overflowX}px`);
      assert.equal(FORBIDDEN_LEFT_RIGHT_REGEX.test(metrics.bodyText), false, `${label}: forbidden left/right turn text found`);
      await page.screenshot({ path: path.join(outDir, fileName), fullPage: false });
      console.log(`  PASS [1024x600]: ${label} -> ${fileName}`);
    };

    // Load /kiosk -> Screen 02 (Device Activation)
    await page.goto(`${baseUrl}/kiosk`, { waitUntil: 'networkidle' });
    await page.waitForSelector('[data-testid="kiosk-screen-02"]');
    await auditScreen('Screen 02 Device Activation', '02_activation.png');

    // Screen 01 (Splash Preview)
    await page.evaluate(() => window.__SAVAGE_KIOSK_TEST_HOOK__.previewScreen('splash'));
    await page.waitForSelector('[data-testid="kiosk-screen-01"]');
    await auditScreen('Screen 01 Splash Screen', '01_splash.png');

    // Return to Screen 02 and perform REAL Device Activation
    await page.evaluate(() => window.__SAVAGE_KIOSK_TEST_HOOK__.previewScreen('activation'));
    await page.fill('[data-testid="kiosk-device-code-input"]', activation_code);
    await page.click('[data-testid="kiosk-activate-submit"]');
    await page.waitForSelector('[data-testid="kiosk-screen-03"]');
    await auditScreen('Screen 03 Kiosk Ready Home', '03_ready_home.png');

    // Click Start Attendance -> Screen 16 -> Screen 04 (Live Face Scanning)
    await page.click('[data-testid="kiosk-open-scan-btn"]');
    await page.waitForSelector('[data-testid="kiosk-screen-16"]');
    await auditScreen('Screen 16 Attendance Scan Ready', '16_attendance_ready.png');

    await page.click('[data-testid="kiosk-face-recognition-active-btn"]');
    await page.waitForSelector('[data-testid="kiosk-screen-04"]');
    await auditScreen('Screen 04 Face Scanning', '04_face_scanning.png');

    // Clicking TIME IN when models are missing MUST honestly fail closed to Screen 07!
    await page.click('[data-testid="kiosk-time-in-btn"]');
    await page.waitForSelector('[data-testid="kiosk-screen-07"]');
    const failMsg = await page.textContent('[data-testid="kiosk-failure-message"]');
    assert.match(failMsg || '', /models|not deployed|biometric/i);
    await auditScreen('Screen 07 Verification Failed (Honest Model-Missing Fail-Closed)', '07_verification_failed.png');

    // Screens 05, 06, 08 visual audit
    await page.evaluate(() =>
      window.__SAVAGE_KIOSK_TEST_HOOK__.previewScreen('time_in_success', {
        attendanceOutcome: {
          action: 'TIME_IN',
          employee_name: 'Juan Dela Cruz',
          employee_code: 'RSU-0001',
          shift_date: 'Nov 23, 2026 (Mon)',
          recorded_time: '08:00 AM',
          status: 'Present',
        },
      })
    );
    await page.waitForSelector('[data-testid="kiosk-screen-05"]');
    await auditScreen('Screen 05 Time In Success', '05_time_in_success.png');

    await page.evaluate(() =>
      window.__SAVAGE_KIOSK_TEST_HOOK__.previewScreen('time_out_success', {
        attendanceOutcome: {
          action: 'TIME_OUT',
          employee_name: 'Juan Dela Cruz',
          employee_code: 'RSU-0001',
          shift_date: 'Nov 23, 2026 (Mon)',
          recorded_time: '05:00 PM',
          status: 'Present',
        },
      })
    );
    await page.waitForSelector('[data-testid="kiosk-screen-06"]');
    await auditScreen('Screen 06 Time Out Success', '06_time_out_success.png');

    await page.evaluate(() => window.__SAVAGE_KIOSK_TEST_HOOK__.previewScreen('not_enrolled'));
    await page.waitForSelector('[data-testid="kiosk-screen-08"]');
    await auditScreen('Screen 08 Not Enrolled', '08_not_enrolled.png');

    // Screen 09 (Admin PIN Access) -> Real Unlock -> Screen 14 (Settings) -> Screen 15 (Kiosk Information)
    await page.click('[data-testid="kiosk-settings-btn"]');
    await page.waitForSelector('[data-testid="kiosk-screen-09"]');
    await auditScreen('Screen 09 Admin PIN Access', '09_admin_pin.png');

    await page.fill('[data-testid="kiosk-admin-pin-input"]', '849271');
    await page.click('[data-testid="kiosk-admin-pin-unlock-btn"]');
    await page.waitForSelector('[data-testid="kiosk-screen-14"]');
    await auditScreen('Screen 14 Kiosk Settings', '14_settings.png');

    // Real Sync Now button
    await page.click('[data-testid="kiosk-sync-now-btn"]');
    await page.waitForTimeout(300);

    await page.click('[data-testid="kiosk-open-info-btn"]');
    await page.waitForSelector('[data-testid="kiosk-screen-15"]');
    await auditScreen('Screen 15 Kiosk Information', '15_kiosk_info.png');

    // Back to Settings -> Enroll Employee -> Screen 10 -> Screen 11 (Front Face Only!) -> Screen 12 -> Screen 13
    await page.click('[data-testid="kiosk-info-back-btn"]');
    await page.waitForSelector('[data-testid="kiosk-screen-14"]');
    await page.click('[data-testid="kiosk-settings-enroll-btn"]');
    await page.waitForSelector('[data-testid="kiosk-screen-10"]');
    await page.waitForSelector('[data-testid="kiosk-enroll-row-RSU-0001"]');
    await page.click('[data-testid="kiosk-enroll-row-RSU-0001"]');
    await auditScreen('Screen 10 Enrollment Select Employee', '10_enroll_select.png');

    await page.click('[data-testid="kiosk-enroll-next-btn"]');
    await page.waitForSelector('[data-testid="kiosk-screen-11"]');
    // Verify NO manual capture button exists on Screen 11
    const captureBtns = await page.locator('button:has-text("Capture")').count();
    assert.equal(captureBtns, 0, 'Screen 11 must NOT contain a manual Capture button');
    await auditScreen('Screen 11 Auto Enroll Scanning (Front Face Only)', '11_enroll_scanning.png');

    await page.evaluate(() =>
      window.__SAVAGE_KIOSK_TEST_HOOK__.previewScreen('enroll_processing', { progressPercent: 75 })
    );
    await page.waitForSelector('[data-testid="kiosk-screen-12"]');
    await auditScreen('Screen 12 Auto Enroll Processing', '12_enroll_processing.png');

    await page.evaluate(() =>
      window.__SAVAGE_KIOSK_TEST_HOOK__.previewScreen('enroll_success', {
        enrolledEmployee: { name: 'Juan Dela Cruz', code: 'RSU-0001' },
      })
    );
    await page.waitForSelector('[data-testid="kiosk-screen-13"]');
    await auditScreen('Screen 13 Enrollment Completed', '13_enroll_success.png');

    // Multi-viewport responsive check (Android phone 390x844, Android tablet 768x1024, Desktop 1366x768)
    for (const vp of [
      { name: 'mobile_390x844', width: 390, height: 844 },
      { name: 'tablet_768x1024', width: 768, height: 1024 },
      { name: 'desktop_1366x768', width: 1366, height: 768 },
    ]) {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.evaluate(() => window.__SAVAGE_KIOSK_TEST_HOOK__.previewScreen('ready_home'));
      await page.waitForSelector('[data-testid="kiosk-screen-03"]');
      await auditScreen(`Responsive Ready Home (${vp.name})`, `responsive_${vp.name}_home.png`);
    }

    assert.equal(pageErrors.length, 0, `Uncaught page errors: ${pageErrors.join('; ')}`);
    console.log('\nALL 16 WEB KIOSK SCREENS & 4 RESPONSIVE VIEWPORTS PASSED E2E VISUAL & FUNCTIONAL AUDIT!');
  } finally {
    await browser.close();
    await new Promise((resolve) => server.close(resolve));
    db.close();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
