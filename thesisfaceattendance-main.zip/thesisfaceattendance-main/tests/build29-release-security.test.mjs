import { test } from 'node:test';
import assert from 'node:assert/strict';
import { computeAndroidAttendanceDigest, computeAndroidEnrollmentHash,
  validateAndroidPunch, validateAndroidEnrollment } from '../server/androidBridgeProtocol.ts';

const now=Date.parse('2026-11-22T04:00:00.000Z');
const name='RSU-TEST-KIOSK';
function punch(overrides={}) {
  const p={event_id:'event-29-abcdef123',employee_id:'EMP-0001',action:'TIME_IN',
    kiosk_device_id:name,captured_at_ms:now-1000,biometric_confidence:.9,
    liveness_score:.95,anti_spoofing_score:.92,offline_queued:false,...overrides};
  return [p,{idempotencyKey:p.event_id,eventTimestamp:String(p.captured_at_ms),
    digest:computeAndroidAttendanceDigest(p.event_id,p.employee_id,p.action,p.captured_at_ms,p.kiosk_device_id)}];
}
test('valid online biometric claim retains existing authenticated contract',()=>{
  const [p,h]=punch();
  assert.deepEqual(validateAndroidPunch(p,h,name,now),{valid:true});
});
test('score-only offline replay is rejected even with valid digest and high scores',()=>{
  const [p,h]=punch({offline_queued:true});
  assert.deepEqual(validateAndroidPunch(p,h,name,now),
    {valid:false,code:'OFFLINE_CAPTURE_ATTESTATION_REQUIRED'});
});
test('unsupported offline flag types are rejected',()=>{
  const [p,h]=punch({offline_queued:'true'});
  assert.equal(validateAndroidPunch(p,h,name,now).valid,false);
});
function enrollment(vector) {
  const p={employee_id:'EMP-0001',employee_name:'Example Test Employee',kiosk_device_id:name,
    composite_embedding:vector,enrolled_at_ms:now,
    embedding_sha256:computeAndroidEnrollmentHash('EMP-0001','Example Test Employee',vector)};
  return [p,`${p.employee_id}-${p.embedding_sha256}`];
}
const raw=Array.from({length:192},(_,i)=>Math.cos(i*0.37));
const magnitude=Math.sqrt(raw.reduce((sum,v)=>sum+v*v,0));
const valid=raw.map(v=>v/magnitude);
test('unit normalized 192-dimensional face vector accepted after valid digest',()=>{
  const [p,k]=enrollment(valid);
  assert.deepEqual(validateAndroidEnrollment(p,k,name,now),{valid:true});
});
test('zero vector and non-normalized vector rejected despite correct hash',()=>{
  for(const vector of [Array(192).fill(0),Array(192).fill(0.1)]) {
    const [p,k]=enrollment(vector);
    assert.equal(validateAndroidEnrollment(p,k,name,now).valid,false);
  }
});
test('wrong dimensions (128, 512) and NaN prevented',()=>{
  for(const vector of [valid.slice(0,128),Array(512).fill(.01),[...valid.slice(0,191),NaN]]) {
    const [p,k]=enrollment(vector);
    assert.equal(validateAndroidEnrollment(p,k,name,now).valid,false);
  }
});
test('tampered vector digest is rejected',()=>{
  const [p,k]=enrollment(valid);
  assert.deepEqual(validateAndroidEnrollment({...p,composite_embedding:[...valid.slice(0,191),0.0]},k,name,now),
    {valid:false,code:'TEMPLATE_HASH_MISMATCH'});
});
