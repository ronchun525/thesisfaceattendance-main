/**
 * SAVAGE-RSUCAJ BUILD 36 — Automated Backend, Security, Database & Biometric Unit Test Suite
 *
 * Run with: npx tsx tests/web-kiosk-build36.test.mjs
 */
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import { initDatabase } from '../server/db.ts';
import { createApiRouter } from '../server/api.ts';
import { securityHeadersMiddleware } from '../server/security.ts';
import {
  averageAndNormalizeEmbeddings,
  BIOMETRIC_THRESHOLDS,
  cosineSimilarity,
  decodeClassifierLiveScore,
  EMBEDDING_DIMENSION,
  encodeLivenessBgrNchw,
  encodePadRgbNhwc,
  encodeRecognitionRgbNhwc,
  inspectKioskModels,
  validateL2NormalizedEmbedding,
} from '../server/webKioskBiometrics.ts';

process.env.SESSION_SECRET = crypto.randomBytes(48).toString('hex');
process.env.KIOSK_TEMPLATE_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');

function makeUnitVector(seed) {
  const arr = new Array(EMBEDDING_DIMENSION);
  let sumSq = 0;
  for (let i = 0; i < EMBEDDING_DIMENSION; i++) {
    const val = Math.sin((i + 1) * (seed + 1.37)) * Math.cos((i + 3) * (seed * 0.73 + 0.5));
    arr[i] = val;
    sumSq += val * val;
  }
  const norm = Math.sqrt(sumSq);
  return arr.map((v) => v / norm);
}

function createCookieJar() {
  const map = new Map();
  return {
    ingest(res) {
      const setCookies = typeof res.headers.getSetCookie === 'function'
        ? res.headers.getSetCookie()
        : res.headers.get('set-cookie')
          ? [res.headers.get('set-cookie')]
          : [];
      for (const raw of setCookies) {
        const first = String(raw).split(';')[0];
        const eq = first.indexOf('=');
        if (eq > 0) {
          const name = first.slice(0, eq).trim();
          const val = first.slice(eq + 1).trim();
          if (val === '' || /Max-Age=0/i.test(raw)) {
            map.delete(name);
          } else {
            map.set(name, val);
          }
        }
      }
    },
    header() {
      return Array.from(map.entries())
        .map(([k, v]) => `${k}=${v}`)
        .join('; ');
    },
    has(name) {
      return map.has(name);
    },
  };
}

async function startTestServer(appMode, fixedNowMsRef) {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-b36-'));
  const dbPath = path.join(tmpDir, 'test.db');
  const db = initDatabase(dbPath, {
    mode: appMode,
    initialAdmin: {
      username: 'sysadmin',
      email: 'admin@rsu-cajidiocan.tech',
      password: 'StrongPassword#2026!',
    },
  });

  // Clear forced password change on test admin and seed 2 active employees
  db.prepare(`UPDATE users SET must_change_password = 0 WHERE username = 'sysadmin'`).run();
  db.prepare(`INSERT OR IGNORE INTO departments (code, name) VALUES ('DCS', 'Computer Studies')`).run();
  db.prepare(`INSERT OR IGNORE INTO positions (code, name, base_salary) VALUES ('INST1', 'Instructor I', 28000)`).run();
  db.prepare(`INSERT OR IGNORE INTO shifts (name, time_in, time_out, grace_minutes, status) VALUES ('Regular Day', '08:00', '17:00', 15, 'Active')`).run();
  const dept = db.prepare(`SELECT id FROM departments LIMIT 1`).get();
  const pos = db.prepare(`SELECT id FROM positions LIMIT 1`).get();
  const shift = db.prepare(`SELECT id FROM shifts LIMIT 1`).get();

  db.prepare(
    `INSERT INTO employees (employee_code, full_name, email, department_id, position_id, shift_id, status)
     VALUES ('RSU-0001', 'Juan Dela Cruz', 'juan@rsu.edu.ph', ?, ?, ?, 'Active'),
            ('RSU-0002', 'Maria Santos', 'maria@rsu.edu.ph', ?, ?, ?, 'Active')`
  ).run(dept.id, pos.id, shift.id, dept.id, pos.id, shift.id);

  const app = express();
  app.use(securityHeadersMiddleware);
  app.use(express.json({ limit: '2mb' }));
  app.use(
    '/api',
    createApiRouter(db, {
      appMode,
      nowMs: () => fixedNowMsRef.value,
    })
  );
  app.get('/kiosk', (_req, res) => res.status(200).send('kiosk'));
  app.get('/', (_req, res) => res.status(200).send('admin'));

  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const addr = server.address();
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  return {
    db,
    baseUrl,
    close: async () => {
      await new Promise((resolve) => server.close(resolve));
      db.close();
      fs.rmSync(tmpDir, { recursive: true, force: true });
    },
  };
}

let passed = 0;
async function test(name, fn) {
  try {
    await fn();
    passed += 1;
    console.log(`  PASS: ${name}`);
  } catch (err) {
    console.error(`  FAIL: ${name}`);
    console.error(err);
    process.exitCode = 1;
    throw err;
  }
}

async function run() {
  console.log('Running SAVAGE-RSUCAJ BUILD 36 Web Kiosk Test Suite...\n');

  // 1. Pure BUILD 20 Biometric Codec & Model Integrity Unit Tests
  await test('BUILD 20 PAD RGB NHWC 80x80 & Liveness BGR NCHW 80x80 & Recognition RGB NHWC 112x112 tensor codecs', async () => {
    const rgba80 = new Uint8ClampedArray(80 * 80 * 4);
    rgba80[0] = 255; // R
    rgba80[1] = 128; // G
    rgba80[2] = 0;   // B
    rgba80[3] = 255; // A

    const pad = encodePadRgbNhwc(rgba80, 80, 80);
    assert.equal(pad.length, 80 * 80 * 3);
    assert.ok(Math.abs(pad[0] - (255 / 128 - 1)) < 1e-5);
    assert.ok(Math.abs(pad[1] - 0) < 1e-5);
    assert.ok(Math.abs(pad[2] - -1) < 1e-5);

    const live = encodeLivenessBgrNchw(rgba80, 80, 80);
    assert.equal(live.length, 3 * 80 * 80);
    assert.ok(Math.abs(live[0] - 0) < 1e-5); // Channel 0 = B
    assert.ok(Math.abs(live[6400] - 128 / 255) < 1e-5); // Channel 1 = G
    assert.ok(Math.abs(live[12800] - 1.0) < 1e-5); // Channel 2 = R

    const rgba112 = new Uint8ClampedArray(112 * 112 * 4);
    rgba112[0] = 64;
    rgba112[1] = 128;
    rgba112[2] = 192;
    const rec = encodeRecognitionRgbNhwc(rgba112, 112, 112);
    assert.equal(rec.length, 112 * 112 * 3);
    assert.ok(Math.abs(rec[0] - (64 / 128 - 1)) < 1e-5);
    assert.ok(Math.abs(rec[1] - 0) < 1e-5);
    assert.ok(Math.abs(rec[2] - (192 / 128 - 1)) < 1e-5);
  });

  await test('Classifier live-score decoding preserves probabilities, applies stabilized softmax to logits, and fails closed on NaN', async () => {
    const probRes = decodeClassifierLiveScore([0.92, 0.05, 0.03], 0);
    assert.equal(probRes.valid, true);
    assert.equal(probRes.wasAlreadyProbability, true);
    assert.ok(Math.abs(probRes.liveProbability - 0.92) < 1e-4);

    const logitRes = decodeClassifierLiveScore([-1.2, 4.5, -0.8], 1);
    assert.equal(logitRes.valid, true);
    assert.equal(logitRes.wasAlreadyProbability, false);
    assert.ok(logitRes.liveProbability > 0.98);

    const nanRes = decodeClassifierLiveScore([0.1, Number.NaN, 0.2], 1);
    assert.equal(nanRes.valid, false);
    assert.equal(nanRes.liveProbability, 0);
  });

  await test('inspectKioskModels reports MISSING, INVALID_HEADER, and HASH_MISMATCH honestly', async () => {
    const tmpModels = fs.mkdtempSync(path.join(os.tmpdir(), 'savage-models-'));
    try {
      const emptyCheck = inspectKioskModels(tmpModels);
      assert.equal(emptyCheck.all_models_verified_on_disk, false);
      assert.equal(emptyCheck.production_attendance_ready, false);
      assert.equal(emptyCheck.models.anti_spoofing_pad.status, 'MISSING');

      // Write bogus file without TFL3 header
      fs.writeFileSync(path.join(tmpModels, 'anti_spoofing_pad.tflite'), Buffer.from('NOT_A_TFLITE_MODEL'));
      // Write file with TFL3 header at offset 4 but wrong SHA-256
      const fakeTfl = Buffer.concat([Buffer.from([0, 0, 0, 0]), Buffer.from('TFL3'), Buffer.from('payload')]);
      fs.writeFileSync(path.join(tmpModels, 'liveness_detection.tflite'), fakeTfl);

      const inspected = inspectKioskModels(tmpModels);
      assert.equal(inspected.models.anti_spoofing_pad.status, 'INVALID_HEADER');
      assert.equal(inspected.models.liveness_detection.status, 'HASH_MISMATCH');
      assert.equal(inspected.models.face_recognition.status, 'MISSING');
    } finally {
      fs.rmSync(tmpModels, { recursive: true, force: true });
    }
  });

  await test('Embedding validation and averaging enforce 192D L2 unit norm', async () => {
    const v1 = makeUnitVector(1);
    const v2Raw = v1.map((x, idx) => x + (idx % 2 === 0 ? 0.002 : -0.002));
    const v2Norm = Math.sqrt(v2Raw.reduce((acc, x) => acc + x * x, 0));
    const v2 = v2Raw.map((x) => x / v2Norm);
    assert.equal(validateL2NormalizedEmbedding(v1).valid, true);
    assert.equal(validateL2NormalizedEmbedding(v1.map((x) => x * 5)).valid, false);
    const avg = averageAndNormalizeEmbeddings([v1, v2]);
    assert.equal(validateL2NormalizedEmbedding(avg).valid, true);
    assert.ok(cosineSimilarity(avg, v1) > 0.99);
  });

  // 2. Full Non-Production Integration & Security Test (appMode='test')
  const nowRef = { value: Date.parse('2026-11-23T00:05:00.000Z') }; // 08:05 AM Asia/Manila (Monday)
  const srv = await startTestServer('test', nowRef);
  try {
    const adminJar = createCookieJar();
    const kioskJar = createCookieJar();

    await test('Permissions-Policy enables camera=(self) on /kiosk and keeps camera=() on /', async () => {
      const kioskRes = await fetch(`${srv.baseUrl}/kiosk`);
      assert.equal(kioskRes.headers.get('permissions-policy'), 'camera=(self), microphone=(), geolocation=()');
      const adminRes = await fetch(`${srv.baseUrl}/`);
      assert.equal(adminRes.headers.get('permissions-policy'), 'camera=(), microphone=(), geolocation=()');
    });

    // Sign in Admin
    const loginRes = await fetch(`${srv.baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier: 'sysadmin', password: 'StrongPassword#2026!' }),
    });
    assert.equal(loginRes.status, 200);
    adminJar.ingest(loginRes);
    const loginBody = await loginRes.json();
    const adminCsrf = loginBody.csrfToken;

    const adminHeaders = () => ({
      'Content-Type': 'application/json',
      Cookie: adminJar.header(),
      'X-CSRF-Token': adminCsrf,
    });

    // Register a Kiosk Device + Generate One-Time Activation Code + Configure Admin PIN
    let deviceId;
    let activationCode;
    await test('Admin creates kiosk device, mints one-time activation code, and configures scrypt Admin PIN', async () => {
      const devRes = await fetch(`${srv.baseUrl}/api/devices`, {
        method: 'POST',
        headers: adminHeaders(),
        body: JSON.stringify({
          name: 'RSUCAJ-KIOSK-01',
          device_type: 'Raspberry Pi',
          model_info: 'Raspberry Pi 3B Chromium',
          ip_address: '192.168.1.50',
          location: 'Main Gate',
        }),
      });
      assert.equal(devRes.status, 201);
      const devData = await devRes.json();
      deviceId = devData.id;

      const codeRes = await fetch(`${srv.baseUrl}/api/devices/${deviceId}/activation-code`, {
        method: 'POST',
        headers: adminHeaders(),
        body: JSON.stringify({}),
      });
      assert.equal(codeRes.status, 201);
      const codeData = await codeRes.json();
      assert.match(codeData.activation_code, /^RSU-[A-Z0-9]{4}-[A-Z0-9]{4}$/);
      activationCode = codeData.activation_code;

      // Weak PIN rejected
      const weakPin = await fetch(`${srv.baseUrl}/api/kiosk/web/admin-pin`, {
        method: 'PUT',
        headers: adminHeaders(),
        body: JSON.stringify({ pin: '1234' }),
      });
      assert.equal(weakPin.status, 400);

      // Strong PIN accepted
      const strongPin = await fetch(`${srv.baseUrl}/api/kiosk/web/admin-pin`, {
        method: 'PUT',
        headers: adminHeaders(),
        body: JSON.stringify({ pin: '849271' }),
      });
      assert.equal(strongPin.status, 200);
    });

    let kioskCsrf;
    await test('Device activation sets HttpOnly cookie, omits raw api_token, and blocks activation code replay', async () => {
      const actRes = await fetch(`${srv.baseUrl}/api/kiosk/web/activate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ device_code: activationCode }),
      });
      assert.equal(actRes.status, 200);
      const setCookieHeader = actRes.headers.get('set-cookie') || '';
      assert.match(setCookieHeader, /savage_kiosk_session=/);
      assert.match(setCookieHeader, /HttpOnly/i);
      kioskJar.ingest(actRes);
      const actData = await actRes.json();
      assert.equal(actData.activated, true);
      assert.equal(actData.device.api_token, undefined);
      assert.ok(actData.csrf_token);
      kioskCsrf = actData.csrf_token;

      // Replay rejected
      const replayRes = await fetch(`${srv.baseUrl}/api/kiosk/web/activate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ device_code: activationCode }),
      });
      assert.equal(replayRes.status, 409);
    });

    const kioskHeaders = () => ({
      'Content-Type': 'application/json',
      Cookie: kioskJar.header(),
      'X-Kiosk-CSRF': kioskCsrf,
    });

    await test('Anonymous enrollment & settings mutation blocked before Admin PIN unlock; valid PIN unlocks', async () => {
      const unauthEmp = await fetch(`${srv.baseUrl}/api/kiosk/web/employees`, { headers: { Cookie: kioskJar.header() } });
      assert.equal(unauthEmp.status, 403);

      const unauthSettings = await fetch(`${srv.baseUrl}/api/kiosk/web/settings`, {
        method: 'PATCH',
        headers: kioskHeaders(),
        body: JSON.stringify({ voice_prompt_enabled: false }),
      });
      assert.equal(unauthSettings.status, 403);

      // Wrong PIN rejected
      const wrongPin = await fetch(`${srv.baseUrl}/api/kiosk/web/admin/unlock`, {
        method: 'POST',
        headers: kioskHeaders(),
        body: JSON.stringify({ pin: '999999' }),
      });
      assert.equal(wrongPin.status, 401);

      // Valid PIN unlocks
      const okPin = await fetch(`${srv.baseUrl}/api/kiosk/web/admin/unlock`, {
        method: 'POST',
        headers: kioskHeaders(),
        body: JSON.stringify({ pin: '849271' }),
      });
      assert.equal(okPin.status, 200);
      const okPinData = await okPin.json();
      assert.equal(okPinData.unlocked, true);

      // Persisted settings update + Sync Now work
      const patchRes = await fetch(`${srv.baseUrl}/api/kiosk/web/settings`, {
        method: 'PATCH',
        headers: kioskHeaders(),
        body: JSON.stringify({ voice_prompt_enabled: true, face_capture_enabled: true }),
      });
      assert.equal(patchRes.status, 200);

      const syncRes = await fetch(`${srv.baseUrl}/api/kiosk/web/sync`, {
        method: 'POST',
        headers: kioskHeaders(),
        body: JSON.stringify({}),
      });
      assert.equal(syncRes.status, 200);
      const syncData = await syncRes.json();
      assert.equal(syncData.ok, true);
      assert.equal(syncData.active_employee_count, 2);
    });

    const juanVec = makeUnitVector(42);
    const unknownVec = makeUnitVector(999);
    const juanRow = srv.db.prepare(`SELECT id FROM employees WHERE employee_code = 'RSU-0001'`).get();
    const mariaRow = srv.db.prepare(`SELECT id FROM employees WHERE employee_code = 'RSU-0002'`).get();

    await test('Front-face enrollment requires single-use nonce, persists AES-256-GCM template, and blocks cross-employee duplicate', async () => {
      const chRes = await fetch(`${srv.baseUrl}/api/kiosk/web/challenge`, {
        method: 'POST',
        headers: kioskHeaders(),
        body: JSON.stringify({ scope: 'ENROLLMENT' }),
      });
      assert.equal(chRes.status, 201);
      const { challenge_nonce: nonce1 } = await chRes.json();

      const enrollRes = await fetch(`${srv.baseUrl}/api/kiosk/web/enroll`, {
        method: 'POST',
        headers: kioskHeaders(),
        body: JSON.stringify({
          challenge_nonce: nonce1,
          employee_id: juanRow.id,
          frontal_only: true,
          captured_frames: 4,
          frame_timestamps_ms: [1000, 1400, 1800, 2200],
          detection_confidence: 0.94,
          quality_score: 0.88,
          liveness_score: 0.91,
          anti_spoof_score: 0.93,
          embedding: juanVec,
        }),
      });
      assert.equal(enrollRes.status, 201);
      const enrollData = await enrollRes.json();
      assert.equal(enrollData.backend_confirmed, true);

      // Replaying the same nonce is rejected (409)
      const replayNonceRes = await fetch(`${srv.baseUrl}/api/kiosk/web/enroll`, {
        method: 'POST',
        headers: kioskHeaders(),
        body: JSON.stringify({
          challenge_nonce: nonce1,
          employee_id: juanRow.id,
          frontal_only: true,
          captured_frames: 3,
          detection_confidence: 0.94,
          quality_score: 0.88,
          liveness_score: 0.91,
          anti_spoof_score: 0.93,
          embedding: juanVec,
        }),
      });
      assert.equal(replayNonceRes.status, 409);

      // Cross-employee duplicate identity blocked (409 CROSS_EMPLOYEE_DUPLICATE)
      const ch2 = await (
        await fetch(`${srv.baseUrl}/api/kiosk/web/challenge`, {
          method: 'POST',
          headers: kioskHeaders(),
          body: JSON.stringify({ scope: 'ENROLLMENT' }),
        })
      ).json();
      const dupEmpRes = await fetch(`${srv.baseUrl}/api/kiosk/web/enroll`, {
        method: 'POST',
        headers: kioskHeaders(),
        body: JSON.stringify({
          challenge_nonce: ch2.challenge_nonce,
          employee_id: mariaRow.id,
          frontal_only: true,
          captured_frames: 3,
          frame_timestamps_ms: [100, 500, 900],
          detection_confidence: 0.94,
          quality_score: 0.88,
          liveness_score: 0.91,
          anti_spoof_score: 0.93,
          embedding: juanVec,
        }),
      });
      assert.equal(dupEmpRes.status, 409);
      const dupData = await dupEmpRes.json();
      assert.equal(dupData.code, 'CROSS_EMPLOYEE_DUPLICATE');
    });

    await test('Attendance resolves identity strictly server-side, rejects spoofing/unknown faces, records Time In/Out, and enforces duplicate protection', async () => {
      const nextNonce = async () =>
        (
          await (
            await fetch(`${srv.baseUrl}/api/kiosk/web/challenge`, {
              method: 'POST',
              headers: kioskHeaders(),
              body: JSON.stringify({ scope: 'ATTENDANCE' }),
            })
          ).json()
        ).challenge_nonce;

      // 1) Low anti-spoof rejected (422)
      const spoofRes = await fetch(`${srv.baseUrl}/api/kiosk/web/attendance`, {
        method: 'POST',
        headers: kioskHeaders(),
        body: JSON.stringify({
          challenge_nonce: await nextNonce(),
          action: 'TIME_IN',
          detection_confidence: 0.93,
          quality_score: 0.85,
          liveness_score: 0.92,
          anti_spoof_score: 0.25,
          embedding: juanVec,
        }),
      });
      assert.equal(spoofRes.status, 422);

      // 2) Unknown face returns 404 NOT_ENROLLED even if client attempts to inject employee_id!
      const unknownRes = await fetch(`${srv.baseUrl}/api/kiosk/web/attendance`, {
        method: 'POST',
        headers: kioskHeaders(),
        body: JSON.stringify({
          challenge_nonce: await nextNonce(),
          action: 'TIME_IN',
          employee_id: juanRow.id, // untrusted client claim MUST be ignored
          match_verified: true,    // untrusted client claim MUST be ignored
          detection_confidence: 0.95,
          quality_score: 0.9,
          liveness_score: 0.92,
          anti_spoof_score: 0.91,
          embedding: unknownVec,
        }),
      });
      assert.equal(unknownRes.status, 404);
      const unknownData = await unknownRes.json();
      assert.equal(unknownData.code, 'NOT_ENROLLED');

      // 3) Valid server-matched TIME_IN recorded with voice_cue THANK_YOU
      const timeInRes = await fetch(`${srv.baseUrl}/api/kiosk/web/attendance`, {
        method: 'POST',
        headers: kioskHeaders(),
        body: JSON.stringify({
          challenge_nonce: await nextNonce(),
          action: 'TIME_IN',
          detection_confidence: 0.95,
          quality_score: 0.9,
          liveness_score: 0.92,
          anti_spoof_score: 0.91,
          embedding: juanVec,
        }),
      });
      assert.equal(timeInRes.status, 200);
      const timeInData = await timeInRes.json();
      assert.equal(timeInData.recorded, true);
      assert.equal(timeInData.employee_code, 'RSU-0001');
      assert.equal(timeInData.voice_cue, 'THANK_YOU');

      // 4) Duplicate TIME_IN returns 409 "Already taken attendance"
      const dupInRes = await fetch(`${srv.baseUrl}/api/kiosk/web/attendance`, {
        method: 'POST',
        headers: kioskHeaders(),
        body: JSON.stringify({
          challenge_nonce: await nextNonce(),
          action: 'TIME_IN',
          detection_confidence: 0.95,
          quality_score: 0.9,
          liveness_score: 0.92,
          anti_spoof_score: 0.91,
          embedding: juanVec,
        }),
      });
      assert.equal(dupInRes.status, 409);
      const dupInData = await dupInRes.json();
      assert.equal(dupInData.error, 'Already taken attendance');
      assert.equal(dupInData.voice_cue, 'TRY_AGAIN');

      // 5) Advance server clock to 17:05 Manila and record TIME_OUT
      nowRef.value = Date.parse('2026-11-23T09:05:00.000Z');
      const timeOutRes = await fetch(`${srv.baseUrl}/api/kiosk/web/attendance`, {
        method: 'POST',
        headers: kioskHeaders(),
        body: JSON.stringify({
          challenge_nonce: await nextNonce(),
          action: 'TIME_OUT',
          detection_confidence: 0.95,
          quality_score: 0.9,
          liveness_score: 0.92,
          anti_spoof_score: 0.91,
          embedding: juanVec,
        }),
      });
      assert.equal(timeOutRes.status, 200);
      const timeOutData = await timeOutRes.json();
      assert.equal(timeOutData.action, 'TIME_OUT');
      assert.equal(timeOutData.voice_cue, 'THANK_YOU');
    });

    await test('Revoking kiosk device immediately invalidates active HttpOnly web_kiosk_sessions', async () => {
      const revRes = await fetch(`${srv.baseUrl}/api/devices/${deviceId}/revoke`, {
        method: 'POST',
        headers: adminHeaders(),
        body: JSON.stringify({}),
      });
      assert.equal(revRes.status, 200);

      const sessAfterRevoke = await (
        await fetch(`${srv.baseUrl}/api/kiosk/web/session`, { headers: { Cookie: kioskJar.header() } })
      ).json();
      assert.equal(sessAfterRevoke.activated, false);
    });
  } finally {
    await srv.close();
  }

  // 3. Production Fail-Closed Security Gate Test (appMode='production')
  const prodNow = { value: Date.parse('2026-11-23T00:05:00.000Z') };
  const prodSrv = await startTestServer('production', prodNow);
  try {
    await test('Production mode strictly locks liveness_enforced=true and fails closed (503) when TFLite models/server attestation are absent', async () => {
      const aJar = createCookieJar();
      const kJar = createCookieJar();
      const loginRes = await fetch(`${prodSrv.baseUrl}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: 'sysadmin', password: 'StrongPassword#2026!' }),
      });
      aJar.ingest(loginRes);
      const { csrfToken } = await loginRes.json();
      const aHeaders = { 'Content-Type': 'application/json', Cookie: aJar.header(), 'X-CSRF-Token': csrfToken };

      const dev = await (
        await fetch(`${prodSrv.baseUrl}/api/devices`, {
          method: 'POST',
          headers: aHeaders,
          body: JSON.stringify({ name: 'PROD-KIOSK', ip_address: '10.0.0.10' }),
        })
      ).json();
      const { activation_code } = await (
        await fetch(`${prodSrv.baseUrl}/api/devices/${dev.id}/activation-code`, {
          method: 'POST',
          headers: aHeaders,
          body: JSON.stringify({}),
        })
      ).json();
      await fetch(`${prodSrv.baseUrl}/api/kiosk/web/admin-pin`, {
        method: 'PUT',
        headers: aHeaders,
        body: JSON.stringify({ pin: '739152' }),
      });

      const actRes = await fetch(`${prodSrv.baseUrl}/api/kiosk/web/activate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ device_code: activation_code }),
      });
      kJar.ingest(actRes);
      const actBody = await actRes.json();
      assert.equal(actBody.biometric_policy.production_attendance_blocked, true);

      const kHeaders = { 'Content-Type': 'application/json', Cookie: kJar.header(), 'X-Kiosk-CSRF': actBody.csrf_token };
      await fetch(`${prodSrv.baseUrl}/api/kiosk/web/admin/unlock`, {
        method: 'POST',
        headers: kHeaders,
        body: JSON.stringify({ pin: '739152' }),
      });

      // Disabling liveness in production MUST return 403
      const livenessOff = await fetch(`${prodSrv.baseUrl}/api/kiosk/web/settings`, {
        method: 'PATCH',
        headers: kHeaders,
        body: JSON.stringify({ liveness_enforced: false }),
      });
      assert.equal(livenessOff.status, 403);

      // Attendance in production MUST fail closed with 503 when TFLite models/server attestation are absent
      const prodAtt = await fetch(`${prodSrv.baseUrl}/api/kiosk/web/attendance`, {
        method: 'POST',
        headers: kHeaders,
        body: JSON.stringify({
          action: 'TIME_IN',
          embedding: makeUnitVector(1),
        }),
      });
      assert.equal(prodAtt.status, 503);
      const prodAttBody = await prodAtt.json();
      assert.equal(prodAttBody.code, 'PRODUCTION_BIOMETRIC_ATTESTATION_BLOCKED');
    });
  } finally {
    await prodSrv.close();
  }

  console.log(`\nALL BUILD 36 WEB KIOSK BACKEND & SECURITY TESTS PASSED (${passed}/${passed}).`);
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
