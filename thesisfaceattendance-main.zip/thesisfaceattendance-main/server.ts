import 'dotenv/config';
import crypto from 'node:crypto';
import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { createServer as createViteServer } from 'vite';
import { closeDatabaseSafely, initDatabase } from './server/db.ts';
import { createApiRouter } from './server/api.ts';
import { validateEnv } from './server/env.ts';
import { securityHeadersMiddleware } from './server/security.ts';
import { RealtimeHub } from './server/realtimeHub.ts';

async function startServer() {
  const rawNodeEnv = (process.env.NODE_ENV ?? 'development').trim();
  const isDevBoot = rawNodeEnv === 'development';

  // In local development only, if SESSION_SECRET is completely unset (no .env provisioned yet),
  // mint a non-deterministic ephemeral 384-bit CSPRNG secret in memory for this single dev process.
  // Production (NODE_ENV=production) and any invalid/placeholder secret ALWAYS fail securely.
  if (isDevBoot && !process.env.SESSION_SECRET?.trim()) {
    process.env.SESSION_SECRET = crypto.randomBytes(48).toString('hex');
    console.warn(
      '[DEV SECURITY NOTICE] SESSION_SECRET is not set in .env; generated an ephemeral in-memory random key for this development session only. Active sessions will reset on restart. Configure SESSION_SECRET in .env before production deployment.'
    );
  }

  const envCheck = validateEnv(process.env);
  if (!envCheck.valid) {
    console.error('SECURITY BOOT ABORTED — Environment configuration validation failed:');
    for (const err of envCheck.errors) {
      console.error(`  - ${err}`);
    }
    console.error('Configure .env from .env.example and verify with `npm run check:env`.');
    process.exit(1);
  }
  for (const warning of envCheck.warnings) {
    console.warn(`[ENV NOTICE] ${warning}`);
  }

  const app = express();
  app.disable('x-powered-by');
  if (envCheck.config.trustProxy) {
    app.set('trust proxy', 1);
  }
  app.use(securityHeadersMiddleware);

  const isProd = envCheck.config.nodeEnv === 'production';
  // Dev server must listen on port 3000 (or explicit DEV_PORT) regardless of container PORT=8080.
  const port = isProd ? envCheck.config.port : Number(process.env.DEV_PORT) || 3000;

  const hasAnyAdminEnv = Boolean(
    process.env.ADMIN_INITIAL_USERNAME?.trim() ||
      process.env.ADMIN_INITIAL_EMAIL?.trim() ||
      process.env.ADMIN_INITIAL_PASSWORD?.trim()
  );
  const devInitialAdmin =
    isDevBoot && !hasAnyAdminEnv
      ? {
          username: 'dev_admin',
          email: 'dev_admin@rsucaj.edu.ph',
          password: `Dev!${crypto.randomBytes(12).toString('hex')}9A`,
        }
      : undefined;

  let activeDb = initDatabase(envCheck.config.databasePath, {
    mode: envCheck.config.appMode,
    seedDemoData: false,
    busyTimeoutMs: envCheck.config.sqliteBusyTimeoutMs,
    walAutocheckpoint: envCheck.config.sqliteWalAutocheckpoint,
    initialAdmin: devInitialAdmin,
  });

  if (devInitialAdmin) {
    const bootstrappedDevAdmin = activeDb
      .prepare('SELECT COUNT(*) as c FROM users WHERE username = ?')
      .get(devInitialAdmin.username) as { c: number };
    if (bootstrappedDevAdmin.c > 0) {
      console.warn(
        '[DEV SECURITY NOTICE] ADMIN_INITIAL_* credentials are not set in .env; ensured an ephemeral development administrator account (username="dev_admin", forced password change on first login). Set ADMIN_INITIAL_USERNAME, ADMIN_INITIAL_EMAIL, and ADMIN_INITIAL_PASSWORD in .env or use `npm run admin:recover` to manage credentials.'
      );
    }
  }

  const realtimeHub = new RealtimeHub();

  // Mount REST API routes
  app.use(
    '/api',
    createApiRouter(activeDb, {
      maxFailedLoginAttempts: envCheck.config.maxFailedLoginAttempts,
      lockoutDurationMinutes: envCheck.config.lockoutDurationMinutes,
      loginRateLimitMax: envCheck.config.loginRateLimitMax,
      dbPath: envCheck.config.databasePath,
      backupDir: envCheck.config.backupDir,
      backupRetentionCount: envCheck.config.backupRetentionCount,
      appMode: envCheck.config.appMode,
      stagingImpairmentEnabled: envCheck.config.stagingImpairmentEnabled,
      realtimeHub,
      onDatabaseReplaced: (nextDb) => {
        activeDb = nextDb;
      },
    })
  );

  // Explicit API miss: don't let an invalid kiosk path resolve to the website SPA.
  app.use('/api', (_req, res) => {
    res.status(404).json({ code: 'API_NOT_FOUND', message: 'The requested backend API route is not deployed.' });
  });

  let viteServer: Awaited<ReturnType<typeof createViteServer>> | null = null;

  if (!isProd) {
    viteServer = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(viteServer.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.use((req, res, next) => {
      if (req.path.startsWith('/api')) {
        next();
        return;
      }
      const indexHtml = path.join(distDir, 'index.html');
      if (fs.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(503).send('Build output not found. Run npm run build first.');
      }
    });
  }

  const httpServer = app.listen(port, '0.0.0.0', () => {
    console.log(
      `SAVAGE-RSUCAJ Smart Attendance System (${envCheck.config.nodeEnv} / mode=${envCheck.config.appMode}) running on http://0.0.0.0:${port}`
    );
  });

  let shuttingDown = false;
  const shutdown = (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    console.log(`Received ${signal}; closing SSE clients, checkpointing SQLite WAL, and shutting down SAVAGE-RSUCAJ server gracefully...`);
    realtimeHub.closeAll();
    httpServer.close(async () => {
      try {
        if (viteServer) {
          await viteServer.close();
        }
        const cp = closeDatabaseSafely(activeDb);
        if (cp) {
          console.log(`SQLite WAL checkpointed (${cp.mode}: ${cp.checkpointed}/${cp.log} frames) and database closed safely.`);
        }
      } catch (err) {
        console.error('Error during graceful shutdown:', err);
      }
      process.exit(0);
    });
    setTimeout(() => {
      try {
        closeDatabaseSafely(activeDb);
      } catch {
        // ignore double-close
      }
      process.exit(0);
    }, 3000).unref();
  };

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

startServer().catch((err) => {
  console.error('Failed to start SAVAGE-RSUCAJ server:', err instanceof Error ? err.message : err);
  process.exit(1);
});
