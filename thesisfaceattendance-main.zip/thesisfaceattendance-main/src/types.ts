export type NavModule =
  | 'dashboard'
  | 'employees'
  | 'departments'
  | 'positions'
  | 'shifts'
  | 'holidays'
  | 'attendance'
  | 'corrections'
  | 'leaves'
  | 'payroll'
  | 'reports'
  | 'devices'
  | 'audit-logs'
  | 'notifications'
  | 'settings';

export interface AuthUser {
  id: number;
  username: string;
  email: string;
  full_name: string;
  role: string;
  department_id?: number | null;
  employee_id?: number | null;
  must_change_password?: boolean;
  permissions?: string[];
}

export interface PortalUser {
  id: number;
  username: string;
  email: string;
  full_name: string;
  role: string;
  department_id: number | null;
  department_code?: string | null;
  department_name?: string | null;
  employee_id: number | null;
  must_change_password: number;
  is_active: number;
  failed_login_attempts: number;
  locked_until: string | null;
  password_changed_at: string | null;
  created_at: string;
}

export interface Department {
  id: number;
  code: string;
  name: string;
  head_name: string;
  employee_count: number;
  created_at: string;
}

export interface Position {
  id: number;
  code: string;
  name: string;
  type: 'Regular' | 'Contractual' | 'Part-Time';
  base_salary: number;
  allowance: number;
  employee_count?: number;
  created_at: string;
}

export interface Shift {
  id: number;
  name: string;
  time_in: string;
  time_out: string;
  grace_minutes: number;
  rest_days?: string;
  status: 'Active' | 'Inactive';
  created_at: string;
}

export interface Holiday {
  id: number;
  date: string;
  name: string;
  type: 'Regular' | 'Special Non-Working';
  created_at: string;
}

export interface Employee {
  id: number;
  employee_code: string;
  full_name: string;
  email: string;
  department_id: number;
  department_code?: string;
  department_name?: string;
  position_id: number;
  position_code?: string;
  position_name?: string;
  shift_id: number;
  shift_name?: string;
  status: 'Active' | 'Inactive';
  hired_date: string;
  monthly_salary: number;
  monthly_allowance: number;
  created_at: string;
}

export type AttendanceStatus =
  | 'Present'
  | 'Late'
  | 'Absent'
  | 'Undertime'
  | 'On Leave'
  | 'OB'
  | 'Rest Day'
  | 'Holiday'
  | 'Missing Time In'
  | 'Missing Time Out'
  | 'No Schedule';

export type AttendanceAction =
  | 'TIME_IN'
  | 'TIME_OUT'
  | 'BREAK_OUT'
  | 'BREAK_IN'
  | 'OVERTIME_OUT';

export interface AttendanceRecord {
  id: number;
  employee_id: number;
  employee_code: string;
  employee_name: string;
  department_code: string;
  department_name: string;
  date: string;
  time_in: string | null;
  time_out: string | null;
  break_out?: string | null;
  break_in?: string | null;
  overtime_out?: string | null;
  work_hours: string;
  late_minutes?: number;
  undertime_minutes?: number;
  overtime_minutes?: number;
  status: AttendanceStatus;
  device_name: string;
  remarks: string;
  reconciled_at?: string | null;
}

export interface AttendanceEvent {
  id: number;
  event_uid: string;
  employee_id: number;
  device_id: number | null;
  device_name: string;
  attendance_date: string;
  punch_type: string;
  punch_time: string;
  server_timestamp_utc: string;
  manila_timestamp: string;
  device_timestamp_utc: string | null;
  clock_drift_seconds: number | null;
  offline_replay: number;
  decision: 'ACCEPTED' | 'REJECTED' | 'ESCALATED';
  decision_code: string;
  decision_reason: string;
  source: string;
  created_at: string;
}

export interface CorrectionRequest {
  id: number;
  employee_id: number;
  employee_code: string;
  employee_name: string;
  department_code: string;
  attendance_date: string;
  request_type: 'Time In' | 'Time Out' | 'Full Day';
  requested_time: string;
  requested_time_out?: string | null;
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Reversed';
  reviewed_by: string | null;
  reviewed_by_user_id?: number | null;
  reviewed_at: string | null;
  reviewed_at_utc?: string | null;
  reviewer_notes?: string;
  original_time_in?: string | null;
  original_time_out?: string | null;
  original_status?: string | null;
  original_work_hours?: string | null;
  approved_time?: string | null;
  approved_time_out?: string | null;
  attachment_name?: string;
  attachment_mime?: string;
  attachment_data?: string;
  has_attachment?: number;
  document_reference?: string;
  reversed_by?: string | null;
  reversed_at_utc?: string | null;
  reversal_reason?: string;
  created_by_username?: string | null;
  current_time_in?: string | null;
  current_time_out?: string | null;
  current_attendance_status?: string | null;
  created_at: string;
}

export interface CorrectionAuditEntry {
  id: number;
  correction_id: number;
  employee_id: number;
  attendance_date: string;
  action: 'SUBMITTED' | 'APPROVED' | 'REJECTED' | 'REVERSED';
  actor_user_id: number | null;
  actor_username: string;
  actor_role: string;
  original_time_in: string | null;
  original_time_out: string | null;
  original_status: string | null;
  requested_type: string;
  requested_time: string;
  requested_time_out: string | null;
  approved_time: string | null;
  approved_time_out: string | null;
  resulting_time_in: string | null;
  resulting_time_out: string | null;
  resulting_status: string | null;
  reason: string;
  document_ref: string;
  recorded_at_utc: string;
  recorded_at_manila: string;
}

export type LeaveDayPortion = 'FULL' | 'HALF_AM' | 'HALF_PM';

export interface LeavePolicy {
  id: number;
  leave_type: string;
  code: string;
  annual_entitlement: number;
  track_balance: number;
  allow_half_day: number;
  exclude_weekends_rest_days: number;
  exclude_holidays: number;
  allow_negative_balance: number;
  requires_document_after_days: number;
  attendance_status: 'On Leave' | 'OB';
  is_paid: number;
  is_active: number;
  updated_by: string;
  updated_at: string;
}

export interface LeaveRequest {
  id: number;
  employee_id: number;
  employee_code: string;
  employee_name: string;
  department_code: string;
  leave_type: string;
  start_date: string;
  end_date: string;
  days_count: number;
  day_portion?: LeaveDayPortion;
  calendar_days?: number;
  excluded_days_json?: string;
  eligible_dates_json?: string;
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Cancelled';
  reviewed_by: string | null;
  reviewed_at?: string | null;
  reviewed_at_utc?: string | null;
  reviewer_notes?: string;
  cancelled_by?: string | null;
  cancelled_at_utc?: string | null;
  cancel_reason?: string;
  attachment_name?: string;
  attachment_mime?: string;
  attachment_data?: string;
  has_attachment?: number;
  document_reference?: string;
  created_by_username?: string | null;
  created_at: string;
}

export interface LeaveDayAllocation {
  id: number;
  leave_id: number;
  employee_id: number;
  leave_date: string;
  leave_year: number;
  day_fraction: number;
  day_portion: LeaveDayPortion;
  attendance_applied: number;
  conflict_preserved: number;
  conflict_note: string;
}

export interface LeaveAuditEntry {
  id: number;
  leave_id: number;
  employee_id: number;
  action: 'SUBMITTED' | 'APPROVED' | 'REJECTED' | 'CANCELLED';
  actor_user_id: number | null;
  actor_username: string;
  actor_role: string;
  leave_type: string;
  start_date: string;
  end_date: string;
  day_portion: string;
  days_count: number;
  reason: string;
  document_ref: string;
  details_json: string;
  recorded_at_utc: string;
  recorded_at_manila: string;
}

export interface LeaveBalanceRow {
  employee_id: number;
  employee_code: string;
  employee_name: string;
  department_code: string;
  year: number;
  vl_entitlement: number;
  vl_used: number;
  vl_pending: number;
  vl_remaining: number;
  sl_entitlement: number;
  sl_used: number;
  sl_pending: number;
  sl_remaining: number;
  el_entitlement: number;
  el_used: number;
  el_pending: number;
  el_remaining: number;
  ob_days: number;
}

export interface LeavePreview {
  policy: LeavePolicy;
  start_date: string;
  end_date: string;
  day_portion: LeaveDayPortion;
  calendar_days: number;
  eligible_days: Array<{
    date: string;
    year: number;
    fraction: number;
    portion: LeaveDayPortion;
    has_valid_punch: boolean;
    existing_time_in: string | null;
    existing_time_out: string | null;
    existing_status: string | null;
  }>;
  excluded_days: Array<{
    date: string;
    reason: 'WEEKEND' | 'REST_DAY' | 'HOLIDAY';
    detail: string;
  }>;
  total_eligible_credits: number;
  credits_by_year: Record<string, number>;
  conflicting_punch_dates: Array<{
    date: string;
    time_in: string | null;
    time_out: string | null;
    status: string | null;
  }>;
  overlapping_leaves: Array<{
    id: number;
    leave_type: string;
    start_date: string;
    end_date: string;
    day_portion: string;
    status: string;
  }>;
  balance_check: {
    sufficient: boolean;
    years: Array<{
      year: number;
      entitlement: number;
      approved_used: number;
      pending_requested: number;
      requested: number;
      remaining_after: number;
    }>;
  };
}

export type PayrollPolicyApprovalStatus = 'DRAFT_NOT_APPROVED' | 'APPROVED_BY_FINANCE' | 'SUPERSEDED';

export interface PayrollPolicy {
  id: number;
  policy_code: string;
  policy_name: string;
  effective_from: string;
  effective_to: string | null;
  approval_status: PayrollPolicyApprovalStatus;
  approval_reference: string;
  finance_approved_by: string | null;
  finance_approved_by_user_id: number | null;
  finance_approved_at_utc: string | null;
  rules_json: string;
  rules?: Record<string, unknown>;
  notes: string;
  created_by: string;
  created_at: string;
  updated_by: string;
  updated_at: string;
}

export interface PayrollAuditEntry {
  id: number;
  payroll_run_id: number | null;
  policy_id: number | null;
  action: string;
  previous_status: string;
  new_status: string;
  calculation_version: number;
  snapshot_sha256: string;
  reference_code: string;
  details_json: string;
  actor_user_id: number | null;
  actor_username: string;
  actor_role: string;
  acted_at_utc: string;
  acted_at_manila: string;
  ip_address: string;
}

export interface PayrollPrecheck {
  start_date: string;
  end_date: string;
  canCompute: boolean;
  canFinalizeAndRelease: boolean;
  isProductionApprovedPolicy: boolean;
  policy: PayrollPolicy | null;
  activeEmployeeCount: number;
  splitMonthSegments: Array<{ month: string; startDate: string; endDate: string; calendarDays: number }>;
  existingRunForPeriod: {
    id: number;
    period_label: string;
    status: string;
    calculation_version: number;
    snapshot_sha256: string;
  } | null;
  overlappingRuns: Array<{ id: number; period_label: string; start_date: string; end_date: string; status: string }>;
  pendingCorrections: Array<{
    id: number;
    employee_code: string;
    employee_name: string;
    attendance_date: string;
    request_type: string;
  }>;
  pendingLeaves: Array<{
    id: number;
    employee_code: string;
    employee_name: string;
    leave_type: string;
    start_date: string;
    end_date: string;
  }>;
  unresolvedMissingPunches: Array<{
    id: number;
    employee_code: string;
    employee_name: string;
    date: string;
    status: string;
  }>;
  blockers: Array<{ code: string; message: string; count?: number }>;
  warnings: Array<{ code: string; message: string }>;
}

export interface PayrollItem {
  id: number;
  payroll_run_id: number;
  employee_id: number;
  employee_code: string;
  employee_name: string;
  department_code: string;
  department_name?: string;
  position_name: string;
  employee_type?: string;
  scheduled_working_days?: number;
  days_present: number;
  days_late: number;
  days_absent: number;
  days_paid_leave?: number;
  days_unpaid_leave?: number;
  days_holiday?: number;
  days_rest_worked?: number;
  late_minutes?: number;
  undertime_minutes?: number;
  overtime_minutes?: number;
  basic_pay: number;
  prorated_basic_pay?: number;
  allowances: number;
  overtime_pay?: number;
  holiday_rest_pay?: number;
  other_earnings?: number;
  late_deduction?: number;
  undertime_deduction?: number;
  absence_deduction?: number;
  unpaid_leave_deduction?: number;
  statutory_deductions?: number;
  tax_deduction?: number;
  other_deductions?: number;
  gross_pay?: number;
  deductions: number;
  net_pay: number;
  breakdown_json?: string;
  // Included on /api/payroll/my-payslips responses
  period_label?: string;
  start_date?: string;
  end_date?: string;
  run_status?: string;
  policy_code?: string;
  policy_approval_status?: string;
  calculation_version?: number;
  snapshot_sha256?: string;
  released_at?: string | null;
  finance_signoff_ref?: string;
}

export interface PayrollRun {
  id: number;
  period_label: string;
  start_date: string;
  end_date: string;
  status: 'Computed' | 'Finalized' | 'Released';
  policy_id?: number | null;
  policy_code?: string;
  policy_approval_status?: PayrollPolicyApprovalStatus;
  is_production_approved?: number;
  calculation_engine_version?: string;
  calculation_version?: number;
  snapshot_sha256?: string;
  policy_snapshot_json?: string | null;
  reconciliation_summary_json?: string | null;
  computed_by_user_id?: number | null;
  finalized_by_user_id?: number | null;
  finalized_by?: string | null;
  finalized_at_utc?: string | null;
  finance_signoff_by_user_id?: number | null;
  finance_signoff_by?: string | null;
  finance_signoff_ref?: string;
  finance_signoff_at_utc?: string | null;
  released_by_user_id?: number | null;
  released_by?: string | null;
  released_at_utc?: string | null;
  total_basic_pay: number;
  total_allowances: number;
  total_overtime_pay?: number;
  total_holiday_rest_pay?: number;
  total_gross_pay?: number;
  total_deductions: number;
  total_net_pay: number;
  employee_count: number;
  created_by: string;
  created_at: string;
  finalized_at: string | null;
  released_at: string | null;
  items?: PayrollItem[];
}

export interface KioskDevice {
  id: number;
  name: string;
  device_type: 'Raspberry Pi' | 'Android';
  model_info: string;
  ip_address: string;
  location: string;
  api_token?: string;
  token_masked?: string;
  token_fingerprint?: string;
  token_rotated_at?: string | null;
  offline_alert_state?: string;
  status: 'Online' | 'Offline';
  connectivity?: 'Online' | 'Stale' | 'Offline' | 'Revoked';
  last_heartbeat: string;
  last_heartbeat_utc?: string | null;
  last_sync_utc?: string | null;
  seconds_since_heartbeat?: number | null;
  pending_queue_count?: number;
  stale_warning?: boolean;
  last_clock_drift_seconds?: number | null;
  last_monotonic_seq?: number;
  last_sync_status?: string;
  last_sync_error?: string;
  is_revoked?: number;
  revoked_at?: string | null;
  device_boot_id?: string;
  created_at: string;
}

export interface KioskSyncBatch {
  id: number;
  batch_uid: string;
  device_id: number | null;
  device_name: string;
  device_boot_id: string;
  received_at_utc: string;
  total_events: number;
  accepted_count: number;
  duplicate_count: number;
  conflict_count: number;
  rejected_count: number;
  escalated_count: number;
  error_summary: string;
}

export interface EmployeeTodayAttendance {
  date: string;
  timezone: string;
  read_only: boolean;
  allow_manual_punch: boolean;
  server_timestamp_utc: string;
  employee: {
    id: number;
    employee_code: string;
    full_name: string;
    department_code: string;
    department_name: string;
    shift_name: string;
    shift_time_in: string;
    shift_time_out: string;
    grace_minutes: number;
  };
  attendance: AttendanceRecord | null;
  events: AttendanceEvent[];
}

export interface AuditLog {
  id: number;
  timestamp: string;
  username: string;
  activity: string;
  module: string;
  status: 'Success' | 'Warning' | 'Error';
  ip_address: string;
  action_type?: string;
  target_type?: string;
  target_id?: string;
  before_json?: string;
  after_json?: string;
  prev_hash?: string;
  entry_hash?: string;
  is_security_event?: number;
}

export interface AuditHashVerificationResult {
  valid: boolean;
  checkedCount: number;
  brokenRowId: number | null;
  reason: string | null;
  genesisHash: string;
  latestHash: string;
}

export interface SecretStatusInfo {
  sessionSecretConfigured: boolean;
  sessionSecretMasked: string;
  backupEncryptionConfigured: boolean;
  backupEncryptionMasked: string;
  smtpConfigured: boolean;
  googleSsoConfigured: boolean;
}

export interface BackupArchiveOption {
  fileName: string;
  sizeBytes: number;
  modifiedAt: string;
  encrypted: boolean;
}

export interface RetentionCategorySummary {
  key: string;
  label: string;
  eligibleDeleteCount: number;
  preservedCount: number;
  policyNote: string;
}

export interface DataRetentionPreview {
  dryRun: boolean;
  evaluatedAtUtc: string;
  attendanceRetentionDays: number;
  auditLogRetentionDays: number;
  cutoffAttendanceDate: string;
  cutoffAuditDate: string;
  totalEligibleDeletes: number;
  totalPreservedImmutable: number;
  categories: RetentionCategorySummary[];
}

export interface RetentionJobRow {
  id: number;
  job_uid: string;
  mode: string;
  attendance_retention_days: number;
  audit_log_retention_days: number;
  cutoff_attendance_date: string;
  cutoff_audit_date: string;
  deleted_counts_json: string;
  skipped_counts_json: string;
  total_deleted: number;
  status: string;
  executed_by: string;
  executed_at_utc: string;
  notes: string;
}

export interface AppNotification {
  id: number;
  title: string;
  message: string;
  category: 'Attendance Alerts' | 'Device Alerts' | 'System Notices';
  priority: 'High' | 'Medium' | 'Low';
  is_read: number;
  action_module: NavModule | null;
  action_entity_id: number | null;
  target_roles?: string;
  event_type?: string;
  created_at: string;
}

export interface DashboardSummary {
  date: string;
  kpis: {
    totalEmployees: number;
    present: number;
    late: number;
    absent: number;
    onLeave: number;
    others: number;
    attendanceRate: number;
    onlineDevices: number;
    totalDevices: number;
  };
  weeklyTrend: Array<{
    day: string;
    date: string;
    present: number;
    late: number;
    absent: number;
    total: number;
    isToday: boolean;
  }>;
  devices: KioskDevice[];
  recentAttendance: AttendanceRecord[];
  unreadNotifications: number;
  pendingCorrections: number;
  pendingLeaves: number;
}

export type ReportType = 'attendance' | 'dtr' | 'leaves' | 'payroll' | 'employees' | 'audit-logs';

export interface ReportPagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export interface DtrUnresolvedBlocker {
  type: 'PENDING_CORRECTION' | 'PENDING_LEAVE' | 'MISSING_PUNCH' | 'ESCALATED_EVENT';
  date: string;
  detail: string;
  ref_id: number;
}

export interface DtrDayRow {
  day: number;
  date: string;
  day_code: string;
  employee_id: number;
  employee_code: string;
  employee_name: string;
  department_code: string;
  department_name: string;
  time_in: string | null;
  break_out: string | null;
  break_in: string | null;
  time_out: string | null;
  overtime_out: string | null;
  work_hours: string;
  worked_minutes: number;
  late_minutes: number;
  undertime_minutes: number;
  overtime_minutes: number;
  status: string;
  leave_label: string;
  holiday_label: string;
  overnight_note: string;
  device_name: string;
  remarks: string;
  has_unresolved_punch: boolean;
  has_pending_correction: boolean;
  has_pending_leave: boolean;
}

export interface DtrSignoffInfo {
  id: number;
  employee_id: number;
  month: string;
  status: 'SIGNED' | 'REVOKED';
  employee_signed_by_user_id: number | null;
  employee_signed_by: string | null;
  employee_signed_at_utc: string | null;
  supervisor_verified_by_user_id: number | null;
  supervisor_verified_by: string | null;
  supervisor_verified_at_utc: string | null;
  campus_director_name: string;
  dtr_snapshot_sha256: string;
  notes: string;
  hash_matches: boolean;
}

export interface MonthlyDtrEmployeeReport {
  month: string;
  month_label: string;
  days_in_month: number;
  is_leap_year: boolean;
  start_date: string;
  end_date: string;
  employee: {
    id: number;
    employee_code: string;
    full_name: string;
    email: string;
    department_id: number;
    department_code: string;
    department_name: string;
    department_head_name: string;
    position_name: string;
    employee_type: string;
    shift_id: number;
    shift_name: string;
    shift_time_in: string;
    shift_time_out: string;
    is_overnight_shift: boolean;
    rest_days: string;
    hired_date: string;
    status: string;
  };
  cs_form_48_reference_verified: boolean;
  cs_form_48_reference_note: string;
  dtr_state: 'DRAFT_UNRESOLVED' | 'READY_UNSIGNED' | 'SIGNED' | 'SIGNED_STALE';
  is_draft: boolean;
  is_signed: boolean;
  snapshot_sha256: string;
  unresolved_blockers: DtrUnresolvedBlocker[];
  signoff: DtrSignoffInfo | null;
  campus_director_name: string;
  totals: {
    days_present: number;
    days_late: number;
    days_undertime: number;
    days_absent: number;
    days_on_leave: number;
    days_ob: number;
    days_holiday: number;
    days_rest_day: number;
    days_missing_punch: number;
    days_no_schedule: number;
    days_unreconciled: number;
    total_late_minutes: number;
    total_undertime_minutes: number;
    total_overtime_minutes: number;
    total_worked_minutes: number;
    total_worked_hours_formatted: string;
    approved_corrections_count: number;
  };
  rows: DtrDayRow[];
}

export interface ReportResponse {
  title: string;
  type: ReportType;
  generatedAt: string;
  columns: string[];
  rows: Record<string, unknown>[];
  pagination: ReportPagination;
  summary: Record<string, unknown>;
  dtr_reports?: MonthlyDtrEmployeeReport[];
  leave_balances?: LeaveBalanceRow[];
  cs_form_48_reference_verified?: boolean;
  cs_form_48_reference_note?: string;
}

