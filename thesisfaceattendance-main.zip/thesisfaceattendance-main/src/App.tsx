import React, { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import {
  Home,
  Users,
  Building2,
  Briefcase,
  Clock,
  CalendarHeart,
  CalendarCheck2,
  FileCheck2,
  Umbrella,
  Wallet,
  FileBarChart2,
  MonitorSmartphone,
  ShieldAlert,
  Bell,
  Settings,
  Menu,
  X,
  LogOut,
  ChevronDown,
  User,
  KeyRound,
  AlertCircle,
} from 'lucide-react';
import { SavageLogo } from './components/SavageLogo';
import { RsuBottomWave } from './components/ModuleFrame';
import { LoginView } from './components/LoginView';
import { EmployeeMobilePortal } from './components/EmployeeMobilePortal';
import { EmployeeEntryFlow, EmployeeSplashScreen } from './components/employee/EmployeeEntryFlow';
import { ChangePasswordScreen } from './components/employee/ProfileAndUtilityScreens';
import { WebKioskPortal } from './components/WebKioskPortal';
import { AdminDashboardView } from './components/AdminDashboardView';
import { EmployeesView } from './components/EmployeesView';
import { AttendanceView } from './components/AttendanceView';
import { CorrectionsView, LeavesView } from './components/CorrectionsLeavesViews';
import { PayrollView, ReportsView } from './components/PayrollReportsViews';
import { ShiftsView, DepartmentsView, PositionsView, HolidaysView } from './components/OrgSetupViews';
import { DevicesView, AuditLogsView, NotificationsView, SettingsView } from './components/SystemAdminViews';
import { apiFetch, clearCsrfToken, setCsrfToken, setUnauthorizedHandler } from './lib/api';
import { useRealtimeStream } from './lib/realtime';
import type { AuthUser, NavModule } from './types';

interface NavItem {
  id: NavModule;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  anyPermissions: string[];
}

// Reference-matched sidebar navigation (Admin Biometrics module intentionally excluded per mandatory rule)
const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: Home, anyPermissions: ['dashboard:read'] },
  { id: 'employees', label: 'Employees', icon: Users, anyPermissions: ['employees:read'] },
  { id: 'departments', label: 'Departments', icon: Building2, anyPermissions: ['org:read'] },
  { id: 'positions', label: 'Positions', icon: Briefcase, anyPermissions: ['org:read'] },
  { id: 'shifts', label: 'Shifts & Schedules', icon: Clock, anyPermissions: ['org:read'] },
  { id: 'holidays', label: 'Holidays', icon: CalendarHeart, anyPermissions: ['org:read'] },
  { id: 'attendance', label: 'Attendance', icon: CalendarCheck2, anyPermissions: ['attendance:read', 'attendance:read_self'] },
  { id: 'corrections', label: 'Corrections', icon: FileCheck2, anyPermissions: ['corrections:read', 'corrections:read_self'] },
  { id: 'leaves', label: 'Leaves', icon: Umbrella, anyPermissions: ['leaves:read', 'leaves:read_self'] },
  { id: 'payroll', label: 'Payroll', icon: Wallet, anyPermissions: ['payroll:read', 'payroll:read_self'] },
  {
    id: 'reports',
    label: 'Reports',
    icon: FileBarChart2,
    anyPermissions: [
      'reports:read',
      'reports:attendance',
      'reports:dtr',
      'reports:leaves',
      'reports:payroll',
      'reports:employees',
      'reports:audit',
    ],
  },
  { id: 'devices', label: 'Devices (Kiosk)', icon: MonitorSmartphone, anyPermissions: ['devices:read'] },
  { id: 'audit-logs', label: 'Audit Logs', icon: ShieldAlert, anyPermissions: ['audit:read'] },
  { id: 'notifications', label: 'Notifications', icon: Bell, anyPermissions: ['notifications:read'] },
  { id: 'settings', label: 'System Settings', icon: Settings, anyPermissions: ['settings:read'] },
];

function userHasAnyPermission(user: AuthUser | null, required: string[]): boolean {
  if (!user) return false;
  const perms = user.permissions || [];
  return required.some((code) => perms.includes(code));
}

function detectInitialPortalMode(): 'admin' | 'employee' | 'kiosk' {
  if (typeof window === 'undefined') return 'admin';
  const path = window.location.pathname.toLowerCase();
  const params = new URLSearchParams(window.location.search);
  if (path === '/kiosk' || path.startsWith('/kiosk/') || params.get('portal') === 'kiosk') {
    return 'kiosk';
  }
  if (path.startsWith('/employee') || params.get('portal') === 'employee') {
    return 'employee';
  }
  return 'admin';
}

export default function App() {
  const [portalMode, setPortalMode] = useState<'admin' | 'employee' | 'kiosk'>(detectInitialPortalMode);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [activeModule, setActiveModule] = useState<NavModule>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [sessionExpiredNotice, setSessionExpiredNotice] = useState<string | null>(null);
  const profileMenuRef = useRef<HTMLDivElement>(null);
  const activeUserRoleRef = useRef<string | null>(null);
  activeUserRoleRef.current = user?.role ?? null;

  const switchPortalMode = useCallback((mode: 'admin' | 'employee') => {
    setPortalMode(mode);
    if (typeof window !== 'undefined' && window.history?.replaceState) {
      try {
        const nextUrl = mode === 'employee' ? '/employee' : '/';
        if (window.location.pathname !== nextUrl) {
          window.history.replaceState(null, '', nextUrl);
        }
      } catch {
        // ignore history restrictions
      }
    }
  }, []);

  useEffect(() => {
    if (!mobileMenuOpen && !profileMenuOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (profileMenuOpen) setProfileMenuOpen(false);
        if (mobileMenuOpen) setMobileMenuOpen(false);
      }
    };
    const onMouseDown = (e: MouseEvent) => {
      if (profileMenuOpen && profileMenuRef.current && !profileMenuRef.current.contains(e.target as Node)) {
        setProfileMenuOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('mousedown', onMouseDown);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('mousedown', onMouseDown);
    };
  }, [mobileMenuOpen, profileMenuOpen]);

  // Forced initial password rotation state
  const [rotationForm, setRotationForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [rotationLoading, setRotationLoading] = useState(false);
  const [rotationError, setRotationError] = useState<string | null>(null);

  const allowedNavItems = useMemo(() => {
    if (!user) return [];
    return NAV_ITEMS.filter((item) => userHasAnyPermission(user, item.anyPermissions));
  }, [user]);

  const canViewNotifications = userHasAnyPermission(user, ['notifications:read']);
  const canViewSettings = userHasAnyPermission(user, ['settings:read']);

  const fetchUnreadCount = useCallback(async (targetUser?: AuthUser | null) => {
    const u = targetUser ?? user;
    if (!u || u.must_change_password || !userHasAnyPermission(u, ['notifications:read'])) {
      setUnreadCount(0);
      return;
    }
    try {
      const res = await apiFetch<{ counts: { unread: number } }>('/api/notifications?filter=Unread');
      setUnreadCount(res.counts.unread);
    } catch {
      // ignore if session expired or role lacks permission
    }
  }, [user]);

  useRealtimeStream({
    channels: ['notification:created', 'device:telemetry'],
    enabled: Boolean(user && !user.must_change_password && canViewNotifications),
    onEvent: () => {
      fetchUnreadCount();
    },
    onResync: () => {
      fetchUnreadCount();
    },
  });

  useEffect(() => {
    setUnauthorizedHandler(() => {
      const wasEmployee = activeUserRoleRef.current === 'Employee';
      setUser(null);
      setProfileMenuOpen(false);
      if (wasEmployee) {
        switchPortalMode('employee');
        setSessionExpiredNotice('Your session has expired. Please sign in again.');
      }
    });
    return () => setUnauthorizedHandler(null);
  }, [switchPortalMode]);

  useEffect(() => {
    if (portalMode === 'kiosk') {
      setAuthChecked(true);
      return;
    }
    apiFetch<{ user: AuthUser; csrfToken?: string }>('/api/auth/me')
      .then((res) => {
        setCsrfToken(res.csrfToken ?? null);
        setUser(res.user);
        if (!res.user.must_change_password && userHasAnyPermission(res.user, ['notifications:read'])) {
          fetchUnreadCount(res.user);
        }
      })
      .catch(() => {
        clearCsrfToken();
        setUser(null);
      })
      .finally(() => setAuthChecked(true));
  }, [portalMode]);

  // Keep activeModule aligned with the user's permitted modules
  useEffect(() => {
    if (!user || user.must_change_password || allowedNavItems.length === 0) return;
    const isAllowed = allowedNavItems.some((item) => item.id === activeModule);
    if (!isAllowed) {
      setActiveModule(allowedNavItems[0].id);
    }
  }, [user, allowedNavItems, activeModule]);

  const handleLogout = async () => {
    const wasEmployee = user?.role === 'Employee';
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore network error on logout
    } finally {
      clearCsrfToken();
      setSessionExpiredNotice(null);
      setUser(null);
      setProfileMenuOpen(false);
      setActiveModule('dashboard');
      setRotationForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
      setRotationError(null);
      if (wasEmployee) {
        switchPortalMode('employee');
      }
    }
  };

  const handleForceRotatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setRotationError(null);
    if (rotationForm.newPassword !== rotationForm.confirmPassword) {
      setRotationError('New password and confirmation do not match.');
      return;
    }
    setRotationLoading(true);
    try {
      const res = await apiFetch<{ user: AuthUser; csrfToken?: string }>('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({
          currentPassword: rotationForm.currentPassword,
          newPassword: rotationForm.newPassword,
        }),
      });
      setCsrfToken(res.csrfToken ?? null);
      setRotationForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
      setUser(res.user);
      fetchUnreadCount(res.user);
    } catch (err) {
      setRotationError(err instanceof Error ? err.message : 'Unable to rotate password.');
    } finally {
      setRotationLoading(false);
    }
  };

  const handleNavigate = (mod: NavModule) => {
    if (!allowedNavItems.some((item) => item.id === mod)) return;
    setActiveModule(mod);
    setMobileMenuOpen(false);
    setProfileMenuOpen(false);
    fetchUnreadCount();
  };

  if (portalMode === 'kiosk') {
    return <WebKioskPortal />;
  }

  if (!authChecked) {
    if (portalMode === 'employee') {
      return <EmployeeSplashScreen statusText="Loading..." />;
    }
    return (
      <div className="min-h-screen bg-[#EEF5F2] flex flex-col items-center justify-center gap-3">
        <SavageLogo size={96} variant="light" />
        <p className="text-xs font-semibold text-[#0B5537]">Loading SAVAGE-RSUCAJ Portal...</p>
      </div>
    );
  }

  if (!user) {
    if (portalMode === 'employee') {
      return (
        <EmployeeEntryFlow
          sessionNotice={sessionExpiredNotice}
          onDismissSessionNotice={() => setSessionExpiredNotice(null)}
          onSuccess={(u) => {
            setSessionExpiredNotice(null);
            setUser(u);
            if (!u.must_change_password) {
              fetchUnreadCount(u);
            }
          }}
        />
      );
    }
    return (
      <LoginView
        onSuccess={(u) => {
          setUser(u);
          if (!u.must_change_password) {
            fetchUnreadCount(u);
          }
        }}
        onOpenEmployeePortal={() => switchPortalMode('employee')}
      />
    );
  }

  // BUILD 05: Forced initial password change gate (enforced independently server-side as well)
  if (user.must_change_password) {
    if (user.role === 'Employee') {
      return (
        <ChangePasswordScreen
          forcedMode
          username={user.username}
          onPasswordUpdated={(updatedUser) => {
            setUser(updatedUser);
            fetchUnreadCount(updatedUser);
          }}
          onSignOut={handleLogout}
        />
      );
    }
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#E6F4EE] via-[#F9FCFB] to-[#E2F2EC] flex items-center justify-center p-5">
        <div className="w-full max-w-md bg-white rounded-2xl border border-emerald-950/10 shadow-2xl p-7 sm:p-8">
          <div className="flex flex-col items-center text-center mb-6">
            <SavageLogo size={84} variant="light" />
            <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-[11px] font-bold">
              <KeyRound className="w-3.5 h-3.5" />
              <span>Security Action Required</span>
            </div>
            <h1 className="font-display text-xl font-extrabold text-[#07442B] mt-3">
              Update Initial Password
            </h1>
            <p className="text-xs text-slate-600 mt-1">
              Signed in as <span className="font-bold text-slate-800">{user.username}</span> ({user.role}).
              You must set a new personal password before accessing the portal.
            </p>
          </div>

          {rotationError && (
            <div
              role="alert"
              className="mb-4 flex items-start gap-2 rounded-xl bg-red-50 border border-red-200 px-3 py-2.5 text-xs text-red-800"
            >
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
              <span>{rotationError}</span>
            </div>
          )}

          <form onSubmit={handleForceRotatePassword} className="space-y-3.5 text-xs">
            <div>
              <label htmlFor="rot-current" className="block font-semibold text-slate-700 mb-1">
                Current Password
              </label>
              <input
                id="rot-current"
                type="password"
                required
                autoComplete="current-password"
                value={rotationForm.currentPassword}
                onChange={(e) => setRotationForm({ ...rotationForm, currentPassword: e.target.value })}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-[#F8FBFA] focus:bg-white focus:outline-none focus:border-[#0B5537]"
              />
            </div>
            <div>
              <label htmlFor="rot-new" className="block font-semibold text-slate-700 mb-1">
                New Strong Password
              </label>
              <input
                id="rot-new"
                type="password"
                required
                minLength={10}
                autoComplete="new-password"
                value={rotationForm.newPassword}
                onChange={(e) => setRotationForm({ ...rotationForm, newPassword: e.target.value })}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-[#F8FBFA] focus:bg-white focus:outline-none focus:border-[#0B5537]"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Minimum 10 characters with uppercase, lowercase, number, and symbol.
              </p>
            </div>
            <div>
              <label htmlFor="rot-confirm" className="block font-semibold text-slate-700 mb-1">
                Confirm New Password
              </label>
              <input
                id="rot-confirm"
                type="password"
                required
                minLength={10}
                autoComplete="new-password"
                value={rotationForm.confirmPassword}
                onChange={(e) => setRotationForm({ ...rotationForm, confirmPassword: e.target.value })}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-[#F8FBFA] focus:bg-white focus:outline-none focus:border-[#0B5537]"
              />
            </div>

            <div className="pt-2 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={handleLogout}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 font-semibold cursor-pointer"
              >
                Sign Out
              </button>
              <button
                type="submit"
                disabled={rotationLoading}
                className="px-5 py-2.5 rounded-xl btn-rsu-primary font-bold disabled:opacity-60 cursor-pointer"
              >
                {rotationLoading ? 'Updating...' : 'Save New Password'}
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  // Employee-only mobile-first portal. Never render administrator modules or kiosk punch controls.
  if (user.role === 'Employee') {
    return <EmployeeMobilePortal user={user} onLogout={handleLogout} onUserChanged={setUser} />;
  }

  const renderModule = () => {
    switch (activeModule) {
      case 'dashboard':
        return (
          <AdminDashboardView
            currentUser={user}
            onNavigate={handleNavigate}
            onUnreadCountChange={setUnreadCount}
          />
        );
      case 'employees':
        return <EmployeesView currentUser={user} />;
      case 'departments':
        return <DepartmentsView currentUser={user} />;
      case 'positions':
        return <PositionsView currentUser={user} />;
      case 'shifts':
        return <ShiftsView currentUser={user} />;
      case 'holidays':
        return <HolidaysView currentUser={user} />;
      case 'attendance':
        return <AttendanceView currentUser={user} />;
      case 'corrections':
        return <CorrectionsView currentUser={user} />;
      case 'leaves':
        return <LeavesView currentUser={user} />;
      case 'payroll':
        return <PayrollView currentUser={user} />;
      case 'reports':
        return <ReportsView />;
      case 'devices':
        return <DevicesView currentUser={user} />;
      case 'audit-logs':
        return <AuditLogsView />;
      case 'notifications':
        return (
          <NotificationsView
            currentUser={user}
            onNavigate={handleNavigate}
            onUnreadCountChange={setUnreadCount}
          />
        );
      case 'settings':
        return <SettingsView currentUser={user} />;
      default:
        return (
          <AdminDashboardView
            currentUser={user}
            onNavigate={handleNavigate}
            onUnreadCountChange={setUnreadCount}
          />
        );
    }
  };

  const SidebarContent = (
    <div className="flex flex-col h-full bg-gradient-to-b from-[#043421] via-[#07472E] to-[#042B1B] text-white select-none relative overflow-hidden">
      {/* Subtle luminous radial glow at top of sidebar matching 02_Admin_Dashboard.png */}
      <div
        className="pointer-events-none absolute -top-10 left-1/2 -translate-x-1/2 w-56 h-40 rounded-full bg-emerald-400/15 blur-2xl"
        aria-hidden="true"
      />

      {/* Brand Header matching 02_Admin_Dashboard.png */}
      <div className="relative z-10 px-4 pt-5 pb-4 border-b border-white/10 flex flex-col items-center text-center">
        <SavageLogo size={74} variant="dark" />
        <h2 className="font-display text-[15px] font-extrabold tracking-wide text-white mt-2.5 leading-tight">
          SAVAGE-RSUCAJ
        </h2>
        <p className="text-[9.5px] font-bold tracking-[0.14em] text-emerald-200/90 uppercase mt-0.5">
          SMART ATTENDANCE SYSTEM
        </p>
      </div>

      {/* Navigation Links */}
      <nav
        className="relative z-10 flex-1 overflow-y-auto px-3 py-3 space-y-0.5"
        aria-label="Primary sidebar navigation"
      >
        {allowedNavItems.map((item) => {
          const Icon = item.icon;
          const active = activeModule === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleNavigate(item.id)}
              aria-current={active ? 'page' : undefined}
              className={`w-full flex items-center justify-between gap-2.5 px-3 py-2.5 rounded-xl text-[13px] font-semibold transition-all cursor-pointer ${
                active
                  ? 'bg-gradient-to-r from-[#12A366] via-[#139860] to-[#0C7D4E] text-white shadow-md shadow-black/25 ring-1 ring-emerald-300/35'
                  : 'text-emerald-100/90 hover:bg-white/10 hover:text-white'
              }`}
            >
              <span className="flex items-center gap-3 min-w-0">
                <Icon className="w-[17px] h-[17px] shrink-0" />
                <span className="truncate">{item.label}</span>
              </span>
              {item.id === 'notifications' && unreadCount > 0 && (
                <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-[#EF4444] text-white text-[10px] font-bold font-mono-num flex items-center justify-center shadow-xs">
                  {unreadCount}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom Institutional Wave Trim matching 02_Admin_Dashboard.png */}
      <div className="relative z-10 pt-2">
        <div className="px-4 pb-1.5 text-[10px] text-emerald-100/85 text-center font-medium">
          RSU – Cajidiocan Campus
        </div>
        <RsuBottomWave height={18} />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-[#EEF5F2] text-slate-900">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[60] focus:px-4 focus:py-2 focus:rounded-lg focus:bg-[#053522] focus:text-white focus:text-xs focus:font-bold focus:shadow-lg"
      >
        Skip to main content
      </a>

      {/* Desktop Sidebar */}
      <aside
        aria-label="Campus portal sidebar"
        className={`hidden lg:block shrink-0 transition-all duration-200 no-print ${
          sidebarOpen ? 'w-60' : 'w-0 overflow-hidden'
        }`}
      >
        <div className="sticky top-0 h-screen w-60 shadow-xl shadow-emerald-950/20">
          {SidebarContent}
        </div>
      </aside>

      {/* Mobile Drawer Sidebar */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-50 lg:hidden flex no-print"
          role="dialog"
          aria-modal="true"
          aria-label="Mobile navigation menu"
        >
          <div
            className="fixed inset-0 bg-slate-950/55 backdrop-blur-[1px]"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative w-64 max-w-[82vw] h-full shadow-2xl z-10">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(false)}
              className="absolute top-3 right-3 z-20 p-1.5 rounded-lg bg-white/15 text-white hover:bg-white/25 cursor-pointer"
              aria-label="Close navigation menu"
            >
              <X className="w-4 h-4" />
            </button>
            {SidebarContent}
          </div>
        </div>
      )}

      {/* Main Column */}
      <div className="flex-1 flex flex-col min-w-0 relative">
        {/* Top Institutional Dark Emerald Header Bar matching 02_Admin_Dashboard.png */}
        <header className="sticky top-0 z-30 h-14 bg-gradient-to-r from-[#053522] via-[#094D33] to-[#073E29] text-white px-4 sm:px-6 flex items-center justify-between gap-4 shadow-md shadow-emerald-950/15 no-print">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => {
                if (window.innerWidth < 1024) {
                  setMobileMenuOpen((v) => !v);
                } else {
                  setSidebarOpen((v) => !v);
                }
              }}
              className="p-2 rounded-lg text-emerald-100 hover:bg-white/12 hover:text-white transition-colors cursor-pointer"
              aria-label="Toggle sidebar navigation"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span className="font-display text-sm font-bold tracking-tight truncate hidden sm:inline text-emerald-50">
              {NAV_ITEMS.find((n) => n.id === activeModule)?.label || 'Admin Dashboard'}
            </span>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {/* Notification Bell matching 02_Admin_Dashboard.png */}
            {canViewNotifications && (
              <>
                <button
                  type="button"
                  onClick={() => handleNavigate('notifications')}
                  className="relative p-2 rounded-lg text-white hover:bg-white/12 transition-colors cursor-pointer"
                  aria-label="Open notifications"
                >
                  <Bell className="w-5 h-5 fill-white/15" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 min-w-[19px] h-[19px] px-1 rounded-full bg-[#EF4444] text-white text-[10px] font-bold font-mono-num flex items-center justify-center ring-2 ring-[#073E29]">
                      {unreadCount}
                    </span>
                  )}
                </button>
                <div className="h-6 w-px bg-white/15 hidden sm:block" aria-hidden="true" />
              </>
            )}

            {/* Admin Profile Menu matching 02_Admin_Dashboard.png */}
            <div className="relative" ref={profileMenuRef}>
              <button
                type="button"
                onClick={() => setProfileMenuOpen((v) => !v)}
                aria-haspopup="menu"
                aria-expanded={profileMenuOpen}
                aria-label="Account profile menu"
                className="flex items-center gap-2.5 pl-1.5 pr-2 py-1 rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
              >
                <div className="w-8 h-8 rounded-full bg-white text-[#073E29] flex items-center justify-center shrink-0 shadow-xs">
                  <User className="w-4 h-4" />
                </div>
                <div className="text-left hidden sm:block leading-tight">
                  <div className="text-xs font-bold text-white whitespace-nowrap">
                    {user.full_name}
                  </div>
                  <div className="text-[10px] text-emerald-100/90 whitespace-nowrap">
                    {user.role}
                  </div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-emerald-200" />
              </button>

              {profileMenuOpen && (
                <div
                  role="menu"
                  aria-label="Account actions"
                  className="absolute right-0 mt-2 w-56 bg-white rounded-xl border border-slate-200 shadow-2xl py-1.5 text-xs text-slate-700 z-40"
                >
                  <div className="px-3.5 py-2.5 border-b border-slate-100">
                    <p className="font-bold text-slate-900 truncate">{user.full_name}</p>
                    <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
                  </div>
                  {canViewSettings && (
                    <button
                      type="button"
                      role="menuitem"
                      onClick={() => handleNavigate('settings')}
                      className="w-full px-3.5 py-2 text-left hover:bg-emerald-50/70 flex items-center gap-2 font-medium cursor-pointer"
                    >
                      <Settings className="w-3.5 h-3.5 text-[#0B5537]" />
                      <span>System Settings</span>
                    </button>
                  )}
                  <button
                    type="button"
                    role="menuitem"
                    onClick={handleLogout}
                    className="w-full px-3.5 py-2 text-left hover:bg-red-50 text-red-600 flex items-center gap-2 font-semibold cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Active Module Viewport */}
        <main id="main-content" tabIndex={-1} className="flex-1 p-4 sm:p-6 max-w-[1680px] w-full mx-auto min-w-0 focus:outline-none">
          {renderModule()}
        </main>

        {/* Bottom Campus Wave Ribbon on Dashboard matching 02_Admin_Dashboard.png */}
        {activeModule === 'dashboard' && (
          <div className="no-print mt-auto pt-2">
            <RsuBottomWave height={28} />
          </div>
        )}
      </div>
    </div>
  );
}
