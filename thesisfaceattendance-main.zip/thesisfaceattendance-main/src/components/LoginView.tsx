import React, { useEffect, useState } from 'react';
import { Eye, EyeOff, Lock, LogIn, User, AlertCircle, ShieldAlert } from 'lucide-react';
import { SavageLogo } from './SavageLogo';
import { Modal } from './ModuleFrame';
import { apiFetch, setCsrfToken } from '../lib/api';
import type { AuthUser } from '../types';

interface LoginViewProps {
  onSuccess: (user: AuthUser) => void;
  onOpenEmployeePortal?: () => void;
}

interface AuthConfigResponse {
  googleSsoConfigured: boolean;
  smtpConfigured: boolean;
}

export const LoginView: React.FC<LoginViewProps> = ({ onSuccess, onOpenEmployeePortal }) => {
  // BUILD 05: Zero hardcoded credentials or password prefill
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [authConfig, setAuthConfig] = useState<AuthConfigResponse>({
    googleSsoConfigured: false,
    smtpConfigured: false,
  });

  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSubmitting, setForgotSubmitting] = useState(false);
  const [forgotResult, setForgotResult] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<AuthConfigResponse>('/api/auth/config')
      .then((cfg) => setAuthConfig(cfg))
      .catch(() => {
        setAuthConfig({ googleSsoConfigured: false, smtpConfigured: false });
      });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!identifier.trim() || !password) {
      setError('Please enter your username/email and password.');
      return;
    }
    setLoading(true);
    try {
      const data = await apiFetch<{ user: AuthUser; csrfToken?: string }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ identifier: identifier.trim(), password, rememberMe }),
      });
      setCsrfToken(data.csrfToken ?? null);
      setPassword('');
      onSuccess(data.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to sign in.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authConfig.smtpConfigured || !forgotEmail.trim()) return;
    setForgotSubmitting(true);
    setForgotResult(null);
    try {
      const res = await apiFetch<{ message?: string; error?: string }>('/api/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email: forgotEmail.trim() }),
      });
      setForgotResult(res.message || res.error || 'Request processed.');
    } catch (err) {
      setForgotResult(err instanceof Error ? err.message : 'Unable to submit request.');
    } finally {
      setForgotSubmitting(false);
    }
  };

  return (
    <main className="min-h-screen w-full relative overflow-hidden bg-gradient-to-br from-[#E6F4EE] via-[#F9FCFB] to-[#E2F2EC] flex items-center justify-center p-5 sm:p-8">
      {/* Reference 01_Login.png: Silk mint & deep forest waves top-left */}
      <svg
        className="pointer-events-none fixed top-0 left-0 w-[560px] max-w-[85vw] h-[300px]"
        viewBox="0 0 560 300"
        fill="none"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <path
          d="M0 0H520C390 42 250 112 128 214C74 258 34 282 0 296V0Z"
          fill="#0B5537"
          fillOpacity="0.11"
        />
        <path
          d="M0 0H340C225 46 118 118 0 228V0Z"
          fill="#0F7B50"
          fillOpacity="0.22"
        />
        <path d="M0 0H185C110 34 52 84 0 144V0Z" fill="#0B5537" fillOpacity="0.55" />
      </svg>

      {/* Reference 01_Login.png: Sculpted sweeping gold & deep emerald ribbon along bottom */}
      <svg
        className="pointer-events-none fixed bottom-0 left-0 w-full h-[260px]"
        viewBox="0 0 1440 260"
        fill="none"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="loginGoldSweep" x1="0%" y1="0%" x2="80%" y2="100%">
            <stop offset="0%" stopColor="#FDE047" />
            <stop offset="45%" stopColor="#F59E0B" />
            <stop offset="100%" stopColor="#D97706" />
          </linearGradient>
          <linearGradient id="loginForestSweep" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#053824" />
            <stop offset="50%" stopColor="#0A5C3B" />
            <stop offset="100%" stopColor="#0E8452" />
          </linearGradient>
        </defs>
        <path
          d="M720 260C940 198 1190 175 1440 205V260H720Z"
          fill="#0B5537"
          fillOpacity="0.1"
        />
        <path
          d="M0 0C30 92 140 165 440 208C710 246 980 255 1230 260H0V0Z"
          fill="url(#loginGoldSweep)"
        />
        <path
          d="M0 88C165 158 465 204 895 234C1040 244 1140 252 1210 260H0V88Z"
          fill="url(#loginForestSweep)"
        />
        <path
          d="M0 156C180 196 420 226 780 260H0V156Z"
          fill="#053522"
        />
      </svg>

      {/* Main Centered Split Layout matching 01_Login.png */}
      <div className="relative z-10 w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
        {/* Left Institutional Brand Showcase */}
        <div className="lg:col-span-6 flex flex-col items-center text-center px-2">
          <div className="mb-3">
            <SavageLogo size={184} variant="light" />
          </div>
          <h1 className="font-display text-3xl sm:text-[38px] font-extrabold tracking-tight text-[#073E27] leading-none">
            SAVAGE-RSUCAJ
          </h1>
          <p className="font-display text-sm sm:text-base font-bold tracking-[0.14em] text-[#094C31] uppercase mt-2">
            SMART ATTENDANCE SYSTEM
          </p>
          <p className="text-sm sm:text-base font-semibold text-[#0B4D32]/90 mt-4">
            Romblon State University – Cajidiocan Campus
          </p>
          <div className="mt-5 flex items-center gap-3.5 text-base font-semibold italic text-[#0B5B3A]">
            <span>Safe</span>
            <span className="not-italic text-[#0B5B3A]/60">·</span>
            <span>Secure</span>
            <span className="not-italic text-[#0B5B3A]/60">·</span>
            <span>Smart</span>
          </div>
        </div>

        {/* Right Floating White Login Card matching 01_Login.png */}
        <div className="lg:col-span-6 w-full max-w-[430px] mx-auto">
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl border border-emerald-950/8 shadow-2xl shadow-emerald-950/12 p-7 sm:p-9">
            <div className="mb-6">
              <h2 className="font-display text-[26px] font-extrabold text-[#07442B] leading-tight">
                Welcome Back!
              </h2>
              <p className="text-sm text-slate-500 mt-1">Sign in to your portal account</p>
            </div>

            {error && (
              <div
                role="alert"
                className="mb-4 flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-3.5 py-2.5 text-xs text-red-800"
              >
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="login-identifier" className="sr-only">
                  Username or Email
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#0B4D32]/70 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    id="login-identifier"
                    type="text"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="Username or Email"
                    autoComplete="username"
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-[#F8FBFA] text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-[#0B5537] focus:ring-2 focus:ring-[#0B5537]/15 transition"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="login-password" className="sr-only">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-[#0B4D32]/70 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    id="login-password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                    autoComplete="current-password"
                    className="w-full pl-10 pr-10 py-3 rounded-xl border border-slate-200 bg-[#F8FBFA] text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-[#0B5537] focus:ring-2 focus:ring-[#0B5537]/15 transition"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-[#0B4D32] p-1 cursor-pointer"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs pt-0.5">
                <label className="inline-flex items-center gap-2 text-slate-700 font-medium cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-300 accent-[#0B5537]"
                  />
                  <span>Remember me</span>
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setForgotResult(null);
                    setForgotEmail('');
                    setForgotOpen(true);
                  }}
                  className="font-semibold text-[#0E7454] hover:text-[#084A34] underline underline-offset-2 cursor-pointer"
                >
                  {authConfig.smtpConfigured ? 'Forgot Password?' : 'Password Recovery Help'}
                </button>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 px-4 rounded-xl btn-rsu-dark font-semibold text-sm flex items-center justify-center gap-2 transition-all disabled:opacity-60 cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>{loading ? 'Signing In...' : 'Sign In'}</span>
              </button>
            </form>

            <div className="my-5 flex items-center gap-3">
              <div className="h-px flex-1 bg-slate-200" />
              <span className="text-xs text-slate-500 font-medium italic">or</span>
              <div className="h-px flex-1 bg-slate-200" />
            </div>

            {/* BUILD 05: Visibly disabled when Google OAuth is not configured (no fake working button) */}
            <button
              type="button"
              disabled={!authConfig.googleSsoConfigured}
              aria-disabled={!authConfig.googleSsoConfigured}
              title={
                authConfig.googleSsoConfigured
                  ? 'Sign in with Google'
                  : 'Google OAuth is not configured on this server deployment'
              }
              className="w-full py-2.5 px-4 rounded-xl border border-slate-200 bg-slate-100 text-slate-600 font-semibold text-sm flex items-center justify-center gap-2.5 shadow-xs transition-colors disabled:opacity-80 disabled:cursor-not-allowed"
            >
              <svg className="w-4 h-4 grayscale opacity-60" viewBox="0 0 24 24" aria-hidden="true">
                <path
                  fill="#4285F4"
                  d="M23.49 12.27c0-.79-.07-1.55-.2-2.27H12v4.3h6.45c-.28 1.48-1.12 2.74-2.38 3.59v2.98h3.85c2.25-2.08 3.57-5.14 3.57-8.6z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.07 7.93-2.91l-3.85-2.98c-1.07.72-2.44 1.15-4.08 1.15-3.14 0-5.8-2.12-6.75-4.97H1.27v3.08C3.24 21.3 7.31 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.25 14.29c-.24-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.63H1.27C.46 8.24 0 10.07 0 12s.46 3.76 1.27 5.37l3.98-3.08z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.76 0 3.34.61 4.59 1.8l3.44-3.44C17.95 1.19 15.24 0 12 0 7.31 0 3.24 2.7 1.27 6.63l3.98 3.08C6.2 6.87 8.86 4.75 12 4.75z"
                />
              </svg>
              <span>
                {authConfig.googleSsoConfigured
                  ? 'Sign in with Google'
                  : 'Sign in with Google (Not Configured)'}
              </span>
            </button>

            {onOpenEmployeePortal && (
              <button
                type="button"
                onClick={onOpenEmployeePortal}
                className="mt-3 w-full py-2.5 px-4 rounded-xl border border-[#0B5537]/25 bg-[#F2FAF5] text-[#065A32] hover:bg-[#E4F6EC] font-semibold text-sm flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <User className="w-4 h-4" />
                <span>Employee Portal (Mobile Self-Service)</span>
              </button>
            )}

            <div className="mt-6 pt-4 border-t border-slate-100 text-center">
              <p className="text-[11px] font-medium text-slate-600">
                SAVAGE-RSUCAJ Smart Attendance System
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Password Recovery Modal — honest disabled state when SMTP is unconfigured */}
      <Modal
        open={forgotOpen}
        onClose={() => setForgotOpen(false)}
        title="Account Password Recovery"
        subtitle="Romblon State University – Cajidiocan Campus MIS"
        maxWidth="max-w-md"
      >
        {!authConfig.smtpConfigured ? (
          <div className="space-y-4">
            <div className="rounded-xl bg-amber-50 border border-amber-200 p-3.5 text-xs text-amber-900 flex items-start gap-2.5">
              <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1.5">
                <p className="font-bold">Email Password Reset Not Configured</p>
                <p>
                  Outbound SMTP email delivery is disabled on this server. Self-service password reset links
                  cannot be sent until an institutional SMTP relay is configured.
                </p>
              </div>
            </div>
            <div className="rounded-xl bg-slate-50 border border-slate-200 p-3.5 text-xs text-slate-700 space-y-1.5">
              <p className="font-bold text-[#07442B]">MIS Operator Recovery Procedure</p>
              <p>
                To recover a locked or forgotten administrator account on the campus server, set{' '}
                <code className="font-mono-num bg-white px-1 py-0.5 rounded border border-slate-200">
                  RECOVERY_NEW_PASSWORD
                </code>{' '}
                and run:
              </p>
              <pre className="bg-slate-900 text-emerald-200 p-2.5 rounded-lg text-[11px] font-mono-num overflow-x-auto">
                npm run admin:recover -- --username admin --force-rotate
              </pre>
            </div>
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setForgotOpen(false)}
                className="px-4 py-2 text-xs font-semibold btn-rsu-primary rounded-lg cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleForgotSubmit} className="space-y-4">
            <p className="text-sm text-slate-600">
              Enter your institutional email address to request a password reset.
            </p>
            <div>
              <label htmlFor="forgot-email" className="block text-xs font-semibold text-slate-700 mb-1">
                Institutional Email
              </label>
              <input
                id="forgot-email"
                type="email"
                required
                value={forgotEmail}
                onChange={(e) => setForgotEmail(e.target.value)}
                placeholder="name@rsucaj.edu.ph"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:border-[#0B5537] focus:ring-2 focus:ring-[#0B5537]/15"
              />
            </div>

            {forgotResult && (
              <div className="rounded-lg bg-amber-50 border border-amber-200 p-3 text-xs text-amber-900">
                {forgotResult}
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setForgotOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                Close
              </button>
              <button
                type="submit"
                disabled={forgotSubmitting}
                className="px-4 py-2 text-xs font-semibold btn-rsu-primary rounded-lg disabled:opacity-60 cursor-pointer"
              >
                {forgotSubmitting ? 'Submitting...' : 'Submit Reset Request'}
              </button>
            </div>
          </form>
        )}
      </Modal>
    </main>
  );
};
