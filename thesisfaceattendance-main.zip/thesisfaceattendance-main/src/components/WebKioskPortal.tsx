import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  classifyCameraError,
  FrontalFrameAnalyzer,
  KioskVerificationStateMachine,
  KioskVoiceController,
  startFrontCameraStream,
  stopMediaStream,
  type CameraErrorInfo,
  type FrameQualityAnalysis,
  type KioskModelsStatusPayload,
  type VerificationStateSnapshot,
} from '../lib/kioskBiometrics';
import { KioskHeader } from './kiosk/KioskPrimitives';
import {
  KioskActivationScreen,
  KioskAdminPinModal,
  KioskAttendanceReadyScreen,
  KioskAttendanceSuccessScreen,
  KioskAutoEnrollProcessingScreen,
  KioskAutoEnrollScanningScreen,
  KioskEnrollmentSuccessScreen,
  KioskEnrollSelectEmployeeScreen,
  KioskFaceScanningScreen,
  KioskInformationScreen,
  KioskNotEnrolledScreen,
  KioskReadyHomeScreen,
  KioskSettingsScreen,
  KioskSplashScreen,
  KioskVerificationFailedScreen,
} from './kiosk/KioskScreens';
import type {
  KioskAdminIntent,
  KioskAttendanceOutcome,
  KioskEmployeeOption,
  KioskFailureOutcome,
  KioskScreenId,
  KioskSessionResponse,
  KioskSettingsState,
} from './kiosk/types';

const DEFAULT_MODELS_STATUS: KioskModelsStatusPayload = {
  models_dir: './models',
  all_models_verified_on_disk: false,
  server_inference_available: false,
  production_attendance_ready: false,
  blocking_reasons: ['Checking biometric model availability...'],
  models: {
    anti_spoofing_pad: {
      key: 'anti_spoofing_pad',
      filename: 'anti_spoofing_pad.tflite',
      architecture: 'MiniFASNetV1',
      status: 'MISSING',
      size_bytes: null,
      expected_sha256: '5d573d20b795a19d7b2a0f67cc4c1130ce8ec30d5f6aa06b2c788a344a49d4dd',
      actual_sha256: null,
      reason: 'Not inspected yet.',
    },
    liveness_detection: {
      key: 'liveness_detection',
      filename: 'liveness_detection.tflite',
      architecture: 'MiniFASNetV2',
      status: 'MISSING',
      size_bytes: null,
      expected_sha256: '4ff758f470b757d9005b418c9978693f09b8f2a5e7b7ee848c160db21208e1b2',
      actual_sha256: null,
      reason: 'Not inspected yet.',
    },
    face_recognition: {
      key: 'face_recognition',
      filename: 'face_recognition.tflite',
      architecture: 'MobileFaceNet',
      status: 'MISSING',
      size_bytes: null,
      expected_sha256: 'be4bc7cfc53f7bc336d0f28b1ab92535f618c913a422b683210750f6b5354854',
      actual_sha256: null,
      reason: 'Not inspected yet.',
    },
  },
};

const DEFAULT_SETTINGS: KioskSettingsState = {
  face_capture_enabled: true,
  liveness_enforced: true,
  liveness_locked_by_policy: true,
  voice_prompt_enabled: true,
};

export const WebKioskPortal: React.FC = () => {
  const [screen, setScreen] = useState<KioskScreenId>('splash');
  const [splashStatus, setSplashStatus] = useState('Checking device session...');
  const [online, setOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [session, setSession] = useState<KioskSessionResponse | null>(null);
  const [csrfToken, setCsrfToken] = useState<string>('');
  const [activationLoading, setActivationLoading] = useState(false);
  const [activationError, setActivationError] = useState<string | null>(null);

  // Admin PIN Modal (Screen 09)
  const [pinModalOpen, setPinModalOpen] = useState(false);
  const [pinIntent, setPinIntent] = useState<KioskAdminIntent>('settings');
  const [pinLoading, setPinLoading] = useState(false);
  const [pinError, setPinError] = useState<string | null>(null);

  // Camera & Real Frame Analysis State
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const analyzerRef = useRef<FrontalFrameAnalyzer | null>(null);
  const voiceRef = useRef<KioskVoiceController | null>(null);
  const stateMachineRef = useRef<KioskVerificationStateMachine | null>(null);
  const [cameraReady, setCameraReady] = useState(false);
  const [cameraError, setCameraError] = useState<CameraErrorInfo | null>(null);
  const [cameraHealth, setCameraHealth] = useState<string>('standby');
  const [frameAnalysis, setFrameAnalysis] = useState<FrameQualityAnalysis | null>(null);

  if (!voiceRef.current && typeof window !== 'undefined') {
    voiceRef.current = new KioskVoiceController();
  }
  if (!analyzerRef.current && typeof window !== 'undefined') {
    analyzerRef.current = new FrontalFrameAnalyzer();
  }
  if (!stateMachineRef.current) {
    stateMachineRef.current = new KioskVerificationStateMachine();
  }
  const [verificationState, setVerificationState] = useState<VerificationStateSnapshot>(() =>
    stateMachineRef.current!.getSnapshot(Date.now(), { modelsReady: false, backendOnline: true })
  );

  // Attendance State
  const [scanningAction, setScanningAction] = useState<'TIME_IN' | 'TIME_OUT' | null>(null);
  const [attendanceOutcome, setAttendanceOutcome] = useState<KioskAttendanceOutcome | null>(null);
  const [failureOutcome, setFailureOutcome] = useState<KioskFailureOutcome | null>(null);
  const attendanceCooldownRef = useRef<number>(0);

  // Enrollment State (Screens 10–13 — FRONT FACE ONLY)
  const [employees, setEmployees] = useState<KioskEmployeeOption[]>([]);
  const [employeesLoading, setEmployeesLoading] = useState(false);
  const [employeesError, setEmployeesError] = useState<string | null>(null);
  const [selectedEmployee, setSelectedEmployee] = useState<KioskEmployeeOption | null>(null);
  const [confirmReEnroll, setConfirmReEnroll] = useState(false);
  const [enrollFramesCaptured, setEnrollFramesCaptured] = useState(0);
  const [enrollProgress, setEnrollProgress] = useState(0);
  const [enrollStageLabel, setEnrollStageLabel] = useState('');
  const [enrolledEmployeeResult, setEnrolledEmployeeResult] = useState<{ name: string; code: string } | null>(null);

  // Settings & Sync State (Screens 14–15)
  const [settingsSaving, setSettingsSaving] = useState(false);
  const [speakerTesting, setSpeakerTesting] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [settingsNotice, setSettingsNotice] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const kioskFetch = useCallback(
    async <T,>(url: string, init: RequestInit = {}): Promise<T> => {
      const headers = new Headers(init.headers || {});
      if (init.body && !headers.has('Content-Type')) {
        headers.set('Content-Type', 'application/json');
      }
      if (csrfToken && init.method && init.method.toUpperCase() !== 'GET') {
        headers.set('X-Kiosk-CSRF', csrfToken);
      }
      const res = await fetch(url, {
        ...init,
        credentials: 'same-origin',
        headers,
      });
      const text = await res.text();
      let parsed: Record<string, unknown> = {};
      if (text) {
        try {
          parsed = JSON.parse(text) as Record<string, unknown>;
        } catch {
          parsed = { error: text };
        }
      }
      if (!res.ok) {
        if (res.status === 401 && url !== '/api/kiosk/web/activate' && url !== '/api/kiosk/web/admin/unlock') {
          stopMediaStream(streamRef.current);
          streamRef.current = null;
          setCameraReady(false);
          setSession(null);
          setCsrfToken('');
          setPinModalOpen(false);
          setActivationError('Your kiosk session expired or was revoked by an Administrator. Please re-activate this device.');
          setScreen('activation');
        }
        const err = new Error(String(parsed.error || `Request failed (${res.status})`)) as Error & {
          status?: number;
          code?: string;
          payload?: Record<string, unknown>;
        };
        err.status = res.status;
        err.code = typeof parsed.code === 'string' ? parsed.code : undefined;
        err.payload = parsed;
        throw err;
      }
      return parsed as T;
    },
    [csrfToken]
  );

  const loadSession = useCallback(async () => {
    setSplashStatus('Checking kiosk device session...');
    try {
      const data = await kioskFetch<KioskSessionResponse>('/api/kiosk/web/session');
      setSession(data);
      if (data.csrf_token) setCsrfToken(data.csrf_token);
      setOnline(true);
      setSplashStatus('Checking biometric models...');
      if (data.activated) {
        setScreen('ready_home');
      } else {
        setScreen('activation');
      }
    } catch {
      setOnline(false);
      setScreen('activation');
    }
  }, [kioskFetch]);

  useEffect(() => {
    loadSession();
  }, [loadSession]);

  // Network online/offline listeners
  useEffect(() => {
    const onOnline = () => setOnline(true);
    const onOffline = () => setOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  // Periodic real heartbeat while activated
  useEffect(() => {
    if (!session?.activated || !csrfToken) return;
    const sendHeartbeat = async () => {
      if (document.visibilityState === 'hidden') return;
      try {
        await kioskFetch('/api/kiosk/web/heartbeat', {
          method: 'POST',
          body: JSON.stringify({
            camera_health: cameraHealth,
            model_readiness: {
              all_verified_on_disk: session.models.all_models_verified_on_disk,
              server_inference_available: session.models.server_inference_available,
            },
          }),
        });
        setOnline(true);
      } catch (err) {
        const e = err as { status?: number };
        if (e.status === 401) {
          // Device session revoked remotely from Admin Portal — lock kiosk immediately
          setSession(null);
          setCsrfToken('');
          setScreen('activation');
          setActivationError('This kiosk session was revoked by an Administrator. Re-activate with a new code.');
        } else {
          setOnline(false);
        }
      }
    };
    const timer = window.setInterval(sendHeartbeat, 30_000);
    return () => window.clearInterval(timer);
  }, [session?.activated, session?.models, csrfToken, cameraHealth, kioskFetch]);

  // Camera Lifecycle: strictly active ONLY on Screen 04 (face_scanning) and Screen 11 (enroll_scanning)
  const needsCamera = screen === 'face_scanning' || screen === 'enroll_scanning';

  const stopCamera = useCallback(() => {
    stopMediaStream(streamRef.current);
    streamRef.current = null;
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraReady(false);
  }, []);

  const startCamera = useCallback(async () => {
    stopCamera();
    setCameraError(null);
    setCameraHealth('starting');
    try {
      const stream = await startFrontCameraStream();
      streamRef.current = stream;
      const track = stream.getVideoTracks()[0];
      if (track) {
        track.addEventListener('ended', () => {
          setCameraReady(false);
          setCameraHealth('disconnected');
          setCameraError({
            code: 'DISCONNECTED',
            message: 'Camera feed disconnected. Reconnect the camera and tap Retry Camera.',
          });
        });
      }
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {
          // autoplay may resolve on loadedmetadata
        });
      }
      setCameraReady(true);
      setCameraHealth('active');
    } catch (err) {
      const classified = classifyCameraError(err);
      setCameraError(classified);
      setCameraHealth(classified.code.toLowerCase());
      setCameraReady(false);
    }
  }, [stopCamera]);

  useEffect(() => {
    if (!needsCamera) {
      stopCamera();
      setCameraHealth('standby');
      return;
    }
    startCamera();

    const onVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        stopCamera();
        setCameraHealth('paused');
      } else if (needsCamera) {
        startCamera();
      }
    };
    document.addEventListener('visibilitychange', onVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', onVisibilityChange);
      stopCamera();
    };
  }, [needsCamera, startCamera, stopCamera]);

  // Continuous real offscreen canvas quality analysis & state-machine evaluation while camera is live
  useEffect(() => {
    if (!needsCamera) return;
    let cancelled = false;
    const loop = window.setInterval(async () => {
      if (cancelled) return;
      const models = session?.models ?? DEFAULT_MODELS_STATUS;
      if (!cameraReady || !videoRef.current || !analyzerRef.current) {
        if (stateMachineRef.current) {
          setVerificationState(
            stateMachineRef.current.evaluateFrame({
              timestampMs: Date.now(),
              cameraReady: false,
              cameraErrorCode: cameraError?.code ?? null,
              modelsVerifiedOnDisk: models.all_models_verified_on_disk,
              serverInferenceAvailable: models.server_inference_available,
              backendOnline: online,
              faceCount: 0,
              centered: false,
              sizeOk: false,
              lightingOk: false,
              sharpnessOk: false,
              frozenFrame: false,
              boundingBox: null,
              detectionConfidence: 0,
              qualityScore: 0,
            })
          );
        }
        return;
      }
      const result = await analyzerRef.current.analyze(videoRef.current);
      if (!cancelled) {
        setFrameAnalysis(result);
        if (stateMachineRef.current) {
          setVerificationState(
            stateMachineRef.current.evaluateFrame({
              timestampMs: result.timestampMs,
              cameraReady: true,
              cameraErrorCode: cameraError?.code ?? null,
              modelsVerifiedOnDisk: models.all_models_verified_on_disk,
              serverInferenceAvailable: models.server_inference_available,
              backendOnline: online,
              faceCount: result.faceCount,
              centered: result.centered,
              sizeOk: result.sizeOk,
              lightingOk: result.lightingOk,
              sharpnessOk: result.sharpnessOk,
              frozenFrame: result.frozenFrame,
              occlusionSuspected: result.occlusionSuspected,
              boundingBox: result.boundingBox,
              detectionConfidence: result.detectionConfidence,
              qualityScore: result.qualityScore,
            })
          );
        }
      }
    }, 350);
    return () => {
      cancelled = true;
      window.clearInterval(loop);
    };
  }, [needsCamera, cameraReady, cameraError, online, session?.models]);

  // Bounded cooldown countdown ticker so disabled buttons automatically recover when cooldown expires
  useEffect(() => {
    if (verificationState.cooldownRemainingMs <= 0) return;
    const timer = window.setInterval(() => {
      if (!stateMachineRef.current) return;
      const models = session?.models ?? DEFAULT_MODELS_STATUS;
      const next = stateMachineRef.current.getSnapshot(Date.now(), {
        modelsReady: models.all_models_verified_on_disk && models.server_inference_available,
        backendOnline: online,
      });
      setVerificationState(next);
    }, 500);
    return () => window.clearInterval(timer);
  }, [verificationState.cooldownRemainingMs, online, session?.models]);

  // Load active employees for Screen 10 (Admin-unlocked)
  const loadEnrollmentEmployees = useCallback(
    async (searchText = '') => {
      setEmployeesLoading(true);
      setEmployeesError(null);
      try {
        const res = await kioskFetch<{ data: KioskEmployeeOption[] }>(
          `/api/kiosk/web/employees?q=${encodeURIComponent(searchText)}`
        );
        setEmployees(res.data);
      } catch (err) {
        setEmployeesError(err instanceof Error ? err.message : 'Unable to load employee roster.');
      } finally {
        setEmployeesLoading(false);
      }
    },
    [kioskFetch]
  );

  // Screen 02: Activate Kiosk Device
  const handleActivateDevice = async (code: string) => {
    setActivationLoading(true);
    setActivationError(null);
    try {
      const res = await kioskFetch<KioskSessionResponse>('/api/kiosk/web/activate', {
        method: 'POST',
        body: JSON.stringify({ device_code: code }),
      });
      setSession(res);
      if (res.csrf_token) setCsrfToken(res.csrf_token);
      setOnline(true);
      setScreen('ready_home');
    } catch (err) {
      setActivationError(err instanceof Error ? err.message : 'Device activation failed.');
    } finally {
      setActivationLoading(false);
    }
  };

  // Request Admin PIN Modal (Screen 09) before Settings (Screen 14) or Enrollment (Screen 10)
  const openAdminGate = (intent: KioskAdminIntent) => {
    if (!session?.activated) return;
    setPinError(null);
    setPinIntent(intent);
    if (session.admin_unlocked && session.admin_unlocked_until && session.admin_unlocked_until > Date.now()) {
      if (intent === 'enrollment') {
        setSelectedEmployee(null);
        setScreen('enroll_select_employee');
        loadEnrollmentEmployees('');
      } else {
        setSettingsNotice(null);
        setScreen('settings');
      }
      return;
    }
    setPinModalOpen(true);
  };

  const handleUnlockAdminPin = async (pin: string) => {
    setPinLoading(true);
    setPinError(null);
    try {
      const res = await kioskFetch<{ unlocked: boolean; admin_unlocked_until: number }>(
        '/api/kiosk/web/admin/unlock',
        {
          method: 'POST',
          body: JSON.stringify({ pin }),
        }
      );
      setSession((prev) =>
        prev
          ? {
              ...prev,
              admin_unlocked: true,
              admin_unlocked_until: res.admin_unlocked_until,
            }
          : prev
      );
      setPinModalOpen(false);
      if (pinIntent === 'enrollment') {
        setSelectedEmployee(null);
        setScreen('enroll_select_employee');
        loadEnrollmentEmployees('');
      } else {
        setSettingsNotice(null);
        setScreen('settings');
      }
    } catch (err) {
      setPinError(err instanceof Error ? err.message : 'Incorrect Administrator PIN.');
    } finally {
      setPinLoading(false);
    }
  };

  // Screen 04 -> Attendance Submission (strictly fail-closed when real TFLite models/inference are absent!)
  const handleTriggerAttendance = async (action: 'TIME_IN' | 'TIME_OUT') => {
    if (scanningAction) return;
    const now = Date.now();
    if (now - attendanceCooldownRef.current < 2000) return;
    attendanceCooldownRef.current = now;

    const voiceEnabled = session?.settings?.voice_prompt_enabled ?? true;
    const models = session?.models ?? DEFAULT_MODELS_STATUS;

    // Never fabricate a face embedding or biometric match!
    if (!models.all_models_verified_on_disk || !models.server_inference_available) {
      const msg =
        'Biometric verification models (anti_spoofing_pad.tflite, liveness_detection.tflite, face_recognition.tflite) are not deployed on this server. Attendance cannot be verified without real biometric inference.';
      if (stateMachineRef.current) {
        setVerificationState(stateMachineRef.current.recordFailure('MODEL_ERROR', msg, now));
      }
      setFailureOutcome({
        title: 'Verification Failed',
        message: msg,
        code: 'MODEL_ERROR',
      });
      voiceRef.current?.speakAttendanceResult('failure', voiceEnabled);
      setScreen('verification_failed');
      return;
    }

    if (!cameraReady || cameraError) {
      const msg = cameraError?.message || 'Camera is not ready. Please allow camera access and try again.';
      if (stateMachineRef.current) {
        setVerificationState(stateMachineRef.current.recordFailure('CAMERA_BLOCKED', msg, now));
      }
      setFailureOutcome({
        title: 'Verification Failed',
        message: msg,
        code: 'CAMERA_BLOCKED',
      });
      voiceRef.current?.speakAttendanceResult('failure', voiceEnabled);
      setScreen('verification_failed');
      return;
    }

    if (stateMachineRef.current) {
      stateMachineRef.current.markBackendVerifying();
      setVerificationState(
        stateMachineRef.current.getSnapshot(now, {
          modelsReady: models.all_models_verified_on_disk && models.server_inference_available,
          backendOnline: online,
        })
      );
    }

    setScanningAction(action);
    try {
      // 1. Obtain single-use expiring verification challenge nonce
      const challenge = await kioskFetch<{ challenge_nonce: string }>('/api/kiosk/web/challenge', {
        method: 'POST',
        body: JSON.stringify({ scope: 'ATTENDANCE' }),
      });

      // 2. Submit verified biometric payload (server performs 1:N matching — NEVER accepts client employee_id)
      const result = await kioskFetch<{
        recorded: boolean;
        action: 'TIME_IN' | 'TIME_OUT';
        employee_name: string;
        employee_code: string;
        shift_date: string;
        recorded_time: string;
        status: string;
        voice_cue?: 'THANK_YOU' | 'TRY_AGAIN';
      }>('/api/kiosk/web/attendance', {
        method: 'POST',
        body: JSON.stringify({
          challenge_nonce: challenge.challenge_nonce,
          action,
          detection_confidence: frameAnalysis?.detectionConfidence ?? 0,
          quality_score: frameAnalysis?.qualityScore ?? 0,
        }),
      });

      setAttendanceOutcome({
        action: result.action,
        employee_name: result.employee_name,
        employee_code: result.employee_code,
        shift_date: result.shift_date,
        recorded_time: result.recorded_time,
        status: result.status,
      });
      voiceRef.current?.speakAttendanceResult('success', voiceEnabled);
      setScreen(result.action === 'TIME_IN' ? 'time_in_success' : 'time_out_success');
    } catch (err) {
      const e = err as Error & { code?: string };
      voiceRef.current?.speakAttendanceResult('failure', voiceEnabled);
      if (e.code === 'NOT_ENROLLED') {
        setScreen('not_enrolled');
      } else if (e.code === 'ALREADY_TAKEN') {
        setFailureOutcome({
          title: 'Verification Failed',
          message: 'Already taken attendance',
          code: 'ALREADY_TAKEN',
          alreadyTaken: true,
        });
        setScreen('verification_failed');
      } else {
        setFailureOutcome({
          title: 'Verification Failed',
          message: e.message || 'Face not recognized or verification did not pass.',
          code: e.code || 'VERIFICATION_FAILED',
        });
        setScreen('verification_failed');
      }
    } finally {
      setScanningAction(null);
    }
  };

  // Screen 11 Automatic Touchless Front-Face Capture Monitor (Zero manual shutter button!)
  useEffect(() => {
    if (screen !== 'enroll_scanning' || !selectedEmployee) return;
    const models = session?.models ?? DEFAULT_MODELS_STATUS;
    if (!models.all_models_verified_on_disk || !models.server_inference_available) {
      return; // Stay honest on Screen 11 showing model-missing explanation; never fake enrollment!
    }
    if (!cameraReady || !frameAnalysis) return;
    if (
      frameAnalysis.faceDetected &&
      frameAnalysis.centered &&
      frameAnalysis.sizeOk &&
      frameAnalysis.lightingOk &&
      frameAnalysis.sharpnessOk &&
      !frameAnalysis.frozenFrame
    ) {
      setEnrollFramesCaptured((prev) => {
        const next = Math.min(3, prev + 1);
        if (next >= 3) {
          setEnrollProgress(35);
          setEnrollStageLabel('Verifying captured frontal frames...');
          setScreen('enroll_processing');
        }
        return next;
      });
    }
  }, [screen, selectedEmployee, session?.models, cameraReady, frameAnalysis]);

  // Admin-only diagnostic. It tests a short tone through the local audio asset,
  // without pretending that a successful browser play() proves physical speaker output.
  const handleTestSpeaker = async () => {
    if (speakerTesting) return;
    setSpeakerTesting(true);
    setSettingsNotice(null);
    try {
      const started = await voiceRef.current?.testSpeaker();
      setSettingsNotice(started
        ? { type: 'ok', text: 'Speaker test tone started. If you heard nothing, check the OS audio output, mute and volume.' }
        : { type: 'err', text: 'Browser audio playback was blocked or unavailable. Tap Test Speaker again, check browser autoplay permission, and verify the OS audio device.' });
    } finally {
      setSpeakerTesting(false);
    }
  };

  // Screen 14: Persisted Settings Update
  const handleUpdateSettings = async (
    patch: Partial<Pick<KioskSettingsState, 'face_capture_enabled' | 'liveness_enforced' | 'voice_prompt_enabled'>>
  ) => {
    setSettingsSaving(true);
    setSettingsNotice(null);
    try {
      const res = await kioskFetch<{ ok: boolean; settings: KioskSettingsState }>('/api/kiosk/web/settings', {
        method: 'PATCH',
        body: JSON.stringify(patch),
      });
      setSession((prev) => (prev ? { ...prev, settings: res.settings } : prev));
      setSettingsNotice({ type: 'ok', text: 'Kiosk settings saved.' });
    } catch (err) {
      setSettingsNotice({ type: 'err', text: err instanceof Error ? err.message : 'Unable to save kiosk settings.' });
    } finally {
      setSettingsSaving(false);
    }
  };

  // Screen 14: Real Sync Now
  const handleSyncNow = async () => {
    setSyncing(true);
    setSettingsNotice(null);
    try {
      const res = await kioskFetch<{
        ok: boolean;
        synced_at_utc: string;
        last_sync_display: string;
        enrolled_employee_count: number;
        active_employee_count: number;
        models: KioskModelsStatusPayload;
      }>('/api/kiosk/web/sync', { method: 'POST', body: JSON.stringify({}) });

      setSession((prev) =>
        prev && prev.device
          ? {
              ...prev,
              enrolled_employee_count: res.enrolled_employee_count,
              models: res.models,
              device: {
                ...prev.device,
                last_sync_utc: res.synced_at_utc,
                last_sync_display: res.last_sync_display,
              },
            }
          : prev
      );
      setOnline(true);
      setSettingsNotice({
        type: 'ok',
        text: `Synced successfully at ${res.last_sync_display} (${res.enrolled_employee_count}/${res.active_employee_count} employees enrolled).`,
      });
    } catch (err) {
      setOnline(false);
      setSettingsNotice({ type: 'err', text: err instanceof Error ? err.message : 'Sync failed — server unreachable.' });
    } finally {
      setSyncing(false);
    }
  };

  const handleLockAdminAndReturn = async () => {
    try {
      await kioskFetch('/api/kiosk/web/admin/lock', { method: 'POST', body: JSON.stringify({}) });
    } catch {
      // ignore
    }
    setSession((prev) => (prev ? { ...prev, admin_unlocked: false, admin_unlocked_until: null } : prev));
    setScreen('ready_home');
  };

  const handleDeactivateDevice = async () => {
    try {
      await kioskFetch('/api/kiosk/web/deactivate', { method: 'POST', body: JSON.stringify({}) });
      setSession(null);
      setCsrfToken('');
      setActivationError(null);
      setScreen('activation');
    } catch (err) {
      setSettingsNotice({ type: 'err', text: err instanceof Error ? err.message : 'Unable to deactivate kiosk.' });
    }
  };

  // Expose controlled screen preview state ONLY on non-production test builds via window hook for automated 16-screen Playwright visual verification (never bypasses backend auth or attendance APIs!)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (session?.app_mode === 'production') return;
    (window as unknown as { __SAVAGE_KIOSK_TEST_HOOK__?: Record<string, unknown> }).__SAVAGE_KIOSK_TEST_HOOK__ = {
      previewScreen: (
        target: KioskScreenId,
        opts?: {
          attendanceOutcome?: KioskAttendanceOutcome;
          failureOutcome?: KioskFailureOutcome;
          enrolledEmployee?: { name: string; code: string };
          progressPercent?: number;
          openPinModal?: boolean;
          selectedEmployee?: KioskEmployeeOption;
        }
      ) => {
        if (opts?.attendanceOutcome) setAttendanceOutcome(opts.attendanceOutcome);
        if (opts?.failureOutcome) setFailureOutcome(opts.failureOutcome);
        if (opts?.enrolledEmployee) setEnrolledEmployeeResult(opts.enrolledEmployee);
        if (typeof opts?.progressPercent === 'number') setEnrollProgress(opts.progressPercent);
        if (opts?.selectedEmployee) setSelectedEmployee(opts.selectedEmployee);
        setPinModalOpen(Boolean(opts?.openPinModal));
        setScreen(target);
      },
    };
    return () => {
      delete (window as unknown as { __SAVAGE_KIOSK_TEST_HOOK__?: Record<string, unknown> }).__SAVAGE_KIOSK_TEST_HOOK__;
    };
  }, [session?.app_mode]);

  // Cancel any in-progress voice playback when the kiosk unmounts.
  useEffect(() => () => voiceRef.current?.stop(), []);

  // Screen 01: Full-screen emerald Splash
  if (screen === 'splash') {
    return <KioskSplashScreen statusText={splashStatus} />;
  }

  const activeSettings = session?.settings ?? DEFAULT_SETTINGS;
  const activeModels = session?.models ?? DEFAULT_MODELS_STATUS;
  const productionBlocked = Boolean(session?.biometric_policy?.production_attendance_blocked);

  return (
    <div className="min-h-screen w-full bg-[#F7FAF8] flex flex-col overflow-x-hidden">
      <KioskHeader
        online={online}
        showWave={screen !== 'face_scanning'}
        onOpenSettings={session?.activated ? () => openAdminGate('settings') : undefined}
        onLogoClick={session?.activated && screen !== 'enroll_processing' ? () => setScreen('ready_home') : undefined}
      />

      <main className="flex-1 flex flex-col w-full">
        {screen === 'activation' && (
          <KioskActivationScreen
            onActivate={handleActivateDevice}
            loading={activationLoading}
            error={activationError}
          />
        )}

        {screen === 'ready_home' && (
          <KioskReadyHomeScreen
            models={activeModels}
            livenessEnforced={activeSettings.liveness_enforced}
            onStartAttendance={() => { voiceRef.current?.prepareFromUserGesture(); setScreen('attendance_ready'); }}
            onRequestAutoEnroll={() => openAdminGate('enrollment')}
          />
        )}

        {screen === 'attendance_ready' && (
          <KioskAttendanceReadyScreen
            faceCaptureEnabled={activeSettings.face_capture_enabled}
            onActivateScan={() => { voiceRef.current?.prepareFromUserGesture(); setScreen('face_scanning'); }}
            onBackHome={() => setScreen('ready_home')}
          />
        )}

        {screen === 'face_scanning' && (
          <KioskFaceScanningScreen
            videoRef={videoRef}
            cameraReady={cameraReady}
            cameraError={cameraError}
            onRetryCamera={startCamera}
            frameAnalysis={frameAnalysis}
            verificationState={verificationState}
            scanningAction={scanningAction}
            models={activeModels}
            productionBlocked={productionBlocked}
            onCancelScan={() => {
              stateMachineRef.current?.cancel();
              setScreen('ready_home');
            }}
            onResetCooldown={() => {
              stateMachineRef.current?.resetForRetry();
              if (stateMachineRef.current) {
                setVerificationState(
                  stateMachineRef.current.getSnapshot(Date.now(), {
                    modelsReady: activeModels.all_models_verified_on_disk && activeModels.server_inference_available,
                    backendOnline: online,
                  })
                );
              }
            }}
            onTriggerAttendance={handleTriggerAttendance}
          />
        )}

        {(screen === 'time_in_success' || screen === 'time_out_success') && attendanceOutcome && (
          <KioskAttendanceSuccessScreen
            outcome={attendanceOutcome}
            onDismiss={() => setScreen('face_scanning')}
          />
        )}

        {screen === 'verification_failed' && failureOutcome && (
          <KioskVerificationFailedScreen
            failure={failureOutcome}
            cooldownSeconds={Math.ceil(verificationState.cooldownRemainingMs / 1000)}
            onTryAgain={() => {
              stateMachineRef.current?.resetForRetry();
              setScreen('face_scanning');
            }}
            onCancel={() => {
              stateMachineRef.current?.cancel();
              setScreen('ready_home');
            }}
          />
        )}

        {screen === 'not_enrolled' && (
          <KioskNotEnrolledScreen onDismiss={() => setScreen('face_scanning')} />
        )}

        {screen === 'enroll_select_employee' && (
          <KioskEnrollSelectEmployeeScreen
            employees={employees}
            loading={employeesLoading}
            error={employeesError}
            selectedEmployeeId={selectedEmployee?.id ?? null}
            onSelectEmployee={(emp) => setSelectedEmployee(emp)}
            onSearchChange={(q) => loadEnrollmentEmployees(q)}
            onNext={(reEnroll) => {
              setConfirmReEnroll(reEnroll);
              setEnrollFramesCaptured(0);
              stateMachineRef.current?.resetForRetry();
              setScreen('enroll_scanning');
            }}
            onCancel={() => setScreen('ready_home')}
          />
        )}

        {screen === 'enroll_scanning' && selectedEmployee && (
          <KioskAutoEnrollScanningScreen
            employee={selectedEmployee}
            videoRef={videoRef}
            cameraReady={cameraReady}
            cameraError={cameraError}
            onRetryCamera={startCamera}
            capturedFrames={enrollFramesCaptured}
            requiredFrames={3}
            guidance={frameAnalysis?.guidance || 'Look straight at the camera.'}
            modelsMissing={!activeModels.all_models_verified_on_disk || !activeModels.server_inference_available}
            verificationState={verificationState}
            onCancel={() => {
              setEnrollFramesCaptured(0);
              stateMachineRef.current?.cancel();
              setScreen('enroll_select_employee');
            }}
          />
        )}

        {screen === 'enroll_processing' && (
          <KioskAutoEnrollProcessingScreen
            progressPercent={enrollProgress}
            stageLabel={
              enrollStageLabel ||
              (confirmReEnroll
                ? 'Replacing existing encrypted face template. Please do not move.'
                : 'Automatically capturing and registering your face. Please do not move.')
            }
          />
        )}

        {screen === 'enroll_success' && enrolledEmployeeResult && (
          <KioskEnrollmentSuccessScreen
            employeeName={enrolledEmployeeResult.name}
            employeeCode={enrolledEmployeeResult.code}
            onDone={() => {
              setEnrolledEmployeeResult(null);
              setSelectedEmployee(null);
              setScreen('ready_home');
            }}
          />
        )}

        {screen === 'settings' && (
          <KioskSettingsScreen
            settings={activeSettings}
            saving={settingsSaving}
            syncing={syncing}
            notice={settingsNotice}
            onUpdateSetting={handleUpdateSettings}
            onOpenInfo={() => setScreen('kiosk_info')}
            onSyncNow={handleSyncNow}
            onTestSpeaker={handleTestSpeaker}
            speakerTesting={speakerTesting}
            onStartEnrollment={() => {
              setSelectedEmployee(null);
              setScreen('enroll_select_employee');
              loadEnrollmentEmployees('');
            }}
            onLockAndReturn={handleLockAdminAndReturn}
            onDeactivateDevice={handleDeactivateDevice}
          />
        )}

        {screen === 'kiosk_info' && session?.device && (
          <KioskInformationScreen
            device={session.device}
            online={online}
            models={activeModels}
            cameraHealth={cameraHealth}
            onBack={() => setScreen('settings')}
          />
        )}
      </main>

      {/* Screen 09: Administrator PIN Access Modal */}
      <KioskAdminPinModal
        open={pinModalOpen}
        loading={pinLoading}
        error={pinError}
        onCancel={() => setPinModalOpen(false)}
        onSubmitPin={handleUnlockAdminPin}
      />
    </div>
  );
};
