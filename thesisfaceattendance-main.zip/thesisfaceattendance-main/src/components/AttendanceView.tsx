import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  CalendarCheck2,
  Search,
  Plus,
  Download,
  Trash2,
  Eye,
  ChevronLeft,
  ChevronRight,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';
import { ModuleFrame, Modal, ConfirmModal, StatusLabel } from './ModuleFrame';
import { apiFetch, downloadCsv, formatDisplayDate, getManilaTodayIso } from '../lib/api';
import { useRealtimeStream } from '../lib/realtime';
import type { RealtimeConnectionStatus } from '../lib/realtime';
import type {
  AttendanceEvent,
  AttendanceRecord,
  AttendanceStatus,
  AuthUser,
  Department,
  Employee,
  EmployeeTodayAttendance,
} from '../types';

const ATTENDANCE_STATUSES: AttendanceStatus[] = [
  'Present',
  'Late',
  'Absent',
  'Undertime',
  'On Leave',
  'OB',
  'Rest Day',
  'Holiday',
  'Missing Time In',
  'Missing Time Out',
  'No Schedule',
];

export const AttendanceView: React.FC<{ currentUser?: AuthUser }> = ({ currentUser }) => {
  const perms = currentUser?.permissions || [];
  const canWriteAttendance = !currentUser || perms.includes('attendance:write');
  const isEmployeeSelfOnly =
    currentUser?.role === 'Employee' ||
    (Boolean(currentUser) && !perms.includes('attendance:read') && perms.includes('attendance:read_self'));

  const todayIso = getManilaTodayIso();
  const [date, setDate] = useState(todayIso);
  const [deptId, setDeptId] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  useEffect(() => {
    const timeout = setTimeout(() => setDebouncedSearch(search), 220);
    return () => clearTimeout(timeout);
  }, [search]);
  const [page, setPage] = useState(1);
  const limit = 10;

  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [total, setTotal] = useState(0);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [employeeToday, setEmployeeToday] = useState<EmployeeTodayAttendance | null>(null);
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [liveStatus, setLiveStatus] = useState<RealtimeConnectionStatus>('connecting');
  const [lastSyncedUtc, setLastSyncedUtc] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [viewing, setViewing] = useState<AttendanceRecord | null>(null);
  const [viewingEvents, setViewingEvents] = useState<AttendanceEvent[]>([]);
  const [eventsLoading, setEventsLoading] = useState(false);
  const [deleting, setDeleting] = useState<AttendanceRecord | null>(null);
  const [reconciling, setReconciling] = useState(false);

  const [form, setForm] = useState({
    employee_id: '',
    date: todayIso,
    time_in: '08:00 AM',
    time_out: '05:00 PM',
    status: 'Present' as AttendanceStatus,
    device_name: 'Admin Manual Entry',
    remarks: '',
  });
  const [saving, setSaving] = useState(false);

  const loadMeta = useCallback(async () => {
    if (isEmployeeSelfOnly) return;
    try {
      const [d, e] = await Promise.all([
        apiFetch<{ data: Department[] }>('/api/departments'),
        apiFetch<{ data: Employee[] }>('/api/employees?limit=100'),
      ]);
      setDepartments(d.data);
      setEmployees(e.data);
    } catch {
      // ignore if user role does not have employees:read
    }
  }, [isEmployeeSelfOnly]);

  const loadEmployeeToday = useCallback(async () => {
    if (!isEmployeeSelfOnly) return;
    try {
      const res = await apiFetch<EmployeeTodayAttendance>('/api/employee/today-attendance');
      setEmployeeToday(res);
    } catch {
      setEmployeeToday(null);
    }
  }, [isEmployeeSelfOnly]);

  const loadAttendance = useCallback(async () => {
    setLoading(true);
    setFetchError(null);
    try {
      const qs = new URLSearchParams({
        date,
        page: String(page),
        limit: String(limit),
      });
      if (deptId) qs.set('department_id', deptId);
      if (statusFilter) qs.set('status', statusFilter);
      if (debouncedSearch.trim()) qs.set('search', debouncedSearch.trim());
      const res = await apiFetch<{ data: AttendanceRecord[]; total?: number }>(
        `/api/attendance?${qs.toString()}`
      );
      setRecords(res.data);
      setTotal(res.total ?? res.data.length);
      setLastSyncedUtc(new Date().toISOString());
    } catch (err) {
      setFetchError(err instanceof Error ? err.message : 'Unable to fetch attendance from server.');
    } finally {
      setLoading(false);
    }
  }, [date, deptId, statusFilter, debouncedSearch, page]);

  useEffect(() => {
    loadMeta();
  }, [loadMeta]);

  useEffect(() => {
    loadAttendance();
    loadEmployeeToday();
  }, [loadAttendance, loadEmployeeToday]);

  // BUILD 25: one fetch per event burst instead of overlapping network calls.
  const latestAttendanceLoader = useRef(loadAttendance);
  latestAttendanceLoader.current = loadAttendance;
  const latestTodayLoader = useRef(loadEmployeeToday);
  latestTodayLoader.current = loadEmployeeToday;
  const realtimeRefreshTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scheduleRealtimeRefresh = useCallback(() => {
    if (realtimeRefreshTimer.current !== null) return;
    realtimeRefreshTimer.current = setTimeout(() => {
      realtimeRefreshTimer.current = null;
      void latestAttendanceLoader.current();
      void latestTodayLoader.current();
    }, 150);
  }, []);
  useEffect(() => () => {
    if (realtimeRefreshTimer.current !== null) clearTimeout(realtimeRefreshTimer.current);
  }, []);

  // BUILD 10: Real-time attendance updates over authenticated & RBAC-scoped SSE
  useRealtimeStream({
    channels: ['attendance:updated'],
    onEvent: scheduleRealtimeRefresh,
    onResync: scheduleRealtimeRefresh,
    onStatusChange: setLiveStatus,
  });

  useEffect(() => {
    if (!viewing) {
      setViewingEvents([]);
      return;
    }
    let cancelled = false;
    setEventsLoading(true);
    apiFetch<{ data: AttendanceEvent[] }>(`/api/attendance/${viewing.id}/events`)
      .then((res) => {
        if (!cancelled) setViewingEvents(res.data);
      })
      .catch(() => {
        if (!cancelled) setViewingEvents([]);
      })
      .finally(() => {
        if (!cancelled) setEventsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [viewing]);

  const openLogModal = () => {
    setForm({
      employee_id: String(employees[0]?.id || ''),
      date,
      time_in: '08:00 AM',
      time_out: '05:00 PM',
      status: 'Present',
      device_name: 'Admin Manual Entry',
      remarks: '',
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setFeedback(null);
    try {
      const noTimeStatus = ['Absent', 'On Leave', 'No Schedule'].includes(form.status);
      const missingInStatus = form.status === 'Missing Time In';
      const missingOutStatus = form.status === 'Missing Time Out';
      await apiFetch('/api/attendance', {
        method: 'POST',
        body: JSON.stringify({
          ...form,
          employee_id: Number(form.employee_id),
          time_in: noTimeStatus || missingInStatus ? null : form.time_in || null,
          time_out: noTimeStatus || missingOutStatus ? null : form.time_out || null,
        }),
      });
      setModalOpen(false);
      setFeedback({ type: 'ok', text: `Attendance saved for ${formatDisplayDate(form.date)}.` });
      loadAttendance();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Failed to save record.' });
    } finally {
      setSaving(false);
    }
  };

  const handleReconcile = async () => {
    setReconciling(true);
    setFeedback(null);
    try {
      const res = await apiFetch<{
        summary: {
          date: string;
          evaluatedEmployees: number;
          markedMissingTimeOut: number;
          markedAbsent: number;
          markedOnLeave: number;
          markedOB: number;
          markedHoliday: number;
          markedRestDay: number;
          markedNoSchedule: number;
        };
      }>('/api/attendance/reconcile', {
        method: 'POST',
        body: JSON.stringify({ date }),
      });
      const s = res.summary;
      setFeedback({
        type: 'ok',
        text: `Reconciled ${formatDisplayDate(s.date)} (Asia/Manila): ${s.evaluatedEmployees} evaluated · ${s.markedMissingTimeOut} Missing Time Out · ${s.markedAbsent} Absent · ${s.markedOnLeave} On Leave · ${s.markedOB} OB · ${s.markedHoliday} Holiday · ${s.markedRestDay} Rest Day.`,
      });
      loadAttendance();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Reconciliation failed.' });
    } finally {
      setReconciling(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleting) return;
    setFeedback(null);
    try {
      await apiFetch(`/api/attendance/${deleting.id}`, { method: 'DELETE' });
      setFeedback({ type: 'ok', text: `Attendance record for ${deleting.employee_name} removed.` });
      setDeleting(null);
      loadAttendance();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Delete failed.' });
      setDeleting(null);
    }
  };

  const handleExport = () => {
    downloadCsv(
      `savage-rsucaj-attendance-${date}.csv`,
      [
        'employee_code',
        'employee_name',
        'department_code',
        'date',
        'time_in',
        'break_out',
        'break_in',
        'time_out',
        'overtime_out',
        'work_hours',
        'late_minutes',
        'undertime_minutes',
        'overtime_minutes',
        'status',
        'device_name',
      ],
      records as unknown as Record<string, unknown>[]
    );
    setFeedback({ type: 'ok', text: `Exported ${records.length} attendance record(s) for ${formatDisplayDate(date)}.` });
  };

  const totalPages = Math.max(1, Math.ceil(total / limit));
  const startIdx = total === 0 ? 0 : (page - 1) * limit + 1;
  const endIdx = Math.min(total, page * limit);

  return (
    <ModuleFrame
      title={isEmployeeSelfOnly ? "My Attendance (Read-Only)" : "Attendance Records"}
      subtitle={
        isEmployeeSelfOnly
          ? "Read-only personal daily attendance synced from campus kiosk terminals (Asia/Manila). Time In / Time Out is recorded exclusively at campus kiosks."
          : "Daily time-in, time-out, computed work hours, and kiosk source verification (Asia/Manila)."
      }
      icon={<CalendarCheck2 className="w-5 h-5" />}
      headerAction={
        <div className="flex flex-wrap items-center gap-2">
          {canWriteAttendance && (
            <button
              type="button"
              disabled={reconciling}
              onClick={handleReconcile}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-semibold transition-colors cursor-pointer disabled:opacity-60"
              title="Run shift-date reconciliation for Missing Time Out, Absent, On Leave, OB, Holiday, and Rest Day"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${reconciling ? 'animate-spin' : ''}`} />
              <span>{reconciling ? 'Reconciling...' : 'Reconcile Day'}</span>
            </button>
          )}
          <button
            type="button"
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          {canWriteAttendance && (
            <button
              type="button"
              onClick={openLogModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl btn-rsu-primary text-xs font-semibold transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log Attendance</span>
            </button>
          )}
        </div>
      }
    >
      {isEmployeeSelfOnly && employeeToday && (
        <div className="mb-4 p-4 rounded-xl bg-[#F4F8F6] border border-emerald-900/10 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
            <div>
              <p className="font-bold text-[#07442B]">
                Today&apos;s Attendance · {formatDisplayDate(employeeToday.date)} (Read-Only)
              </p>
              <p className="text-[11px] text-slate-500">
                {employeeToday.employee.employee_code} · {employeeToday.employee.shift_name} ({employeeToday.employee.shift_time_in} – {employeeToday.employee.shift_time_out})
              </p>
            </div>
            <StatusLabel status={employeeToday.attendance?.status || 'No Check-In Yet'} />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white p-3 rounded-lg border border-slate-200/70">
            <div>
              <p className="text-[11px] text-slate-400">Time In</p>
              <p className="font-mono-num font-bold text-slate-800 mt-0.5">
                {employeeToday.attendance?.time_in || '—'}
              </p>
            </div>
            <div>
              <p className="text-[11px] text-slate-400">Time Out</p>
              <p className="font-mono-num font-bold text-slate-800 mt-0.5">
                {employeeToday.attendance?.time_out || '—'}
              </p>
            </div>
            <div>
              <p className="text-[11px] text-slate-400">Work Hours</p>
              <p className="font-mono-num font-bold text-[#0B5537] mt-0.5">
                {employeeToday.attendance?.work_hours || '—'}
              </p>
            </div>
            <div>
              <p className="text-[11px] text-slate-400">Capture Source</p>
              <p className="font-medium text-slate-700 mt-0.5">
                {employeeToday.attendance?.device_name || 'Awaiting campus kiosk'}
              </p>
            </div>
          </div>
        </div>
      )}

      <section aria-label="Attendance live synchronization" className="mb-4 flex flex-wrap gap-2 items-center justify-between rounded-xl border border-emerald-900/10 bg-white px-4 py-2 text-xs">
        <span className="font-bold text-[#07442B]" aria-live="polite">
          {liveStatus === 'live' ? 'Live attendance updates connected' : liveStatus === 'polling' ? 'Auto-refresh fallback active' : liveStatus === 'reconnecting' ? 'Reconnecting live attendance' : 'Connecting to live attendance'}
        </span>
        <span className="text-slate-500">
          {lastSyncedUtc ? `Last server sync: ${new Date(lastSyncedUtc).toLocaleTimeString('en-PH', { timeZone: 'Asia/Manila' })}` : 'No successful sync yet'}
        </span>
      </section>
      {fetchError && (
        <div role="alert" className="mb-4 rounded-xl border border-red-200 bg-red-50 p-3 text-xs text-red-800">
          Server refresh failed: {fetchError}. Existing table may be stale.
          <button type="button" onClick={() => void loadAttendance()} className="ml-2 font-bold underline">Retry</button>
        </div>
      )}
      {feedback && (
        <div
          className={`mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Filter Bar matching 05_Attendance_Records.png */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          setPage(1);
          loadAttendance();
        }}
        className="flex flex-wrap items-center gap-2.5 mb-4"
      >
        <input
          type="date"
          aria-label="Attendance date"
          value={date}
          onChange={(e) => {
            setDate(e.target.value);
            setPage(1);
          }}
          className="px-3.5 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 font-semibold font-mono-num shadow-2xs focus:outline-none focus:border-[#0B5537]"
        />
        <select
          aria-label="Filter by department"
          value={deptId}
          onChange={(e) => {
            setDeptId(e.target.value);
            setPage(1);
          }}
          className="px-3.5 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 bg-white shadow-2xs focus:outline-none focus:border-[#0B5537] min-w-[170px]"
        >
          <option value="">All Departments</option>
          {departments.map((d) => (
            <option key={d.id} value={d.id}>
              {d.code} — {d.name}
            </option>
          ))}
        </select>
        <select
          aria-label="Filter by status"
          value={statusFilter}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            setPage(1);
          }}
          className="px-3.5 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 bg-white shadow-2xs focus:outline-none focus:border-[#0B5537]"
        >
          <option value="">All Statuses</option>
          {ATTENDANCE_STATUSES.map((st) => (
            <option key={st} value={st}>
              {st}
            </option>
          ))}
        </select>
        <input
          type="text"
          aria-label="Search attendance by employee ID or name"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search employee ID or name..."
          className="flex-1 min-w-[160px] max-w-xs px-3.5 py-2 rounded-xl border border-slate-200 bg-white text-xs shadow-2xs focus:outline-none focus:border-[#0B5537]"
        />
        <button
          type="submit"
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl btn-rsu-primary text-xs font-semibold transition-all cursor-pointer"
        >
          <Search className="w-3.5 h-3.5" />
          <span>Search</span>
        </button>
      </form>

      {/* Attendance Table matching 05_Attendance_Records.png */}
      <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
              <th className="py-3 px-4">Employee ID</th>
              <th className="py-3 px-4">Name</th>
              <th className="py-3 px-4">Time In</th>
              <th className="py-3 px-4">Time Out</th>
              <th className="py-3 px-4">Work Hours</th>
              <th className="py-3 px-4 text-center">Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs">
            {loading ? (
              <tr>
                <td colSpan={7} className="py-8 text-center text-slate-400">
                  Loading attendance logs...
                </td>
              </tr>
            ) : records.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-8 text-center text-slate-400">
                  No attendance entries recorded for {formatDisplayDate(date)}.
                </td>
              </tr>
            ) : (
              records.map((rec) => (
                <tr key={rec.id} className="hover:bg-emerald-50/35 transition-colors">
                  <td className="py-3.5 px-4 font-mono-num font-semibold text-slate-800 whitespace-nowrap">
                    {rec.employee_code}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-slate-900">{rec.employee_name}</div>
                    <div className="text-[11px] text-slate-500">{rec.department_code}</div>
                  </td>
                  <td className="py-3.5 px-4 font-mono-num text-slate-700 whitespace-nowrap">
                    {rec.time_in || '-'}
                  </td>
                  <td className="py-3.5 px-4 font-mono-num text-slate-700 whitespace-nowrap">
                    {rec.time_out || '-'}
                  </td>
                  <td className="py-3.5 px-4 font-mono-num text-slate-700 whitespace-nowrap">
                    {rec.work_hours}
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <StatusLabel status={rec.status} />
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <div className="inline-flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setViewing(rec)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-[#0B5537] hover:bg-emerald-50 cursor-pointer"
                        aria-label={`View details for ${rec.employee_name}`}
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      {canWriteAttendance && (
                        <button
                          type="button"
                          onClick={() => setDeleting(rec)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                          aria-label={`Delete attendance record for ${rec.employee_name}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
        <span className="font-semibold font-mono-num">
          Showing {startIdx} – {endIdx} of {total}
        </span>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            disabled={page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="p-1.5 rounded-lg border border-slate-200 bg-white disabled:opacity-40 cursor-pointer"
            aria-label="Previous attendance page"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="min-w-[30px] h-7 px-2 rounded-lg bg-[#07442B] text-white font-bold font-mono-num flex items-center justify-center">
            {page}
          </span>
          <button
            type="button"
            disabled={page >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            className="p-1.5 rounded-lg border border-slate-200 bg-white disabled:opacity-40 cursor-pointer"
            aria-label="Next attendance page"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Record Detail Modal with Immutable Punch History */}
      <Modal
        open={Boolean(viewing)}
        onClose={() => setViewing(null)}
        title="Attendance Record Details"
        subtitle={viewing ? `${viewing.employee_code} · Shift Date ${formatDisplayDate(viewing.date)} (Asia/Manila)` : undefined}
        maxWidth="max-w-2xl"
      >
        {viewing && (
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200/80">
              <div>
                <p className="text-slate-400">Employee</p>
                <p className="font-bold text-slate-900 mt-0.5">{viewing.employee_name}</p>
              </div>
              <div>
                <p className="text-slate-400">Department</p>
                <p className="font-semibold text-slate-800 mt-0.5">{viewing.department_name}</p>
              </div>
              <div>
                <p className="text-slate-400">Status</p>
                <div className="mt-1">
                  <StatusLabel status={viewing.status} />
                </div>
              </div>
              <div>
                <p className="text-slate-400">Time In</p>
                <p className="font-mono-num font-semibold text-slate-800 mt-0.5">
                  {viewing.time_in || '—'}
                </p>
              </div>
              <div>
                <p className="text-slate-400">Time Out</p>
                <p className="font-mono-num font-semibold text-slate-800 mt-0.5">
                  {viewing.time_out || '—'}
                </p>
              </div>
              <div>
                <p className="text-slate-400">Computed Work Hours</p>
                <p className="font-mono-num font-bold text-[#0B5537] mt-0.5">{viewing.work_hours}</p>
              </div>
              <div>
                <p className="text-slate-400">Break Out / In</p>
                <p className="font-mono-num text-slate-700 mt-0.5">
                  {viewing.break_out || '—'} / {viewing.break_in || '—'}
                </p>
              </div>
              <div>
                <p className="text-slate-400">Overtime Out</p>
                <p className="font-mono-num text-slate-700 mt-0.5">{viewing.overtime_out || '—'}</p>
              </div>
              <div>
                <p className="text-slate-400">Late / Undertime / OT</p>
                <p className="font-mono-num text-slate-700 mt-0.5">
                  {viewing.late_minutes ?? 0}m / {viewing.undertime_minutes ?? 0}m / {viewing.overtime_minutes ?? 0}m
                </p>
              </div>
              <div>
                <p className="text-slate-400">Capture Source</p>
                <p className="font-medium text-slate-700 mt-0.5">{viewing.device_name}</p>
              </div>
              <div className="col-span-2">
                <p className="text-slate-400">Remarks</p>
                <p className="font-medium text-slate-700 mt-0.5">{viewing.remarks || '—'}</p>
              </div>
            </div>

            <div>
              <h3 className="font-bold text-[#07442B] mb-2">Immutable Punch &amp; Audit Event Trail</h3>
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left border-collapse text-[11px]">
                  <thead>
                    <tr className="bg-[#F4F8F6] border-b border-slate-200 text-slate-700 font-bold">
                      <th className="py-2 px-3">Manila Timestamp</th>
                      <th className="py-2 px-3">Action</th>
                      <th className="py-2 px-3">Decision</th>
                      <th className="py-2 px-3">Source / Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {eventsLoading ? (
                      <tr>
                        <td colSpan={4} className="py-5 text-center text-slate-400">
                          Loading immutable punch events...
                        </td>
                      </tr>
                    ) : viewingEvents.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-5 text-center text-slate-400">
                          No punch events logged for this shift date.
                        </td>
                      </tr>
                    ) : (
                      viewingEvents.map((ev) => (
                        <tr key={ev.id} className="hover:bg-emerald-50/30">
                          <td className="py-2 px-3 font-mono-num text-slate-700 whitespace-nowrap">
                            {ev.manila_timestamp || ev.created_at}
                          </td>
                          <td className="py-2 px-3 font-mono-num font-bold text-slate-800 whitespace-nowrap">
                            {ev.punch_type}
                            {ev.offline_replay === 1 && (
                              <span className="ml-1.5 px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 text-[10px] font-semibold">
                                OFFLINE
                              </span>
                            )}
                          </td>
                          <td className="py-2 px-3 whitespace-nowrap">
                            <StatusLabel status={ev.decision} />
                          </td>
                          <td className="py-2 px-3 text-slate-600">
                            <div className="font-medium text-slate-800">
                              {ev.device_name || ev.source}
                              {ev.clock_drift_seconds !== null && (
                                <span className="ml-1.5 font-mono-num text-[10px] text-slate-400">
                                  (drift: {ev.clock_drift_seconds}s)
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-slate-500">
                              {ev.decision_code}
                              {ev.decision_reason ? ` — ${ev.decision_reason}` : ''}
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Log Attendance Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Record / Update Attendance"
        subtitle="Creates or updates an employee's daily attendance log with duplicate-date protection."
      >
        <form onSubmit={handleSave} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Employee *</label>
              <select
                required
                value={form.employee_id}
                onChange={(e) => setForm({ ...form, employee_id: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white focus:outline-none focus:border-[#0B5537]"
              >
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.employee_code} — {emp.full_name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Shift Date (Asia/Manila) *</label>
              <input
                type="date"
                required
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num focus:outline-none focus:border-[#0B5537]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Status</label>
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value as AttendanceStatus })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white focus:outline-none focus:border-[#0B5537]"
              >
                {ATTENDANCE_STATUSES.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Time In</label>
              <input
                type="text"
                placeholder="08:00 AM"
                disabled={['Absent', 'On Leave', 'No Schedule', 'Missing Time In'].includes(form.status)}
                value={form.time_in}
                onChange={(e) => setForm({ ...form, time_in: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num disabled:bg-slate-100 focus:outline-none focus:border-[#0B5537]"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Time Out</label>
              <input
                type="text"
                placeholder="05:00 PM"
                disabled={['Absent', 'On Leave', 'No Schedule', 'Missing Time Out'].includes(form.status)}
                value={form.time_out}
                onChange={(e) => setForm({ ...form, time_out: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num disabled:bg-slate-100 focus:outline-none focus:border-[#0B5537]"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Remarks</label>
            <input
              type="text"
              placeholder="Optional note or shift observation"
              value={form.remarks}
              onChange={(e) => setForm({ ...form, remarks: e.target.value })}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-[#0B5537]"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold disabled:opacity-60 cursor-pointer"
            >
              {saving ? 'Saving...' : 'Save Attendance'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmModal
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={confirmDelete}
        title="Delete Attendance Record?"
        message={
          deleting
            ? `Delete attendance log for ${deleting.employee_name} on ${formatDisplayDate(deleting.date)}?`
            : ''
        }
        confirmLabel="Delete Record"
        destructive
      />
    </ModuleFrame>
  );
};
