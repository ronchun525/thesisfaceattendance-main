import React, { useState } from 'react';

export const SAVAGE_LOGO_URL = '/assets/aistudio/SAVAGE-RSUCAJ_Smart_Attendance_Emblem_39488c28.png';

interface SavageLogoProps {
  size?: number;
  variant?: 'light' | 'dark';
  className?: string;
}

export const SavageLogo: React.FC<SavageLogoProps> = ({
  size = 64,
  variant = 'light',
  className = '',
}) => {
  const [imgFailed, setImgFailed] = useState(false);

  if (imgFailed) {
    return (
      <div
        style={{ width: size, height: size }}
        className={`rounded-xl bg-[#0B4D32] text-white font-display font-extrabold flex items-center justify-center text-xs tracking-tight border border-amber-400/50 ${className}`}
        aria-label="SAVAGE-RSUCAJ Official Emblem"
      >
        RSU
      </div>
    );
  }

  if (variant === 'dark') {
    return (
      <div
        style={{ width: size, height: size }}
        className={`rounded-2xl bg-white p-1.5 shadow-md shadow-black/25 ring-2 ring-[#F2B705]/45 flex items-center justify-center overflow-hidden shrink-0 ${className}`}
      >
        <img
          src={SAVAGE_LOGO_URL}
          alt="SAVAGE-RSUCAJ Smart Attendance System Official Emblem"
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className="w-full h-full object-contain select-none"
        />
      </div>
    );
  }

  return (
    <img
      src={SAVAGE_LOGO_URL}
      alt="SAVAGE-RSUCAJ Smart Attendance System Official Emblem"
      referrerPolicy="no-referrer"
      onError={() => setImgFailed(true)}
      style={{ width: size, height: size }}
      className={`object-contain mix-blend-multiply select-none shrink-0 ${className}`}
    />
  );
};
