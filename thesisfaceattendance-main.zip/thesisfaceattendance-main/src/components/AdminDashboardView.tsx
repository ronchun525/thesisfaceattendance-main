import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  Users,
  CheckCircle2,
  Clock,
  XCircle,
  CalendarOff,
  MonitorSmartphone,
  ArrowRight,
  Bell,
  CheckCheck,
  Trash2,
  Cpu,
  Smartphone,
  ChevronLeft,
  ChevronRight,
  Check,
  Square,
  CheckSquare,
  RadioTower,
  RefreshCw,
} from 'lucide-react';
import { apiFetch, formatDisplayDate } from '../lib/api';
import { useRealtimeStream } from '../lib/realtime';
import type { RealtimeConnectionStatus, RealtimeFrame } from '../lib/realtime';
import { ConfirmModal, RsuBottomWave, StatusLabel } from './ModuleFrame';
import type { AppNotification, AuthUser, DashboardSummary, NavModule } from '../types';

interface AdminDashboardViewProps {
  currentUser?: AuthUser;
  onNavigate: (module: NavModule) => void;
  onUnreadCountChange: (count: number) => void;
}

function getInitials(name: string): string {
  const parts = name.replace(/,/g, '').split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  currentUser,
  onNavigate,
  onUnreadCountChange,
}) => {
  const perms = currentUser?.permissions || [];
  const canWriteNotifications = !currentUser || perms.includes('notifications:write');
  const canApproveCorrections = !currentUser || perms.includes('corrections:approve');
  const canApproveLeaves = !currentUser || perms.includes('leaves:approve');
  const [range, setRange] = useState<'week' | 'lastWeek'>('week');
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [notifCounts, setNotifCounts] = useState({
    all: 0,
    unread: 0,
    attendance: 0,
    device: 0,
    system: 0,
  });
  const [notifFilter, setNotifFilter] = useState<string>('All');
  const [notifPage, setNotifPage] = useState(1);
  const [selectedNotifs, setSelectedNotifs] = useState<number[]>([]);
  const [clearConfirmOpen, setClearConfirmOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notifError, setNotifError] = useState<string | null>(null);
  const [hoveredDay, setHoveredDay] = useState<number | null>(null);
  const [liveStatus, setLiveStatus] = useState<RealtimeConnectionStatus>('connecting');
  const [lastRefreshUtc, setLastRefreshUtc] = useState<string | null>(null);
  const [liveActivity, setLiveActivity] = useState<RealtimeFrame[]>([]);

  const loadDashboard = useCallback(async () => {
    setError(null);
    try {
      const [dash, notifs] = await Promise.all([
        apiFetch<DashboardSummary>(`/api/dashboard?range=${range}`),
        apiFetch<{
          data: AppNotification[];
          counts: { all: number; unread: number; attendance: number; device: number; system: number };
        }>(`/api/notifications?filter=${encodeURIComponent(notifFilter)}`),
      ]);
      setSummary(dash);
      setLastRefreshUtc(new Date().toISOString());
      setNotifications(notifs.data);
      setNotifCounts(notifs.counts);
      onUnreadCountChange(notifs.counts.unread);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load dashboard data.');
    } finally {
      setLoading(false);
    }
  }, [range, notifFilter, onUnreadCountChange]);

  useEffect(() => {
    void loadDashboard();
  }, [loadDashboard]);

  // BUILD 25: coalesce event bursts into one real backend refresh. Does not hide
  // events or fabricate rows; manual refresh and initial fetch stay immediate.
  const latestDashboardLoader = useRef(loadDashboard);
  latestDashboardLoader.current = loadDashboard;
  const realtimeRefreshTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scheduleRealtimeRefresh = useCallback(() => {
    if (realtimeRefreshTimer.current !== null) return;
    realtimeRefreshTimer.current = setTimeout(() => {
      realtimeRefreshTimer.current = null;
      void latestDashboardLoader.current();
    }, 150);
  }, []);
  useEffect(() => () => {
    if (realtimeRefreshTimer.current !== null) clearTimeout(realtimeRefreshTimer.current);
  }, []);

  // BUILD 10: Authenticated SSE live updates with automatic reconnect resync & polling fallback
  useRealtimeStream({
    channels: ['attendance:updated', 'device:telemetry', 'notification:created'],
    onEvent: (frame) => {
      if (frame.type === 'attendance:updated' || frame.type === 'device:telemetry') {
        setLiveActivity((prev) => [frame, ...prev].slice(0, 6));
      }
      scheduleRealtimeRefresh();
    },
    onResync: scheduleRealtimeRefresh,
    onStatusChange: setLiveStatus,
  });

  const handleMarkAsRead = async () => {
    setNotifError(null);
    try {
      await apiFetch('/api/notifications/mark-all-read', {
        method: 'POST',
        body: JSON.stringify(selectedNotifs.length > 0 ? { ids: selectedNotifs } : {}),
      });
      setSelectedNotifs([]);
      loadDashboard();
    } catch (err) {
      setNotifError(err instanceof Error ? err.message : 'Unable to mark notifications as read.');
    }
  };

  const handleClearAllNotifs = async () => {
    setNotifError(null);
    try {
      await apiFetch('/api/notifications', { method: 'DELETE' });
      setClearConfirmOpen(false);
      setSelectedNotifs([]);
      loadDashboard();
    } catch (err) {
      setClearConfirmOpen(false);
      setNotifError(err instanceof Error ? err.message : 'Unable to clear notifications.');
    }
  };

  const handleDismissNotif = async (id: number) => {
    setNotifError(null);
    try {
      await apiFetch(`/api/notifications/${id}`, { method: 'DELETE' });
      setSelectedNotifs((prev) => prev.filter((x) => x !== id));
      loadDashboard();
    } catch (err) {
      setNotifError(err instanceof Error ? err.message : 'Unable to dismiss notification.');
    }
  };

  const handleQuickApprove = async (n: AppNotification) => {
    setNotifError(null);
    if (!n.action_entity_id) {
      if (n.action_module) onNavigate(n.action_module);
      return;
    }
    try {
      if (n.action_module === 'corrections') {
        await apiFetch(`/api/corrections/${n.action_entity_id}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ status: 'Approved' }),
        });
      } else if (n.action_module === 'leaves') {
        await apiFetch(`/api/leaves/${n.action_entity_id}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ status: 'Approved' }),
        });
      }
      if (canWriteNotifications) {
        await apiFetch(`/api/notifications/${n.id}/read`, { method: 'PATCH' });
      }
      loadDashboard();
    } catch (err) {
      setNotifError(err instanceof Error ? err.message : 'Quick approval failed.');
      if (n.action_module) onNavigate(n.action_module);
    }
  };

  const handleViewNotif = async (n: AppNotification) => {
    setNotifError(null);
    try {
      if (!n.is_read && canWriteNotifications) {
        await apiFetch(`/api/notifications/${n.id}/read`, { method: 'PATCH' });
      }
      if (n.action_module) {
        onNavigate(n.action_module);
      } else {
        loadDashboard();
      }
    } catch (err) {
      setNotifError(err instanceof Error ? err.message : 'Unable to open notification.');
    }
  };

  const toggleSelectNotif = (id: number) => {
    setSelectedNotifs((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  if (error && !summary) {
    return (
      <div className="bg-white rounded-2xl border border-red-200 p-6 max-w-lg mx-auto mt-8 text-center shadow-sm">
        <p className="text-sm font-bold text-red-700">Unable to load Admin Dashboard</p>
        <p className="text-xs text-slate-600 mt-1.5">{error}</p>
        <button
          type="button"
          onClick={() => {
            setLoading(true);
            loadDashboard();
          }}
          className="mt-4 btn-rsu-primary px-4 py-2 rounded-lg text-xs font-bold cursor-pointer"
        >
          Retry
        </button>
      </div>
    );
  }

  if (loading || !summary) {
    return (
      <div className="space-y-5 animate-pulse">
        <div className="h-12 bg-emerald-900/10 rounded-xl w-72" />
        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3.5">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-28 bg-emerald-900/10 rounded-2xl" />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-5 h-72 bg-emerald-900/10 rounded-2xl" />
          <div className="lg:col-span-7 h-72 bg-emerald-900/10 rounded-2xl" />
        </div>
      </div>
    );
  }

  const { kpis, weeklyTrend, devices, recentAttendance } = summary;
  const pct = (v: number) =>
    kpis.totalEmployees > 0 ? `${((v / kpis.totalEmployees) * 100).toFixed(1)}%` : '0.0%';

  // Donut Chart geometry
  const radius = 48;
  const circ = 2 * Math.PI * radius;
  const totalDonut = Math.max(1, kpis.totalEmployees);
  const segPresent = (kpis.present / totalDonut) * circ;
  const segLate = (kpis.late / totalDonut) * circ;
  const segAbsent = (kpis.absent / totalDonut) * circ;
  const segLeave = (kpis.onLeave / totalDonut) * circ;
  const segOthers = Math.max(0, circ - (segPresent + segLate + segAbsent + segLeave));

  // Weekly chart dynamic Y-axis
  const rawMax = Math.max(5, kpis.totalEmployees, ...weeklyTrend.map((d) => d.total));
  const stepSize = Math.max(1, Math.ceil(rawMax / 4));
  const chartCeiling = stepSize * 4;
  const yTicks = [chartCeiling, stepSize * 3, stepSize * 2, stepSize, 0];

  // Notifications pagination (6 per page matching 03_Notifications.png)
  const pageSize = 6;
  const totalNotifPages = Math.max(1, Math.ceil(notifications.length / pageSize));
  const safePage = Math.min(notifPage, totalNotifPages);
  const visibleNotifs = notifications.slice((safePage - 1) * pageSize, safePage * pageSize);

  const kpiCards = [
    {
      label: 'Employees',
      value: kpis.totalEmployees,
      sub: 'Total Registered',
      bg: 'from-[#0E9F8E] via-[#0B877A] to-[#086960]',
      icon: Users,
      target: 'employees' as NavModule,
    },
    {
      label: 'Present',
      value: kpis.present,
      sub: `(${pct(kpis.present)})`,
      bg: 'from-[#1DC45B] via-[#13A449] to-[#0B7C35]',
      icon: CheckCircle2,
      target: 'attendance' as NavModule,
    },
    {
      label: 'Late',
      value: kpis.late,
      sub: `(${pct(kpis.late)})`,
      bg: 'from-[#FACC15] via-[#F59E0B] to-[#D97706]',
      icon: Clock,
      target: 'attendance' as NavModule,
    },
    {
      label: 'Absent',
      value: kpis.absent,
      sub: `(${pct(kpis.absent)})`,
      bg: 'from-[#F87171] via-[#EF4444] to-[#DC2626]',
      icon: XCircle,
      target: 'attendance' as NavModule,
    },
    {
      label: 'On Leave',
      value: kpis.onLeave,
      sub: `(${pct(kpis.onLeave)})`,
      bg: 'from-[#3B82F6] via-[#2563EB] to-[#1D4ED8]',
      icon: CalendarOff,
      target: 'leaves' as NavModule,
    },
    {
      label: 'Active Devices',
      value: `${kpis.onlineDevices}/${kpis.totalDevices}`,
      sub: kpis.onlineDevices === kpis.totalDevices ? 'Online' : 'Attention',
      bg: 'from-[#8B5CF6] via-[#7C3AED] to-[#5B21B6]',
      icon: MonitorSmartphone,
      target: 'devices' as NavModule,
    },
  ];

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 2xl:grid-cols-12 gap-5 items-start">
        {/* Left/Center Main Admin Dashboard Canvas (matching 02_Admin_Dashboard.png) */}
        <div className="2xl:col-span-8 space-y-5">
          {/* Header Title */}
          <div className="flex flex-wrap items-end justify-between gap-2">
            <div>
              <h1 className="font-display text-2xl sm:text-[28px] font-extrabold text-[#062E1E] tracking-tight leading-tight">
                Admin Dashboard
              </h1>
              <p className="text-sm text-slate-600 mt-0.5">
                System overview, attendance, devices, and quick actions
              </p>
            </div>
            <span className="text-xs font-semibold text-[#0B5537] bg-white/80 border border-emerald-900/10 rounded-full px-3 py-1 font-mono-num">
              {formatDisplayDate(summary.date)}
            </span>
          </div>

          {/* BUILD 24 — Live server data. Nothing here is simulated. */}
          <section aria-label="Live attendance and device updates" className="rounded-2xl border border-emerald-950/10 bg-white px-4 py-3 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <RadioTower aria-hidden="true" className="w-4 h-4 text-[#0B5537]" />
                <span className="text-xs font-extrabold text-[#07442B]">Realtime Data Display</span>
                <span aria-live="polite" className={`text-[11px] rounded-full px-2 py-0.5 font-bold ${
                  liveStatus === 'live' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                }`}>
                  {liveStatus === 'live' ? 'Live SSE' : liveStatus === 'polling' ? 'Polling fallback' : liveStatus === 'reconnecting' ? 'Reconnecting' : 'Connecting'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-500" title={lastRefreshUtc ?? undefined}>
                  {lastRefreshUtc ? `Last synced ${new Date(lastRefreshUtc).toLocaleTimeString('en-PH', { timeZone: 'Asia/Manila' })}` : 'Awaiting server sync'}
                </span>
                <button type="button" onClick={() => void loadDashboard()} aria-label="Refresh dashboard data" title="Refresh from backend"
                  className="rounded-lg border border-emerald-900/15 p-1.5 text-[#0B5537] hover:bg-emerald-50">
                  <RefreshCw aria-hidden="true" className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            {liveActivity.length > 0 ? (
              <ul aria-label="Recent server events" className="mt-2 space-y-1 text-[11px] text-slate-700">
                {liveActivity.slice(0, 3).map((frame, i) => (
                  <li key={`${frame.seq}-${i}`} className="flex flex-wrap gap-2 border-t border-slate-100 pt-1.5">
                    <span className="font-semibold text-[#0B5537]">{frame.type === 'attendance:updated' ? 'Attendance' : 'Device'}</span>
                    <span>{frame.type === 'attendance:updated'
                      ? `${String(frame.data.employee_code ?? 'Employee')} · ${String(frame.data.action ?? 'Updated')} · ${String(frame.data.status ?? 'Recorded')}`
                      : `${String(frame.data.name ?? 'Kiosk')} · ${String(frame.data.connectivity ?? 'Updated')}`}</span>
                    <span className="ml-auto text-slate-400">{new Date(frame.server_emitted_utc).toLocaleTimeString('en-PH', {timeZone:'Asia/Manila'})}</span>
                  </li>
                ))}
              </ul>
            ) : <p className="mt-2 text-[11px] text-slate-500">Listening for authorized kiosk events. The KPIs and attendance list are loaded from the backend.</p>}
          </section>

          {/* 6 Glossy Gradient KPI Cards matching 02_Admin_Dashboard.png */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {kpiCards.map((card) => {
              const Icon = card.icon;
              return (
                <button
                  key={card.label}
                  type="button"
                  onClick={() => onNavigate(card.target)}
                  className={`relative overflow-hidden bg-gradient-to-b ${card.bg} text-white rounded-2xl p-3.5 text-center shadow-md shadow-slate-900/10 hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col items-center justify-center`}
                >
                  <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center mb-1.5 ring-1 ring-white/25">
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-xs font-semibold text-white/95 whitespace-nowrap">
                    {card.label}
                  </span>
                  <span className="font-display text-[26px] font-extrabold leading-tight mt-0.5 tabular-nums drop-shadow-xs">
                    {card.value}
                  </span>
                  <span className="text-[11px] font-medium text-white/90 mt-0.5 whitespace-nowrap">
                    {card.sub}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Middle Row: Today's Attendance Donut + Attendance Trend Bar Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Today's Attendance Card */}
            <div className="lg:col-span-5 bg-white rounded-2xl border border-emerald-950/8 p-5 shadow-md shadow-emerald-950/5 flex flex-col justify-between">
              <div>
                <h2 className="font-display text-base font-extrabold text-slate-900">
                  Today&apos;s Attendance
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">{formatDisplayDate(summary.date)}</p>
              </div>

              <div className="mt-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="relative w-36 h-36 shrink-0">
                  <svg viewBox="0 0 120 120" className="w-full h-full -rotate-90" role="img" aria-label={`Today's attendance rate ${kpis.attendanceRate.toFixed(1)} percent`}>
                    <circle cx="60" cy="60" r={radius} fill="none" stroke="#E2E8F0" strokeWidth="15" />
                    <circle
                      cx="60"
                      cy="60"
                      r={radius}
                      fill="none"
                      stroke="#16A34A"
                      strokeWidth="15"
                      strokeDasharray={`${segPresent} ${circ}`}
                      strokeDashoffset={0}
                    />
                    <circle
                      cx="60"
                      cy="60"
                      r={radius}
                      fill="none"
                      stroke="#FACC15"
                      strokeWidth="15"
                      strokeDasharray={`${segLate} ${circ}`}
                      strokeDashoffset={-segPresent}
                    />
                    <circle
                      cx="60"
                      cy="60"
                      r={radius}
                      fill="none"
                      stroke="#EF4444"
                      strokeWidth="15"
                      strokeDasharray={`${segAbsent} ${circ}`}
                      strokeDashoffset={-(segPresent + segLate)}
                    />
                    <circle
                      cx="60"
                      cy="60"
                      r={radius}
                      fill="none"
                      stroke="#2563EB"
                      strokeWidth="15"
                      strokeDasharray={`${segLeave} ${circ}`}
                      strokeDashoffset={-(segPresent + segLate + segAbsent)}
                    />
                    {segOthers > 0.5 && (
                      <circle
                        cx="60"
                        cy="60"
                        r={radius}
                        fill="none"
                        stroke="#94A3B8"
                        strokeWidth="15"
                        strokeDasharray={`${segOthers} ${circ}`}
                        strokeDashoffset={-(segPresent + segLate + segAbsent + segLeave)}
                      />
                    )}
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                    <span className="font-display text-xl font-extrabold text-slate-900 tabular-nums">
                      {kpis.attendanceRate.toFixed(1)}%
                    </span>
                    <span className="text-[11px] font-semibold text-slate-500 font-mono-num">
                      {kpis.present + kpis.late} / {kpis.totalEmployees}
                    </span>
                  </div>
                </div>

                <div className="w-full sm:flex-1 space-y-2 text-xs">
                  {[
                    { label: 'Present', value: kpis.present, color: 'bg-[#16A34A]' },
                    { label: 'Late', value: kpis.late, color: 'bg-[#FACC15]' },
                    { label: 'Absent', value: kpis.absent, color: 'bg-[#EF4444]' },
                    { label: 'On Leave', value: kpis.onLeave, color: 'bg-[#2563EB]' },
                    { label: 'Others', value: kpis.others, color: 'bg-slate-400' },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-slate-700 font-medium">
                        <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${item.color}`} />
                        <span>{item.label}</span>
                      </div>
                      <span className="font-bold text-slate-900 font-mono-num">{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Attendance Trend (This Week) Bar Chart */}
            <div className="lg:col-span-7 bg-white rounded-2xl border border-emerald-950/8 p-5 shadow-md shadow-emerald-950/5 flex flex-col justify-between">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h2 className="font-display text-base font-extrabold text-slate-900">
                    Attendance Trend{' '}
                    <span className="font-semibold text-slate-500">
                      ({range === 'week' ? 'This Week' : 'Last Week'})
                    </span>
                  </h2>
                </div>
                <select
                  aria-label="Attendance trend timeframe"
                  value={range}
                  onChange={(e) => setRange(e.target.value as 'week' | 'lastWeek')}
                  className="text-xs font-semibold text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#0B5537] cursor-pointer"
                >
                  <option value="week">This Week</option>
                  <option value="lastWeek">Last Week</option>
                </select>
              </div>

              <div className="mt-4 flex gap-3 items-stretch h-48">
                {/* Y-Axis Scale */}
                <div className="flex flex-col justify-between pb-6 text-[10px] font-mono-num text-slate-500 text-right w-7 shrink-0">
                  {yTicks.map((t) => (
                    <span key={t}>{t}</span>
                  ))}
                </div>

                {/* Bars + Gridlines */}
                <div className="flex-1 relative flex items-end gap-2 sm:gap-3 pb-6 border-b border-slate-100">
                  {/* Horizontal subtle gridlines */}
                  <div className="pointer-events-none absolute inset-x-0 top-0 bottom-6 flex flex-col justify-between">
                    {yTicks.map((t) => (
                      <div key={t} className="w-full border-t border-slate-100" />
                    ))}
                  </div>

                  {weeklyTrend.map((bar, idx) => {
                    const heightPct = Math.max(8, Math.round((bar.total / chartCeiling) * 100));
                    const isHighlighted = bar.isToday || hoveredDay === idx;
                    return (
                      <div
                        key={bar.date}
                        onMouseEnter={() => setHoveredDay(idx)}
                        onMouseLeave={() => setHoveredDay(null)}
                        className="relative z-10 flex-1 flex flex-col items-center justify-end h-full group"
                      >
                        {hoveredDay === idx && (
                          <div className="absolute -top-7 z-20 bg-[#053522] text-white text-[10px] font-mono-num px-2 py-1 rounded-md shadow whitespace-nowrap">
                            {bar.total} present/late ({bar.absent} absent)
                          </div>
                        )}
                        <div className="w-full max-w-[38px] flex-1 flex items-end">
                          <div
                            style={{ height: `${heightPct}%` }}
                            className={`w-full rounded-t-lg transition-all duration-200 ${
                              isHighlighted
                                ? 'bg-gradient-to-t from-[#0D8A3E] to-[#1CC15C] shadow-sm shadow-emerald-600/25'
                                : 'bg-[#A7F3C0] group-hover:bg-[#52D883]'
                            }`}
                          />
                        </div>
                        <span
                          className={`absolute -bottom-5 text-[11px] font-semibold ${
                            bar.isToday ? 'text-[#07442B] font-extrabold' : 'text-slate-500'
                          }`}
                        >
                          {bar.day}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Row: Device Status + Recent Attendance */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Device Status */}
            <div className="lg:col-span-5 bg-white rounded-2xl border border-emerald-950/8 p-5 shadow-md shadow-emerald-950/5">
              <div className="flex items-center justify-between mb-3.5">
                <h2 className="font-display text-base font-extrabold text-slate-900">
                  Device Status
                </h2>
                <button
                  type="button"
                  onClick={() => onNavigate('devices')}
                  className="text-xs font-semibold text-[#0B5537] hover:underline cursor-pointer"
                >
                  Manage
                </button>
              </div>
              <div className="space-y-3">
                {devices.length === 0 ? (
                  <div className="py-6 px-4 rounded-xl bg-slate-50/90 border border-dashed border-slate-200 text-center">
                    <p className="text-xs font-semibold text-slate-500">
                      No kiosk devices registered yet.
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Register a Raspberry Pi or Android kiosk terminal in Devices (Kiosk).
                    </p>
                  </div>
                ) : (
                  devices.map((dev) => {
                    const liveState = dev.connectivity || dev.status;
                    const isHealthy = liveState === 'Online';
                    const isStale = liveState === 'Stale' || dev.stale_warning;
                    const queueCount = dev.pending_queue_count ?? 0;
                    const driftSec = dev.last_clock_drift_seconds;
                    return (
                      <div
                        key={dev.id}
                        className="flex items-center justify-between gap-3 p-3 rounded-xl bg-slate-50/90 border border-slate-100"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                              isHealthy
                                ? 'bg-emerald-100 text-[#16A34A]'
                                : liveState === 'Stale'
                                  ? 'bg-amber-100 text-amber-700'
                                  : 'bg-red-100 text-red-600'
                            }`}
                          >
                            {dev.device_type === 'Android' ? (
                              <Smartphone className="w-4 h-4" />
                            ) : (
                              <Cpu className="w-4 h-4" />
                            )}
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-slate-900 truncate">{dev.name}</p>
                            <p className="text-[11px] text-slate-500 font-mono-num truncate">
                              {dev.model_info} - {dev.ip_address}
                            </p>
                            <p className="text-[10px] text-slate-500 font-mono-num truncate mt-0.5">
                              Seen: {dev.last_heartbeat || 'Never'}
                              {queueCount > 0 ? ` · Queue: ${queueCount}` : ''}
                              {driftSec !== null && driftSec !== undefined && Math.abs(driftSec) >= 5
                                ? ` · Drift: ${driftSec > 0 ? '+' : ''}${driftSec}s`
                                : ''}
                              {isStale && liveState !== 'Offline' ? ' · Stale' : ''}
                            </p>
                          </div>
                        </div>
                        <StatusLabel status={liveState} showDot />
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Recent Attendance */}
            <div className="lg:col-span-7 bg-white rounded-2xl border border-emerald-950/8 p-5 shadow-md shadow-emerald-950/5">
              <div className="flex items-center justify-between mb-3.5">
                <h2 className="font-display text-base font-extrabold text-slate-900">
                  Recent Attendance
                </h2>
                <button
                  type="button"
                  onClick={() => onNavigate('attendance')}
                  className="inline-flex items-center gap-1 text-xs font-bold text-[#1D4ED8] hover:text-[#1E40AF] cursor-pointer"
                >
                  <span>View All</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-500">
                      <th className="pb-2 pr-3">Time</th>
                      <th className="pb-2 pr-3">Employee</th>
                      <th className="pb-2 pr-3">Department</th>
                      <th className="pb-2 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {recentAttendance.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-6 text-center text-slate-400">
                          No check-ins recorded today yet.
                        </td>
                      </tr>
                    ) : (
                      recentAttendance.map((rec) => (
                        <tr key={rec.id} className="hover:bg-emerald-50/40 transition-colors">
                          <td className="py-2.5 pr-3 font-mono-num text-slate-600 whitespace-nowrap">
                            {rec.time_in || '-'}
                          </td>
                          <td className="py-2.5 pr-3 whitespace-nowrap">
                            <div className="flex items-center gap-2">
                              <span className="w-6 h-6 rounded-full bg-emerald-100 text-[#0B5537] text-[10px] font-extrabold flex items-center justify-center shrink-0">
                                {getInitials(rec.employee_name)}
                              </span>
                              <span className="font-semibold text-slate-900">
                                {rec.employee_name}
                              </span>
                            </div>
                          </td>
                          <td className="py-2.5 pr-3 text-slate-600 whitespace-nowrap">
                            {rec.department_code}
                          </td>
                          <td className="py-2.5 text-right">
                            <StatusLabel status={rec.status === 'Present' ? 'Time In' : rec.status} />
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Notifications Panel matching 02_Admin_Dashboard.png & 03_Notifications.png */}
        <aside aria-label="Notifications panel" className="2xl:col-span-4 bg-white rounded-2xl border border-emerald-950/10 shadow-lg shadow-emerald-950/8 overflow-hidden flex flex-col">
          {/* Deep Emerald Notifications Header */}
          <div className="bg-gradient-to-r from-[#053522] via-[#0A5337] to-[#0D6E48] px-4 pt-3.5 pb-5 text-white flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#20C562] to-[#0B783D] border border-emerald-200/35 flex items-center justify-center shrink-0">
                <Bell className="w-4 h-4 text-white" />
              </div>
              <h2 className="font-display text-sm font-extrabold truncate">Notifications</h2>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                disabled={!canWriteNotifications}
                onClick={handleMarkAsRead}
                title={
                  canWriteNotifications
                    ? 'Mark selected or all scoped notifications as read'
                    : 'Read-only access: your role cannot modify notifications'
                }
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white text-[#0B5537] hover:bg-emerald-50 text-[11px] font-bold shadow-xs transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <CheckCheck className="w-3 h-3 text-[#16A34A]" />
                <span>Mark as Read</span>
              </button>
              <button
                type="button"
                disabled={!canWriteNotifications}
                onClick={() => setClearConfirmOpen(true)}
                title={
                  canWriteNotifications
                    ? 'Clear all notifications visible to your role'
                    : 'Read-only access: your role cannot clear notifications'
                }
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white border border-red-300 text-red-600 hover:bg-red-50 text-[11px] font-bold shadow-xs transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Trash2 className="w-3 h-3" />
                <span>Clear All</span>
              </button>
            </div>
          </div>

          {/* White Rounded Shoulder + Filter Tabs */}
          <div className="-mt-2.5 rounded-t-2xl bg-white px-3 pt-3 pb-2.5 border-b border-slate-100 flex flex-wrap items-center gap-1.5">
            {[
              { id: 'All', label: `All (${notifCounts.all})` },
              { id: 'Unread', label: `Unread (${notifCounts.unread})`, redDot: notifCounts.unread > 0 },
              { id: 'Attendance Alerts', label: `Attendance (${notifCounts.attendance})` },
              { id: 'Device Alerts', label: `Devices (${notifCounts.device})` },
              { id: 'System Notices', label: `System (${notifCounts.system})` },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setNotifFilter(tab.id);
                  setNotifPage(1);
                }}
                className={`relative px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all whitespace-nowrap cursor-pointer border ${
                  notifFilter === tab.id
                    ? 'btn-rsu-primary border-transparent'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {tab.label}
                {tab.redDot && notifFilter !== tab.id && (
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-red-500" />
                )}
              </button>
            ))}
          </div>

          {/* Notification Rows matching 03_Notifications.png */}
          <div className="divide-y divide-slate-100 flex-1">
            {notifError && (
              <div className="m-3 px-3 py-2 rounded-lg bg-red-50 border border-red-200 text-red-700 text-[11px] font-medium">
                {notifError}
              </div>
            )}
            {visibleNotifs.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                No notifications matching this filter.
              </div>
            ) : (
              visibleNotifs.map((n) => {
                const isSelected = selectedNotifs.includes(n.id);
                const canQuickApprove =
                  Boolean(n.action_entity_id) &&
                  !n.is_read &&
                  ((n.action_module === 'corrections' && canApproveCorrections) ||
                    (n.action_module === 'leaves' && canApproveLeaves));

                return (
                  <div
                    key={n.id}
                    className={`p-3.5 transition-colors ${
                      n.is_read ? 'bg-white' : 'bg-emerald-50/35'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <button
                        type="button"
                        disabled={!canWriteNotifications}
                        onClick={() => toggleSelectNotif(n.id)}
                        className="mt-0.5 text-slate-400 hover:text-[#0B5537] cursor-pointer shrink-0 disabled:opacity-40 disabled:cursor-not-allowed"
                        aria-label={`Select notification ${n.title}`}
                        title={
                          canWriteNotifications
                            ? 'Select notification for bulk action'
                            : 'Read-only access: bulk actions disabled'
                        }
                      >
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-[#16A34A]" />
                        ) : (
                          <Square className="w-4 h-4" />
                        )}
                      </button>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-xs font-bold text-slate-900 leading-snug">{n.title}</p>
                        </div>
                        <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed">
                          {n.message}
                        </p>
                        <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5">
                            <StatusLabel status={n.priority} />
                            <span className="text-[10px] text-slate-500 font-mono-num">
                              {n.is_read ? 'Read' : 'Unread'}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            {canQuickApprove && (
                              <button
                                type="button"
                                onClick={() => handleQuickApprove(n)}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md btn-rsu-primary text-[11px] font-semibold cursor-pointer"
                              >
                                <Check className="w-3 h-3" />
                                <span>Approve</span>
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => handleViewNotif(n)}
                              className="px-2.5 py-1 rounded-md border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-[11px] font-semibold transition-colors cursor-pointer"
                            >
                              View
                            </button>
                            <button
                              type="button"
                              disabled={!canWriteNotifications}
                              onClick={() => handleDismissNotif(n.id)}
                              title={
                                canWriteNotifications
                                  ? 'Dismiss notification'
                                  : 'Read-only access: your role cannot dismiss notifications'
                              }
                              className="px-2 py-1 rounded-md border border-slate-200 bg-white hover:bg-red-50 hover:text-red-600 text-slate-500 text-[11px] font-medium transition-colors cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed"
                            >
                              Dismiss
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Pagination Footer */}
          <div className="px-3.5 py-2.5 border-t border-slate-100 bg-slate-50/70 flex items-center justify-between text-[11px] text-slate-500">
            <span className="font-mono-num">
              Showing {visibleNotifs.length > 0 ? (safePage - 1) * pageSize + 1 : 0} –{' '}
              {(safePage - 1) * pageSize + visibleNotifs.length} of {notifications.length} notifications
            </span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                disabled={safePage <= 1}
                onClick={() => setNotifPage((p) => Math.max(1, p - 1))}
                className="p-1 rounded-md border border-slate-200 bg-white disabled:opacity-40 cursor-pointer"
                aria-label="Previous notifications page"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <span className="min-w-[24px] h-6 px-1.5 rounded-md bg-[#0B5537] text-white font-bold font-mono-num flex items-center justify-center">
                {safePage}
              </span>
              <button
                type="button"
                disabled={safePage >= totalNotifPages}
                onClick={() => setNotifPage((p) => Math.min(totalNotifPages, p + 1))}
                className="p-1 rounded-md border border-slate-200 bg-white disabled:opacity-40 cursor-pointer"
                aria-label="Next notifications page"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <RsuBottomWave height={18} />
        </aside>
      </div>

      <ConfirmModal
        open={clearConfirmOpen}
        onClose={() => setClearConfirmOpen(false)}
        onConfirm={handleClearAllNotifs}
        title="Clear All Notifications?"
        message="This will permanently remove all current notifications from the database and record the action in Audit Logs."
        confirmLabel="Clear All"
        destructive
      />
    </div>
  );
};
