import React, { useEffect, useState, useCallback } from 'react';
import {
  Wallet,
  Plus,
  CheckCircle2,
  Send,
  Banknote,
  HandCoins,
  UserMinus,
  Coins,
  FileBarChart2,
  CalendarDays,
  FileSpreadsheet,
  Umbrella,
  Users,
  ShieldCheck,
  Download,
  Printer,
  AlertCircle,
  Eye,
  Filter,
  FileCode2,
  History,
  RefreshCw,
  Stamp,
  Lock,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  FileDown,
  FileCheck2,
  RotateCcw,
} from 'lucide-react';
import { ModuleFrame, Modal, ConfirmModal, StatusLabel } from './ModuleFrame';
import {
  apiFetch,
  downloadAuthenticatedBlob,
  downloadJson,
  formatPeso,
  getManilaTodayIso,
} from '../lib/api';
import type {
  AuthUser,
  Department,
  Employee,
  MonthlyDtrEmployeeReport,
  PayrollAuditEntry,
  PayrollItem,
  PayrollPolicy,
  PayrollPrecheck,
  PayrollRun,
  ReportResponse,
  ReportType,
} from '../types';

interface PayrollViewProps {
  currentUser?: AuthUser | null;
}

export const PayrollView: React.FC<PayrollViewProps> = ({ currentUser }) => {
  const perms = new Set(currentUser?.permissions || []);
  const canReadAll = perms.has('payroll:read');
  const canCompute = perms.has('payroll:compute');
  const canFinalize = perms.has('payroll:finalize');
  const canRelease = perms.has('payroll:release');
  const canManagePolicy = perms.has('payroll:policy_manage');
  const canFinanceSignoff = perms.has('payroll:finance_signoff');
  const isSelfServiceOnly = !canReadAll && perms.has('payroll:read_self');

  const [runs, setRuns] = useState<PayrollRun[]>([]);
  const [activeRunId, setActiveRunId] = useState<number | null>(null);
  const [items, setItems] = useState<PayrollItem[]>([]);
  const [myPayslips, setMyPayslips] = useState<PayrollItem[]>([]);
  const [policies, setPolicies] = useState<PayrollPolicy[]>([]);
  const [activeApprovedPolicy, setActiveApprovedPolicy] = useState<PayrollPolicy | null>(null);
  const [auditEntries, setAuditEntries] = useState<PayrollAuditEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const [computeOpen, setComputeOpen] = useState(false);
  const [policyModalOpen, setPolicyModalOpen] = useState(false);
  const [auditModalOpen, setAuditModalOpen] = useState(false);
  const [signoffModalOpen, setSignoffModalOpen] = useState(false);
  const [confirmStage, setConfirmStage] = useState<'finalize' | 'release' | null>(null);
  const [payslipItem, setPayslipItem] = useState<PayrollItem | null>(null);

  const [precheck, setPrecheck] = useState<PayrollPrecheck | null>(null);
  const [precheckLoading, setPrecheckLoading] = useState(false);

  const [policyApproveId, setPolicyApproveId] = useState<number | null>(null);
  const [policyApproveRef, setPolicyApproveRef] = useState('');
  const [policyApproveNotes, setPolicyApproveNotes] = useState('');
  const [newPolicyForm, setNewPolicyForm] = useState({
    policy_code: '',
    policy_name: '',
    effective_from: new Date().toISOString().slice(0, 10),
    effective_to: '',
    notes: '',
    rulesJson: '',
  });
  const [showCreatePolicy, setShowCreatePolicy] = useState(false);

  const [signoffRef, setSignoffRef] = useState('');
  const [signoffNotes, setSignoffNotes] = useState('');

  const now = new Date();
  const [computeForm, setComputeForm] = useState({
    period_label: `${now.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })} (Cut-off 2)`,
    start_date: new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10),
    end_date: new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().slice(0, 10),
    policy_id: '' as string,
  });
  const [submitting, setSubmitting] = useState(false);

  const loadPayroll = useCallback(
    async (selectedRunId?: number | null) => {
      setLoading(true);
      try {
        if (isSelfServiceOnly) {
          const res = await apiFetch<{ payslips: PayrollItem[] }>('/api/payroll/my-payslips');
          setMyPayslips(res.payslips || []);
          return;
        }
        const qs = selectedRunId ? `?run_id=${selectedRunId}` : '';
        const res = await apiFetch<{
          runs: PayrollRun[];
          activeRunId: number | null;
          items: PayrollItem[];
          policies: PayrollPolicy[];
          activeApprovedPolicy: PayrollPolicy | null;
          audit: PayrollAuditEntry[];
        }>(`/api/payroll${qs}`);
        setRuns(res.runs || []);
        setActiveRunId(res.activeRunId);
        setItems(res.items || []);
        setPolicies(res.policies || []);
        setActiveApprovedPolicy(res.activeApprovedPolicy || null);
        setAuditEntries(res.audit || []);
      } catch (err) {
        setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to load payroll data.' });
      } finally {
        setLoading(false);
      }
    },
    [isSelfServiceOnly]
  );

  useEffect(() => {
    loadPayroll();
  }, [loadPayroll]);

  const activeRun = runs.find((r) => r.id === activeRunId) || null;
  const currentStep =
    activeRun?.status === 'Released' ? 3 : activeRun?.status === 'Finalized' ? 2 : 1;

  const runPrecheck = useCallback(
    async (startDate: string, endDate: string, policyId?: string) => {
      if (!canCompute || !startDate || !endDate || endDate < startDate) {
        setPrecheck(null);
        return;
      }
      setPrecheckLoading(true);
      try {
        const qs = new URLSearchParams({ start_date: startDate, end_date: endDate });
        if (policyId) qs.set('policy_id', policyId);
        const res = await apiFetch<PayrollPrecheck>(`/api/payroll/precheck?${qs.toString()}`);
        setPrecheck(res);
      } catch {
        setPrecheck(null);
      } finally {
        setPrecheckLoading(false);
      }
    },
    [canCompute]
  );

  useEffect(() => {
    if (computeOpen) {
      runPrecheck(computeForm.start_date, computeForm.end_date, computeForm.policy_id);
    }
  }, [computeOpen, computeForm.start_date, computeForm.end_date, computeForm.policy_id, runPrecheck]);

  const handleCompute = async (e: React.FormEvent, recompute = false) => {
    e.preventDefault();
    setSubmitting(true);
    setFeedback(null);
    try {
      const res = await apiFetch<{
        id: number;
        calculation_version: number;
        idempotentNoOp: boolean;
        is_production_approved: boolean;
      }>('/api/payroll/compute', {
        method: 'POST',
        body: JSON.stringify({
          period_label: computeForm.period_label,
          start_date: computeForm.start_date,
          end_date: computeForm.end_date,
          policy_id: computeForm.policy_id ? Number(computeForm.policy_id) : null,
          recompute,
        }),
      });
      setComputeOpen(false);
      setFeedback({
        type: 'ok',
        text: res.idempotentNoOp
          ? `Payroll "${computeForm.period_label}" is already up to date (v${res.calculation_version}, identical snapshot).`
          : `Payroll computed for "${computeForm.period_label}" (v${res.calculation_version}).${
              res.is_production_approved ? '' : ' Stamped NOT APPROVED FOR PRODUCTION (draft policy).'
            }`,
      });
      loadPayroll(res.id);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Computation failed.' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleRecomputeActive = async () => {
    if (!activeRun || activeRun.status !== 'Computed') return;
    setSubmitting(true);
    setFeedback(null);
    try {
      const res = await apiFetch<{
        id: number;
        calculation_version: number;
        idempotentNoOp: boolean;
      }>('/api/payroll/compute', {
        method: 'POST',
        body: JSON.stringify({
          period_label: activeRun.period_label,
          start_date: activeRun.start_date,
          end_date: activeRun.end_date,
          policy_id: activeApprovedPolicy?.id || activeRun.policy_id || null,
          recompute: true,
        }),
      });
      setFeedback({
        type: 'ok',
        text: res.idempotentNoOp
          ? `Idempotent check: no attendance, leave, or policy changes detected (v${res.calculation_version}).`
          : `Recomputed "${activeRun.period_label}" cleanly to calculation v${res.calculation_version}.`,
      });
      loadPayroll(res.id);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Recomputation failed.' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleStageConfirm = async () => {
    if (!activeRun || !confirmStage) return;
    setFeedback(null);
    try {
      await apiFetch(`/api/payroll/${activeRun.id}/${confirmStage}`, { method: 'PATCH' });
      setFeedback({
        type: 'ok',
        text:
          confirmStage === 'finalize'
            ? `Payroll run "${activeRun.period_label}" finalized and locked (immutable). Record Finance sign-off to release.`
            : `Payroll run "${activeRun.period_label}" released. Released payslips are now available to employees.`,
      });
      setConfirmStage(null);
      loadPayroll(activeRun.id);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Operation failed.' });
      setConfirmStage(null);
    }
  };

  const handleFinanceSignoffSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRun) return;
    setSubmitting(true);
    setFeedback(null);
    try {
      await apiFetch(`/api/payroll/${activeRun.id}/finance-signoff`, {
        method: 'POST',
        body: JSON.stringify({
          finance_signoff_ref: signoffRef,
          notes: signoffNotes,
        }),
      });
      setSignoffModalOpen(false);
      setSignoffRef('');
      setSignoffNotes('');
      setFeedback({
        type: 'ok',
        text: `Finance sign-off recorded for "${activeRun.period_label}". Run is now eligible for Release.`,
      });
      loadPayroll(activeRun.id);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Finance sign-off failed.' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDownloadPolicyTemplate = async () => {
    try {
      const tpl = await apiFetch<Record<string, unknown>>('/api/payroll/policy-template');
      downloadJson('RSU-CAJ-Payroll-Policy-Input-Template.json', tpl);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Failed to download template.' });
    }
  };

  const handleLoadTemplateIntoForm = async () => {
    try {
      const tpl = await apiFetch<{ fields: { policy_code: string; policy_name: string; effective_from: string; notes: string; rules: Record<string, unknown> } }>('/api/payroll/policy-template');
      setNewPolicyForm({
        policy_code: tpl.fields.policy_code,
        policy_name: tpl.fields.policy_name,
        effective_from: tpl.fields.effective_from,
        effective_to: '',
        notes: tpl.fields.notes,
        rulesJson: JSON.stringify(tpl.fields.rules, null, 2),
      });
      setShowCreatePolicy(true);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to load template.' });
    }
  };

  const handleCreatePolicy = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setFeedback(null);
    try {
      const parsedRules = JSON.parse(newPolicyForm.rulesJson);
      await apiFetch('/api/payroll/policies', {
        method: 'POST',
        body: JSON.stringify({
          policy_code: newPolicyForm.policy_code,
          policy_name: newPolicyForm.policy_name,
          effective_from: newPolicyForm.effective_from,
          effective_to: newPolicyForm.effective_to || null,
          notes: newPolicyForm.notes,
          rules: parsedRules,
        }),
      });
      setShowCreatePolicy(false);
      setFeedback({
        type: 'ok',
        text: `Draft payroll policy "${newPolicyForm.policy_code}" created. Finance approval is required before live release.`,
      });
      loadPayroll(activeRunId);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Failed to create payroll policy.' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleFinanceApprovePolicy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!policyApproveId) return;
    setSubmitting(true);
    setFeedback(null);
    try {
      await apiFetch(`/api/payroll/policies/${policyApproveId}/finance-approve`, {
        method: 'POST',
        body: JSON.stringify({
          approval_reference: policyApproveRef,
          notes: policyApproveNotes,
        }),
      });
      setPolicyApproveId(null);
      setPolicyApproveRef('');
      setPolicyApproveNotes('');
      setFeedback({ type: 'ok', text: 'Institutional payroll policy approved by Finance.' });
      loadPayroll(activeRunId);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Policy approval failed.' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleExportServerCsv = async () => {
    if (!activeRun) return;
    setFeedback(null);
    try {
      const res = await fetch(`/api/payroll/${activeRun.id}/export.csv`, {
        method: 'GET',
        credentials: 'include',
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `CSV export failed (${res.status})`);
      }
      const csvText = await res.text();
      const blob = new Blob([csvText], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute(
        'download',
        `SAVAGE-RSUCAJ-Payroll-${activeRun.start_date}_to_${activeRun.end_date}-v${activeRun.calculation_version || 1}.csv`
      );
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to export payroll CSV.' });
    }
  };

  // Self-service read-only view for Employee role (Released payslips ONLY)
  if (isSelfServiceOnly) {
    return (
      <ModuleFrame
        title="My Released Payslips"
        subtitle="View and print your official Finance-released campus payslips."
        icon={<Wallet className="w-5 h-5" />}
      >
        {feedback && (
          <div className="mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border bg-red-50 border-red-200 text-red-800">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{feedback.text}</span>
          </div>
        )}

        <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
                <th className="py-3 px-4">Pay Period</th>
                <th className="py-3 px-4 text-right">Gross Pay</th>
                <th className="py-3 px-4 text-right">Deductions</th>
                <th className="py-3 px-4 text-right">Net Pay</th>
                <th className="py-3 px-4">Released</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    Loading your released payslips...
                  </td>
                </tr>
              ) : myPayslips.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    No released payslips are available for your account yet. Draft and unfinalized runs are hidden until officially released by Finance.
                  </td>
                </tr>
              ) : (
                myPayslips.map((item) => (
                  <tr key={item.id} className="hover:bg-emerald-50/35">
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-900">{item.period_label}</div>
                      <div className="text-[11px] text-slate-400 font-mono-num">
                        {item.start_date} to {item.end_date} · Ref: {item.finance_signoff_ref || '-'}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono-num text-slate-800">
                      {formatPeso(item.gross_pay ?? item.basic_pay + item.allowances)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono-num text-red-600">
                      -{formatPeso(item.deductions)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono-num font-bold text-[#15803D]">
                      {formatPeso(item.net_pay)}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 font-mono-num">
                      {item.released_at || '-'}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => setPayslipItem(item)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 hover:bg-emerald-50 text-slate-700 text-[11px] font-semibold cursor-pointer"
                      >
                        <Eye className="w-3 h-3 text-[#0B5537]" />
                        <span>View Payslip</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <PayslipDetailModal
          item={payslipItem}
          run={
            payslipItem
              ? ({
                  id: payslipItem.payroll_run_id,
                  period_label: payslipItem.period_label || '',
                  start_date: payslipItem.start_date || '',
                  end_date: payslipItem.end_date || '',
                  status: 'Released',
                  policy_code: payslipItem.policy_code,
                  policy_approval_status: 'APPROVED_BY_FINANCE',
                  is_production_approved: 1,
                  calculation_version: payslipItem.calculation_version,
                  snapshot_sha256: payslipItem.snapshot_sha256,
                  finance_signoff_ref: payslipItem.finance_signoff_ref,
                  total_basic_pay: 0,
                  total_allowances: 0,
                  total_deductions: 0,
                  total_net_pay: 0,
                  employee_count: 1,
                  created_by: '',
                  created_at: '',
                  finalized_at: null,
                  released_at: payslipItem.released_at || null,
                } as PayrollRun)
              : null
          }
          onClose={() => setPayslipItem(null)}
        />
      </ModuleFrame>
    );
  }

  return (
    <ModuleFrame
      title="Payroll Processing"
      subtitle="Compute, finalize, and release employee payroll."
      icon={<Wallet className="w-5 h-5" />}
    >
      {feedback && (
        <div
          className={`mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Governance Banner: Explicit Policy Approval Status (No silent placeholder rates) */}
      {!activeApprovedPolicy && (
        <div className="mb-4 px-4 py-3 rounded-xl bg-amber-50 border border-amber-300/90 text-amber-950 text-xs flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-amber-950">
                NOT APPROVED FOR PRODUCTION — No Finance-Approved Institutional Payroll Policy Active
              </p>
              <p className="text-amber-800 mt-0.5">
                Hard-coded placeholder deductions are disabled. Download the Policy Input Template, enter written RSU Cajidiocan rates, and record Finance approval before finalizing or releasing live payroll.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadPolicyTemplate}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-amber-400 bg-white hover:bg-amber-100/60 text-amber-950 font-semibold cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Policy Template</span>
            </button>
            <button
              type="button"
              onClick={() => setPolicyModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-700 hover:bg-amber-800 text-white font-semibold cursor-pointer"
            >
              <FileCode2 className="w-3.5 h-3.5" />
              <span>Manage Policies</span>
            </button>
          </div>
        </div>
      )}

      {/* 3-Step Workflow Stepper + "+ Compute Payroll" CTA matching 08_Payroll_Processing.png */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-5 mb-5 border-b border-slate-100">
        <div className="flex flex-wrap items-center gap-2.5 sm:gap-5">
          {[
            { num: 1, label: 'Compute' },
            { num: 2, label: 'Finalize' },
            { num: 3, label: 'Release' },
          ].map((step, idx) => {
            const reached = currentStep >= step.num;
            const isPrimaryGreen = step.num === 1 || currentStep > step.num || (step.num === 3 && currentStep === 3);
            return (
              <React.Fragment key={step.num}>
                <div className="flex items-center gap-2">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-extrabold font-mono-num shadow-xs shrink-0 ${
                      reached && isPrimaryGreen
                        ? 'bg-[#16A34A] text-white'
                        : reached
                          ? 'bg-[#3B82F6] text-white'
                          : 'bg-[#60A5FA]/80 text-white'
                    }`}
                  >
                    {step.num}
                  </div>
                  <span
                    className={`text-sm font-bold ${
                      reached ? 'text-slate-900' : 'text-slate-500'
                    }`}
                  >
                    {step.label}
                  </span>
                </div>
                {idx < 2 && (
                  <div
                    className={`w-6 sm:w-20 h-[2px] ${
                      currentStep > step.num ? 'bg-[#16A34A]' : 'bg-slate-200'
                    }`}
                  />
                )}
              </React.Fragment>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setPolicyModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs cursor-pointer"
          >
            <FileCode2 className="w-4 h-4 text-[#0B5537]" />
            <span>Policies ({policies.length})</span>
          </button>
          {canCompute && (
            <button
              type="button"
              onClick={() => setComputeOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl btn-rsu-primary text-xs font-bold transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Compute Payroll</span>
            </button>
          )}
        </div>
      </div>

      {/* 4 Currency Summary Cards matching 08_Payroll_Processing.png */}
      {activeRun && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
          {[
            {
              label: 'Total Basic Pay',
              value: formatPeso(activeRun.total_basic_pay),
              icon: Banknote,
              iconBg: 'bg-[#DCFCE7] text-[#15803D]',
            },
            {
              label: 'Total Allowances',
              value: formatPeso(activeRun.total_allowances),
              icon: HandCoins,
              iconBg: 'bg-[#DBEAFE] text-[#1D4ED8]',
            },
            {
              label: 'Total Deductions',
              value: formatPeso(activeRun.total_deductions),
              icon: UserMinus,
              iconBg: 'bg-[#FEE2E2] text-[#DC2626]',
            },
            {
              label: 'Net Pay',
              value: formatPeso(activeRun.total_net_pay),
              icon: Coins,
              iconBg: 'bg-[#FEF3C7] text-[#D97706]',
            },
          ].map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.label}
                className="p-4 rounded-2xl border border-slate-200/80 bg-white shadow-sm flex items-center gap-3.5"
              >
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 ${card.iconBg}`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <div className="min-w-0">
                  <p className="font-display text-base font-extrabold text-slate-900 font-mono-num truncate">
                    {card.value}
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5 font-medium">{card.label}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Active Run Snapshot & Maker-Checker Metadata Strip */}
      {activeRun && (
        <div className="mb-4 px-3.5 py-2.5 rounded-xl bg-[#F4F8F6] border border-slate-200/80 text-[11px] flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-slate-600">
            <span>
              Policy:{' '}
              <strong className="text-slate-900 font-mono-num">
                {activeRun.policy_code || 'Legacy (Unassigned)'}
              </strong>
            </span>
            <span>
              Calc: <strong className="text-slate-900 font-mono-num">v{activeRun.calculation_version || 1}</strong>
            </span>
            {activeRun.snapshot_sha256 && (
              <span>
                SHA-256:{' '}
                <strong className="text-slate-800 font-mono-num">{activeRun.snapshot_sha256.slice(0, 12)}…</strong>
              </span>
            )}
            <span>
              Maker: <strong className="text-slate-900">{activeRun.created_by}</strong>
            </span>
            {activeRun.finalized_by && (
              <span>
                Finalized By: <strong className="text-slate-900">{activeRun.finalized_by}</strong>
              </span>
            )}
            {activeRun.finance_signoff_ref && (
              <span>
                Finance Sign-Off:{' '}
                <strong className="text-emerald-800 font-mono-num">
                  {activeRun.finance_signoff_ref} ({activeRun.finance_signoff_by})
                </strong>
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {activeRun.is_production_approved !== 1 ? (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-bold">
                <AlertTriangle className="w-3 h-3" />
                NOT APPROVED FOR PRODUCTION
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-bold">
                <ShieldCheck className="w-3 h-3" />
                FINANCE POLICY APPROVED
              </span>
            )}
            {(activeRun.status === 'Finalized' || activeRun.status === 'Released') && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-200 text-slate-700 font-bold">
                <Lock className="w-3 h-3" />
                IMMUTABLE
              </span>
            )}
          </div>
        </div>
      )}

      {/* Batch Controls Row */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2.5">
          {runs.length > 0 && (
            <select
              aria-label="Select payroll run"
              value={activeRunId || ''}
              onChange={(e) => loadPayroll(Number(e.target.value))}
              className="px-3.5 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 bg-white shadow-2xs focus:outline-none focus:border-[#0B5537]"
            >
              {runs.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.period_label} ({r.status} · v{r.calculation_version || 1})
                </option>
              ))}
            </select>
          )}
          {activeRun && <StatusLabel status={activeRun.status} />}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {activeRun?.status === 'Computed' && canCompute && (
            <button
              type="button"
              onClick={handleRecomputeActive}
              disabled={submitting}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5 text-[#0B5537]" />
              <span>Recompute</span>
            </button>
          )}
          {activeRun?.status === 'Computed' && canFinalize && (
            <button
              type="button"
              onClick={() => setConfirmStage('finalize')}
              disabled={activeRun.is_production_approved !== 1}
              title={
                activeRun.is_production_approved !== 1
                  ? 'Blocked: Finance-approved institutional policy required before Finalize'
                  : 'Finalize and lock payroll run (requires second reviewer — maker-checker)'
              }
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-45 disabled:cursor-not-allowed text-white text-xs font-semibold shadow-xs cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Finalize Payroll</span>
            </button>
          )}
          {activeRun?.status === 'Finalized' && !activeRun.finance_signoff_ref && canFinanceSignoff && (
            <button
              type="button"
              onClick={() => setSignoffModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold shadow-xs cursor-pointer"
            >
              <Stamp className="w-3.5 h-3.5" />
              <span>Finance Sign-Off</span>
            </button>
          )}
          {activeRun?.status === 'Finalized' && canRelease && (
            <button
              type="button"
              onClick={() => setConfirmStage('release')}
              disabled={!activeRun.finance_signoff_ref}
              title={
                !activeRun.finance_signoff_ref
                  ? 'Record Finance Sign-Off before releasing payroll'
                  : 'Release official Finance-approved payslips'
              }
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl btn-rsu-dark disabled:opacity-45 disabled:cursor-not-allowed text-xs font-semibold cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Release Payroll</span>
            </button>
          )}
          {activeRun && (
            <>
              <button
                type="button"
                onClick={() => setAuditModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs cursor-pointer"
              >
                <History className="w-3.5 h-3.5 text-[#0B5537]" />
                <span>Audit ({auditEntries.length})</span>
              </button>
              <button
                type="button"
                onClick={handleExportServerCsv}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-[#0B5537]" />
                <span>Export CSV</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Employee Payroll Ledger Table */}
      <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
              <th className="py-3 px-4">Employee</th>
              <th className="py-3 px-4">Dept</th>
              <th className="py-3 px-4 text-right">Basic Pay</th>
              <th className="py-3 px-4 text-right">OT / Hol</th>
              <th className="py-3 px-4 text-right">Allowances</th>
              <th className="py-3 px-4 text-right">Deductions</th>
              <th className="py-3 px-4 text-right">Net Pay</th>
              <th className="py-3 px-4 text-right">Payslip</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs">
            {loading ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-400">
                  Loading payroll breakdown...
                </td>
              </tr>
            ) : items.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-400">
                  No payroll runs computed yet. Configure an institutional policy and click Compute Payroll to begin.
                </td>
              </tr>
            ) : (
              items.map((item) => {
                const otAndHol = (item.overtime_pay || 0) + (item.holiday_rest_pay || 0);
                return (
                  <tr key={item.id} className="hover:bg-emerald-50/35 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-900">{item.employee_name}</div>
                      <div className="text-[11px] text-slate-400 font-mono-num">
                        {item.employee_code} · {item.position_name}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">{item.department_code}</td>
                    <td className="py-3.5 px-4 text-right font-mono-num text-slate-800">
                      {formatPeso(item.basic_pay)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono-num text-emerald-700">
                      {formatPeso(otAndHol)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono-num text-blue-700">
                      {formatPeso(item.allowances)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono-num text-red-600">
                      -{formatPeso(item.deductions)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono-num font-bold text-[#15803D]">
                      {formatPeso(item.net_pay)}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => setPayslipItem(item)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 hover:bg-emerald-50 hover:border-emerald-200 text-slate-700 text-[11px] font-semibold cursor-pointer"
                      >
                        <Eye className="w-3 h-3 text-[#0B5537]" />
                        <span>Payslip</span>
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Compute New Payroll Modal with Live Pre-Compute Reconciliation */}
      <Modal
        open={computeOpen}
        onClose={() => setComputeOpen(false)}
        title="Compute Payroll Batch"
        subtitle="Uses effective-dated institutional payroll policies and runs mandatory attendance, correction & leave reconciliation."
      >
        <form onSubmit={(e) => handleCompute(e, false)} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Payroll Period Label *</label>
            <input
              type="text"
              required
              value={computeForm.period_label}
              onChange={(e) => setComputeForm({ ...computeForm, period_label: e.target.value })}
              className="w-full px-3 py-2 rounded-lg border border-slate-300"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Start Date *</label>
              <input
                type="date"
                required
                value={computeForm.start_date}
                onChange={(e) => setComputeForm({ ...computeForm, start_date: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">End Date *</label>
              <input
                type="date"
                required
                value={computeForm.end_date}
                onChange={(e) => setComputeForm({ ...computeForm, end_date: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Institutional Payroll Policy</label>
            <select
              value={computeForm.policy_id}
              onChange={(e) => setComputeForm({ ...computeForm, policy_id: e.target.value })}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
            >
              <option value="">Auto-select effective policy for period</option>
              {policies.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.policy_code} — {p.approval_status} ({p.effective_from} to {p.effective_to || 'open'})
                </option>
              ))}
            </select>
          </div>

          {/* Live Pre-Compute Reconciliation Summary */}
          <div className="p-3 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800">Pre-Compute Reconciliation Check</span>
              {precheckLoading && <span className="text-slate-400">Checking...</span>}
            </div>
            {precheck && (
              <div className="space-y-1.5 text-[11px]">
                <div className="grid grid-cols-2 gap-2 text-slate-600">
                  <span>Active Employees: <strong>{precheck.activeEmployeeCount}</strong></span>
                  <span>Pending Corrections: <strong className={precheck.pendingCorrections.length ? 'text-red-600' : 'text-emerald-700'}>{precheck.pendingCorrections.length}</strong></span>
                  <span>Pending Leaves: <strong className={precheck.pendingLeaves.length ? 'text-red-600' : 'text-emerald-700'}>{precheck.pendingLeaves.length}</strong></span>
                  <span>Missing Punches: <strong className={precheck.unresolvedMissingPunches.length ? 'text-red-600' : 'text-emerald-700'}>{precheck.unresolvedMissingPunches.length}</strong></span>
                </div>
                {precheck.blockers.map((b, i) => (
                  <div key={i} className="p-2 rounded-lg bg-red-50 border border-red-200 text-red-800 font-medium">
                    <strong>{b.code}:</strong> {b.message}
                  </div>
                ))}
                {precheck.warnings.map((w, i) => (
                  <div key={i} className="p-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 font-medium">
                    <strong>{w.code}:</strong> {w.message}
                  </div>
                ))}
                {precheck.blockers.length === 0 && (
                  <div className="p-2 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 font-semibold">
                    Reconciliation passed. Ready to compute atomically.
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setComputeOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || Boolean(precheck && !precheck.canCompute)}
              className="px-4 py-2 rounded-lg btn-rsu-primary disabled:opacity-50 font-semibold cursor-pointer"
            >
              {submitting ? 'Computing...' : 'Run Computation'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Institutional Payroll Policies & Template Modal */}
      <Modal
        open={policyModalOpen}
        onClose={() => {
          setPolicyModalOpen(false);
          setShowCreatePolicy(false);
          setPolicyApproveId(null);
        }}
        title="Institutional Payroll Policies & Governance"
        subtitle="Effective-dated rules. Live release is strictly blocked until Finance approves a written policy."
        maxWidth="max-w-3xl"
      >
        <div className="space-y-4 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-slate-600">
              Configured policies: <strong>{policies.length}</strong>
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleDownloadPolicyTemplate}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 font-semibold text-slate-700 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-[#0B5537]" />
                <span>Download Policy Input Template</span>
              </button>
              {canManagePolicy && (
                <button
                  type="button"
                  onClick={handleLoadTemplateIntoForm}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>New Draft Policy</span>
                </button>
              )}
            </div>
          </div>

          {showCreatePolicy && (
            <form onSubmit={handleCreatePolicy} className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/40 space-y-3">
              <div className="font-bold text-[#07442B]">Create Effective-Dated Draft Policy (Pending Finance Approval)</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Policy Code *</label>
                  <input
                    type="text"
                    required
                    value={newPolicyForm.policy_code}
                    onChange={(e) => setNewPolicyForm({ ...newPolicyForm, policy_code: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-mono-num"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Policy Name *</label>
                  <input
                    type="text"
                    required
                    value={newPolicyForm.policy_name}
                    onChange={(e) => setNewPolicyForm({ ...newPolicyForm, policy_name: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Effective From *</label>
                  <input
                    type="date"
                    required
                    value={newPolicyForm.effective_from}
                    onChange={(e) => setNewPolicyForm({ ...newPolicyForm, effective_from: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-mono-num"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Effective To (Optional)</label>
                  <input
                    type="date"
                    value={newPolicyForm.effective_to}
                    onChange={(e) => setNewPolicyForm({ ...newPolicyForm, effective_to: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-mono-num"
                  />
                </div>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Policy Rules JSON (Supply Institutional Statutory &amp; Tax Tables) *</label>
                <textarea
                  rows={8}
                  required
                  value={newPolicyForm.rulesJson}
                  onChange={(e) => setNewPolicyForm({ ...newPolicyForm, rulesJson: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white font-mono text-[11px]"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreatePolicy(false)}
                  className="px-3 py-1.5 rounded-lg text-slate-600 hover:bg-slate-200/60 font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-3.5 py-1.5 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
                >
                  Save Draft Policy
                </button>
              </div>
            </form>
          )}

          {policyApproveId && (
            <form onSubmit={handleFinanceApprovePolicy} className="p-4 rounded-xl border border-amber-300 bg-amber-50 space-y-3">
              <div className="font-bold text-amber-950">Record Institutional Finance Approval</div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Board Resolution / Finance Memo Reference *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. RSU-FIN-MEMO-2026-04-001"
                  value={policyApproveRef}
                  onChange={(e) => setPolicyApproveRef(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-mono-num"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Approval Notes</label>
                <input
                  type="text"
                  value={policyApproveNotes}
                  onChange={(e) => setPolicyApproveNotes(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPolicyApproveId(null)}
                  className="px-3 py-1.5 rounded-lg text-slate-600 hover:bg-amber-100 font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-3.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold cursor-pointer"
                >
                  Confirm Finance Approval
                </button>
              </div>
            </form>
          )}

          <div className="divide-y divide-slate-200 border border-slate-200 rounded-xl overflow-hidden">
            {policies.length === 0 ? (
              <div className="p-6 text-center text-slate-500">
                No institutional payroll policies saved yet. Download the Policy Input Template or create a draft policy above.
              </div>
            ) : (
              policies.map((p) => (
                <div key={p.id} className="p-3.5 bg-white flex flex-wrap items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 font-mono-num">{p.policy_code}</span>
                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                          p.approval_status === 'APPROVED_BY_FINANCE'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-900'
                        }`}
                      >
                        {p.approval_status}
                      </span>
                    </div>
                    <p className="text-slate-700 font-medium">{p.policy_name}</p>
                    <p className="text-[11px] text-slate-500 font-mono-num">
                      Effective: {p.effective_from} to {p.effective_to || 'Open'}
                      {p.approval_reference ? ` · Ref: ${p.approval_reference} (${p.finance_approved_by})` : ''}
                    </p>
                  </div>
                  {p.approval_status === 'DRAFT_NOT_APPROVED' && canFinanceSignoff && (
                    <button
                      type="button"
                      onClick={() => setPolicyApproveId(p.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold cursor-pointer"
                    >
                      <Stamp className="w-3.5 h-3.5" />
                      <span>Finance Approve</span>
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </Modal>

      {/* Finance Sign-Off Modal for Finalized Run */}
      <Modal
        open={signoffModalOpen}
        onClose={() => setSignoffModalOpen(false)}
        title="Record Finance Sign-Off"
        subtitle={activeRun ? `Required prior to releasing "${activeRun.period_label}". Maker-checker enforced.` : undefined}
      >
        <form onSubmit={handleFinanceSignoffSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Finance Clearance / Voucher Reference *</label>
            <input
              type="text"
              required
              placeholder="e.g. DV-2026-04-0182"
              value={signoffRef}
              onChange={(e) => setSignoffRef(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
            />
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Verification Notes</label>
            <textarea
              rows={3}
              value={signoffNotes}
              onChange={(e) => setSignoffNotes(e.target.value)}
              placeholder="Verified against payroll ledger, attendance records, and approved institutional policy."
              className="w-full px-3 py-2 rounded-lg border border-slate-300"
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setSignoffModalOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-semibold cursor-pointer"
            >
              {submitting ? 'Recording...' : 'Record Finance Sign-Off'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Immutable Payroll Audit Trail Modal */}
      <Modal
        open={auditModalOpen}
        onClose={() => setAuditModalOpen(false)}
        title="Immutable Payroll Audit Trail"
        subtitle={activeRun ? `Run: ${activeRun.period_label} (v${activeRun.calculation_version || 1})` : undefined}
        maxWidth="max-w-2xl"
      >
        <div className="space-y-2.5 text-xs max-h-[60vh] overflow-y-auto">
          {auditEntries.length === 0 ? (
            <p className="text-slate-500 text-center py-6">No payroll audit entries recorded for this run yet.</p>
          ) : (
            auditEntries.map((entry) => (
              <div key={entry.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50/70 space-y-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-bold text-[#07442B]">{entry.action}</span>
                  <span className="text-[11px] font-mono-num text-slate-500">{entry.acted_at_manila}</span>
                </div>
                <div className="text-slate-600">
                  Actor: <strong>{entry.actor_username}</strong> ({entry.actor_role}) · Version: <strong>v{entry.calculation_version}</strong>
                  {entry.reference_code ? ` · Ref: ${entry.reference_code}` : ''}
                </div>
                {entry.snapshot_sha256 && (
                  <div className="text-[11px] font-mono-num text-slate-500 truncate">
                    Snapshot SHA-256: {entry.snapshot_sha256}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </Modal>

      <ConfirmModal
        open={Boolean(confirmStage)}
        onClose={() => setConfirmStage(null)}
        onConfirm={handleStageConfirm}
        title={confirmStage === 'finalize' ? 'Finalize & Lock Payroll Run?' : 'Release Payroll Run?'}
        message={
          confirmStage === 'finalize'
            ? `Finalize "${activeRun?.period_label}" for ${activeRun?.employee_count} employees? Once finalized, financial figures are permanently locked by SQLite triggers and require a different reviewer (maker-checker).`
            : `Release Finance-signed official payslips for "${activeRun?.period_label}" (Ref: ${activeRun?.finance_signoff_ref || 'required'})? Released runs are permanently immutable.`
        }
        confirmLabel={confirmStage === 'finalize' ? 'Finalize & Lock' : 'Release Payroll'}
        destructive={false}
      />

      <PayslipDetailModal item={payslipItem} run={activeRun} onClose={() => setPayslipItem(null)} />
    </ModuleFrame>
  );
};

const PayslipDetailModal: React.FC<{
  item: PayrollItem | null;
  run: PayrollRun | null;
  onClose: () => void;
}> = ({ item, run, onClose }) => {
  return (
    <Modal
      open={Boolean(item)}
      onClose={onClose}
      title="Official Campus Payslip"
      subtitle={run ? `Pay Period: ${run.period_label} (${run.start_date} to ${run.end_date})` : undefined}
    >
      {item && run && (
        <div className="space-y-4 text-xs">
          {run.is_production_approved !== 1 && (
            <div className="px-3.5 py-2 rounded-xl bg-amber-100 border border-amber-300 text-amber-950 font-bold text-center">
              NOT APPROVED FOR PRODUCTION — COMPUTED UNDER UNAPPROVED DRAFT POLICY
            </div>
          )}

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-500">Institution</span>
              <span className="font-bold text-[#07442B]">RSU – Cajidiocan Campus</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Employee</span>
              <span className="font-bold text-slate-900">
                {item.employee_name} ({item.employee_code})
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Department / Position</span>
              <span className="font-medium text-slate-700">
                {item.department_code} · {item.position_name}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Policy / Calc Version</span>
              <span className="font-mono-num text-slate-700">
                {run.policy_code || '-'} · v{run.calculation_version || 1}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Batch Status</span>
              <StatusLabel status={run.status} />
            </div>
            {run.finance_signoff_ref && (
              <div className="flex justify-between">
                <span className="text-slate-500">Finance Sign-Off Ref</span>
                <span className="font-mono-num font-semibold text-emerald-800">{run.finance_signoff_ref}</span>
              </div>
            )}
          </div>

          <div className="border border-slate-200 rounded-xl divide-y divide-slate-100 overflow-hidden">
            <div className="px-4 py-2 bg-slate-50 font-bold text-slate-700 uppercase text-[10px]">Earnings</div>
            <div className="px-4 py-2 flex justify-between">
              <span className="text-slate-600">Prorated Basic Pay</span>
              <span className="font-mono-num font-semibold">{formatPeso(item.basic_pay)}</span>
            </div>
            <div className="px-4 py-2 flex justify-between">
              <span className="text-slate-600">Allowances</span>
              <span className="font-mono-num font-semibold text-blue-700">+{formatPeso(item.allowances)}</span>
            </div>
            {(item.overtime_pay || 0) > 0 && (
              <div className="px-4 py-2 flex justify-between">
                <span className="text-slate-600">Overtime Pay ({item.overtime_minutes || 0}m)</span>
                <span className="font-mono-num font-semibold text-emerald-700">+{formatPeso(item.overtime_pay || 0)}</span>
              </div>
            )}
            {(item.holiday_rest_pay || 0) > 0 && (
              <div className="px-4 py-2 flex justify-between">
                <span className="text-slate-600">Holiday &amp; Rest Day Pay</span>
                <span className="font-mono-num font-semibold text-emerald-700">+{formatPeso(item.holiday_rest_pay || 0)}</span>
              </div>
            )}
            {(item.other_earnings || 0) > 0 && (
              <div className="px-4 py-2 flex justify-between">
                <span className="text-slate-600">Other Earnings / Exceptions</span>
                <span className="font-mono-num font-semibold text-emerald-700">+{formatPeso(item.other_earnings || 0)}</span>
              </div>
            )}
            <div className="px-4 py-2 bg-slate-50/70 flex justify-between font-bold text-slate-800">
              <span>Gross Pay</span>
              <span className="font-mono-num">
                {formatPeso(item.gross_pay ?? item.basic_pay + item.allowances + (item.overtime_pay || 0) + (item.holiday_rest_pay || 0))}
              </span>
            </div>

            <div className="px-4 py-2 bg-slate-50 font-bold text-slate-700 uppercase text-[10px]">Deductions</div>
            {(item.late_deduction || 0) > 0 && (
              <div className="px-4 py-2 flex justify-between">
                <span className="text-slate-600">Tardiness ({item.late_minutes || 0}m)</span>
                <span className="font-mono-num text-red-600">-{formatPeso(item.late_deduction || 0)}</span>
              </div>
            )}
            {(item.undertime_deduction || 0) > 0 && (
              <div className="px-4 py-2 flex justify-between">
                <span className="text-slate-600">Undertime ({item.undertime_minutes || 0}m)</span>
                <span className="font-mono-num text-red-600">-{formatPeso(item.undertime_deduction || 0)}</span>
              </div>
            )}
            {(item.absence_deduction || 0) > 0 && (
              <div className="px-4 py-2 flex justify-between">
                <span className="text-slate-600">Absences ({item.days_absent}d)</span>
                <span className="font-mono-num text-red-600">-{formatPeso(item.absence_deduction || 0)}</span>
              </div>
            )}
            {(item.unpaid_leave_deduction || 0) > 0 && (
              <div className="px-4 py-2 flex justify-between">
                <span className="text-slate-600">Unpaid Leave ({item.days_unpaid_leave || 0}d)</span>
                <span className="font-mono-num text-red-600">-{formatPeso(item.unpaid_leave_deduction || 0)}</span>
              </div>
            )}
            {(item.statutory_deductions || 0) > 0 && (
              <div className="px-4 py-2 flex justify-between">
                <span className="text-slate-600">Statutory Contributions</span>
                <span className="font-mono-num text-red-600">-{formatPeso(item.statutory_deductions || 0)}</span>
              </div>
            )}
            {(item.tax_deduction || 0) > 0 && (
              <div className="px-4 py-2 flex justify-between">
                <span className="text-slate-600">Withholding Tax</span>
                <span className="font-mono-num text-red-600">-{formatPeso(item.tax_deduction || 0)}</span>
              </div>
            )}
            {(item.other_deductions || 0) > 0 && (
              <div className="px-4 py-2 flex justify-between">
                <span className="text-slate-600">Other Deductions</span>
                <span className="font-mono-num text-red-600">-{formatPeso(item.other_deductions || 0)}</span>
              </div>
            )}
            <div className="px-4 py-2 flex justify-between font-semibold text-red-700">
              <span>Total Deductions</span>
              <span className="font-mono-num">-{formatPeso(item.deductions)}</span>
            </div>

            <div className="px-4 py-3 bg-emerald-50 flex justify-between font-bold text-sm text-[#07442B]">
              <span>Net Take-Home Pay</span>
              <span className="font-mono-num">{formatPeso(item.net_pay)}</span>
            </div>
          </div>

          <div className="flex justify-end gap-2 no-print">
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl btn-rsu-primary font-semibold cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
          </div>
        </div>
      )}
    </Modal>
  );
};

export const ReportsView: React.FC = () => {
  const [departments, setDepartments] = useState<Department[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [deptFilter, setDeptFilter] = useState('');
  const [empFilter, setEmpFilter] = useState('');
  const [monthFilter, setMonthFilter] = useState(() => getManilaTodayIso().slice(0, 7));
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [strictDraftBlock, setStrictDraftBlock] = useState(false);

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [activeReport, setActiveReport] = useState<ReportResponse | null>(null);
  const [selectedDtrEmpId, setSelectedDtrEmpId] = useState<number | null>(null);
  const [loadingType, setLoadingType] = useState<string | null>(null);
  const [downloadingFormat, setDownloadingFormat] = useState<'csv' | 'pdf' | null>(null);
  const [signBusy, setSignBusy] = useState(false);

  useEffect(() => {
    apiFetch<{ data: Department[] }>('/api/departments')
      .then((r) => setDepartments(r.data))
      .catch(() => {});
    apiFetch<{ data: Employee[] }>('/api/employees?limit=500')
      .then((r) => setEmployees(r.data))
      .catch(() => {});
  }, []);

  const reportCards: Array<{ type: ReportType; title: string; desc: string; icon: React.ComponentType<{ className?: string }> }> = [
    { type: 'attendance', title: 'Attendance Report', desc: 'Daily/Monthly', icon: CalendarDays },
    { type: 'dtr', title: 'DTR (Daily Time Record)', desc: 'Monthly DTR (PDF/CSV)', icon: FileSpreadsheet },
    { type: 'leaves', title: 'Leave Report', desc: 'Applications & Balances', icon: Umbrella },
    { type: 'payroll', title: 'Payroll Report', desc: 'Summary & Payslips', icon: Wallet },
    { type: 'employees', title: 'Employee Report', desc: 'Employee Masterlist', icon: Users },
    { type: 'audit-logs', title: 'Audit Logs Report', desc: 'System Activities', icon: ShieldCheck },
  ];

  const buildFilterQueryParams = (type: ReportType, extra: Record<string, string> = {}) => {
    const qs = new URLSearchParams();
    if (deptFilter) qs.set('department_id', deptFilter);
    if (empFilter) qs.set('employee_id', empFilter);
    if (type === 'dtr' && monthFilter) {
      qs.set('month', monthFilter);
    }
    if (startDate) qs.set('start_date', startDate);
    if (endDate) qs.set('end_date', endDate);
    if (statusFilter && statusFilter !== 'All') qs.set('status', statusFilter);
    if (type === 'dtr' && strictDraftBlock) qs.set('strict', 'true');
    for (const [k, v] of Object.entries(extra)) {
      if (v) qs.set(k, v);
    }
    return qs.toString();
  };

  const runReport = async (type: ReportType, page = 1) => {
    setLoadingType(type);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      const q = buildFilterQueryParams(type, { page: String(page), limit: '100' });
      const data = await apiFetch<ReportResponse>(`/api/reports/${type}${q ? `?${q}` : ''}`);
      setActiveReport(data);
      if (data.type === 'dtr' && data.dtr_reports && data.dtr_reports.length > 0) {
        const stillValid = data.dtr_reports.some((r) => r.employee.id === selectedDtrEmpId);
        if (!stillValid) {
          setSelectedDtrEmpId(data.dtr_reports[0].employee.id);
        }
      } else {
        setSelectedDtrEmpId(null);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to generate report.');
    } finally {
      setLoadingType(null);
    }
  };

  const handleServerExport = async (format: 'csv' | 'pdf') => {
    if (!activeReport) return;
    setDownloadingFormat(format);
    setErrorMsg(null);
    try {
      const extra: Record<string, string> = {};
      if (activeReport.type === 'dtr' && !empFilter && selectedDtrEmpId && format === 'pdf') {
        extra.employee_id = String(selectedDtrEmpId);
      }
      const q = buildFilterQueryParams(activeReport.type, extra);
      const url = `/api/reports/${activeReport.type}/export.${format}${q ? `?${q}` : ''}`;
      const fallbackName = `SAVAGE-RSUCAJ-${activeReport.type}-${getManilaTodayIso()}.${format}`;
      await downloadAuthenticatedBlob(url, fallbackName);
      setSuccessMsg(`Downloaded authenticated ${format.toUpperCase()} export (${activeReport.type}).`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : `Failed to export ${format.toUpperCase()}.`);
    } finally {
      setDownloadingFormat(null);
    }
  };

  const handleSignDtr = async (rep: MonthlyDtrEmployeeReport) => {
    setSignBusy(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      await apiFetch('/api/reports/dtr/sign', {
        method: 'POST',
        body: JSON.stringify({
          employee_id: rep.employee.id,
          month: rep.month,
          role_action: 'BOTH',
        }),
      });
      await runReport('dtr', activeReport?.pagination?.page || 1);
      setSuccessMsg(`Verified and signed Monthly DTR for ${rep.employee.full_name} (${rep.month}).`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to verify/sign DTR.');
    } finally {
      setSignBusy(false);
    }
  };

  const handleRevokeDtr = async (rep: MonthlyDtrEmployeeReport) => {
    setSignBusy(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      await apiFetch('/api/reports/dtr/revoke', {
        method: 'POST',
        body: JSON.stringify({
          employee_id: rep.employee.id,
          month: rep.month,
          reason: 'Revoked from Reports console for re-verification',
        }),
      });
      await runReport('dtr', activeReport?.pagination?.page || 1);
      setSuccessMsg(`Revoked DTR sign-off for ${rep.employee.full_name} (${rep.month}).`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to revoke DTR sign-off.');
    } finally {
      setSignBusy(false);
    }
  };

  const activeDtrReport: MonthlyDtrEmployeeReport | null =
    activeReport?.type === 'dtr' && activeReport.dtr_reports && activeReport.dtr_reports.length > 0
      ? activeReport.dtr_reports.find((r) => r.employee.id === selectedDtrEmpId) || activeReport.dtr_reports[0]
      : null;

  return (
    <ModuleFrame
      title="Reports"
      subtitle="Generate and download system reports."
      icon={<FileBarChart2 className="w-5 h-5" />}
    >
      {errorMsg && (
        <div className="mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border bg-red-50 border-red-200 text-red-800 no-print">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border bg-emerald-50 border-emerald-200 text-emerald-800 no-print">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* 6 Institutional Report Cards matching 09_Reports_6eabab71.png */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 no-print">
        {reportCards.map((card) => {
          const Icon = card.icon;
          const isSelected = activeReport?.type === card.type;
          return (
            <button
              key={card.type}
              type="button"
              onClick={() => runReport(card.type, 1)}
              className={`p-4 rounded-2xl border text-left transition-all flex items-center gap-4 cursor-pointer shadow-xs ${
                isSelected
                  ? 'border-[#16A34A] bg-emerald-50/60 shadow-md shadow-emerald-950/6'
                  : 'border-slate-200/90 bg-white hover:border-[#16A34A]/60 hover:shadow-md'
              }`}
            >
              <div className="w-11 h-11 rounded-xl bg-emerald-50 text-[#15803D] flex items-center justify-center shrink-0">
                <Icon className="w-6 h-6" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="font-display text-sm font-extrabold text-slate-900 truncate">
                  {card.title}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5 truncate">
                  {loadingType === card.type ? 'Querying SQLite database...' : card.desc}
                </p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Filters + Export Controls */}
      <div className="mt-6 pt-5 border-t border-slate-200/80">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4 no-print">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="inline-flex items-center gap-1 font-bold text-slate-600">
              <Filter className="w-3.5 h-3.5 text-[#0B5537]" />
              Filters:
            </span>
            <select
              aria-label="Report department filter"
              value={deptFilter}
              onChange={(e) => setDeptFilter(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white text-xs text-slate-700"
            >
              <option value="">All Departments</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.code} — {d.name}
                </option>
              ))}
            </select>
            <select
              aria-label="Report employee filter"
              value={empFilter}
              onChange={(e) => setEmpFilter(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white text-xs text-slate-700 max-w-full sm:max-w-[200px]"
            >
              <option value="">All Employees</option>
              {employees
                .filter((emp) => !deptFilter || String(emp.department_id) === deptFilter)
                .map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.employee_code} — {emp.full_name}
                  </option>
                ))}
            </select>
            <input
              type="month"
              aria-label="Report month"
              value={monthFilter}
              onChange={(e) => setMonthFilter(e.target.value)}
              title="Monthly DTR target month (YYYY-MM)"
              className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white text-xs font-mono-num"
            />
            <input
              type="date"
              aria-label="Report start date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white text-xs font-mono-num"
            />
            <span className="text-slate-400">to</span>
            <input
              type="date"
              aria-label="Report end date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white text-xs font-mono-num"
            />
            {activeReport?.type === 'dtr' && (
              <label className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200 bg-white text-[11px] font-medium text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={strictDraftBlock}
                  onChange={(e) => setStrictDraftBlock(e.target.checked)}
                  className="rounded border-slate-300 accent-[#0B5537]"
                />
                <span>Block Draft Export</span>
              </label>
            )}
            {activeReport && (
              <button
                type="button"
                onClick={() => runReport(activeReport.type, 1)}
                className="px-3 py-1.5 rounded-xl btn-rsu-primary text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
              >
                Apply Filters
              </button>
            )}
          </div>

          {activeReport && (
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
              >
                <Printer className="w-3.5 h-3.5 text-[#0B5537]" />
                <span>Print A4</span>
              </button>
              <button
                type="button"
                disabled={downloadingFormat !== null}
                onClick={() => handleServerExport('pdf')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-emerald-700/30 bg-emerald-50 hover:bg-emerald-100 text-[#07442B] text-xs font-bold cursor-pointer whitespace-nowrap shrink-0 disabled:opacity-60"
              >
                <FileDown className="w-3.5 h-3.5" />
                <span>{downloadingFormat === 'pdf' ? 'Rendering PDF...' : 'Download PDF'}</span>
              </button>
              <button
                type="button"
                disabled={downloadingFormat !== null}
                onClick={() => handleServerExport('csv')}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl btn-rsu-dark text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0 disabled:opacity-60"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{downloadingFormat === 'csv' ? 'Streaming CSV...' : 'Download CSV'}</span>
              </button>
            </div>
          )}
        </div>

        {activeReport ? (
          <div>
            {/* Reconciled Report Header & Summary */}
            <div className="mb-4 no-print">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="font-display text-base font-extrabold text-slate-900">
                    {activeReport.title}
                  </h2>
                  <p className="text-xs text-slate-500 font-mono-num">
                    {activeReport.pagination.total} total record(s) · Page {activeReport.pagination.page} of{' '}
                    {activeReport.pagination.totalPages} · Generated{' '}
                    {new Date(activeReport.generatedAt).toLocaleString()}
                  </p>
                </div>

                {activeReport.type === 'dtr' && activeReport.dtr_reports && activeReport.dtr_reports.length > 1 && (
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-semibold text-slate-600">Preview Employee Sheet:</span>
                    <select
                      aria-label="Select employee DTR sheet"
                      value={activeDtrReport?.employee.id || ''}
                      onChange={(e) => setSelectedDtrEmpId(Number(e.target.value))}
                      className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white font-semibold text-slate-800"
                    >
                      {activeReport.dtr_reports.map((rep) => (
                        <option key={rep.employee.id} value={rep.employee.id}>
                          {rep.employee.employee_code} — {rep.employee.full_name} ({rep.dtr_state})
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              {activeReport.summary && Object.keys(activeReport.summary).length > 0 && (
                <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2.5">
                  {Object.entries(activeReport.summary)
                    .slice(0, 6)
                    .map(([k, v]) => {
                      const isMoney = k.includes('pay') || k.includes('deductions');
                      return (
                        <div key={k} className="p-2.5 rounded-xl border border-slate-200/80 bg-[#F8FBFA]">
                          <div className="text-[10px] font-bold text-slate-500 uppercase truncate">
                            {k.replace(/_/g, ' ')}
                          </div>
                          <div className="text-xs font-extrabold text-[#07442B] font-mono-num mt-0.5 truncate">
                            {isMoney ? formatPeso(Number(v || 0)) : String(v ?? 0)}
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>

            {/* Institutional Monthly DTR A4 Portrait Printable Sheet */}
            {activeReport.type === 'dtr' && activeDtrReport ? (
              <div className="dtr-print-sheet bg-white border border-slate-300 rounded-2xl p-5 sm:p-6 shadow-xs space-y-4">
                <div className="flex flex-wrap items-start justify-between gap-4 pb-3 border-b-2 border-[#0B5537]">
                  <div className="flex items-center gap-3.5">
                    <img
                      src="/assets/aistudio/SAVAGE-RSUCAJ_Smart_Attendance_Emblem_39488c28.png"
                      alt="RSU Cajidiocan Campus Official Emblem"
                      className="w-12 h-12 object-contain shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="font-display text-sm font-extrabold text-[#07442B]">
                        ROMBLON STATE UNIVERSITY — CAJIDIOCAN CAMPUS
                      </div>
                      <div className="text-xs font-bold text-slate-700">
                        {activeDtrReport.cs_form_48_reference_verified
                          ? 'CIVIL SERVICE FORM NO. 48 — DAILY TIME RECORD'
                          : 'MONTHLY DAILY TIME RECORD (DRAFT INSTITUTIONAL FORMAT)'}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {activeDtrReport.cs_form_48_reference_note}
                      </div>
                    </div>
                  </div>

                  <div className="text-right space-y-1 no-print">
                    <div
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold ${
                        activeDtrReport.is_draft
                          ? 'bg-red-100 text-red-800 border border-red-200'
                          : activeDtrReport.is_signed
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-amber-100 text-amber-900 border border-amber-200'
                      }`}
                    >
                      {activeDtrReport.is_draft
                        ? 'DRAFT — UNRESOLVED / STALE'
                        : activeDtrReport.is_signed
                          ? 'VERIFIED & SIGNED'
                          : 'READY FOR SIGN-OFF'}
                    </div>
                    <div className="flex items-center justify-end gap-1.5">
                      {!activeDtrReport.unresolved_blockers.length && !activeDtrReport.is_signed && (
                        <button
                          type="button"
                          disabled={signBusy}
                          onClick={() => handleSignDtr(activeDtrReport)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg btn-rsu-primary text-[11px] font-semibold cursor-pointer disabled:opacity-60"
                        >
                          <FileCheck2 className="w-3.5 h-3.5" />
                          <span>{signBusy ? 'Signing...' : 'Verify & Sign DTR'}</span>
                        </button>
                      )}
                      {activeDtrReport.signoff?.status === 'SIGNED' && (
                        <button
                          type="button"
                          disabled={signBusy}
                          onClick={() => handleRevokeDtr(activeDtrReport)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-[11px] font-semibold cursor-pointer disabled:opacity-60"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>Revoke</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Employee + Period Metadata */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 p-3 rounded-xl bg-[#F4F8F6] border border-slate-200 text-xs">
                  <div>
                    <span className="text-slate-500">Employee: </span>
                    <strong className="text-slate-900">
                      {activeDtrReport.employee.full_name} ({activeDtrReport.employee.employee_code})
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-500">For the Month of: </span>
                    <strong className="text-slate-900 font-mono-num">
                      {activeDtrReport.month_label} ({activeDtrReport.days_in_month} days
                      {activeDtrReport.is_leap_year ? ' · Leap Year' : ''})
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-500">Department / Position: </span>
                    <span className="font-semibold text-slate-800">
                      {activeDtrReport.employee.department_code} — {activeDtrReport.employee.position_name}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500">Official Shift: </span>
                    <span className="font-semibold text-slate-800 font-mono-num">
                      {activeDtrReport.employee.shift_name} ({activeDtrReport.employee.shift_time_in} –{' '}
                      {activeDtrReport.employee.shift_time_out})
                      {activeDtrReport.employee.is_overnight_shift ? ' [Overnight]' : ''}
                    </span>
                  </div>
                </div>

                {/* Draft / Unresolved Blockers Notice */}
                {activeDtrReport.is_draft && (
                  <div className="p-3 rounded-xl border border-red-300 bg-red-50 text-xs text-red-900 space-y-1">
                    <div className="font-bold flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                      <span>
                        DRAFT DTR — Unresolved scans, pending corrections/leaves, or post-signoff changes detected. Missing times are NEVER fabricated.
                      </span>
                    </div>
                    {activeDtrReport.unresolved_blockers.length > 0 && (
                      <ul className="list-disc pl-5 text-[11px] font-mono-num space-y-0.5">
                        {activeDtrReport.unresolved_blockers.slice(0, 6).map((b, idx) => (
                          <li key={idx}>
                            {b.date}: {b.detail}
                          </li>
                        ))}
                        {activeDtrReport.unresolved_blockers.length > 6 && (
                          <li>+{activeDtrReport.unresolved_blockers.length - 6} additional blocker(s)</li>
                        )}
                      </ul>
                    )}
                  </div>
                )}

                {/* Full Calendar Days Table (28/29/30/31 rows) */}
                <div className="overflow-x-auto border border-slate-300 rounded-xl">
                  <table className="w-full text-left border-collapse text-[11px]">
                    <thead>
                      <tr className="bg-[#07442B] text-white font-bold uppercase">
                        <th className="py-2 px-2.5">Day</th>
                        <th className="py-2 px-2.5">Time In</th>
                        <th className="py-2 px-2.5">Break Out</th>
                        <th className="py-2 px-2.5">Break In</th>
                        <th className="py-2 px-2.5">Time Out</th>
                        <th className="py-2 px-2.5">OT Out</th>
                        <th className="py-2 px-2.5">Work Hrs</th>
                        <th className="py-2 px-2 text-center">Late</th>
                        <th className="py-2 px-2 text-center">UT</th>
                        <th className="py-2 px-2.5">Status / Label</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 font-mono-num">
                      {activeDtrReport.rows.map((r) => {
                        const isIssue = r.has_unresolved_punch || r.has_pending_correction || r.has_pending_leave;
                        const labelSuffix = [r.leave_label, r.holiday_label, r.overnight_note]
                          .filter(Boolean)
                          .join(' · ');
                        return (
                          <tr
                            key={r.date}
                            className={
                              isIssue
                                ? 'bg-red-50/70'
                                : r.status === 'Holiday'
                                  ? 'bg-amber-50/50'
                                  : r.status === 'Rest Day'
                                    ? 'bg-slate-50/80'
                                    : ''
                            }
                          >
                            <td className="py-1.5 px-2.5 font-semibold text-slate-900 whitespace-nowrap">
                              {String(r.day).padStart(2, '0')} {r.day_code}
                            </td>
                            <td
                              className={`py-1.5 px-2.5 whitespace-nowrap ${
                                r.has_unresolved_punch && r.status === 'Missing Time In'
                                  ? 'text-red-700 font-bold'
                                  : 'text-slate-700'
                              }`}
                            >
                              {r.time_in ?? (r.has_unresolved_punch && r.status === 'Missing Time In' ? 'MISSING' : '-')}
                            </td>
                            <td className="py-1.5 px-2.5 whitespace-nowrap text-slate-600">{r.break_out ?? '-'}</td>
                            <td className="py-1.5 px-2.5 whitespace-nowrap text-slate-600">{r.break_in ?? '-'}</td>
                            <td
                              className={`py-1.5 px-2.5 whitespace-nowrap ${
                                r.has_unresolved_punch && r.status === 'Missing Time Out'
                                  ? 'text-red-700 font-bold'
                                  : 'text-slate-700'
                              }`}
                            >
                              {r.time_out ??
                                (r.has_unresolved_punch && r.status === 'Missing Time Out' ? 'MISSING' : '-')}
                            </td>
                            <td className="py-1.5 px-2.5 whitespace-nowrap text-slate-600">{r.overtime_out ?? '-'}</td>
                            <td className="py-1.5 px-2.5 whitespace-nowrap text-slate-800">{r.work_hours || '-'}</td>
                            <td className="py-1.5 px-2 text-center text-slate-700">
                              {r.late_minutes > 0 ? `${r.late_minutes}m` : '0'}
                            </td>
                            <td className="py-1.5 px-2 text-center text-slate-700">
                              {r.undertime_minutes > 0 ? `${r.undertime_minutes}m` : '0'}
                            </td>
                            <td className="py-1.5 px-2.5 font-sans text-slate-800">
                              <span className="font-semibold">{r.status}</span>
                              {labelSuffix ? <span className="text-slate-500"> · {labelSuffix}</span> : null}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Monthly DTR Totals */}
                <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200 text-xs flex flex-wrap items-center justify-between gap-2 font-mono-num text-[#07442B]">
                  <div>
                    <strong>Totals:</strong> Present {activeDtrReport.totals.days_present}d · Late{' '}
                    {activeDtrReport.totals.days_late}d ({activeDtrReport.totals.total_late_minutes}m) · Undertime{' '}
                    {activeDtrReport.totals.days_undertime}d ({activeDtrReport.totals.total_undertime_minutes}m) · Absent{' '}
                    {activeDtrReport.totals.days_absent}d · Leave {activeDtrReport.totals.days_on_leave}d · OB{' '}
                    {activeDtrReport.totals.days_ob}d · Holiday {activeDtrReport.totals.days_holiday}d
                  </div>
                  <div className="font-extrabold">
                    Worked: {activeDtrReport.totals.total_worked_hours_formatted}
                  </div>
                </div>

                {/* Certification & Signature Lines (Employee + Campus Director) */}
                <div className="pt-2 space-y-5 text-xs">
                  <p className="italic text-slate-600 text-[11px]">
                    I certify on my honor that the above is a true and correct report of the hours of work performed, record of which was made daily at the time of arrival and departure from office.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4">
                    <div className="text-center">
                      <div className="border-b border-slate-800 pb-1 font-bold text-slate-900 uppercase">
                        {activeDtrReport.employee.full_name}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-1">
                        {activeDtrReport.signoff?.employee_signed_at_utc && activeDtrReport.is_signed
                          ? `Employee Signature (${activeDtrReport.signoff.employee_signed_by})`
                          : 'Employee Signature'}
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="border-b border-slate-800 pb-1 font-bold text-slate-900 uppercase">
                        {activeDtrReport.campus_director_name || 'Campus Director'}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-1">
                        {activeDtrReport.signoff?.supervisor_verified_at_utc && activeDtrReport.is_signed
                          ? `Campus Director / Verified (${activeDtrReport.signoff.supervisor_verified_by})`
                          : 'Campus Director / Authorized Official (RSU — Cajidiocan)'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              /* Standard Paginated Report Table + Leave Balances Subtable */
              <div className="space-y-4">
                <div className="overflow-x-auto border border-slate-200/80 rounded-xl max-h-[460px]">
                  <table className="w-full text-left border-collapse">
                    <thead className="sticky top-0 bg-[#F4F8F6] border-b border-slate-200">
                      <tr className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                        {activeReport.columns.map((col) => (
                          <th key={col} className="py-2.5 px-3 whitespace-nowrap">
                            {col.replace(/_/g, ' ')}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs">
                      {activeReport.rows.length === 0 ? (
                        <tr>
                          <td colSpan={activeReport.columns.length} className="py-8 text-center text-slate-400">
                            No database records found matching the selected filters.
                          </td>
                        </tr>
                      ) : (
                        activeReport.rows.map((row, i) => (
                          <tr key={i} className="hover:bg-emerald-50/35">
                            {activeReport.columns.map((col) => (
                              <td key={col} className="py-2.5 px-3 whitespace-nowrap font-mono-num text-slate-700">
                                {String(row[col] ?? '-')}
                              </td>
                            ))}
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                {activeReport.pagination.totalPages > 1 && (
                  <div className="flex items-center justify-between text-xs text-slate-600 no-print">
                    <span className="font-mono-num">
                      Showing page {activeReport.pagination.page} of {activeReport.pagination.totalPages} (
                      {activeReport.pagination.total} total rows; CSV export streams full dataset)
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        disabled={activeReport.pagination.page <= 1}
                        onClick={() => runReport(activeReport.type, activeReport.pagination.page - 1)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                      >
                        <ChevronLeft className="w-3.5 h-3.5" />
                        <span>Previous</span>
                      </button>
                      <button
                        type="button"
                        disabled={activeReport.pagination.page >= activeReport.pagination.totalPages}
                        onClick={() => runReport(activeReport.type, activeReport.pagination.page + 1)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                      >
                        <span>Next</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="p-8 rounded-xl border border-dashed border-slate-200 text-center text-xs text-slate-500">
            Select any report card above to query live SQLite records, preview Monthly DTR sheets, print A4, or download authenticated CSV / PDF exports.
          </div>
        )}
      </div>
    </ModuleFrame>
  );
};
