import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Calendar,
  Camera,
  ChevronRight,
  Eye,
  EyeOff,
  Info,
  Lock,
  LogIn,
  LogOut,
  Monitor,
  RefreshCw,
  ScanFace,
  Search,
  ShieldCheck,
  User,
  UserPlus,
  Volume2,
  X,
  Zap,
} from 'lucide-react';
import {
  KIOSK_SHIELD_LOGO_SRC,
  KioskFaceFrameIcon,
  KioskLiveFaceReticle,
  KioskPrimaryButton,
  KioskStatusCircle,
  KioskToggleSwitch,
} from './KioskPrimitives';
import type {
  KioskAttendanceOutcome,
  KioskDeviceInfo,
  KioskEmployeeOption,
  KioskFailureOutcome,
  KioskSettingsState,
} from './types';
import type {
  CameraErrorInfo,
  FrameQualityAnalysis,
  KioskIndicatorStatus,
  KioskModelsStatusPayload,
  VerificationStateSnapshot,
} from '../../lib/kioskBiometrics';

const indicatorBadgeClass = (status: KioskIndicatorStatus, darkSurface = true): string => {
  if (darkSurface) {
    switch (status) {
      case 'PASS':
        return 'bg-emerald-500/25 text-emerald-200 border-emerald-400/50';
      case 'FAIL':
        return 'bg-red-500/25 text-red-200 border-red-400/50';
      case 'CHECKING':
        return 'bg-sky-500/20 text-sky-100 border-sky-300/40';
      default:
        return 'bg-amber-500/20 text-amber-200 border-amber-400/45';
    }
  }
  switch (status) {
    case 'PASS':
      return 'bg-emerald-50 text-emerald-800 border-emerald-200';
    case 'FAIL':
      return 'bg-red-50 text-red-700 border-red-200';
    case 'CHECKING':
      return 'bg-sky-50 text-sky-800 border-sky-200';
    default:
      return 'bg-amber-50 text-amber-800 border-amber-200';
  }
};

const indicatorLabel = (status: KioskIndicatorStatus): string => {
  switch (status) {
    case 'PASS':
      return 'PASS';
    case 'FAIL':
      return 'FAIL';
    case 'CHECKING':
      return 'Checking';
    default:
      return 'Pending';
  }
};

// ============================================================================
// SCREEN 01 — SPLASH SCREEN (01_Splash_Screen_491ba823.png)
// ============================================================================
export const KioskSplashScreen: React.FC<{ statusText: string }> = ({ statusText }) => (
  <div
    data-testid="kiosk-screen-01"
    className="relative min-h-screen w-full flex flex-col items-center justify-center overflow-hidden px-6 py-12 select-none"
    style={{
      background: 'radial-gradient(circle at 50% 34%, #0B6B36 0%, #054924 58%, #033318 100%)',
    }}
  >
    <div className="relative z-10 flex flex-col items-center text-center max-w-xl">
      <img
        src={KIOSK_SHIELD_LOGO_SRC}
        alt="SAVAGE-RSUCAJ Attendance Shield"
        className="w-32 h-32 sm:w-40 sm:h-40 object-contain drop-shadow-[0_10px_22px_rgba(0,0,0,0.4)] mb-4"
      />
      <h1 className="text-white font-extrabold tracking-wide text-3xl sm:text-5xl leading-tight drop-shadow-sm">
        SAVAGE-RSUCAJ
      </h1>
      <p className="text-emerald-100/95 font-semibold tracking-[0.14em] text-sm sm:text-lg mt-1.5 uppercase">
        SMART ATTENDANCE SYSTEM
      </p>

      {/* Real Initialization Spinner */}
      <div className="mt-8 flex flex-col items-center gap-3">
        <div
          className="w-12 h-12 sm:w-14 sm:h-14 rounded-full border-[5px] border-white/85 border-t-[#2CE63F] animate-spin"
          role="status"
          aria-label="Initializing kiosk"
        />
        <p className="text-white/95 font-semibold text-base sm:text-lg">{statusText || 'Loading...'}</p>
      </div>
    </div>

    {/* Signature Bottom Golden-Emerald Wave */}
    <div className="absolute bottom-0 inset-x-0 h-28 sm:h-36 pointer-events-none" aria-hidden="true">
      <svg viewBox="0 0 1200 180" preserveAspectRatio="none" className="w-full h-full block">
        <defs>
          <linearGradient id="splashGoldWave" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#E7A808" />
            <stop offset="30%" stopColor="#FFE14C" />
            <stop offset="65%" stopColor="#E6AA0A" />
            <stop offset="100%" stopColor="#FCD42D" />
          </linearGradient>
        </defs>
        <path
          d="M0,45 Q240,-10 580,75 Q900,155 1200,45 L1200,180 L0,180 Z"
          fill="url(#splashGoldWave)"
        />
        <path
          d="M0,105 Q290,45 610,120 Q920,185 1200,98 L1200,180 L0,180 Z"
          fill="#055C2B"
        />
      </svg>
    </div>
  </div>
);

// ============================================================================
// SCREEN 02 — DEVICE ACTIVATION (02_Device_Activation_614c9f89.png)
// ============================================================================
export const KioskActivationScreen: React.FC<{
  onActivate: (code: string) => Promise<void>;
  loading: boolean;
  error: string | null;
}> = ({ onActivate, loading, error }) => {
  const [code, setCode] = useState('');
  const [helpOpen, setHelpOpen] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || loading) return;
    await onActivate(code.trim());
  };

  return (
    <div
      data-testid="kiosk-screen-02"
      className="flex-1 flex flex-col items-center justify-center px-5 sm:px-8 py-6 sm:py-10"
    >
      <form onSubmit={handleSubmit} className="w-full max-w-lg flex flex-col items-center text-center">
        <h1 className="text-2xl sm:text-4xl font-extrabold text-[#0B1210] tracking-tight">
          Kiosk Device Activation
        </h1>
        <p className="mt-2.5 text-sm sm:text-lg font-semibold text-slate-800">
          Enter the device code provided by the Administrator
        </p>

        {error && (
          <div
            role="alert"
            className="mt-4 w-full rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-800 text-left flex items-start gap-2.5"
          >
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
            <span>{error}</span>
          </div>
        )}

        <div className="mt-6 w-full relative">
          <Monitor className="w-6 h-6 text-[#0A4D28] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="Enter Device Code"
            aria-label="Enter Device Code"
            autoComplete="off"
            spellCheck={false}
            data-testid="kiosk-device-code-input"
            className="w-full min-h-[56px] pl-14 pr-4 py-3.5 rounded-2xl border-2 border-slate-300 bg-white text-slate-900 font-semibold text-base sm:text-lg placeholder:text-slate-500 shadow-xs focus:outline-none focus:border-[#0A6934] focus:ring-2 focus:ring-[#0A6934]/20"
          />
        </div>

        <div className="mt-5 w-full">
          <KioskPrimaryButton
            type="submit"
            fullWidth
            disabled={loading || code.trim().length < 6}
            data-testid="kiosk-activate-submit"
            className="min-h-[56px] text-lg sm:text-xl"
          >
            {loading ? 'Activating Device...' : 'Activate Device'}
          </KioskPrimaryButton>
        </div>

        <button
          type="button"
          onClick={() => setHelpOpen(true)}
          className="mt-5 inline-flex items-center gap-2 text-slate-800 hover:text-[#0A6934] font-semibold text-sm sm:text-base py-2 px-3 rounded-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0A6934] cursor-pointer"
        >
          <Info className="w-5 h-5 text-[#08522B]" />
          <span>Where to get the device code?</span>
        </button>
      </form>

      {helpOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="activation-help-title"
        >
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between gap-2">
              <h2 id="activation-help-title" className="text-lg font-extrabold text-slate-900">
                How to Get a Device Code
              </h2>
              <button
                type="button"
                onClick={() => setHelpOpen(false)}
                aria-label="Close help"
                className="w-9 h-9 rounded-full flex items-center justify-center text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <ol className="mt-4 space-y-2.5 text-sm text-slate-700 list-decimal pl-5">
              <li>Sign in to the <strong>SAVAGE-RSUCAJ Admin Portal</strong> as an Administrator.</li>
              <li>Open <strong>Devices (Kiosk)</strong> in the left sidebar and register or locate this kiosk terminal.</li>
              <li>Click <strong>Activation Code</strong> to mint a one-time 24-hour code (format <code className="font-mono bg-slate-100 px-1.5 py-0.5 rounded">RSU-XXXX-XXXX</code>).</li>
              <li>Enter that code here to establish an HttpOnly revocable kiosk session.</li>
            </ol>
            <div className="mt-5">
              <KioskPrimaryButton fullWidth onClick={() => setHelpOpen(false)}>
                Got It
              </KioskPrimaryButton>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// SCREEN 03 — KIOSK READY HOME (03_Kiosk_Ready_Home_Auto_Enroll_e69b8a81.png)
// ============================================================================
export const KioskReadyHomeScreen: React.FC<{
  models: KioskModelsStatusPayload;
  livenessEnforced: boolean;
  onStartAttendance: () => void;
  onRequestAutoEnroll: () => void;
}> = ({ models, livenessEnforced, onStartAttendance, onRequestAutoEnroll }) => {
  const padReady = models.models.anti_spoofing_pad.status === 'VERIFIED_ON_DISK';
  const liveReady = models.models.liveness_detection.status === 'VERIFIED_ON_DISK';
  const recReady = models.models.face_recognition.status === 'VERIFIED_ON_DISK';

  return (
    <div
      data-testid="kiosk-screen-03"
      className="relative flex-1 flex flex-col items-center justify-between px-4 sm:px-8 pt-2 pb-5 overflow-hidden"
    >
      <div className="w-full max-w-2xl flex flex-col items-center text-center my-auto">
        <button
          type="button"
          onClick={onStartAttendance}
          data-testid="kiosk-ready-start-btn"
          className="group flex flex-col items-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0A6934] rounded-2xl p-1 cursor-pointer"
        >
          <KioskFaceFrameIcon className="w-16 h-16 sm:w-20 sm:h-20 transition-transform group-hover:scale-105" />
          <h1 className="mt-1.5 text-2xl sm:text-3xl font-extrabold text-[#0B1210] tracking-tight">
            Ready for Attendance
          </h1>
          <p className="mt-0.5 text-sm sm:text-base font-semibold text-slate-800">
            Look at the camera to verify your identity.
          </p>
        </button>

        {/* Three Feature Cards matching Screen 03 */}
        <div className="mt-3.5 w-full grid grid-cols-3 gap-2.5 sm:gap-4">
          <div className="rounded-2xl bg-[#F4F6F5] border border-slate-200/80 px-2.5 py-2.5 sm:py-3 flex flex-col items-center justify-center text-center">
            <ShieldCheck className={`w-6 h-6 sm:w-7 sm:h-7 ${recReady ? 'text-[#0A6934]' : 'text-amber-700'}`} />
            <span className="mt-1 text-xs sm:text-sm font-semibold text-slate-900 leading-tight">
              Face Recognition
            </span>
            {!recReady && (
              <span className="mt-0.5 text-[10px] sm:text-[11px] font-semibold text-amber-800">Model Pending</span>
            )}
          </div>

          <div className="rounded-2xl bg-[#F4F6F5] border border-slate-200/80 px-2.5 py-2.5 sm:py-3 flex flex-col items-center justify-center text-center">
            <Zap className={`w-6 h-6 sm:w-7 sm:h-7 ${liveReady && livenessEnforced ? 'text-[#0A6934]' : 'text-amber-700'}`} />
            <span className="mt-1 text-xs sm:text-sm font-semibold text-slate-900 leading-tight">
              Liveness Check
            </span>
            {!liveReady && (
              <span className="mt-0.5 text-[10px] sm:text-[11px] font-semibold text-amber-800">Model Pending</span>
            )}
          </div>

          <div className="rounded-2xl bg-[#F4F6F5] border border-slate-200/80 px-2.5 py-2.5 sm:py-3 flex flex-col items-center justify-center text-center">
            <Lock className={`w-6 h-6 sm:w-7 sm:h-7 ${padReady && livenessEnforced ? 'text-[#0A6934]' : 'text-amber-700'}`} />
            <span className="mt-1 text-xs sm:text-sm font-semibold text-slate-900 leading-tight">
              Anti-Spoofing
            </span>
            {!padReady && (
              <span className="mt-0.5 text-[10px] sm:text-[11px] font-semibold text-amber-800">Model Pending</span>
            )}
          </div>
        </div>

        {/* Gold AUTO ENROLL (TOUCHLESS) Banner — Strictly triggers Admin PIN Authorization (Screen 09 -> Screen 10) */}
        <button
          type="button"
          onClick={onRequestAutoEnroll}
          data-testid="kiosk-auto-enroll-banner"
          className="mt-3.5 w-full rounded-[24px] border-2 border-[#E5AC08] px-4 sm:px-5 py-2.5 sm:py-3 flex items-center gap-3.5 sm:gap-4 text-left shadow-[0_6px_16px_rgba(229,172,8,0.22)] hover:brightness-[0.98] active:scale-[0.99] transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0A6934] cursor-pointer"
          style={{
            background: 'linear-gradient(180deg, #FFF7C9 0%, #FFE47A 100%)',
          }}
        >
          <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center shrink-0 bg-[#F9CF2B]/45 border border-[#D49C07]/40">
            <ScanFace className="w-7 h-7 text-[#0B1210]" strokeWidth={2.2} />
          </div>
          <div className="min-w-0">
            <div className="text-sm sm:text-lg font-extrabold text-[#0B1210] tracking-tight leading-snug">
              AUTO ENROLL (TOUCHLESS)
            </div>
            <p className="text-xs sm:text-sm font-medium text-slate-900 leading-snug mt-0.5">
              Touchless front-face employee enrollment after Administrator PIN authorization.
            </p>
          </div>
        </button>

        <div className="mt-3.5">
          <KioskPrimaryButton onClick={onStartAttendance} data-testid="kiosk-open-scan-btn">
            Start Attendance Scan
          </KioskPrimaryButton>
        </div>
      </div>

      {/* Bottom Subtle Gold Corner Ribbons matching Screen 03 */}
      <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-5 overflow-hidden" aria-hidden="true">
        <svg viewBox="0 0 1200 30" preserveAspectRatio="none" className="w-full h-full">
          <path d="M0,0 Q180,26 420,30 L0,30 Z" fill="#F2C017" />
          <path d="M1200,0 Q1020,26 780,30 L1200,30 Z" fill="#F2C017" />
        </svg>
      </div>
    </div>
  );
};

// ============================================================================
// SCREEN 16 — ATTENDANCE SCAN READY (16_Attendance_Scan_Ready_be0e2772.png)
// ============================================================================
export const KioskAttendanceReadyScreen: React.FC<{
  faceCaptureEnabled: boolean;
  onActivateScan: () => void;
  onBackHome: () => void;
}> = ({ faceCaptureEnabled, onActivateScan, onBackHome }) => (
  <div
    data-testid="kiosk-screen-16"
    className="flex-1 flex flex-col items-center justify-center px-5 sm:px-8 py-6 text-center"
  >
    <div className="w-full max-w-xl flex flex-col items-center">
      <KioskFaceFrameIcon className="w-24 h-24 sm:w-28 sm:h-28" />
      <h1 className="mt-4 text-2xl sm:text-4xl font-extrabold text-[#0B1210] tracking-tight">
        Attendance Scan Ready
      </h1>
      <p className="mt-2 text-sm sm:text-lg font-semibold text-slate-800">
        Look at the camera to record your time in or time out.
      </p>

      <button
        type="button"
        onClick={onActivateScan}
        disabled={!faceCaptureEnabled}
        data-testid="kiosk-face-recognition-active-btn"
        className="mt-7 w-full max-w-md min-h-[60px] rounded-full px-6 py-3.5 flex items-center justify-center gap-3.5 text-lg sm:text-2xl font-bold text-[#0B1210] border border-emerald-300/90 shadow-xs hover:brightness-[0.97] active:scale-[0.99] transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0A6934] disabled:opacity-55 cursor-pointer"
        style={{
          background: 'linear-gradient(180deg, #DDF6E1 0%, #BFECC7 100%)',
        }}
      >
        <Camera className="w-7 h-7 sm:w-8 sm:h-8 text-[#0B1210]" strokeWidth={2.2} />
        <span>{faceCaptureEnabled ? 'Face Recognition Active' : 'Face Capture Disabled'}</span>
      </button>

      <button
        type="button"
        onClick={onBackHome}
        className="mt-5 text-sm font-semibold text-slate-600 hover:text-[#0A6934] py-2 px-3 rounded-lg cursor-pointer"
      >
        Back to Kiosk Home
      </button>
    </div>
  </div>
);

// ============================================================================
// SCREEN 04 — FACE SCANNING (04_Face_Scanning_b69a83e0.png)
// ============================================================================
export const KioskFaceScanningScreen: React.FC<{
  videoRef: React.RefObject<HTMLVideoElement | null>;
  cameraReady: boolean;
  cameraError: CameraErrorInfo | null;
  onRetryCamera: () => void;
  frameAnalysis: FrameQualityAnalysis | null;
  verificationState: VerificationStateSnapshot;
  scanningAction: 'TIME_IN' | 'TIME_OUT' | null;
  models: KioskModelsStatusPayload;
  productionBlocked: boolean;
  onCancelScan: () => void;
  onResetCooldown: () => void;
  onTriggerAttendance: (action: 'TIME_IN' | 'TIME_OUT') => void;
}> = ({
  videoRef,
  cameraReady,
  cameraError,
  onRetryCamera,
  frameAnalysis,
  verificationState,
  scanningAction,
  models,
  productionBlocked,
  onCancelScan,
  onResetCooldown,
  onTriggerAttendance,
}) => {
  const missingModels = !models.all_models_verified_on_disk;
  const inCooldown = verificationState.cooldownRemainingMs > 0;
  const statusHeadline = scanningAction
    ? scanningAction === 'TIME_IN'
      ? 'Verifying Time In...'
      : 'Verifying Time Out...'
    : inCooldown
      ? 'Cooldown Active'
      : 'Scanning...';
  const statusSubtext = cameraError
    ? cameraError.message
    : inCooldown
      ? verificationState.guidance
      : frameAnalysis?.guidance || verificationState.guidance || 'Please hold still';

  return (
    <div
      data-testid="kiosk-screen-04"
      className="relative flex-1 w-full bg-[#111915] overflow-hidden flex flex-col justify-between min-h-[420px]"
    >
      {/* Full-bleed front camera video layer */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className={`absolute inset-0 w-full h-full object-cover scale-x-[-1] transition-opacity duration-300 ${
          cameraReady ? 'opacity-100' : 'opacity-20'
        }`}
      />

      {/* Subtle dark vignette for high contrast on buttons & reticle */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'linear-gradient(180deg, rgba(0,0,0,0.22) 0%, rgba(0,0,0,0.06) 45%, rgba(0,0,0,0.48) 100%)',
        }}
      />

      {/* Truthful Model / Attestation Readiness Banner when models are absent */}
      {(missingModels || productionBlocked) && (
        <div
          role="status"
          data-testid="kiosk-models-warning-banner"
          className="relative z-10 mx-4 mt-3 rounded-xl bg-amber-950/90 border border-amber-400/70 px-3.5 py-2 text-xs sm:text-sm text-amber-100 flex items-center gap-2.5 backdrop-blur-sm"
        >
          <AlertTriangle className="w-4 h-4 text-amber-300 shrink-0" />
          <span className="font-medium">
            Biometric TFLite models are not deployed on this server ({missingModels ? '3/3 missing' : 'server attestation inactive'}).
            Official face verification will fail closed until verified models are installed.
          </span>
        </div>
      )}

      {/* Middle Area: Reticle + Dark Frosted Scanning Card matching Screen 04 */}
      <div className="relative z-10 flex-1 flex flex-col md:flex-row items-center justify-center gap-5 md:gap-10 px-4 sm:px-8 py-3">
        <div className="flex flex-col items-center justify-center">
          <KioskLiveFaceReticle
            active={cameraReady && !cameraError && !inCooldown}
            locked={Boolean(
              frameAnalysis?.faceDetected &&
                frameAnalysis?.centered &&
                frameAnalysis?.lightingOk &&
                frameAnalysis?.sharpnessOk &&
                !frameAnalysis?.frozenFrame
            )}
          />
          {cameraError && (
            <button
              type="button"
              onClick={onRetryCamera}
              className="mt-3 px-4 py-2 rounded-full bg-white/95 text-slate-900 font-bold text-xs sm:text-sm shadow-md hover:bg-white cursor-pointer"
            >
              Retry Camera
            </button>
          )}
        </div>

        <div className="w-full max-w-[290px] sm:max-w-[320px] rounded-3xl bg-[#101B18]/85 backdrop-blur-md border border-white/15 px-5 py-5 text-center text-white shadow-2xl">
          <div className="flex justify-center">
            <div
              className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full border-[5px] border-white/80 border-t-[#2CE63F] ${
                cameraError || inCooldown ? '' : 'animate-spin'
              }`}
              aria-hidden="true"
            />
          </div>
          <div className="mt-3 text-xl sm:text-2xl font-extrabold tracking-tight">{statusHeadline}</div>
          <p className="mt-1 text-xs sm:text-sm font-medium text-white/90 leading-snug">{statusSubtext}</p>

          {/* Unobtrusive 4-Gate Status Indicators (No fabricated percentages or raw personal biometric traces) */}
          <div
            data-testid="kiosk-verification-indicators"
            className="mt-3 grid grid-cols-2 gap-1.5 text-[11px] font-semibold"
          >
            <div
              className={`rounded-lg border px-2 py-1 flex items-center justify-between ${indicatorBadgeClass(
                verificationState.indicators.quality,
                true
              )}`}
            >
              <span>Quality</span>
              <span>{indicatorLabel(verificationState.indicators.quality)}</span>
            </div>
            <div
              className={`rounded-lg border px-2 py-1 flex items-center justify-between ${indicatorBadgeClass(
                verificationState.indicators.pad,
                true
              )}`}
            >
              <span>PAD</span>
              <span>{indicatorLabel(verificationState.indicators.pad)}</span>
            </div>
            <div
              className={`rounded-lg border px-2 py-1 flex items-center justify-between ${indicatorBadgeClass(
                verificationState.indicators.liveness,
                true
              )}`}
            >
              <span>Liveness</span>
              <span>{indicatorLabel(verificationState.indicators.liveness)}</span>
            </div>
            <div
              className={`rounded-lg border px-2 py-1 flex items-center justify-between ${indicatorBadgeClass(
                verificationState.indicators.server,
                true
              )}`}
            >
              <span>Server</span>
              <span>{indicatorLabel(verificationState.indicators.server)}</span>
            </div>
          </div>

          <div className="mt-2.5 flex items-center justify-center gap-3 text-xs">
            {inCooldown && (
              <button
                type="button"
                onClick={onResetCooldown}
                className="px-3 py-1 rounded-full bg-white/15 hover:bg-white/25 text-white font-semibold cursor-pointer"
              >
                Reset
              </button>
            )}
            <button
              type="button"
              onClick={onCancelScan}
              className="px-3 py-1 rounded-full bg-white/10 hover:bg-white/20 text-white/85 font-semibold cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Glossy TIME IN & TIME OUT Action Bar matching Screen 04 */}
      <div className="relative z-10 w-full px-4 sm:px-8 pb-5 pt-2">
        <div className="mx-auto max-w-3xl grid grid-cols-2 gap-3 sm:gap-5 rounded-full bg-white/25 backdrop-blur-md p-2 border border-white/35 shadow-xl">
          <button
            type="button"
            disabled={Boolean(scanningAction) || inCooldown}
            onClick={() => onTriggerAttendance('TIME_IN')}
            data-testid="kiosk-time-in-btn"
            className="min-h-[58px] sm:min-h-[68px] rounded-full px-4 sm:px-6 flex items-center justify-center gap-2.5 sm:gap-3.5 text-white font-extrabold text-lg sm:text-2xl tracking-wide shadow-[0_6px_14px_rgba(4,71,34,0.45),inset_0_2px_0_rgba(255,255,255,0.3)] transition-transform active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-white disabled:opacity-60 cursor-pointer"
            style={{
              background: 'linear-gradient(180deg, #169C3E 0%, #0C752F 55%, #054E1E 100%)',
            }}
          >
            <LogIn className="w-6 h-6 sm:w-8 sm:h-8 shrink-0" strokeWidth={2.6} />
            <span>TIME IN</span>
          </button>

          <button
            type="button"
            disabled={Boolean(scanningAction) || inCooldown}
            onClick={() => onTriggerAttendance('TIME_OUT')}
            data-testid="kiosk-time-out-btn"
            className="min-h-[58px] sm:min-h-[68px] rounded-full px-4 sm:px-6 flex items-center justify-center gap-2.5 sm:gap-3.5 text-[#082213] font-extrabold text-lg sm:text-2xl tracking-wide shadow-[0_6px_14px_rgba(180,120,0,0.4),inset_0_2px_0_rgba(255,255,255,0.45)] transition-transform active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#054E1E] disabled:opacity-60 cursor-pointer"
            style={{
              background: 'linear-gradient(180deg, #FFE65A 0%, #F8C61C 55%, #DFA108 100%)',
            }}
          >
            <LogOut className="w-6 h-6 sm:w-8 sm:h-8 shrink-0" strokeWidth={2.6} />
            <span>TIME OUT</span>
          </button>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// SCREENS 05 & 06 — TIME IN / TIME OUT RECORDED (05_Time_In_Success & 06_Time_Out_Success)
// ============================================================================
export const KioskAttendanceSuccessScreen: React.FC<{
  outcome: KioskAttendanceOutcome;
  onDismiss: () => void;
}> = ({ outcome, onDismiss }) => {
  const [secondsLeft, setSecondsLeft] = useState(3);

  useEffect(() => {
    setSecondsLeft(3);
    const interval = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          window.clearInterval(interval);
          onDismiss();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [outcome, onDismiss]);

  const isTimeIn = outcome.action === 'TIME_IN';
  const screenTestId = isTimeIn ? 'kiosk-screen-05' : 'kiosk-screen-06';

  return (
    <div
      data-testid={screenTestId}
      className="flex-1 flex flex-col items-center justify-center px-5 sm:px-8 py-6 text-center"
    >
      <div className="w-full max-w-md flex flex-col items-center">
        <KioskStatusCircle variant="success" />
        <h1 className="mt-4 text-2xl sm:text-4xl font-extrabold text-[#0B1210] tracking-tight">
          {isTimeIn ? 'Time In Recorded!' : 'Time Out Recorded!'}
        </h1>

        <div className="mt-5 w-full rounded-2xl border border-emerald-200 bg-white overflow-hidden shadow-sm text-left">
          <div className="bg-[#D5F2DA] px-4 py-3 flex items-center gap-3">
            <User className="w-6 h-6 text-[#0A6934] shrink-0" strokeWidth={2.4} />
            <span className="text-lg sm:text-xl font-bold text-[#0B1210] truncate">
              {outcome.employee_name}
            </span>
          </div>
          <div className="px-4 py-3.5 flex items-center gap-3">
            <Calendar className="w-6 h-6 text-[#0A6934] shrink-0" strokeWidth={2.2} />
            <div className="text-base sm:text-lg font-bold text-[#0B1210] leading-snug">
              <div>{outcome.shift_date}</div>
              <div className="font-semibold text-slate-800">
                {isTimeIn ? 'Time In' : 'Time Out'}: {outcome.recorded_time}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 w-full max-w-xs">
          <KioskPrimaryButton fullWidth onClick={onDismiss} data-testid="kiosk-success-ok-btn">
            OK ({secondsLeft})
          </KioskPrimaryButton>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// SCREEN 07 — VERIFICATION FAILED (07_Verification_Failed_610513c2.png)
// ============================================================================
export const KioskVerificationFailedScreen: React.FC<{
  failure: KioskFailureOutcome;
  cooldownSeconds?: number;
  onTryAgain: () => void;
  onCancel?: () => void;
}> = ({ failure, cooldownSeconds = 0, onTryAgain, onCancel }) => (
  <div
    data-testid="kiosk-screen-07"
    className="flex-1 flex flex-col items-center justify-center px-5 sm:px-8 py-6 text-center"
  >
    <div className="w-full max-w-md flex flex-col items-center">
      <KioskStatusCircle variant="error" />
      <h1 className="mt-4 text-2xl sm:text-4xl font-extrabold text-[#0B1210] tracking-tight">
        {failure.title || 'Verification Failed'}
      </h1>
      <p
        data-testid="kiosk-failure-message"
        className="mt-3 text-base sm:text-xl font-semibold text-slate-800 leading-snug"
      >
        {failure.message || 'Face not recognized or verification did not pass.'}
      </p>

      <div className="mt-6 w-full max-w-xs flex flex-col items-center gap-2.5">
        <KioskPrimaryButton
          fullWidth
          disabled={cooldownSeconds > 0}
          onClick={onTryAgain}
          data-testid="kiosk-try-again-btn"
        >
          {cooldownSeconds > 0 ? `Try Again (${cooldownSeconds}s)` : 'Try Again'}
        </KioskPrimaryButton>
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="text-sm font-semibold text-slate-600 hover:text-[#0A6934] py-1.5 px-3 rounded-lg cursor-pointer"
          >
            Back to Kiosk Home
          </button>
        )}
      </div>
    </div>
  </div>
);

// ============================================================================
// SCREEN 08 — NOT ENROLLED (08_Not_Enrolled_Message_2e4e7b4b.png)
// ============================================================================
export const KioskNotEnrolledScreen: React.FC<{ onDismiss: () => void }> = ({ onDismiss }) => (
  <div
    data-testid="kiosk-screen-08"
    className="flex-1 flex flex-col items-center justify-center px-5 sm:px-8 py-6 text-center"
  >
    <div className="w-full max-w-md flex flex-col items-center">
      <KioskStatusCircle variant="warning" />
      <h1 className="mt-4 text-2xl sm:text-4xl font-extrabold text-[#0B1210] tracking-tight">
        Not Enrolled
      </h1>
      <p className="mt-3 text-base sm:text-xl font-semibold text-slate-800 leading-snug">
        Your face is not yet registered in the system. Please ask the administrator to enroll your face.
      </p>

      <div className="mt-7 w-full max-w-xs">
        <KioskPrimaryButton fullWidth onClick={onDismiss} data-testid="kiosk-not-enrolled-ok-btn">
          OK
        </KioskPrimaryButton>
      </div>
    </div>
  </div>
);

// ============================================================================
// SCREEN 09 — ADMINISTRATOR ACCESS PIN MODAL (09_Admin_PIN_Access_083bf9ba.png)
// ============================================================================
export const KioskAdminPinModal: React.FC<{
  open: boolean;
  loading: boolean;
  error: string | null;
  onCancel: () => void;
  onSubmitPin: (pin: string) => Promise<void>;
}> = ({ open, loading, error, onCancel, onSubmitPin }) => {
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);

  useEffect(() => {
    if (!open) {
      setPin('');
      setShowPin(false);
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onCancel();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onCancel]);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pin.trim() || loading) return;
    await onSubmitPin(pin.trim());
  };

  return (
    <div
      data-testid="kiosk-screen-09"
      className="fixed inset-0 z-50 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="kiosk-admin-pin-title"
    >
      <form
        onSubmit={handleSubmit}
        className="relative w-full max-w-md rounded-3xl bg-white p-6 sm:p-7 shadow-2xl border border-slate-200"
      >
        <button
          type="button"
          onClick={onCancel}
          aria-label="Close Administrator Access"
          className="absolute right-4 top-4 w-10 h-10 rounded-full flex items-center justify-center text-slate-700 hover:bg-slate-100 cursor-pointer"
        >
          <X className="w-6 h-6" />
        </button>

        <h2
          id="kiosk-admin-pin-title"
          className="text-center text-2xl sm:text-3xl font-extrabold text-[#0B1210]"
        >
          Administrator Access
        </h2>

        <label
          htmlFor="kiosk-admin-pin-input"
          className="block mt-5 text-base sm:text-lg font-semibold text-slate-900"
        >
          Enter Admin PIN
        </label>

        <div className="relative mt-2">
          <input
            id="kiosk-admin-pin-input"
            type={showPin ? 'text' : 'password'}
            inputMode="numeric"
            autoComplete="off"
            maxLength={8}
            value={pin}
            onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
            placeholder="••••"
            data-testid="kiosk-admin-pin-input"
            className="w-full min-h-[54px] pl-4 pr-12 py-3 rounded-2xl border-2 border-slate-300 bg-white text-slate-900 text-xl font-bold tracking-[0.25em] focus:outline-none focus:border-[#0A6934]"
            autoFocus
          />
          <button
            type="button"
            onClick={() => setShowPin((s) => !s)}
            aria-label={showPin ? 'Hide Admin PIN' : 'Show Admin PIN'}
            className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full flex items-center justify-center text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            {showPin ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
          </button>
        </div>

        {error && (
          <div
            role="alert"
            data-testid="kiosk-admin-pin-error"
            className="mt-3 rounded-xl bg-red-50 border border-red-200 px-3.5 py-2.5 text-sm font-medium text-red-800"
          >
            {error}
          </div>
        )}

        <div className="mt-6 grid grid-cols-2 gap-3.5">
          <button
            type="button"
            onClick={onCancel}
            className="min-h-[52px] rounded-2xl border border-slate-300 bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold text-base sm:text-lg cursor-pointer"
          >
            Cancel
          </button>
          <KioskPrimaryButton
            type="submit"
            disabled={loading || pin.length < 4}
            data-testid="kiosk-admin-pin-unlock-btn"
            className="rounded-2xl min-h-[52px]"
          >
            {loading ? 'Checking...' : 'Unlock'}
          </KioskPrimaryButton>
        </div>
      </form>
    </div>
  );
};

// ============================================================================
// SCREEN 10 — ENROLLMENT SELECT EMPLOYEE (10_Enrollment_Select_Employee_ff99e6ad.png)
// ============================================================================
export const KioskEnrollSelectEmployeeScreen: React.FC<{
  employees: KioskEmployeeOption[];
  loading: boolean;
  error: string | null;
  selectedEmployeeId: number | null;
  onSelectEmployee: (emp: KioskEmployeeOption) => void;
  onSearchChange: (q: string) => void;
  onNext: (confirmReEnroll: boolean) => void;
  onCancel: () => void;
}> = ({
  employees,
  loading,
  error,
  selectedEmployeeId,
  onSelectEmployee,
  onSearchChange,
  onNext,
  onCancel,
}) => {
  const [query, setQuery] = useState('');
  const [confirmReEnrollModal, setConfirmReEnrollModal] = useState(false);

  const selectedEmployee = employees.find((e) => e.id === selectedEmployeeId) || null;

  const handleSearch = (val: string) => {
    setQuery(val);
    onSearchChange(val);
  };

  const handleNextClick = () => {
    if (!selectedEmployee) return;
    if (selectedEmployee.is_face_enrolled) {
      setConfirmReEnrollModal(true);
      return;
    }
    onNext(false);
  };

  return (
    <div
      data-testid="kiosk-screen-10"
      className="flex-1 flex flex-col items-center px-4 sm:px-8 py-4 sm:py-6 overflow-y-auto"
    >
      <div className="w-full max-w-xl flex flex-col">
        <h1 className="text-center text-2xl sm:text-3xl font-extrabold text-[#0B1210]">
          Enrollment – Select Employee
        </h1>

        {error && (
          <div role="alert" className="mt-3 rounded-xl bg-red-50 border border-red-200 px-4 py-2.5 text-sm font-medium text-red-800">
            {error}
          </div>
        )}

        {/* Dropdown Select Employee */}
        <div className="mt-4">
          <select
            aria-label="Select Employee"
            value={selectedEmployeeId ?? ''}
            onChange={(e) => {
              const id = Number(e.target.value);
              const found = employees.find((emp) => emp.id === id);
              if (found) onSelectEmployee(found);
            }}
            data-testid="kiosk-enroll-dropdown"
            className="w-full min-h-[48px] px-4 py-2.5 rounded-xl border border-slate-300 bg-white text-slate-900 font-semibold text-base focus:outline-none focus:border-[#0A6934]"
          >
            <option value="">Select Employee</option>
            {employees.map((emp) => (
              <option key={emp.id} value={emp.id}>
                {emp.employee_code} – {emp.full_name} {emp.is_face_enrolled ? '(Enrolled)' : ''}
              </option>
            ))}
          </select>
        </div>

        {/* Search Input */}
        <div className="mt-3 relative">
          <input
            type="text"
            value={query}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="Search employee (ID or name)"
            aria-label="Search employee (ID or name)"
            data-testid="kiosk-enroll-search"
            className="w-full min-h-[48px] pl-4 pr-11 py-2.5 rounded-xl border border-slate-300 bg-white text-slate-900 font-medium text-base placeholder:text-slate-500 focus:outline-none focus:border-[#0A6934]"
          />
          <Search className="w-5 h-5 text-slate-600 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>

        {/* Live Employee List */}
        <div className="mt-3.5 space-y-2 max-h-[240px] sm:max-h-[280px] overflow-y-auto pr-0.5">
          {loading ? (
            <div className="py-8 text-center text-sm font-medium text-slate-500">Loading active employees...</div>
          ) : employees.length === 0 ? (
            <div className="py-8 text-center text-sm font-medium text-slate-500">
              No active employees match your search.
            </div>
          ) : (
            employees.map((emp) => {
              const isSelected = emp.id === selectedEmployeeId;
              return (
                <button
                  key={emp.id}
                  type="button"
                  onClick={() => onSelectEmployee(emp)}
                  data-testid={`kiosk-enroll-row-${emp.employee_code}`}
                  className={`w-full min-h-[50px] px-4 py-2.5 rounded-xl border flex items-center justify-between gap-3 text-left transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-[#8FED99] border-[#4AC959] text-[#082411] font-bold shadow-xs'
                      : 'bg-white border-slate-200 hover:bg-emerald-50/50 text-slate-900 font-semibold'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <User
                      className={`w-5 h-5 shrink-0 ${isSelected ? 'text-[#085F27]' : 'text-slate-700'}`}
                      strokeWidth={2.2}
                    />
                    <span className="truncate text-sm sm:text-base">
                      {emp.employee_code} – {emp.full_name}
                    </span>
                  </div>
                  <span
                    className={`shrink-0 text-xs font-bold px-2.5 py-0.5 rounded-full ${
                      emp.is_face_enrolled
                        ? 'bg-emerald-700 text-white'
                        : 'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}
                  >
                    {emp.is_face_enrolled ? 'Enrolled' : 'Not Enrolled'}
                  </span>
                </button>
              );
            })
          )}
        </div>

        <div className="mt-5 flex items-center justify-center gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="min-h-[48px] px-6 rounded-full border border-slate-300 bg-white text-slate-800 font-bold text-base hover:bg-slate-50 cursor-pointer"
          >
            Cancel
          </button>
          <KioskPrimaryButton
            disabled={!selectedEmployee}
            onClick={handleNextClick}
            data-testid="kiosk-enroll-next-btn"
            className="min-w-[180px]"
          >
            Next
          </KioskPrimaryButton>
        </div>
      </div>

      {/* Explicit Re-Enrollment Confirmation Dialog */}
      {confirmReEnrollModal && selectedEmployee && (
        <div
          className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl border border-slate-200">
            <h2 className="text-lg font-extrabold text-slate-900">Replace Existing Face Profile?</h2>
            <p className="mt-2 text-sm text-slate-700">
              <strong>
                {selectedEmployee.full_name} ({selectedEmployee.employee_code})
              </strong>{' '}
              already has a registered face profile. Confirming will replace the existing encrypted template after fresh front-facing verification.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setConfirmReEnrollModal(false)}
                className="min-h-[46px] rounded-xl border border-slate-300 bg-slate-100 font-bold text-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <KioskPrimaryButton
                onClick={() => {
                  setConfirmReEnrollModal(false);
                  onNext(true);
                }}
                className="rounded-xl min-h-[46px]"
              >
                Confirm Re-Enroll
              </KioskPrimaryButton>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// SCREEN 11 — AUTO ENROLL SCANNING — FRONT FACE ONLY (11_Auto_Enroll_Scanning_bfbfe1fa.png)
// NO LEFT/RIGHT STEPS. NO HEAD-TURN PROMPTS. NO MANUAL CAPTURE SHUTTER BUTTON.
// ============================================================================
export const KioskAutoEnrollScanningScreen: React.FC<{
  employee: KioskEmployeeOption;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  cameraReady: boolean;
  cameraError: CameraErrorInfo | null;
  onRetryCamera: () => void;
  capturedFrames: number;
  requiredFrames: number;
  guidance: string;
  modelsMissing: boolean;
  verificationState: VerificationStateSnapshot;
  onCancel: () => void;
}> = ({
  employee,
  videoRef,
  cameraReady,
  cameraError,
  onRetryCamera,
  capturedFrames,
  requiredFrames,
  guidance,
  modelsMissing,
  verificationState,
  onCancel,
}) => (
  <div
    data-testid="kiosk-screen-11"
    className="flex-1 flex flex-col items-center justify-center px-4 sm:px-8 py-2.5 text-center"
  >
    <div className="w-full max-w-xl flex flex-col items-center">
      <h1 className="text-xl sm:text-3xl font-extrabold text-[#0B1210]">
        Auto Enroll – Scanning
      </h1>
      <p className="mt-0.5 text-xs sm:text-sm font-semibold text-[#0A6934]">
        {employee.employee_code} – {employee.full_name} · Front Face Only ({capturedFrames}/{requiredFrames} frames)
      </p>

      {/* Rounded Centered Live Front Camera Feed with Green Corner Reticle */}
      <div className="relative mt-2 w-full max-w-[360px] aspect-[16/10] max-h-[215px] rounded-3xl overflow-hidden bg-[#15201B] border-2 border-slate-200 shadow-lg flex items-center justify-center">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className={`w-full h-full object-cover scale-x-[-1] ${cameraReady ? 'opacity-100' : 'opacity-25'}`}
        />
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none scale-90">
          <KioskLiveFaceReticle active={cameraReady && !cameraError} locked={capturedFrames > 0} />
        </div>
        {cameraError && (
          <div className="absolute inset-0 bg-slate-950/80 flex flex-col items-center justify-center p-4 text-white">
            <AlertTriangle className="w-8 h-8 text-amber-400 mb-2" />
            <p className="text-sm font-medium max-w-xs">{cameraError.message}</p>
            <button
              type="button"
              onClick={onRetryCamera}
              className="mt-3 px-4 py-2 rounded-full bg-white text-slate-900 font-bold text-xs cursor-pointer"
            >
              Retry Camera
            </button>
          </div>
        )}
      </div>

      {/* Compact Unobtrusive Status Strip (Quality / PAD / Liveness / Server) */}
      <div className="mt-2 flex flex-wrap items-center justify-center gap-1.5 text-[11px] font-semibold">
        <span className={`px-2 py-0.5 rounded-md border ${indicatorBadgeClass(verificationState.indicators.quality, false)}`}>
          Quality: {indicatorLabel(verificationState.indicators.quality)}
        </span>
        <span className={`px-2 py-0.5 rounded-md border ${indicatorBadgeClass(verificationState.indicators.pad, false)}`}>
          PAD: {indicatorLabel(verificationState.indicators.pad)}
        </span>
        <span className={`px-2 py-0.5 rounded-md border ${indicatorBadgeClass(verificationState.indicators.liveness, false)}`}>
          Liveness: {indicatorLabel(verificationState.indicators.liveness)}
        </span>
        <span className={`px-2 py-0.5 rounded-md border ${indicatorBadgeClass(verificationState.indicators.server, false)}`}>
          Server: {indicatorLabel(verificationState.indicators.server)}
        </span>
      </div>

      <p className="mt-1.5 text-base sm:text-lg font-bold text-[#0B1210] max-w-md leading-snug">
        Hold still while the system automatically captures your face.
      </p>
      <p className="mt-0.5 text-xs sm:text-sm font-medium text-slate-600 max-w-lg">
        {modelsMissing
          ? 'Verified TFLite biometric models are missing on this server — live enrollment cannot be finalized until models are installed.'
          : guidance}
      </p>

      <button
        type="button"
        onClick={onCancel}
        className="mt-2 min-h-[42px] px-6 rounded-full border border-slate-300 bg-white text-slate-700 font-semibold text-sm hover:bg-slate-50 cursor-pointer"
      >
        Cancel Enrollment
      </button>
    </div>
  </div>
);

// ============================================================================
// SCREEN 12 — AUTO ENROLL PROCESSING (12_Auto_Enroll_Progress_21ba2688.png)
// ============================================================================
export const KioskAutoEnrollProcessingScreen: React.FC<{
  progressPercent: number;
  stageLabel: string;
}> = ({ progressPercent, stageLabel }) => {
  const clamped = Math.max(0, Math.min(100, Math.round(progressPercent)));
  const radius = 56;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference - (clamped / 100) * circumference;

  return (
    <div
      data-testid="kiosk-screen-12"
      className="flex-1 flex flex-col items-center justify-center px-5 sm:px-8 py-6 text-center"
    >
      <div className="w-full max-w-lg flex flex-col items-center">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#0B1210]">
          Auto Enroll – Processing
        </h1>

        <div className="relative mt-5 w-36 h-36 flex items-center justify-center">
          <svg viewBox="0 0 132 132" className="w-full h-full -rotate-90" aria-hidden="true">
            <circle cx="66" cy="66" r={radius} stroke="#E2E8F0" strokeWidth="8" fill="none" />
            <circle
              cx="66"
              cy="66"
              r={radius}
              stroke="#17A34A"
              strokeWidth="8"
              strokeLinecap="round"
              fill="none"
              strokeDasharray={circumference}
              strokeDashoffset={dashOffset}
              className="transition-all duration-300"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <KioskFaceFrameIcon className="w-16 h-16" />
          </div>
        </div>

        <h2 className="mt-4 text-xl sm:text-2xl font-extrabold text-[#0B1210]">
          Processing Enrollment...
        </h2>
        <p className="mt-1.5 text-sm sm:text-base font-semibold text-slate-800 max-w-md">
          {stageLabel || 'Automatically capturing and registering your face. Please do not move.'}
        </p>

        {/* Horizontal Progress Bar matching Screen 12 */}
        <div className="mt-5 w-full flex items-center gap-3.5">
          <div className="flex-1 h-5 rounded-full bg-slate-200 overflow-hidden shadow-inner">
            <div
              className="h-full rounded-full transition-all duration-300"
              style={{
                width: `${clamped}%`,
                background: 'linear-gradient(90deg, #096C2B 0%, #17A942 100%)',
              }}
            />
          </div>
          <span className="font-extrabold text-lg sm:text-xl text-[#0B1210] w-14 text-right">
            {clamped}%
          </span>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// SCREEN 13 — ENROLLMENT COMPLETED (13_Enrollment_Successful_e71a7bdf.png)
// ONLY shown after real backend 201 + DB read-back confirmation!
// ============================================================================
export const KioskEnrollmentSuccessScreen: React.FC<{
  employeeName: string;
  employeeCode: string;
  onDone: () => void;
}> = ({ employeeName, employeeCode, onDone }) => (
  <div
    data-testid="kiosk-screen-13"
    className="flex-1 flex flex-col items-center justify-center px-5 sm:px-8 py-6 text-center"
  >
    <div className="w-full max-w-lg flex flex-col items-center">
      <KioskStatusCircle variant="success" />
      <h1 className="mt-4 text-2xl sm:text-4xl font-extrabold text-[#0B1210] tracking-tight">
        Enrollment Completed!
      </h1>

      <div className="mt-4 w-full rounded-2xl bg-[#D6F3DB] border border-emerald-200 px-5 py-3.5 flex items-center justify-center gap-3">
        <User className="w-6 h-6 text-[#0A6934] shrink-0" strokeWidth={2.4} />
        <span className="text-lg sm:text-xl font-bold text-[#0B1210]">
          {employeeName} ({employeeCode})
        </span>
      </div>

      <p className="mt-4 text-sm sm:text-lg font-semibold text-slate-800 max-w-md leading-snug">
        Face profile has been successfully registered. You can now use the kiosk for attendance.
      </p>

      <div className="mt-6 w-full max-w-xs">
        <KioskPrimaryButton fullWidth onClick={onDone} data-testid="kiosk-enroll-done-btn">
          OK
        </KioskPrimaryButton>
      </div>
    </div>
  </div>
);

// ============================================================================
// SCREEN 14 — KIOSK SETTINGS (14_Kiosk_Settings_14ac64e6.png)
// ============================================================================
export const KioskSettingsScreen: React.FC<{
  settings: KioskSettingsState;
  saving: boolean;
  syncing: boolean;
  notice: { type: 'ok' | 'err'; text: string } | null;
  onUpdateSetting: (patch: Partial<Pick<KioskSettingsState, 'face_capture_enabled' | 'liveness_enforced' | 'voice_prompt_enabled'>>) => void;
  onOpenInfo: () => void;
  onSyncNow: () => void;
  onTestSpeaker: () => void;
  speakerTesting: boolean;
  onStartEnrollment: () => void;
  onLockAndReturn: () => void;
  onDeactivateDevice: () => void;
}> = ({
  settings,
  saving,
  syncing,
  notice,
  onUpdateSetting,
  onOpenInfo,
  onSyncNow,
  onTestSpeaker,
  speakerTesting,
  onStartEnrollment,
  onLockAndReturn,
  onDeactivateDevice,
}) => (
  <div
    data-testid="kiosk-screen-14"
    className="flex-1 flex flex-col items-center px-4 sm:px-8 py-4 sm:py-6 overflow-y-auto"
  >
    <div className="w-full max-w-xl flex flex-col">
      <h1 className="text-center text-2xl sm:text-3xl font-extrabold text-[#0B1210]">
        Kiosk Settings
      </h1>

      {notice && (
        <div
          role="status"
          className={`mt-3 rounded-xl px-4 py-2.5 text-sm font-medium border ${
            notice.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          {notice.text}
        </div>
      )}

      {/* 5 Stacked Bordered Setting Rows matching Screen 14 */}
      <div className="mt-4 space-y-2.5">
        <div className="min-h-[58px] rounded-2xl border border-slate-300 bg-white px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3.5 min-w-0">
            <Camera className="w-6 h-6 text-[#0B1210] shrink-0" />
            <span className="text-base sm:text-lg font-bold text-[#0B1210]">Face Capture</span>
          </div>
          <KioskToggleSwitch
            checked={settings.face_capture_enabled}
            disabled={saving}
            ariaLabel="Toggle Face Capture"
            onChange={(val) => onUpdateSetting({ face_capture_enabled: val })}
          />
        </div>

        <div className="min-h-[58px] rounded-2xl border border-slate-300 bg-white px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3.5 min-w-0">
            <ShieldCheck className="w-6 h-6 text-[#0B1210] shrink-0" />
            <div>
              <div className="text-base sm:text-lg font-bold text-[#0B1210] leading-tight">
                Liveness / Anti-Spoofing
              </div>
              {settings.liveness_locked_by_policy && (
                <div className="text-xs font-medium text-emerald-800">
                  Enforced by production security policy
                </div>
              )}
            </div>
          </div>
          <KioskToggleSwitch
            checked={settings.liveness_enforced}
            disabled={saving || settings.liveness_locked_by_policy}
            ariaLabel="Toggle Liveness and Anti-Spoofing"
            onChange={(val) => onUpdateSetting({ liveness_enforced: val })}
          />
        </div>

        <div className="min-h-[58px] rounded-2xl border border-slate-300 bg-white px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3.5 min-w-0">
            <Volume2 className="w-6 h-6 text-[#0B1210] shrink-0" />
            <span className="text-base sm:text-lg font-bold text-[#0B1210]">
              Voice Prompt (Time In/Out Only)
            </span>
          </div>
          <KioskToggleSwitch
            checked={settings.voice_prompt_enabled}
            disabled={saving}
            ariaLabel="Toggle Voice Prompt for Time In and Out Only"
            onChange={(val) => onUpdateSetting({ voice_prompt_enabled: val })}
          />
        </div>

        {/* Additional admin-only speaker diagnostic; does not change attendance voice policy. */}
        <button
          type="button"
          onClick={onTestSpeaker}
          disabled={speakerTesting}
          data-testid="kiosk-speaker-test-btn"
          className="w-full min-h-[58px] rounded-2xl border border-slate-300 bg-white hover:bg-emerald-50/40 px-4 py-3 flex items-center justify-between gap-3 text-left disabled:opacity-60 cursor-pointer"
        >
          <div className="flex items-center gap-3.5">
            <Volume2 className="w-6 h-6 text-[#0B1210] shrink-0" />
            <span className="text-base sm:text-lg font-bold text-[#0B1210]">{speakerTesting ? 'Testing Speaker...' : 'Test Speaker'}</span>
          </div>
          <ChevronRight className="w-6 h-6 text-slate-700" />
        </button>

        <button
          type="button"
          onClick={onOpenInfo}
          data-testid="kiosk-open-info-btn"
          className="w-full min-h-[58px] rounded-2xl border border-slate-300 bg-white hover:bg-emerald-50/40 px-4 py-3 flex items-center justify-between gap-3 text-left cursor-pointer"
        >
          <div className="flex items-center gap-3.5">
            <Monitor className="w-6 h-6 text-[#0B1210] shrink-0" />
            <span className="text-base sm:text-lg font-bold text-[#0B1210]">Kiosk Information</span>
          </div>
          <ChevronRight className="w-6 h-6 text-slate-700" />
        </button>

        <button
          type="button"
          onClick={onSyncNow}
          disabled={syncing}
          data-testid="kiosk-sync-now-btn"
          className="w-full min-h-[58px] rounded-2xl border border-slate-300 bg-white hover:bg-emerald-50/40 px-4 py-3 flex items-center justify-between gap-3 text-left disabled:opacity-60 cursor-pointer"
        >
          <div className="flex items-center gap-3.5">
            <RefreshCw className={`w-6 h-6 text-[#0B1210] shrink-0 ${syncing ? 'animate-spin' : ''}`} />
            <span className="text-base sm:text-lg font-bold text-[#0B1210]">
              {syncing ? 'Syncing with Server...' : 'Sync Now'}
            </span>
          </div>
          <ChevronRight className="w-6 h-6 text-slate-700" />
        </button>
      </div>

      {/* Admin Controls Row */}
      <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
        <KioskPrimaryButton onClick={onStartEnrollment} data-testid="kiosk-settings-enroll-btn">
          <span className="inline-flex items-center gap-2">
            <UserPlus className="w-5 h-5" />
            <span>Enroll Employee</span>
          </span>
        </KioskPrimaryButton>

        <button
          type="button"
          onClick={onLockAndReturn}
          className="min-h-[48px] px-5 rounded-full border border-slate-300 bg-white hover:bg-slate-100 text-slate-800 font-bold text-sm sm:text-base cursor-pointer"
        >
          Lock &amp; Return
        </button>

        <button
          type="button"
          onClick={onDeactivateDevice}
          className="min-h-[48px] px-4 rounded-full border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 font-semibold text-xs sm:text-sm cursor-pointer"
        >
          Deactivate Kiosk
        </button>
      </div>
    </div>
  </div>
);

// ============================================================================
// SCREEN 15 — KIOSK INFORMATION (15_Kiosk_Information_Status_9064415b.png)
// ============================================================================
export const KioskInformationScreen: React.FC<{
  device: KioskDeviceInfo;
  online: boolean;
  models: KioskModelsStatusPayload;
  cameraHealth: string;
  onBack: () => void;
}> = ({ device, online, models, cameraHealth, onBack }) => {
  const verifiedCount = Object.values(models.models).filter((m) => m.status === 'VERIFIED_ON_DISK').length;

  return (
    <div
      data-testid="kiosk-screen-15"
      className="flex-1 flex flex-col items-center justify-center px-4 sm:px-8 py-3 overflow-y-auto"
    >
      <div className="w-full max-w-xl flex flex-col items-center">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-[#09672F] text-white flex items-center justify-center font-extrabold text-base">
            i
          </div>
          <h1 className="text-xl sm:text-3xl font-extrabold text-[#0B1210]">
            Kiosk Information
          </h1>
        </div>

        <div className="mt-3 w-full rounded-2xl border border-slate-300 bg-white overflow-hidden divide-y divide-slate-200 shadow-xs">
          <div className="px-5 py-2 flex items-center justify-between gap-4 text-sm sm:text-base">
            <span className="font-semibold text-slate-800">Device Name</span>
            <span className="font-extrabold text-[#0B1210] text-right">{device.name}</span>
          </div>
          <div className="px-5 py-2 flex items-center justify-between gap-4 text-sm sm:text-base">
            <span className="font-semibold text-slate-800">Device ID</span>
            <span className="font-extrabold text-[#0B1210] text-right">{device.device_code}</span>
          </div>
          <div className="px-5 py-2 flex items-center justify-between gap-4 text-sm sm:text-base">
            <span className="font-semibold text-slate-800">Status</span>
            <span className="inline-flex items-center gap-2 font-extrabold text-[#0B1210]">
              <span
                className={`w-3 h-3 rounded-full ${online ? 'bg-[#17A34A]' : 'bg-red-500'}`}
              />
              <span>{online ? 'Online' : 'Offline'}</span>
            </span>
          </div>
          <div className="px-5 py-2 flex items-center justify-between gap-4 text-sm sm:text-base">
            <span className="font-semibold text-slate-800">Last Sync</span>
            <span className="font-extrabold text-[#0B1210] text-right">{device.last_sync_display}</span>
          </div>
          <div className="px-5 py-2 flex items-center justify-between gap-4 text-sm sm:text-base">
            <span className="font-semibold text-slate-800">Version</span>
            <span className="font-extrabold text-[#0B1210] text-right">{device.version}</span>
          </div>
          <div className="px-5 py-2 flex items-center justify-between gap-4 text-xs sm:text-sm bg-slate-50/70">
            <span className="font-semibold text-slate-700">Camera Status</span>
            <span className="font-bold text-slate-900 capitalize text-right">{cameraHealth}</span>
          </div>
          <div className="px-5 py-2 flex items-center justify-between gap-4 text-xs sm:text-sm bg-slate-50/70">
            <span className="font-semibold text-slate-700">Biometric Models</span>
            <span
              className={`font-bold text-right ${
                verifiedCount === 3 && models.server_inference_available ? 'text-emerald-700' : 'text-amber-700'
              }`}
            >
              {verifiedCount}/3 Verified on Disk · Server Inference: {models.server_inference_available ? 'Active' : 'Not Deployed'}
            </span>
          </div>
        </div>

        <div className="mt-4 w-full max-w-xs">
          <KioskPrimaryButton fullWidth onClick={onBack} data-testid="kiosk-info-back-btn">
            Back
          </KioskPrimaryButton>
        </div>
      </div>
    </div>
  );
};
