import React from 'react';
import { Settings } from 'lucide-react';

export const KIOSK_SHIELD_LOGO_SRC = '/assets/aistudio/Savage-Rsucaj_Attendance_Shield_bca5b40c.png';

/**
 * Approved SAVAGE-RSUCAJ Web Kiosk Top Header (matching Screens 02–16 PNG references):
 * Deep emerald green gradient bar, curved golden wave bottom edge, original uncropped shield logo,
 * bold SAVAGE-RSUCAJ + SMART ATTENDANCE SYSTEM branding, live Online/Offline dot, and Settings gear icon.
 */
export const KioskHeader: React.FC<{
  online: boolean;
  statusLabel?: string;
  onOpenSettings?: () => void;
  onLogoClick?: () => void;
  showWave?: boolean;
  settingsDisabled?: boolean;
}> = ({
  online,
  statusLabel,
  onOpenSettings,
  onLogoClick,
  showWave = true,
  settingsDisabled = false,
}) => {
  const effectiveLabel = statusLabel || (online ? 'Online' : 'Offline');

  return (
    <header className="relative w-full shrink-0 select-none z-20">
      <div
        className="relative px-4 sm:px-6 pt-3 pb-4 sm:py-3.5 flex items-center justify-between gap-3"
        style={{
          background: 'linear-gradient(135deg, #044722 0%, #0A6934 52%, #054924 100%)',
        }}
      >
        <button
          type="button"
          onClick={onLogoClick}
          disabled={!onLogoClick}
          className={`flex items-center gap-2.5 sm:gap-3 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F6C820] rounded-lg ${
            onLogoClick ? 'cursor-pointer' : 'cursor-default'
          }`}
        >
          <img
            src={KIOSK_SHIELD_LOGO_SRC}
            alt="SAVAGE-RSUCAJ Attendance Shield"
            className="w-10 h-10 sm:w-12 sm:h-12 object-contain shrink-0 drop-shadow-[0_2px_4px_rgba(0,0,0,0.35)]"
          />
          <div className="leading-tight">
            <div className="text-white font-extrabold tracking-wide text-base sm:text-xl leading-none">
              SAVAGE-RSUCAJ
            </div>
            <div className="text-emerald-100/95 font-semibold tracking-[0.06em] text-[10px] sm:text-xs mt-1 uppercase">
              SMART ATTENDANCE SYSTEM
            </div>
          </div>
        </button>

        <div className="flex items-center gap-3 sm:gap-4 shrink-0">
          <div
            className="flex items-center gap-2 text-white font-semibold text-sm sm:text-base"
            aria-live="polite"
            data-testid="kiosk-online-indicator"
          >
            <span
              className={`inline-block w-3.5 h-3.5 rounded-full shadow-[0_0_8px_rgba(34,197,94,0.8)] ${
                online
                  ? 'bg-[#2CE63F] ring-2 ring-[#2CE63F]/30'
                  : 'bg-red-500 ring-2 ring-red-400/35 shadow-[0_0_8px_rgba(239,68,68,0.75)]'
              }`}
            />
            <span>{effectiveLabel}</span>
          </div>

          {onOpenSettings && (
            <button
              type="button"
              onClick={onOpenSettings}
              disabled={settingsDisabled}
              aria-label="Kiosk Settings"
              title="Kiosk Settings (Administrator PIN required)"
              data-testid="kiosk-settings-btn"
              className="w-11 h-11 rounded-full flex items-center justify-center text-white hover:bg-white/15 active:bg-white/25 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F6C820] cursor-pointer disabled:opacity-40"
            >
              <Settings className="w-6 h-6 sm:w-7 sm:h-7" strokeWidth={2.2} />
            </button>
          )}
        </div>
      </div>

      {/* Signature curved gold/emerald decorative ribbon matching Screens 02–16 */}
      {showWave && (
        <div className="relative w-full h-5 sm:h-6 -mt-1 overflow-hidden pointer-events-none" aria-hidden="true">
          <svg
            viewBox="0 0 1200 44"
            preserveAspectRatio="none"
            className="w-full h-full block"
          >
            <defs>
              <linearGradient id="kioskHeaderGold" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#E6A909" />
                <stop offset="50%" stopColor="#FCD835" />
                <stop offset="100%" stopColor="#E4A708" />
              </linearGradient>
            </defs>
            {/* Emerald curved top */}
            <path d="M0,0 L1200,0 L1200,26 Q860,-6 430,18 Q180,32 0,14 Z" fill="#06532A" />
            {/* Gold accent band underneath */}
            <path
              d="M0,14 Q180,32 430,18 Q860,-6 1200,26 L1200,36 Q860,4 430,28 Q180,42 0,24 Z"
              fill="url(#kioskHeaderGold)"
            />
          </svg>
        </div>
      )}
    </header>
  );
};

/**
 * Approved Glossy Forest-Emerald Primary Pill Button matching Screens 02, 05, 06, 07, 08, 09, 10, 13, 15.
 */
export const KioskPrimaryButton: React.FC<
  React.ButtonHTMLAttributes<HTMLButtonElement> & { fullWidth?: boolean }
> = ({ children, className = '', fullWidth = false, ...props }) => (
  <button
    type="button"
    {...props}
    className={`min-h-[48px] px-8 py-3 rounded-full font-bold text-white text-base sm:text-lg tracking-wide shadow-[0_6px_14px_rgba(6,78,41,0.32),inset_0_1px_0_rgba(255,255,255,0.28)] transition-all active:scale-[0.985] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F6C820] focus-visible:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer ${
      fullWidth ? 'w-full' : ''
    } ${className}`}
    style={{
      background: 'linear-gradient(180deg, #16943B 0%, #0C712D 55%, #064D1E 100%)',
    }}
  >
    {children}
  </button>
);

/**
 * Approved Corner-Bracket Face Frame Icon (used in Screens 03, 12, 16).
 */
export const KioskFaceFrameIcon: React.FC<{ className?: string }> = ({ className = 'w-20 h-20' }) => (
  <svg viewBox="0 0 96 96" fill="none" className={className} aria-hidden="true">
    {/* Four rounded emerald corner brackets */}
    <path
      d="M12 32V18C12 14.686 14.686 12 18 12H32"
      stroke="#0C7B32"
      strokeWidth="5.5"
      strokeLinecap="round"
    />
    <path
      d="M64 12H78C81.314 12 84 14.686 84 18V32"
      stroke="#0C7B32"
      strokeWidth="5.5"
      strokeLinecap="round"
    />
    <path
      d="M12 64V78C12 81.314 14.686 84 18 84H32"
      stroke="#0C7B32"
      strokeWidth="5.5"
      strokeLinecap="round"
    />
    <path
      d="M64 84H78C81.314 84 84 81.314 84 78V64"
      stroke="#0C7B32"
      strokeWidth="5.5"
      strokeLinecap="round"
    />
    {/* Person head + shoulders silhouette */}
    <defs>
      <linearGradient id="kioskPersonGrad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#17A34A" />
        <stop offset="100%" stopColor="#086E2E" />
      </linearGradient>
    </defs>
    <circle cx="48" cy="40" r="16" fill="url(#kioskPersonGrad)" />
    <path
      d="M27 72C27 62.5 36.4 57 48 57C59.6 57 69 62.5 69 72C69 73.657 67.657 75 66 75H30C28.343 75 27 73.657 27 72Z"
      fill="url(#kioskPersonGrad)"
    />
  </svg>
);

/**
 * Approved Status Circle Badge (Green Check / Red X / Gold Info) matching Screens 05, 06, 07, 08, 13.
 */
export const KioskStatusCircle: React.FC<{ variant: 'success' | 'error' | 'warning' }> = ({ variant }) => {
  if (variant === 'success') {
    return (
      <div
        className="w-20 h-20 sm:w-24 sm:h-24 rounded-full flex items-center justify-center shadow-[0_8px_18px_rgba(16,138,54,0.35)]"
        style={{ background: 'linear-gradient(180deg, #17A942 0%, #0B7A2C 100%)' }}
        aria-hidden="true"
      >
        <svg viewBox="0 0 48 48" className="w-12 h-12 sm:w-14 sm:h-14" fill="none">
          <path
            d="M12 25L21 34L37 16"
            stroke="#FFFFFF"
            strokeWidth="5.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
    );
  }
  if (variant === 'error') {
    return (
      <div
        className="w-20 h-20 sm:w-24 sm:h-24 rounded-full flex items-center justify-center shadow-[0_8px_18px_rgba(220,38,38,0.35)]"
        style={{ background: 'linear-gradient(180deg, #F03527 0%, #C81D15 100%)' }}
        aria-hidden="true"
      >
        <svg viewBox="0 0 48 48" className="w-11 h-11 sm:w-12 sm:h-12" fill="none">
          <path
            d="M15 15L33 33M33 15L15 33"
            stroke="#FFFFFF"
            strokeWidth="5.5"
            strokeLinecap="round"
          />
        </svg>
      </div>
    );
  }
  return (
    <div
      className="w-20 h-20 sm:w-24 sm:h-24 rounded-full flex items-center justify-center shadow-[0_8px_18px_rgba(217,153,8,0.35)]"
      style={{ background: 'linear-gradient(180deg, #FBC91E 0%, #DF9D07 100%)' }}
      aria-hidden="true"
    >
      <svg viewBox="0 0 48 48" className="w-11 h-11 sm:w-12 sm:h-12" fill="none">
        <circle cx="24" cy="14" r="3.2" fill="#FFFFFF" />
        <rect x="21" y="21" width="6" height="16" rx="3" fill="#FFFFFF" />
      </svg>
    </div>
  );
};

/**
 * Approved Kiosk Toggle Switch matching Screen 14 (Kiosk Settings).
 */
export const KioskToggleSwitch: React.FC<{
  checked: boolean;
  disabled?: boolean;
  ariaLabel: string;
  onChange: (next: boolean) => void;
}> = ({ checked, disabled = false, ariaLabel, onChange }) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    aria-label={ariaLabel}
    disabled={disabled}
    onClick={() => !disabled && onChange(!checked)}
    className={`relative inline-flex h-8 w-16 shrink-0 items-center rounded-full p-1 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0A6934] focus-visible:ring-offset-2 ${
      disabled ? 'opacity-65 cursor-not-allowed' : 'cursor-pointer'
    }`}
    style={{
      background: checked
        ? 'linear-gradient(180deg, #169E3D 0%, #0A6F2B 100%)'
        : '#CBD5E1',
    }}
  >
    <span
      className={`inline-block h-6 w-6 transform rounded-full bg-white shadow-md transition-transform ${
        checked ? 'translate-x-8' : 'translate-x-0'
      }`}
    />
  </button>
);

/**
 * Green corner-bracket live frontal face reticle overlaid on camera feed (Screens 04 & 11).
 */
export const KioskLiveFaceReticle: React.FC<{ active?: boolean; locked?: boolean }> = ({
  active = true,
  locked = false,
}) => {
  const stroke = locked ? '#22FF55' : active ? '#2CE63F' : '#FACC15';
  return (
    <div className="pointer-events-none relative w-52 h-56 sm:w-64 sm:h-64" aria-hidden="true">
      <svg viewBox="0 0 240 240" className="w-full h-full drop-shadow-[0_0_10px_rgba(34,230,63,0.65)]" fill="none">
        {/* Top-left */}
        <path d="M16 74V34C16 24 24 16 34 16H74" stroke={stroke} strokeWidth="7" strokeLinecap="round" />
        {/* Top-right */}
        <path d="M166 16H206C216 16 224 24 224 34V74" stroke={stroke} strokeWidth="7" strokeLinecap="round" />
        {/* Bottom-left */}
        <path d="M16 166V206C16 216 24 224 34 224H74" stroke={stroke} strokeWidth="7" strokeLinecap="round" />
        {/* Bottom-right */}
        <path d="M166 224H206C216 224 224 216 224 206V166" stroke={stroke} strokeWidth="7" strokeLinecap="round" />
        {/* Subtle vertical alignment side guides matching Screens 04 & 11 */}
        <line x1="16" y1="92" x2="16" y2="148" stroke={stroke} strokeWidth="3" strokeOpacity="0.6" strokeLinecap="round" />
        <line x1="224" y1="92" x2="224" y2="148" stroke={stroke} strokeWidth="3" strokeOpacity="0.6" strokeLinecap="round" />
      </svg>
    </div>
  );
};
