import type { KioskModelsStatusPayload } from '../../lib/kioskBiometrics';

export type KioskScreenId =
  | 'splash'
  | 'activation'
  | 'ready_home'
  | 'attendance_ready'
  | 'face_scanning'
  | 'time_in_success'
  | 'time_out_success'
  | 'verification_failed'
  | 'not_enrolled'
  | 'enroll_select_employee'
  | 'enroll_scanning'
  | 'enroll_processing'
  | 'enroll_success'
  | 'settings'
  | 'kiosk_info';

export type KioskAdminIntent = 'settings' | 'enrollment';

export interface KioskDeviceInfo {
  id: number;
  device_code: string;
  name: string;
  device_type: string;
  model_info: string;
  location: string;
  status: string;
  last_heartbeat: string;
  last_heartbeat_utc: string | null;
  last_sync_utc: string | null;
  last_sync_display: string;
  version: string;
  camera_health: string;
}

export interface KioskSettingsState {
  face_capture_enabled: boolean;
  liveness_enforced: boolean;
  liveness_locked_by_policy: boolean;
  voice_prompt_enabled: boolean;
}

export interface KioskSessionResponse {
  activated: boolean;
  csrf_token?: string;
  app_mode: 'production' | 'staging' | 'demo' | 'test';
  device?: KioskDeviceInfo;
  settings?: KioskSettingsState;
  admin_unlocked?: boolean;
  admin_unlocked_until?: number | null;
  admin_pin_configured?: boolean;
  enrolled_employee_count?: number;
  models: KioskModelsStatusPayload;
  biometric_policy?: {
    require_server_biometric_attestation: boolean;
    production_attendance_blocked: boolean;
    production_block_reason: string | null;
  };
  server_time_utc: string;
}

export interface KioskEmployeeOption {
  id: number;
  employee_code: string;
  full_name: string;
  department: string;
  position: string;
  is_face_enrolled: boolean;
  enrolled_at_utc: string | null;
}

export interface KioskAttendanceOutcome {
  action: 'TIME_IN' | 'TIME_OUT';
  employee_name: string;
  employee_code: string;
  shift_date: string;
  recorded_time: string;
  status: string;
}

export interface KioskFailureOutcome {
  title: string;
  message: string;
  code: string;
  alreadyTaken?: boolean;
}
