import React, { useEffect, useState, useCallback } from 'react';
import {
  Users,
  Search,
  Upload,
  Download,
  Plus,
  Pencil,
  Trash2,
  Eye,
  Power,
  ChevronLeft,
  ChevronRight,
  AlertCircle,
  UserPlus,
} from 'lucide-react';
import { ModuleFrame, Modal, ConfirmModal, StatusLabel } from './ModuleFrame';
import { apiFetch, downloadCsv, formatDisplayDate, formatPeso } from '../lib/api';
import type { AuthUser, Department, Employee, Position, Shift } from '../types';

export const EmployeesView: React.FC<{ currentUser?: AuthUser }> = ({ currentUser }) => {
  const canWriteEmployees = !currentUser || currentUser.permissions?.includes('employees:write') === true;
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const limit = 8;

  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('');
  const [departments, setDepartments] = useState<Department[]>([]);
  const [positions, setPositions] = useState<Position[]>([]);
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Add/Edit Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Employee | null>(null);
  const [viewing, setViewing] = useState<Employee | null>(null);
  const [deleting, setDeleting] = useState<Employee | null>(null);

  const [form, setForm] = useState({
    employee_code: '',
    full_name: '',
    email: '',
    department_id: '',
    position_id: '',
    shift_id: '',
    status: 'Active' as 'Active' | 'Inactive',
    hired_date: new Date().toISOString().slice(0, 10),
    monthly_salary: '30000',
    monthly_allowance: '2000',
  });
  const [saving, setSaving] = useState(false);
  const [accountEmployee, setAccountEmployee] = useState<Employee | null>(null);
  const [accountForm, setAccountForm] = useState({ username: '', email: '', password: '' });
  const [creatingAccount, setCreatingAccount] = useState(false);
  const canCreateAccounts = Boolean(currentUser?.permissions?.includes('users:manage'));

  const openCreateAccount = (emp: Employee) => {
    setAccountEmployee(emp);
    setAccountForm({
      username: emp.employee_code.toLowerCase().replace(/[^a-z0-9._-]/g, ''),
      email: emp.email || '',
      password: '',
    });
    setFeedback(null);
  };
  const createEmployeeAccount = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!accountEmployee || !canCreateAccounts) return;
    setCreatingAccount(true);
    setFeedback(null);
    try {
      await apiFetch('/api/users', { method: 'POST', body: JSON.stringify({
        username: accountForm.username.trim(),
        email: accountForm.email.trim(),
        full_name: accountEmployee.full_name,
        role: 'Employee',
        employee_id: accountEmployee.id,
        password: accountForm.password,
        must_change_password: true,
      }) });
      setFeedback({ type: 'ok', text: `Employee login created for ${accountEmployee.full_name}. Share the initial credentials securely; password change is required on first login.` });
      setAccountEmployee(null);
      setAccountForm({ username: '', email: '', password: '' });
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to create employee login.' });
    } finally { setCreatingAccount(false); }
  };

  // Import CSV Modal
  const [importOpen, setImportOpen] = useState(false);
  const [csvText, setCsvText] = useState(
    'employee_code,full_name,email,department_code,position_code,status\nEMP-2025-019,Villareal, Jose R.,jose.villareal@rsucaj.edu.ph,BSIT,INST,Active'
  );
  const [importing, setImporting] = useState(false);

  const loadMeta = useCallback(async () => {
    try {
      const [d, p, s] = await Promise.all([
        apiFetch<{ data: Department[] }>('/api/departments'),
        apiFetch<{ data: Position[] }>('/api/positions'),
        apiFetch<{ data: Shift[] }>('/api/shifts'),
      ]);
      setDepartments(d.data);
      setPositions(p.data);
      setShifts(s.data);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to load employee settings.' });
    }
  }, []);

  const loadEmployees = useCallback(async () => {
    setLoading(true);
    try {
      const qs = new URLSearchParams({
        page: String(page),
        limit: String(limit),
      });
      if (search.trim()) qs.set('search', search.trim());
      if (deptFilter) qs.set('department_id', deptFilter);
      const res = await apiFetch<{ data: Employee[]; total: number }>(`/api/employees?${qs.toString()}`);
      setEmployees(res.data);
      setTotal(res.total);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to load employees.' });
    } finally {
      setLoading(false);
    }
  }, [page, search, deptFilter]);

  useEffect(() => {
    loadMeta();
  }, [loadMeta]);

  useEffect(() => {
    loadEmployees();
  }, [loadEmployees]);

  const openAdd = () => {
    setEditing(null);
    const defaultPos = positions[0];
    setForm({
      employee_code: `EMP-${new Date().getFullYear()}-${String(total + 1).padStart(3, '0')}`,
      full_name: '',
      email: '',
      department_id: String(departments[0]?.id || ''),
      position_id: String(defaultPos?.id || ''),
      shift_id: String(shifts[0]?.id || ''),
      status: 'Active',
      hired_date: new Date().toISOString().slice(0, 10),
      monthly_salary: String(defaultPos?.base_salary || 25000),
      monthly_allowance: String(defaultPos?.allowance || 2000),
    });
    setModalOpen(true);
  };

  const openEdit = (emp: Employee) => {
    setEditing(emp);
    setForm({
      employee_code: emp.employee_code,
      full_name: emp.full_name,
      email: emp.email || '',
      department_id: String(emp.department_id),
      position_id: String(emp.position_id),
      shift_id: String(emp.shift_id),
      status: emp.status,
      hired_date: emp.hired_date || new Date().toISOString().slice(0, 10),
      monthly_salary: String(emp.monthly_salary),
      monthly_allowance: String(emp.monthly_allowance),
    });
    setModalOpen(true);
  };

  const handleToggleActive = async (emp: Employee) => {
    const nextStatus = emp.status === 'Active' ? 'Inactive' : 'Active';
    setFeedback(null);
    try {
      await apiFetch(`/api/employees/${emp.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          employee_code: emp.employee_code,
          full_name: emp.full_name,
          email: emp.email,
          department_id: emp.department_id,
          position_id: emp.position_id,
          shift_id: emp.shift_id,
          status: nextStatus,
          hired_date: emp.hired_date,
          monthly_salary: emp.monthly_salary,
          monthly_allowance: emp.monthly_allowance,
        }),
      });
      setFeedback({ type: 'ok', text: `${emp.full_name} marked ${nextStatus}.` });
      loadEmployees();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Status update failed.' });
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canWriteEmployees) return;
    setSaving(true);
    setFeedback(null);
    try {
      const payload = {
        ...form,
        department_id: Number(form.department_id),
        position_id: Number(form.position_id),
        shift_id: Number(form.shift_id),
        monthly_salary: Number(form.monthly_salary),
        monthly_allowance: Number(form.monthly_allowance),
      };
      if (editing) {
        await apiFetch(`/api/employees/${editing.id}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
        setFeedback({ type: 'ok', text: `Updated ${form.full_name} (${form.employee_code}).` });
      } else {
        await apiFetch('/api/employees', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
        setFeedback({ type: 'ok', text: `Added ${form.full_name} (${form.employee_code}).` });
      }
      setModalOpen(false);
      loadEmployees();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Save failed.' });
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!canWriteEmployees || !deleting) return;
    setFeedback(null);
    try {
      await apiFetch(`/api/employees/${deleting.id}`, { method: 'DELETE' });
      setFeedback({ type: 'ok', text: `Removed employee ${deleting.full_name}.` });
      setDeleting(null);
      loadEmployees();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Delete failed.' });
    }
  };

  const handleExport = async () => {
    setFeedback(null);
    try {
      const res = await apiFetch<{ data: Employee[] }>('/api/employees?limit=100');
      downloadCsv(
        `savage-rsucaj-employees-${new Date().toISOString().slice(0, 10)}.csv`,
        ['employee_code', 'full_name', 'email', 'department_code', 'position_name', 'shift_name', 'status', 'monthly_salary'],
        res.data as unknown as Record<string, unknown>[]
      );
      setFeedback({ type: 'ok', text: `Exported ${res.data.length} employee record(s) to CSV.` });
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Export failed.' });
    }
  };

  const handleImportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canWriteEmployees) return;
    setImporting(true);
    setFeedback(null);
    try {
      const lines = csvText
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter(Boolean);
      if (lines.length < 2) {
        throw new Error('Provide a CSV header row and at least one employee row.');
      }
      const rows = lines.slice(1).map((line) => {
        const cols = line.split(',').map((c) => c.trim());
        if (cols.length === 7) {
          return {
            employee_code: cols[0],
            full_name: `${cols[1]}, ${cols[2]}`,
            email: cols[3],
            department_code: cols[4],
            position_code: cols[5],
            status: cols[6],
          };
        }
        return {
          employee_code: cols[0] || '',
          full_name: cols[1] || '',
          email: cols[2] || '',
          department_code: cols[3] || '',
          position_code: cols[4] || '',
          status: cols[5] || 'Active',
        };
      });

      const res = await apiFetch<{ inserted: number; skipped: number }>('/api/employees/import', {
        method: 'POST',
        body: JSON.stringify({ rows }),
      });
      setImportOpen(false);
      setFeedback({
        type: 'ok',
        text: `CSV Import complete: ${res.inserted} inserted, ${res.skipped} skipped.`,
      });
      loadEmployees();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Import failed.' });
    } finally {
      setImporting(false);
    }
  };

  const totalPages = Math.max(1, Math.ceil(total / limit));
  const startIdx = total === 0 ? 0 : (page - 1) * limit + 1;
  const endIdx = Math.min(total, page * limit);

  return (
    <ModuleFrame
      title="Employees Management"
      subtitle="Manage faculty, administrative staff, department assignments, and payroll rates."
      icon={<Users className="w-5 h-5" />}
    >
      {feedback && (
        <div
          className={`mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Toolbar matching 04_Employees_Management.png */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-0">
          <div className="relative flex-1 min-w-[180px] max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              aria-label="Search employees by ID, name, or department"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Search by employee ID, name, or department..."
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 placeholder:text-slate-500 shadow-2xs focus:outline-none focus:border-[#0B5537] focus:ring-2 focus:ring-[#0B5537]/15"
            />
          </div>
          <select
            aria-label="Filter by department"
            value={deptFilter}
            onChange={(e) => {
              setDeptFilter(e.target.value);
              setPage(1);
            }}
            className="px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 bg-white shadow-2xs focus:outline-none focus:border-[#0B5537] max-w-full"
          >
            <option value="">All Departments</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>
                {d.code} — {d.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={!canWriteEmployees}
            onClick={() => setImportOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs transition-colors whitespace-nowrap cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5 text-[#0B5537]" />
            <span>Import</span>
          </button>
          <button
            type="button"
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs transition-colors whitespace-nowrap cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-[#0B5537]" />
            <span>Export</span>
          </button>
          <button
            type="button"
            disabled={!canWriteEmployees}
            onClick={openAdd}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl btn-rsu-primary text-xs font-semibold transition-all whitespace-nowrap cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Employee</span>
          </button>
        </div>
      </div>

      {/* Employees Table matching 04_Employees_Management.png */}
      <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
              <th className="py-3 px-4">Employee ID</th>
              <th className="py-3 px-4">Name</th>
              <th className="py-3 px-4">Department</th>
              <th className="py-3 px-4">Position</th>
              <th className="py-3 px-4 text-center">Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs">
            {loading ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-400">
                  Loading employees...
                </td>
              </tr>
            ) : employees.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-400">
                  No employees found matching your criteria.
                </td>
              </tr>
            ) : (
              employees.map((emp) => (
                <tr key={emp.id} className="hover:bg-emerald-50/35 transition-colors">
                  <td className="py-3.5 px-4 font-mono-num font-semibold text-slate-800 whitespace-nowrap">
                    {emp.employee_code}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-slate-900">{emp.full_name}</div>
                    {emp.email && <div className="text-[11px] text-slate-500">{emp.email}</div>}
                  </td>
                  <td className="py-3.5 px-4 text-slate-700 whitespace-nowrap">
                    {emp.department_code}
                  </td>
                  <td className="py-3.5 px-4 text-slate-700 whitespace-nowrap">
                    {emp.position_name}
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <StatusLabel status={emp.status} />
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <div className="inline-flex items-center gap-1">
                      {canCreateAccounts && emp.status === 'Active' && (
                        <button type="button" onClick={() => openCreateAccount(emp)}
                          className="p-1.5 rounded-lg text-[#0B5537] hover:bg-emerald-50 transition-colors cursor-pointer"
                          aria-label={`Create employee login for ${emp.full_name}`} title="Create employee login">
                          <UserPlus className="w-4 h-4"/>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setViewing(emp)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-[#0B5537] hover:bg-emerald-50 transition-colors cursor-pointer"
                        aria-label={`View ${emp.full_name}`}
                        title="View details"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={!canWriteEmployees}
            onClick={() => openEdit(emp)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-[#0B5537] hover:bg-emerald-50 transition-colors cursor-pointer"
                        aria-label={`Edit ${emp.full_name}`}
                        title="Edit employee"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={!canWriteEmployees}
            onClick={() => handleToggleActive(emp)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer"
                        aria-label={`Toggle active status for ${emp.full_name}`}
                        title={emp.status === 'Active' ? 'Deactivate' : 'Activate'}
                      >
                        <Power className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={!canWriteEmployees}
            onClick={() => setDeleting(emp)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                        aria-label={`Delete ${emp.full_name}`}
                        title="Delete employee"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer matching 04_Employees_Management.png */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
        <span className="font-semibold font-mono-num">
          Showing {startIdx} – {endIdx} of {total}
        </span>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            disabled={page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
            aria-label="Previous page"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((pNum) => (
            <button
              key={pNum}
              type="button"
              onClick={() => setPage(pNum)}
              className={`min-w-[30px] h-7 px-2 rounded-lg text-xs font-bold font-mono-num cursor-pointer ${
                pNum === page
                  ? 'bg-[#07442B] text-white shadow-xs'
                  : 'border border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
              }`}
            >
              {pNum}
            </button>
          ))}
          <button
            type="button"
            disabled={page >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
            aria-label="Next page"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* View Employee Details Modal */}
      <Modal
        open={Boolean(viewing)}
        onClose={() => setViewing(null)}
        title="Employee Profile Details"
        subtitle={viewing ? `${viewing.employee_code} · RSU Cajidiocan Campus` : undefined}
      >
        {viewing && (
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200/80">
              <div>
                <p className="text-slate-400">Full Name</p>
                <p className="font-bold text-slate-900 mt-0.5">{viewing.full_name}</p>
              </div>
              <div>
                <p className="text-slate-400">Status</p>
                <div className="mt-1">
                  <StatusLabel status={viewing.status} />
                </div>
              </div>
              <div>
                <p className="text-slate-400">Institutional Email</p>
                <p className="font-medium text-slate-800 mt-0.5">{viewing.email || '—'}</p>
              </div>
              <div>
                <p className="text-slate-400">Department</p>
                <p className="font-semibold text-slate-800 mt-0.5">
                  {viewing.department_code} — {viewing.department_name}
                </p>
              </div>
              <div>
                <p className="text-slate-400">Position</p>
                <p className="font-semibold text-slate-800 mt-0.5">{viewing.position_name}</p>
              </div>
              <div>
                <p className="text-slate-400">Assigned Shift</p>
                <p className="font-semibold text-slate-800 mt-0.5">{viewing.shift_name}</p>
              </div>
              <div>
                <p className="text-slate-400">Date Hired</p>
                <p className="font-mono-num font-semibold text-slate-800 mt-0.5">
                  {formatDisplayDate(viewing.hired_date)}
                </p>
              </div>
              <div>
                <p className="text-slate-400">Monthly Compensation</p>
                <p className="font-mono-num font-bold text-[#0B5537] mt-0.5">
                  {formatPeso(viewing.monthly_salary)} + {formatPeso(viewing.monthly_allowance)} allow.
                </p>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  const emp = viewing;
                  setViewing(null);
                  openEdit(emp);
                }}
                className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
              >
                Edit Employee
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Add/Edit Employee Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Employee' : 'Add New Employee'}
        subtitle="Romblon State University – Cajidiocan Campus Personnel Record"
      >
        <form onSubmit={handleSave} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Employee ID *</label>
              <input
                type="text"
                required
                value={form.employee_code}
                onChange={(e) => setForm({ ...form, employee_code: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num focus:outline-none focus:border-[#0B5537]"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Status</label>
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value as 'Active' | 'Inactive' })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white focus:outline-none focus:border-[#0B5537]"
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Full Name *</label>
              <input
                type="text"
                required
                placeholder="Dela Cruz, Maria S."
                value={form.full_name}
                onChange={(e) => setForm({ ...form, full_name: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-[#0B5537]"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Institutional Email</label>
              <input
                type="email"
                placeholder="name@rsucaj.edu.ph"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-[#0B5537]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Department *</label>
              <select
                required
                value={form.department_id}
                onChange={(e) => setForm({ ...form, department_id: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white focus:outline-none focus:border-[#0B5537]"
              >
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.code} — {d.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Position *</label>
              <select
                required
                value={form.position_id}
                onChange={(e) => {
                  const pos = positions.find((p) => String(p.id) === e.target.value);
                  setForm({
                    ...form,
                    position_id: e.target.value,
                    monthly_salary: pos ? String(pos.base_salary) : form.monthly_salary,
                    monthly_allowance: pos ? String(pos.allowance) : form.monthly_allowance,
                  });
                }}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white focus:outline-none focus:border-[#0B5537]"
              >
                {positions.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Assigned Shift *</label>
              <select
                required
                value={form.shift_id}
                onChange={(e) => setForm({ ...form, shift_id: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white focus:outline-none focus:border-[#0B5537]"
              >
                {shifts.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Date Hired</label>
              <input
                type="date"
                value={form.hired_date}
                onChange={(e) => setForm({ ...form, hired_date: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-[#0B5537]"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Monthly Basic Pay (₱)</label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={form.monthly_salary}
                onChange={(e) => setForm({ ...form, monthly_salary: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num focus:outline-none focus:border-[#0B5537]"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Monthly Allowance (₱)</label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={form.monthly_allowance}
                onChange={(e) => setForm({ ...form, monthly_allowance: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num focus:outline-none focus:border-[#0B5537]"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold disabled:opacity-60 cursor-pointer"
            >
              {saving ? 'Saving...' : editing ? 'Save Changes' : 'Create Employee'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Administrator-only employee account provisioning; uses the existing audited user endpoint. */}
      <Modal open={Boolean(accountEmployee)} onClose={() => { if (!creatingAccount) setAccountEmployee(null); }}
        title="Create Employee Portal Login" subtitle={accountEmployee ? `${accountEmployee.employee_code} — ${accountEmployee.full_name}` : ''}>
        <form onSubmit={(e) => void createEmployeeAccount(e)} className="space-y-4 text-xs">
          <p className="rounded-xl bg-emerald-50 p-3 text-emerald-800">The employee can view personal attendance, corrections, leave requests, and released payslips on Android Chrome. Time In/Out remains kiosk-only.</p>
          <div><label className="block font-semibold mb-1" htmlFor="new-emp-username">Username *</label><input id="new-emp-username" className="w-full rounded-xl border border-slate-300 p-3" required autoComplete="off" value={accountForm.username} onChange={(e) => setAccountForm({...accountForm,username:e.target.value})}/></div>
          <div><label className="block font-semibold mb-1" htmlFor="new-emp-email">Email *</label><input id="new-emp-email" className="w-full rounded-xl border border-slate-300 p-3" required type="email" autoComplete="off" value={accountForm.email} onChange={(e) => setAccountForm({...accountForm,email:e.target.value})}/></div>
          <div><label className="block font-semibold mb-1" htmlFor="new-emp-password">Temporary password *</label><input id="new-emp-password" className="w-full rounded-xl border border-slate-300 p-3" required type="password" minLength={10} autoComplete="new-password" value={accountForm.password} onChange={(e) => setAccountForm({...accountForm,password:e.target.value})}/><p className="mt-1 text-[11px] text-slate-500">At least 10 characters: uppercase, lowercase, number, symbol. The server forces password rotation on first login.</p></div>
          <div className="flex justify-end gap-2"><button type="button" className="rounded-xl border border-slate-200 px-4 py-2.5" onClick={() => setAccountEmployee(null)} disabled={creatingAccount}>Cancel</button><button type="submit" disabled={creatingAccount} className="btn-rsu-primary rounded-xl px-4 py-2.5 font-bold">{creatingAccount?'Creating…':'Create Login'}</button></div>
        </form>
      </Modal>

      {/* CSV Import Modal */}
      <Modal
        open={importOpen}
        onClose={() => setImportOpen(false)}
        title="Import Employees via CSV"
        subtitle="Columns: employee_code, full_name, email, department_code, position_code, status"
      >
        <form onSubmit={handleImportSubmit} className="space-y-4 text-xs">
          <textarea
            aria-label="Employee CSV data"
            rows={7}
            value={csvText}
            onChange={(e) => setCsvText(e.target.value)}
            className="w-full p-3 rounded-lg border border-slate-300 font-mono-num text-xs focus:outline-none focus:border-[#0B5537]"
          />
          <div className="flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setImportOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={importing}
              className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold disabled:opacity-60 cursor-pointer"
            >
              {importing ? 'Importing...' : 'Run CSV Import'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={confirmDelete}
        title="Remove Employee Record?"
        message={
          deleting
            ? `Are you sure you want to permanently remove ${deleting.full_name} (${deleting.employee_code}) and their associated attendance records?`
            : ''
        }
        confirmLabel="Remove Employee"
        destructive
      />
    </ModuleFrame>
  );
};
