import React, { useEffect, useState, useCallback } from 'react';
import {
  FileCheck2,
  Umbrella,
  Plus,
  Check,
  X,
  Trash2,
  Eye,
  AlertCircle,
  RotateCcw,
  FileText,
  SlidersHorizontal,
  Ban,
  Download,
} from 'lucide-react';
import { ModuleFrame, Modal, ConfirmModal, StatusLabel } from './ModuleFrame';
import { apiFetch, formatDisplayDate, getManilaTodayIso } from '../lib/api';
import { useRealtimeStream } from '../lib/realtime';
import type {
  AuthUser,
  CorrectionAuditEntry,
  CorrectionRequest,
  Employee,
  LeaveAuditEntry,
  LeaveBalanceRow,
  LeaveDayAllocation,
  LeaveDayPortion,
  LeavePolicy,
  LeavePreview,
  LeaveRequest,
} from '../types';

function readFileAsBase64(file: File): Promise<{ name: string; mime: string; data: string }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read selected file.'));
    reader.onload = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const commaIdx = result.indexOf(',');
      const base64 = commaIdx >= 0 ? result.slice(commaIdx + 1) : result;
      resolve({
        name: file.name,
        mime: file.type || 'application/octet-stream',
        data: base64,
      });
    };
    reader.readAsDataURL(file);
  });
}

function downloadBase64Attachment(name: string, mime: string, base64Data: string) {
  const safeMime = mime || 'application/octet-stream';
  const link = document.createElement('a');
  link.href = `data:${safeMime};base64,${base64Data}`;
  link.download = name || 'supporting-document';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// ============================================================================
// SCREEN 06 — ATTENDANCE CORRECTIONS (06_Attendance_Corrections.png)
// ============================================================================
export const CorrectionsView: React.FC<{ currentUser?: AuthUser }> = ({ currentUser }) => {
  const perms = currentUser?.permissions || [];
  const canApprove = !currentUser || perms.includes('corrections:approve');
  const canCreate = !currentUser || perms.includes('corrections:create');
  const isEmployeeSelf = currentUser?.role === 'Employee';

  const [tab, setTab] = useState<'Pending' | 'Approved' | 'Rejected' | 'All'>('Pending');
  const [items, setItems] = useState<CorrectionRequest[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Detail + Audit + Review + Reversal state
  const [viewing, setViewing] = useState<CorrectionRequest | null>(null);
  const [viewingAudit, setViewingAudit] = useState<CorrectionAuditEntry[]>([]);
  const [auditLoading, setAuditLoading] = useState(false);
  const [reviewApprovedTime, setReviewApprovedTime] = useState('');
  const [reviewApprovedTimeOut, setReviewApprovedTimeOut] = useState('');
  const [reviewNotes, setReviewNotes] = useState('');
  const [reversalReason, setReversalReason] = useState('');
  const [actionBusy, setActionBusy] = useState(false);

  // Filing modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    employee_id: currentUser?.employee_id ? String(currentUser.employee_id) : '',
    attendance_date: getManilaTodayIso(),
    request_type: 'Time In' as 'Time In' | 'Time Out' | 'Full Day',
    requested_time: '08:00 AM',
    requested_time_out: '05:00 PM',
    reason: '',
    document_reference: '',
    attachment_name: '',
    attachment_mime: '',
    attachment_data: '',
  });
  const [saving, setSaving] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch<{
        data: CorrectionRequest[];
        counts: Array<{ status: string; c: number }>;
      }>(`/api/corrections?status=${tab}`);
      setItems(res.data);
      const map: Record<string, number> = { Pending: 0, Approved: 0, Rejected: 0, Reversed: 0 };
      for (const row of res.counts) map[row.status] = row.c;
      setCounts(map);
    } finally {
      setLoading(false);
    }
  }, [tab]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useRealtimeStream({
    channels: ['attendance:updated', 'notification:created'],
    onEvent: () => {
      loadData();
    },
    onResync: () => {
      loadData();
    },
  });

  useEffect(() => {
    if (isEmployeeSelf) {
      if (currentUser?.employee_id) {
        setForm((f) => ({ ...f, employee_id: String(currentUser.employee_id) }));
      }
      return;
    }
    apiFetch<{ data: Employee[] }>('/api/employees?limit=100')
      .then((r) => {
        setEmployees(r.data);
        if (r.data[0]) setForm((f) => ({ ...f, employee_id: f.employee_id || String(r.data[0].id) }));
      })
      .catch(() => {
        // ignore if role lacks employees:read
      });
  }, [isEmployeeSelf, currentUser?.employee_id]);

  const openDetails = async (item: CorrectionRequest) => {
    setViewing(item);
    setReviewApprovedTime(item.requested_time || '');
    setReviewApprovedTimeOut(item.requested_time_out || '');
    setReviewNotes('');
    setReversalReason('');
    setAuditLoading(true);
    try {
      const res = await apiFetch<{ correction: CorrectionRequest; audit: CorrectionAuditEntry[] }>(
        `/api/corrections/${item.id}/audit`
      );
      setViewing(res.correction);
      setViewingAudit(res.audit || []);
    } catch {
      setViewingAudit([]);
    } finally {
      setAuditLoading(false);
    }
  };

  const handleDecision = async (
    id: number,
    status: 'Approved' | 'Rejected',
    options?: { approved_time?: string; approved_time_out?: string; reviewer_notes?: string }
  ) => {
    setFeedback(null);
    setActionBusy(true);
    try {
      const res = await apiFetch<{
        success: boolean;
        resulting_status?: string;
        incomplete_punch_warning?: string | null;
      }>(`/api/corrections/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({
          status,
          approved_time: options?.approved_time || undefined,
          approved_time_out: options?.approved_time_out || undefined,
          reviewer_notes: options?.reviewer_notes || undefined,
        }),
      });
      setViewing(null);
      setFeedback({
        type: 'ok',
        text:
          status === 'Approved'
            ? `Correction approved and synced to Attendance Records (${res.resulting_status || 'Updated'}).${
                res.incomplete_punch_warning ? ` Note: ${res.incomplete_punch_warning}` : ''
              }`
            : 'Correction request rejected and logged in immutable audit trail.',
      });
      loadData();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Action failed.' });
    } finally {
      setActionBusy(false);
    }
  };

  const handleReverse = async (id: number) => {
    if (reversalReason.trim().length < 5) {
      setFeedback({ type: 'err', text: 'A reversal reason (at least 5 characters) is required.' });
      return;
    }
    setFeedback(null);
    setActionBusy(true);
    try {
      await apiFetch(`/api/corrections/${id}/reverse`, {
        method: 'POST',
        body: JSON.stringify({ reversal_reason: reversalReason.trim() }),
      });
      setViewing(null);
      setReversalReason('');
      setFeedback({
        type: 'ok',
        text: 'Approved correction reversed. Attendance record restored to pre-correction state and logged.',
      });
      loadData();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Reversal failed.' });
    } finally {
      setActionBusy(false);
    }
  };

  const handleAttachmentChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
      setForm((f) => ({ ...f, attachment_name: '', attachment_mime: '', attachment_data: '' }));
      return;
    }
    try {
      const encoded = await readFileAsBase64(file);
      setForm((f) => ({
        ...f,
        attachment_name: encoded.name,
        attachment_mime: encoded.mime,
        attachment_data: encoded.data,
      }));
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Attachment read failed.' });
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setFeedback(null);
    try {
      await apiFetch('/api/corrections', {
        method: 'POST',
        body: JSON.stringify({
          employee_id: form.employee_id ? Number(form.employee_id) : undefined,
          attendance_date: form.attendance_date,
          request_type: form.request_type,
          requested_time: form.requested_time,
          requested_time_out: form.request_type === 'Full Day' ? form.requested_time_out : undefined,
          reason: form.reason,
          document_reference: form.document_reference || undefined,
          attachment_name: form.attachment_name || undefined,
          attachment_mime: form.attachment_mime || undefined,
          attachment_data: form.attachment_data || undefined,
        }),
      });
      setModalOpen(false);
      setForm((f) => ({
        ...f,
        reason: '',
        document_reference: '',
        attachment_name: '',
        attachment_mime: '',
        attachment_data: '',
      }));
      setFeedback({ type: 'ok', text: 'Attendance correction request created and recorded in audit trail.' });
      setTab('Pending');
      loadData();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Submit failed.' });
    } finally {
      setSaving(false);
    }
  };

  const formatCorrectionRequestLabel = (item: CorrectionRequest) => {
    if (item.request_type === 'Full Day' && item.requested_time_out) {
      return `Full Day (${item.requested_time} – ${item.requested_time_out})`;
    }
    return `${item.request_type} (${item.requested_time})`;
  };

  return (
    <ModuleFrame
      title="Corrections"
      subtitle="Manage and approve attendance correction requests."
      icon={<FileCheck2 className="w-5 h-5" />}
      headerAction={
        canCreate ? (
          <button
            type="button"
            onClick={() => setModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl btn-rsu-primary text-xs font-semibold transition-all cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Correction</span>
          </button>
        ) : undefined
      }
    >
      {feedback && (
        <div
          className={`mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{feedback.text}</span>
        </div>
      )}

      {/* 4 Elevated Pill-Tab Buttons matching 06_Attendance_Corrections.png */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
        {(
          [
            { id: 'Pending', label: `Pending (${counts.Pending || 0})` },
            { id: 'Approved', label: `Approved (${counts.Approved || 0})` },
            { id: 'Rejected', label: `Rejected (${counts.Rejected || 0})` },
            {
              id: 'All',
              label: counts.Reversed ? `All (${counts.Reversed} Rev)` : 'All',
            },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`py-2.5 px-4 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer border ${
              tab === t.id
                ? 'btn-rsu-primary border-transparent'
                : 'bg-white border-slate-200 text-slate-700 shadow-2xs hover:bg-slate-50'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
              <th className="py-3 px-4">Employee</th>
              <th className="py-3 px-4">Date</th>
              <th className="py-3 px-4">Request</th>
              <th className="py-3 px-4 text-center">Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs">
            {loading ? (
              <tr>
                <td colSpan={5} className="py-8 text-center text-slate-400">
                  Loading correction requests...
                </td>
              </tr>
            ) : items.length === 0 ? (
              <tr>
                <td colSpan={5} className="py-8 text-center text-slate-400">
                  No correction requests in this category.
                </td>
              </tr>
            ) : (
              items.map((item) => (
                <tr key={item.id} className="hover:bg-emerald-50/35 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-slate-900">{item.employee_name}</div>
                    <div className="text-[11px] text-slate-400 font-mono-num">
                      {item.employee_code} · {item.department_code}
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-mono-num text-slate-700 whitespace-nowrap">
                    {formatDisplayDate(item.attendance_date)}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-slate-800 whitespace-nowrap">
                      {formatCorrectionRequestLabel(item)}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono-num">
                      Orig: {item.original_time_in || '—'} / {item.original_time_out || '—'}
                      {(item.document_reference || item.has_attachment === 1) && (
                        <span className="ml-1.5 inline-flex items-center gap-0.5 text-emerald-700 font-sans font-semibold">
                          <FileText className="w-3 h-3" /> Doc
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <StatusLabel status={item.status} />
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => openDetails(item)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-[#0B5537] hover:bg-emerald-50 cursor-pointer"
                        aria-label={`View correction details for ${item.employee_name}`}
                        title="Inspect Original vs Requested vs Approved & Audit Trail"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      {item.status === 'Pending' && canApprove ? (
                        <>
                          <button
                            type="button"
                            disabled={actionBusy}
                            onClick={() => handleDecision(item.id, 'Approved')}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg btn-rsu-primary text-[11px] font-semibold cursor-pointer disabled:opacity-60"
                          >
                            <Check className="w-3 h-3" />
                            <span>Approve</span>
                          </button>
                          <button
                            type="button"
                            disabled={actionBusy}
                            onClick={() => handleDecision(item.id, 'Rejected')}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 text-[11px] font-semibold cursor-pointer disabled:opacity-60"
                          >
                            <X className="w-3 h-3" />
                            <span>Reject</span>
                          </button>
                        </>
                      ) : item.status === 'Approved' && canApprove ? (
                        <button
                          type="button"
                          onClick={() => openDetails(item)}
                          className="inline-flex items-center gap-1 px-2 py-1 rounded-lg border border-amber-200 bg-amber-50 hover:bg-amber-100 text-amber-800 text-[11px] font-semibold cursor-pointer"
                          title="Reverse approved correction"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>Reverse</span>
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-400">
                          {item.status === 'Reversed'
                            ? `rev by ${item.reversed_by || 'admin'}`
                            : item.reviewed_by
                            ? `by ${item.reviewed_by}`
                            : 'Awaiting review'}
                        </span>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* View Correction Details, Original vs Requested vs Approved, Immutable Audit & Reversal Modal */}
      <Modal
        open={Boolean(viewing)}
        onClose={() => setViewing(null)}
        title="Attendance Correction Audit & Review"
        subtitle={
          viewing
            ? `${viewing.employee_name} (${viewing.employee_code}) · ${formatDisplayDate(viewing.attendance_date)}`
            : undefined
        }
        maxWidth="max-w-2xl"
      >
        {viewing && (
          <div className="space-y-4 text-xs">
            {/* Comparison Grid: Original vs Requested vs Approved */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200/80">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Original Capture</p>
                <p className="font-mono-num text-slate-800 mt-1">
                  In: <span className="font-semibold">{viewing.original_time_in || '—'}</span>
                </p>
                <p className="font-mono-num text-slate-800">
                  Out: <span className="font-semibold">{viewing.original_time_out || '—'}</span>
                </p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Status: {viewing.original_status || 'No Record'}
                </p>
              </div>
              <div>
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Requested Value</p>
                <p className="font-semibold text-slate-900 mt-1">{viewing.request_type}</p>
                <p className="font-mono-num text-slate-800">
                  {viewing.request_type === 'Full Day'
                    ? `${viewing.requested_time} – ${viewing.requested_time_out || '—'}`
                    : viewing.requested_time}
                </p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Filed by {viewing.created_by_username || 'portal'}
                </p>
              </div>
              <div>
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Approved / State</p>
                <div className="mt-1">
                  <StatusLabel status={viewing.status} />
                </div>
                {viewing.approved_time && (
                  <p className="font-mono-num font-bold text-[#0B5537] mt-1">
                    {viewing.approved_time_out
                      ? `${viewing.approved_time} – ${viewing.approved_time_out}`
                      : viewing.approved_time}
                  </p>
                )}
                <p className="text-[11px] text-slate-500 mt-0.5">
                  {viewing.reviewed_by
                    ? `By ${viewing.reviewed_by} (${viewing.reviewed_at || ''})`
                    : 'Awaiting authorized review'}
                </p>
              </div>
            </div>

            <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 space-y-2">
              <div>
                <p className="text-slate-400 font-semibold">Reason / Justification</p>
                <p className="text-slate-800 mt-0.5 leading-relaxed">{viewing.reason || '—'}</p>
              </div>
              {(viewing.document_reference || viewing.attachment_name) && (
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
                  <div>
                    <p className="text-slate-400 font-semibold">Supporting Documentation</p>
                    <p className="text-slate-700 font-mono-num mt-0.5">
                      {viewing.document_reference || viewing.attachment_name}
                    </p>
                  </div>
                  {viewing.attachment_data && viewing.attachment_name && (
                    <button
                      type="button"
                      onClick={() =>
                        downloadBase64Attachment(
                          viewing.attachment_name!,
                          viewing.attachment_mime || 'application/octet-stream',
                          viewing.attachment_data!
                        )
                      }
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-emerald-200 bg-emerald-50 text-emerald-800 font-semibold cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Attachment</span>
                    </button>
                  )}
                </div>
              )}
              {viewing.reviewer_notes && (
                <div className="pt-2 border-t border-slate-100">
                  <p className="text-slate-400 font-semibold">Reviewer Notes</p>
                  <p className="text-slate-700 mt-0.5">{viewing.reviewer_notes}</p>
                </div>
              )}
              {viewing.status === 'Reversed' && viewing.reversal_reason && (
                <div className="pt-2 border-t border-amber-100 bg-amber-50/60 -mx-3.5 -mb-3.5 p-3.5 rounded-b-xl">
                  <p className="text-amber-800 font-bold">
                    Reversed by {viewing.reversed_by} ({viewing.reversed_at_utc})
                  </p>
                  <p className="text-amber-900 mt-0.5">{viewing.reversal_reason}</p>
                </div>
              )}
            </div>

            {/* Reviewer Action Panel for Pending */}
            {viewing.status === 'Pending' && canApprove && (
              <div className="p-3.5 rounded-xl bg-[#F4F8F6] border border-emerald-950/10 space-y-3">
                <p className="font-bold text-[#07442B]">
                  Authorized Review (No Counterpart Punch Will Be Invented)
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Approved {viewing.request_type === 'Full Day' ? 'Time In' : viewing.request_type}
                    </label>
                    <input
                      type="text"
                      value={reviewApprovedTime}
                      onChange={(e) => setReviewApprovedTime(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-mono-num"
                    />
                  </div>
                  {viewing.request_type === 'Full Day' && (
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Approved Time Out</label>
                      <input
                        type="text"
                        value={reviewApprovedTimeOut}
                        onChange={(e) => setReviewApprovedTimeOut(e.target.value)}
                        className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white font-mono-num"
                      />
                    </div>
                  )}
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Reviewer Notes (Optional)</label>
                  <input
                    type="text"
                    value={reviewNotes}
                    onChange={(e) => setReviewNotes(e.target.value)}
                    placeholder="Verified against signed logbook or supervisor memo..."
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    disabled={actionBusy}
                    onClick={() =>
                      handleDecision(viewing.id, 'Rejected', { reviewer_notes: reviewNotes })
                    }
                    className="px-4 py-2 rounded-lg border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 font-semibold cursor-pointer"
                  >
                    Reject
                  </button>
                  <button
                    type="button"
                    disabled={actionBusy}
                    onClick={() =>
                      handleDecision(viewing.id, 'Approved', {
                        approved_time: reviewApprovedTime,
                        approved_time_out: viewing.request_type === 'Full Day' ? reviewApprovedTimeOut : undefined,
                        reviewer_notes: reviewNotes,
                      })
                    }
                    className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
                  >
                    {actionBusy ? 'Saving...' : 'Approve & Sync Attendance'}
                  </button>
                </div>
              </div>
            )}

            {/* Authorized Reversal Panel for Approved */}
            {viewing.status === 'Approved' && canApprove && (
              <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 space-y-2.5">
                <p className="font-bold text-amber-900">Reverse Approved Correction (Audit-Safe)</p>
                <p className="text-[11px] text-amber-800">
                  Restores the attendance record to its captured pre-correction state without erasing original kiosk
                  events or audit history.
                </p>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={reversalReason}
                    onChange={(e) => setReversalReason(e.target.value)}
                    placeholder="Mandatory reversal reason (min 5 characters)..."
                    className="flex-1 px-3 py-1.5 rounded-lg border border-amber-300 bg-white"
                  />
                  <button
                    type="button"
                    disabled={actionBusy}
                    onClick={() => handleReverse(viewing.id)}
                    className="inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-amber-700 hover:bg-amber-800 text-white font-semibold cursor-pointer disabled:opacity-60"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reverse Correction</span>
                  </button>
                </div>
              </div>
            )}

            {/* Immutable Correction Audit Log */}
            <div>
              <h3 className="font-bold text-[#07442B] mb-2">Immutable Correction Audit Trail</h3>
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left border-collapse text-[11px]">
                  <thead>
                    <tr className="bg-[#F4F8F6] border-b border-slate-200 text-slate-700 font-bold">
                      <th className="py-2 px-3">Timestamp (Manila)</th>
                      <th className="py-2 px-3">Action</th>
                      <th className="py-2 px-3">Actor / Role</th>
                      <th className="py-2 px-3">Resulting Attendance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {auditLoading ? (
                      <tr>
                        <td colSpan={4} className="py-4 text-center text-slate-400">
                          Loading immutable audit log...
                        </td>
                      </tr>
                    ) : viewingAudit.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-4 text-center text-slate-400">
                          No audit records found.
                        </td>
                      </tr>
                    ) : (
                      viewingAudit.map((entry) => (
                        <tr key={entry.id}>
                          <td className="py-2 px-3 font-mono-num text-slate-600 whitespace-nowrap">
                            {entry.recorded_at_manila}
                          </td>
                          <td className="py-2 px-3 font-bold text-slate-800 whitespace-nowrap">{entry.action}</td>
                          <td className="py-2 px-3 whitespace-nowrap">
                            <span className="font-semibold text-slate-800">{entry.actor_username}</span>
                            <span className="text-slate-400"> ({entry.actor_role})</span>
                          </td>
                          <td className="py-2 px-3 font-mono-num text-slate-700">
                            {entry.resulting_time_in || '—'} / {entry.resulting_time_out || '—'}{' '}
                            {entry.resulting_status ? `(${entry.resulting_status})` : ''}
                            {entry.reason && (
                              <div className="font-sans text-[10px] text-slate-500 mt-0.5">{entry.reason}</div>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* File Attendance Correction Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="File Attendance Correction"
        subtitle="Submit a verifiable time-in, time-out, or full-day correction. Counterpart times are never fabricated."
      >
        <form onSubmit={handleCreate} className="space-y-4 text-xs">
          {!isEmployeeSelf && (
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Employee *</label>
              <select
                required
                value={form.employee_id}
                onChange={(e) => setForm({ ...form, employee_id: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white focus:outline-none focus:border-[#0B5537]"
              >
                {employees.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.employee_code} — {e.full_name}
                  </option>
                ))}
              </select>
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Attendance Date *</label>
              <input
                type="date"
                required
                value={form.attendance_date}
                onChange={(e) => setForm({ ...form, attendance_date: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Request Type *</label>
              <select
                value={form.request_type}
                onChange={(e) =>
                  setForm({
                    ...form,
                    request_type: e.target.value as 'Time In' | 'Time Out' | 'Full Day',
                  })
                }
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
              >
                <option value="Time In">Time In</option>
                <option value="Time Out">Time Out</option>
                <option value="Full Day">Full Day (Requires Both Times + Documentation)</option>
              </select>
            </div>
          </div>

          <div className={`grid grid-cols-1 ${form.request_type === 'Full Day' ? 'sm:grid-cols-2' : ''} gap-3`}>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                {form.request_type === 'Full Day' ? 'Requested Time In *' : 'Requested Time *'}
              </label>
              <input
                type="text"
                required
                value={form.requested_time}
                onChange={(e) => setForm({ ...form, requested_time: e.target.value })}
                placeholder="08:05 AM"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            {form.request_type === 'Full Day' && (
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Requested Time Out *</label>
                <input
                  type="text"
                  required
                  value={form.requested_time_out}
                  onChange={(e) => setForm({ ...form, requested_time_out: e.target.value })}
                  placeholder="05:00 PM"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
                />
              </div>
            )}
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Reason * (min 5 chars)</label>
            <textarea
              required
              minLength={5}
              rows={3}
              value={form.reason}
              onChange={(e) => setForm({ ...form, reason: e.target.value })}
              placeholder="Explain why an attendance adjustment is requested..."
              className="w-full px-3 py-2 rounded-lg border border-slate-300"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Document Reference {form.request_type === 'Full Day' ? '*' : '(Optional)'}
              </label>
              <input
                type="text"
                value={form.document_reference}
                onChange={(e) => setForm({ ...form, document_reference: e.target.value })}
                placeholder="e.g. MEMO-2026-042 or Signed Logbook"
                className="w-full px-3 py-2 rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Supporting Attachment (Optional)</label>
              <input
                type="file"
                accept=".pdf,.png,.jpg,.jpeg,.webp,.txt"
                onChange={handleAttachmentChange}
                className="w-full text-[11px] text-slate-600 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-emerald-50 file:text-emerald-800 file:font-semibold"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
            >
              {saving ? 'Submitting...' : 'Submit Request'}
            </button>
          </div>
        </form>
      </Modal>
    </ModuleFrame>
  );
};

// ============================================================================
// SCREEN 07 — LEAVES MANAGEMENT (07_Leaves_Management.png)
// ============================================================================
export const LeavesView: React.FC<{ currentUser?: AuthUser }> = ({ currentUser }) => {
  const perms = currentUser?.permissions || [];
  const canApprove = !currentUser || perms.includes('leaves:approve');
  const canCreate = !currentUser || perms.includes('leaves:create');
  const canDelete = !currentUser || perms.includes('leaves:delete');
  const isEmployeeSelf = currentUser?.role === 'Employee';

  const currentManilaYear = Number(getManilaTodayIso().slice(0, 4)) || 2026;
  const [viewMode, setViewMode] = useState<'applications' | 'balances' | 'policies'>('applications');
  const [statusTab, setStatusTab] = useState<'All' | 'Pending' | 'Approved' | 'Rejected' | 'Cancelled'>('All');
  const [balanceYear, setBalanceYear] = useState<number>(currentManilaYear);

  const [leaves, setLeaves] = useState<LeaveRequest[]>([]);
  const [balances, setBalances] = useState<LeaveBalanceRow[]>([]);
  const [policies, setPolicies] = useState<LeavePolicy[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [deleting, setDeleting] = useState<LeaveRequest | null>(null);

  // Leave Detail + Allocations + Audit + Cancellation + Conflict resolution
  const [viewing, setViewing] = useState<LeaveRequest | null>(null);
  const [viewingAllocations, setViewingAllocations] = useState<LeaveDayAllocation[]>([]);
  const [viewingAudit, setViewingAudit] = useState<LeaveAuditEntry[]>([]);
  const [detailLoading, setDetailLoading] = useState(false);
  const [reviewNotes, setReviewNotes] = useState('');
  const [conflictResolution, setConflictResolution] = useState<'BLOCK' | 'PRESERVE_PUNCHES'>('BLOCK');
  const [cancelReason, setCancelReason] = useState('');
  const [actionBusy, setActionBusy] = useState(false);

  // Policy editing state
  const [editingPolicy, setEditingPolicy] = useState<LeavePolicy | null>(null);
  const [policySaving, setPolicySaving] = useState(false);

  // New leave filing modal state (default to next Mon-Fri weekday when opened on a weekend)
  const [modalOpen, setModalOpen] = useState(false);
  const todayIso = getManilaTodayIso();
  const defaultLeaveDateIso = (() => {
    const [y, m, d] = todayIso.split('-').map(Number);
    const dt = new Date(Date.UTC(y, m - 1, d));
    const dow = dt.getUTCDay();
    if (dow === 6) dt.setUTCDate(dt.getUTCDate() + 2);
    else if (dow === 0) dt.setUTCDate(dt.getUTCDate() + 1);
    return dt.toISOString().slice(0, 10);
  })();
  const [form, setForm] = useState({
    employee_id: currentUser?.employee_id ? String(currentUser.employee_id) : '',
    leave_type: 'Vacation Leave',
    start_date: defaultLeaveDateIso,
    end_date: defaultLeaveDateIso,
    day_portion: 'FULL' as LeaveDayPortion,
    reason: '',
    document_reference: '',
    attachment_name: '',
    attachment_mime: '',
    attachment_data: '',
  });
  const [preview, setPreview] = useState<LeavePreview | null>(null);
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const loadLeaves = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch<{
        data: LeaveRequest[];
        balances?: LeaveBalanceRow[];
        policies?: LeavePolicy[];
      }>(`/api/leaves?status=${statusTab}&year=${balanceYear}`);
      setLeaves(res.data);
      setBalances(res.balances || []);
      setPolicies(res.policies || []);
    } finally {
      setLoading(false);
    }
  }, [statusTab, balanceYear]);

  useEffect(() => {
    loadLeaves();
  }, [loadLeaves]);

  useRealtimeStream({
    channels: ['attendance:updated', 'notification:created'],
    onEvent: () => {
      loadLeaves();
    },
    onResync: () => {
      loadLeaves();
    },
  });

  useEffect(() => {
    if (isEmployeeSelf) {
      if (currentUser?.employee_id) {
        setForm((f) => ({ ...f, employee_id: String(currentUser.employee_id) }));
      }
      return;
    }
    apiFetch<{ data: Employee[] }>('/api/employees?limit=100')
      .then((r) => {
        setEmployees(r.data);
        if (r.data[0]) setForm((f) => ({ ...f, employee_id: f.employee_id || String(r.data[0].id) }));
      })
      .catch(() => {
        // ignore if role lacks employees:read
      });
  }, [isEmployeeSelf, currentUser?.employee_id]);

  // Live Leave Eligibility & Balance Preview when filing modal is open
  useEffect(() => {
    if (!modalOpen || !form.employee_id || !form.start_date || !form.end_date) {
      setPreview(null);
      setPreviewError(null);
      return;
    }
    let cancelled = false;
    const qs = new URLSearchParams({
      employee_id: form.employee_id,
      leave_type: form.leave_type,
      start_date: form.start_date,
      end_date: form.end_date,
      day_portion: form.start_date === form.end_date ? form.day_portion : 'FULL',
    });
    apiFetch<LeavePreview>(`/api/leaves/preview?${qs.toString()}`)
      .then((res) => {
        if (!cancelled) {
          setPreview(res);
          setPreviewError(null);
        }
      })
      .catch((err) => {
        if (!cancelled) {
          setPreview(null);
          setPreviewError(err instanceof Error ? err.message : 'Unable to preview leave eligibility.');
        }
      });
    return () => {
      cancelled = true;
    };
  }, [modalOpen, form.employee_id, form.leave_type, form.start_date, form.end_date, form.day_portion]);

  const openDetails = async (leave: LeaveRequest) => {
    setViewing(leave);
    setReviewNotes('');
    setConflictResolution('BLOCK');
    setCancelReason('');
    setDetailLoading(true);
    try {
      const res = await apiFetch<{
        leave: LeaveRequest;
        allocations: LeaveDayAllocation[];
        audit: LeaveAuditEntry[];
      }>(`/api/leaves/${leave.id}/details`);
      setViewing(res.leave);
      setViewingAllocations(res.allocations || []);
      setViewingAudit(res.audit || []);
    } catch {
      setViewingAllocations([]);
      setViewingAudit([]);
    } finally {
      setDetailLoading(false);
    }
  };

  const handleAttachmentChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
      setForm((f) => ({ ...f, attachment_name: '', attachment_mime: '', attachment_data: '' }));
      return;
    }
    try {
      const encoded = await readFileAsBase64(file);
      setForm((f) => ({
        ...f,
        attachment_name: encoded.name,
        attachment_mime: encoded.mime,
        attachment_data: encoded.data,
      }));
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Attachment read failed.' });
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setFeedback(null);
    try {
      await apiFetch('/api/leaves', {
        method: 'POST',
        body: JSON.stringify({
          employee_id: form.employee_id ? Number(form.employee_id) : undefined,
          leave_type: form.leave_type,
          start_date: form.start_date,
          end_date: form.end_date,
          day_portion: form.start_date === form.end_date ? form.day_portion : 'FULL',
          reason: form.reason,
          document_reference: form.document_reference || undefined,
          attachment_name: form.attachment_name || undefined,
          attachment_mime: form.attachment_mime || undefined,
          attachment_data: form.attachment_data || undefined,
        }),
      });
      setModalOpen(false);
      setForm((f) => ({
        ...f,
        reason: '',
        document_reference: '',
        attachment_name: '',
        attachment_mime: '',
        attachment_data: '',
      }));
      setFeedback({ type: 'ok', text: 'Leave application submitted and validated against HR leave policy.' });
      loadLeaves();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Failed to create leave.' });
    } finally {
      setSaving(false);
    }
  };

  const handleDecision = async (
    id: number,
    status: 'Approved' | 'Rejected',
    options?: { reviewer_notes?: string; conflict_resolution?: 'BLOCK' | 'PRESERVE_PUNCHES' }
  ) => {
    setFeedback(null);
    setActionBusy(true);
    try {
      const res = await apiFetch<{
        success: boolean;
        applied_dates?: string[];
        preserved_punch_dates?: string[];
        charged_days?: number;
      }>(`/api/leaves/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({
          status,
          reviewer_notes: options?.reviewer_notes || undefined,
          conflict_resolution: options?.conflict_resolution || 'BLOCK',
        }),
      });
      setViewing(null);
      setFeedback({
        type: 'ok',
        text:
          status === 'Approved'
            ? `Leave approved and propagated across ${res.applied_dates?.length ?? 0} eligible attendance date(s) (${res.charged_days ?? 0}d charged).`
            : 'Leave application rejected and logged.',
      });
      loadLeaves();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to review leave.' });
    } finally {
      setActionBusy(false);
    }
  };

  const handleCancelLeave = async (id: number) => {
    if (cancelReason.trim().length < 5) {
      setFeedback({ type: 'err', text: 'A cancellation reason (at least 5 characters) is required.' });
      return;
    }
    setFeedback(null);
    setActionBusy(true);
    try {
      await apiFetch(`/api/leaves/${id}/cancel`, {
        method: 'POST',
        body: JSON.stringify({ cancel_reason: cancelReason.trim() }),
      });
      setViewing(null);
      setCancelReason('');
      setFeedback({
        type: 'ok',
        text: 'Leave cancelled atomically. Attendance rows and leave balance credits restored.',
      });
      loadLeaves();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Cancellation failed.' });
    } finally {
      setActionBusy(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleting) return;
    await apiFetch(`/api/leaves/${deleting.id}`, { method: 'DELETE' });
    setFeedback({ type: 'ok', text: `Deleted leave record for ${deleting.employee_name}.` });
    setDeleting(null);
    loadLeaves();
  };

  const handleSavePolicy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPolicy) return;
    setPolicySaving(true);
    setFeedback(null);
    try {
      await apiFetch(`/api/leaves/policies/${editingPolicy.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          annual_entitlement: Number(editingPolicy.annual_entitlement),
          track_balance: Boolean(editingPolicy.track_balance),
          allow_half_day: Boolean(editingPolicy.allow_half_day),
          exclude_weekends_rest_days: Boolean(editingPolicy.exclude_weekends_rest_days),
          exclude_holidays: Boolean(editingPolicy.exclude_holidays),
          allow_negative_balance: Boolean(editingPolicy.allow_negative_balance),
          requires_document_after_days: Number(editingPolicy.requires_document_after_days),
        }),
      });
      setEditingPolicy(null);
      setFeedback({ type: 'ok', text: `Updated HR leave policy for ${editingPolicy.leave_type}.` });
      loadLeaves();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Failed to update policy.' });
    } finally {
      setPolicySaving(false);
    }
  };

  const formatPortionTag = (portion?: LeaveDayPortion) => {
    if (portion === 'HALF_AM') return ' · Half-Day AM';
    if (portion === 'HALF_PM') return ' · Half-Day PM';
    return '';
  };

  return (
    <ModuleFrame
      title="Leaves Management"
      subtitle="Manage leave applications, HR credit policies, and approvals."
      icon={<Umbrella className="w-5 h-5" />}
      headerAction={
        canCreate ? (
          <button
            type="button"
            onClick={() => setModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl btn-rsu-primary text-xs font-semibold transition-all cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Leave</span>
          </button>
        ) : undefined
      }
    >
      {feedback && (
        <div
          className={`mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Mode Switch + Status Filter */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex flex-wrap items-center gap-1.5">
          {viewMode === 'applications' &&
            (['All', 'Pending', 'Approved', 'Rejected', 'Cancelled'] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusTab(st)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer border ${
                  statusTab === st
                    ? 'btn-rsu-primary border-transparent'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {st}
              </button>
            ))}
          {viewMode === 'balances' && (
            <div className="flex items-center gap-2 text-xs">
              <label htmlFor="leave-balance-year" className="font-semibold text-slate-700">
                Credit Year:
              </label>
              <select
                id="leave-balance-year"
                value={balanceYear}
                onChange={(e) => setBalanceYear(Number(e.target.value))}
                className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white font-mono-num font-bold text-[#07442B]"
              >
                {[currentManilaYear - 1, currentManilaYear, currentManilaYear + 1].map((yr) => (
                  <option key={yr} value={yr}>
                    {yr}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        <div className="inline-flex rounded-xl bg-slate-100 p-1 text-xs">
          <button
            type="button"
            onClick={() => setViewMode('applications')}
            className={`px-3 py-1 rounded-lg font-semibold cursor-pointer ${
              viewMode === 'applications' ? 'bg-white text-[#07442B] shadow-2xs' : 'text-slate-600'
            }`}
          >
            Applications
          </button>
          <button
            type="button"
            onClick={() => setViewMode('balances')}
            className={`px-3 py-1 rounded-lg font-semibold cursor-pointer ${
              viewMode === 'balances' ? 'bg-white text-[#07442B] shadow-2xs' : 'text-slate-600'
            }`}
          >
            Leave Balances
          </button>
          {canApprove && (
            <button
              type="button"
              onClick={() => setViewMode('policies')}
              className={`px-3 py-1 rounded-lg font-semibold cursor-pointer inline-flex items-center gap-1 ${
                viewMode === 'policies' ? 'bg-white text-[#07442B] shadow-2xs' : 'text-slate-600'
              }`}
            >
              <SlidersHorizontal className="w-3 h-3" />
              <span>Policies</span>
            </button>
          )}
        </div>
      </div>

      {viewMode === 'applications' ? (
        <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4">Leave Type</th>
                <th className="py-3 px-4">Duration</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {loading ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400">
                    Loading leave applications...
                  </td>
                </tr>
              ) : leaves.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400">
                    No leave applications found.
                  </td>
                </tr>
              ) : (
                leaves.map((l) => (
                  <tr key={l.id} className="hover:bg-emerald-50/35 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-900">{l.employee_name}</div>
                      <div className="text-[11px] text-slate-400 font-mono-num">
                        {l.employee_code} · {l.department_code}
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-800 whitespace-nowrap">
                        {l.leave_type}
                        {formatPortionTag(l.day_portion)}
                      </div>
                      {(l.document_reference || l.has_attachment === 1) && (
                        <div className="text-[11px] text-emerald-700 inline-flex items-center gap-0.5 font-semibold">
                          <FileText className="w-3 h-3" /> Documented
                        </div>
                      )}
                    </td>
                    <td className="py-3.5 px-4 font-mono-num text-slate-700 whitespace-nowrap">
                      {formatDisplayDate(l.start_date)} – {formatDisplayDate(l.end_date)} ({l.days_count}d)
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <StatusLabel status={l.status} />
                    </td>
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => openDetails(l)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-[#0B5537] hover:bg-emerald-50 cursor-pointer"
                          aria-label={`View leave details for ${l.employee_name}`}
                          title="Inspect Per-Day Allocation & Audit Trail"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        {l.status === 'Pending' && canApprove && (
                          <>
                            <button
                              type="button"
                              disabled={actionBusy}
                              onClick={() => handleDecision(l.id, 'Approved')}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg btn-rsu-primary text-[11px] font-semibold cursor-pointer disabled:opacity-60"
                            >
                              <Check className="w-3 h-3" />
                              <span>Approve</span>
                            </button>
                            <button
                              type="button"
                              disabled={actionBusy}
                              onClick={() => handleDecision(l.id, 'Rejected')}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 text-[11px] font-semibold cursor-pointer disabled:opacity-60"
                            >
                              <X className="w-3 h-3" />
                              <span>Reject</span>
                            </button>
                          </>
                        )}
                        {((l.status === 'Approved' && canApprove) ||
                          (l.status === 'Pending' && isEmployeeSelf)) && (
                          <button
                            type="button"
                            onClick={() => openDetails(l)}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-[11px] font-semibold cursor-pointer"
                            title="Cancel leave request"
                          >
                            <Ban className="w-3 h-3" />
                            <span>Cancel</span>
                          </button>
                        )}
                        {canDelete && (
                          <button
                            type="button"
                            onClick={() => setDeleting(l)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                            aria-label={`Delete leave for ${l.employee_name}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      ) : viewMode === 'balances' ? (
        <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4 text-right">VL ({balanceYear})</th>
                <th className="py-3 px-4 text-right">SL ({balanceYear})</th>
                <th className="py-3 px-4 text-right">EL ({balanceYear})</th>
                <th className="py-3 px-4 text-right">OB</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {balances.map((b) => (
                <tr key={b.employee_id} className="hover:bg-emerald-50/35">
                  <td className="py-3 px-4">
                    <span className="font-semibold text-slate-900">{b.employee_name}</span>
                    <span className="ml-2 text-[11px] text-slate-400 font-mono-num">
                      {b.employee_code}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-600">{b.department_code}</td>
                  <td className="py-3 px-4 text-right font-mono-num">
                    <span className="text-slate-500">{b.vl_used}/{b.vl_entitlement}d</span> ·{' '}
                    <span className="font-bold text-[#0B5537]">{b.vl_remaining}d left</span>
                    {b.vl_pending > 0 && (
                      <div className="text-[10px] text-amber-700">{b.vl_pending}d pending</div>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right font-mono-num">
                    <span className="text-slate-500">{b.sl_used}/{b.sl_entitlement}d</span> ·{' '}
                    <span className="font-bold text-blue-700">{b.sl_remaining}d left</span>
                    {b.sl_pending > 0 && (
                      <div className="text-[10px] text-amber-700">{b.sl_pending}d pending</div>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right font-mono-num">
                    <span className="text-slate-500">{b.el_used}/{b.el_entitlement}d</span> ·{' '}
                    <span className="font-bold text-slate-800">{b.el_remaining}d left</span>
                  </td>
                  <td className="py-3 px-4 text-right font-mono-num text-slate-700">{b.ob_days}d</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
                <th className="py-3 px-4">Leave Type</th>
                <th className="py-3 px-4 text-right">Annual Credits</th>
                <th className="py-3 px-4">Rules</th>
                <th className="py-3 px-4 text-right">Doc Required After</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {policies.map((p) => (
                <tr key={p.id} className="hover:bg-emerald-50/35">
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-slate-900">{p.leave_type}</div>
                    <div className="text-[11px] text-slate-400 font-mono-num">
                      {p.code} · Maps to {p.attendance_status}
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono-num font-bold text-[#07442B]">
                    {p.track_balance ? `${p.annual_entitlement}d / yr` : 'Untracked'}
                  </td>
                  <td className="py-3.5 px-4 text-[11px] text-slate-600">
                    {[
                      p.allow_half_day ? 'Half-day OK' : 'Full-day only',
                      p.exclude_weekends_rest_days ? 'Excl. Weekends/Rest' : 'Incl. Weekends',
                      p.exclude_holidays ? 'Excl. Holidays' : 'Incl. Holidays',
                      p.allow_negative_balance ? 'Overdraft OK' : 'Strict Balance',
                    ].join(' · ')}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono-num text-slate-700">
                    {p.requires_document_after_days > 0 ? `≥ ${p.requires_document_after_days}d` : 'Optional'}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      type="button"
                      onClick={() => setEditingPolicy({ ...p })}
                      className="px-3 py-1 rounded-lg border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[11px] font-semibold cursor-pointer"
                    >
                      Configure
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Leave Detail, Per-Day Allocations, Conflict Resolution, Cancellation & Audit Modal */}
      <Modal
        open={Boolean(viewing)}
        onClose={() => setViewing(null)}
        title="Leave Application Details & Per-Day Propagation"
        subtitle={
          viewing
            ? `${viewing.employee_name} (${viewing.employee_code}) · ${viewing.leave_type}`
            : undefined
        }
        maxWidth="max-w-2xl"
      >
        {viewing && (
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200/80">
              <div>
                <p className="text-slate-400">Date Range</p>
                <p className="font-mono-num font-bold text-slate-900 mt-0.5">
                  {formatDisplayDate(viewing.start_date)} – {formatDisplayDate(viewing.end_date)}
                </p>
              </div>
              <div>
                <p className="text-slate-400">Eligible Credits</p>
                <p className="font-mono-num font-bold text-[#0B5537] mt-0.5">
                  {viewing.days_count}d{formatPortionTag(viewing.day_portion)}
                </p>
              </div>
              <div>
                <p className="text-slate-400">Status</p>
                <div className="mt-1">
                  <StatusLabel status={viewing.status} />
                </div>
              </div>
              <div className="col-span-2 sm:col-span-3">
                <p className="text-slate-400">Reason</p>
                <p className="text-slate-800 mt-0.5">{viewing.reason || '—'}</p>
              </div>
              {(viewing.document_reference || viewing.attachment_name) && (
                <div className="col-span-2 sm:col-span-3 flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200/70">
                  <div>
                    <p className="text-slate-400">Supporting Documentation</p>
                    <p className="font-mono-num text-slate-700 mt-0.5">
                      {viewing.document_reference || viewing.attachment_name}
                    </p>
                  </div>
                  {viewing.attachment_data && viewing.attachment_name && (
                    <button
                      type="button"
                      onClick={() =>
                        downloadBase64Attachment(
                          viewing.attachment_name!,
                          viewing.attachment_mime || 'application/octet-stream',
                          viewing.attachment_data!
                        )
                      }
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-emerald-200 bg-emerald-50 text-emerald-800 font-semibold cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </button>
                  )}
                </div>
              )}
              {viewing.status === 'Cancelled' && viewing.cancel_reason && (
                <div className="col-span-2 sm:col-span-3 pt-2 border-t border-slate-200/70 text-slate-700">
                  <span className="font-bold">Cancelled by {viewing.cancelled_by}:</span> {viewing.cancel_reason}
                </div>
              )}
            </div>

            {/* Per-Day Allocations */}
            <div>
              <h3 className="font-bold text-[#07442B] mb-2">Per-Day Credit &amp; Attendance Allocations</h3>
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left border-collapse text-[11px]">
                  <thead>
                    <tr className="bg-[#F4F8F6] border-b border-slate-200 text-slate-700 font-bold">
                      <th className="py-2 px-3">Date</th>
                      <th className="py-2 px-3">Year</th>
                      <th className="py-2 px-3">Credit</th>
                      <th className="py-2 px-3">Attendance State</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {detailLoading ? (
                      <tr>
                        <td colSpan={4} className="py-4 text-center text-slate-400">
                          Loading allocations...
                        </td>
                      </tr>
                    ) : viewingAllocations.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-4 text-center text-slate-400">
                          No eligible day allocations.
                        </td>
                      </tr>
                    ) : (
                      viewingAllocations.map((a) => (
                        <tr key={a.id}>
                          <td className="py-2 px-3 font-mono-num font-semibold text-slate-800">
                            {formatDisplayDate(a.leave_date)}
                          </td>
                          <td className="py-2 px-3 font-mono-num text-slate-600">{a.leave_year}</td>
                          <td className="py-2 px-3 font-mono-num text-slate-800">
                            {a.day_fraction}d ({a.day_portion})
                          </td>
                          <td className="py-2 px-3 text-slate-600">
                            {a.conflict_preserved === 1
                              ? `Valid punch preserved (${a.conflict_note || 'not overwritten'})`
                              : a.attendance_applied === 1
                              ? 'Applied to Attendance Records'
                              : 'Pending / Not applied'}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Review Panel for Pending Leaves */}
            {viewing.status === 'Pending' && canApprove && (
              <div className="p-3.5 rounded-xl bg-[#F4F8F6] border border-emerald-950/10 space-y-3">
                <p className="font-bold text-[#07442B]">Approve or Reject Leave Request</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Existing Valid Punch Policy
                    </label>
                    <select
                      value={conflictResolution}
                      onChange={(e) =>
                        setConflictResolution(e.target.value as 'BLOCK' | 'PRESERVE_PUNCHES')
                      }
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white"
                    >
                      <option value="BLOCK">Block approval if valid punches exist (Strict)</option>
                      <option value="PRESERVE_PUNCHES">
                        Preserve valid punched dates &amp; apply leave to unpunched dates
                      </option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Reviewer Notes</label>
                    <input
                      type="text"
                      value={reviewNotes}
                      onChange={(e) => setReviewNotes(e.target.value)}
                      placeholder="Optional approval/rejection remarks..."
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 bg-white"
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    disabled={actionBusy}
                    onClick={() =>
                      handleDecision(viewing.id, 'Rejected', { reviewer_notes: reviewNotes })
                    }
                    className="px-4 py-2 rounded-lg border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 font-semibold cursor-pointer"
                  >
                    Reject
                  </button>
                  <button
                    type="button"
                    disabled={actionBusy}
                    onClick={() =>
                      handleDecision(viewing.id, 'Approved', {
                        reviewer_notes: reviewNotes,
                        conflict_resolution: conflictResolution,
                      })
                    }
                    className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
                  >
                    {actionBusy ? 'Applying...' : 'Approve & Propagate Attendance'}
                  </button>
                </div>
              </div>
            )}

            {/* Cancellation Panel (Approved for HR/Admin/DeptHead, Pending for Employee/HR/Admin) */}
            {((viewing.status === 'Approved' && canApprove) ||
              (viewing.status === 'Pending' && (canApprove || isEmployeeSelf))) && (
              <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 space-y-2">
                <p className="font-bold text-amber-900">
                  Cancel {viewing.status === 'Approved' ? 'Approved ' : ''}Leave Request
                </p>
                <p className="text-[11px] text-amber-800">
                  {viewing.status === 'Approved'
                    ? 'Atomically restores affected Attendance Records and returns leave credits to the employee balance.'
                    : 'Withdraws this pending leave request before approval.'}
                </p>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={cancelReason}
                    onChange={(e) => setCancelReason(e.target.value)}
                    placeholder="Mandatory cancellation reason (min 5 characters)..."
                    className="flex-1 px-3 py-1.5 rounded-lg border border-amber-300 bg-white"
                  />
                  <button
                    type="button"
                    disabled={actionBusy}
                    onClick={() => handleCancelLeave(viewing.id)}
                    className="inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-amber-700 hover:bg-amber-800 text-white font-semibold cursor-pointer"
                  >
                    <Ban className="w-3.5 h-3.5" />
                    <span>Cancel Leave</span>
                  </button>
                </div>
              </div>
            )}

            {/* Immutable Leave Audit Log */}
            <div>
              <h3 className="font-bold text-[#07442B] mb-2">Immutable Leave Audit Trail</h3>
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left border-collapse text-[11px]">
                  <thead>
                    <tr className="bg-[#F4F8F6] border-b border-slate-200 text-slate-700 font-bold">
                      <th className="py-2 px-3">Timestamp (Manila)</th>
                      <th className="py-2 px-3">Action</th>
                      <th className="py-2 px-3">Actor / Role</th>
                      <th className="py-2 px-3">Reason / Notes</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {viewingAudit.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-4 text-center text-slate-400">
                          No audit entries logged.
                        </td>
                      </tr>
                    ) : (
                      viewingAudit.map((entry) => (
                        <tr key={entry.id}>
                          <td className="py-2 px-3 font-mono-num text-slate-600 whitespace-nowrap">
                            {entry.recorded_at_manila}
                          </td>
                          <td className="py-2 px-3 font-bold text-slate-800 whitespace-nowrap">{entry.action}</td>
                          <td className="py-2 px-3 whitespace-nowrap">
                            <span className="font-semibold text-slate-800">{entry.actor_username}</span>
                            <span className="text-slate-400"> ({entry.actor_role})</span>
                          </td>
                          <td className="py-2 px-3 text-slate-600">{entry.reason || '—'}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* New Leave Application Modal with Live Eligibility Preview */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="New Leave Application"
        subtitle="File an employee leave request validated against RSU – Cajidiocan HR leave policies."
        maxWidth="max-w-xl"
      >
        <form onSubmit={handleCreate} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {!isEmployeeSelf && (
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Employee *</label>
                <select
                  required
                  value={form.employee_id}
                  onChange={(e) => setForm({ ...form, employee_id: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
                >
                  {employees.map((e) => (
                    <option key={e.id} value={e.id}>
                      {e.employee_code} — {e.full_name}
                    </option>
                  ))}
                </select>
              </div>
            )}
            <div className={isEmployeeSelf ? 'sm:col-span-2' : ''}>
              <label className="block font-semibold text-slate-700 mb-1">Leave Type *</label>
              <select
                value={form.leave_type}
                onChange={(e) => setForm({ ...form, leave_type: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
              >
                {(policies.length > 0
                  ? policies.map((p) => p.leave_type)
                  : [
                      'Vacation Leave',
                      'Sick Leave',
                      'Emergency Leave',
                      'Official Business',
                      'Maternity/Paternity',
                    ]
                ).map((lt) => (
                  <option key={lt} value={lt}>
                    {lt}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Start Date *</label>
              <input
                type="date"
                required
                value={form.start_date}
                onChange={(e) =>
                  setForm({
                    ...form,
                    start_date: e.target.value,
                    end_date: e.target.value > form.end_date ? e.target.value : form.end_date,
                  })
                }
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">End Date *</label>
              <input
                type="date"
                required
                value={form.end_date}
                onChange={(e) => setForm({ ...form, end_date: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Day Portion</label>
              <select
                value={form.start_date === form.end_date ? form.day_portion : 'FULL'}
                disabled={form.start_date !== form.end_date}
                onChange={(e) => setForm({ ...form, day_portion: e.target.value as LeaveDayPortion })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white disabled:bg-slate-100"
              >
                <option value="FULL">Full Day (1.0d)</option>
                <option value="HALF_AM">Half Day AM (0.5d)</option>
                <option value="HALF_PM">Half Day PM (0.5d)</option>
              </select>
            </div>
          </div>

          {/* Live Eligibility & Balance Preview Box */}
          {previewError ? (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-800">{previewError}</div>
          ) : preview ? (
            <div className="p-3.5 rounded-xl bg-[#F4F8F6] border border-emerald-950/10 space-y-1.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-bold text-[#07442B]">
                  Eligible Credits: {preview.total_eligible_credits}d ({preview.eligible_days.length} working day(s))
                </span>
                <span className="font-mono-num text-[11px] text-slate-500">
                  {preview.calendar_days} calendar day(s) · {preview.excluded_days.length} excluded
                </span>
              </div>
              {preview.excluded_days.length > 0 && (
                <p className="text-[11px] text-slate-600">
                  Excluded: {preview.excluded_days.map((d) => `${d.date} (${d.detail})`).join(', ')}
                </p>
              )}
              {preview.balance_check.years.map((yr) => (
                <p
                  key={yr.year}
                  className={`text-[11px] font-mono-num ${
                    yr.remaining_after < 0 && !preview.policy.allow_negative_balance
                      ? 'text-red-700 font-bold'
                      : 'text-slate-700'
                  }`}
                >
                  {yr.year} Balance: {yr.entitlement}d entitlement − {yr.approved_used}d used − {yr.requested}d
                  requested = {yr.remaining_after}d remaining
                </p>
              ))}
              {preview.overlapping_leaves.length > 0 && (
                <p className="text-[11px] font-bold text-red-700">
                  Overlap detected with existing leave #{preview.overlapping_leaves[0].id} (
                  {preview.overlapping_leaves[0].start_date} – {preview.overlapping_leaves[0].end_date}).
                </p>
              )}
              {preview.conflicting_punch_dates.length > 0 && (
                <p className="text-[11px] font-semibold text-amber-800">
                  Warning: Valid attendance punches exist on{' '}
                  {preview.conflicting_punch_dates.map((c) => c.date).join(', ')}. Reviewer must resolve on approval.
                </p>
              )}
              {preview.policy.requires_document_after_days > 0 &&
                preview.total_eligible_credits >= preview.policy.requires_document_after_days && (
                  <p className="text-[11px] font-semibold text-[#0B5537]">
                    Documentation required for {preview.policy.leave_type} ≥{' '}
                    {preview.policy.requires_document_after_days} day(s).
                  </p>
                )}
            </div>
          ) : null}

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Reason / Notes * (min 5 chars)</label>
            <textarea
              required
              minLength={5}
              rows={3}
              value={form.reason}
              onChange={(e) => setForm({ ...form, reason: e.target.value })}
              placeholder="Specify reason or supporting notes..."
              className="w-full px-3 py-2 rounded-lg border border-slate-300"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Document Reference</label>
              <input
                type="text"
                value={form.document_reference}
                onChange={(e) => setForm({ ...form, document_reference: e.target.value })}
                placeholder="e.g. MED-CERT-2026-019"
                className="w-full px-3 py-2 rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Supporting Attachment</label>
              <input
                type="file"
                accept=".pdf,.png,.jpg,.jpeg,.webp,.txt"
                onChange={handleAttachmentChange}
                className="w-full text-[11px] text-slate-600 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-emerald-50 file:text-emerald-800 file:font-semibold"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
            >
              {saving ? 'Submitting...' : 'Submit Leave'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Edit Leave Policy Modal */}
      <Modal
        open={Boolean(editingPolicy)}
        onClose={() => setEditingPolicy(null)}
        title={editingPolicy ? `Configure Policy: ${editingPolicy.leave_type}` : 'Configure Leave Policy'}
        subtitle="HR-approved annual credit entitlement and calendar exclusion rules."
        maxWidth="max-w-md"
      >
        {editingPolicy && (
          <form onSubmit={handleSavePolicy} className="space-y-3.5 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Annual Entitlement (days)</label>
                <input
                  type="number"
                  step="0.5"
                  min={0}
                  max={365}
                  value={editingPolicy.annual_entitlement}
                  onChange={(e) =>
                    setEditingPolicy({ ...editingPolicy, annual_entitlement: Number(e.target.value) })
                  }
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Doc Required After (days)</label>
                <input
                  type="number"
                  step="0.5"
                  min={0}
                  max={365}
                  value={editingPolicy.requires_document_after_days}
                  onChange={(e) =>
                    setEditingPolicy({
                      ...editingPolicy,
                      requires_document_after_days: Number(e.target.value),
                    })
                  }
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
                />
              </div>
            </div>
            <div className="space-y-2 pt-1">
              {[
                { key: 'track_balance', label: 'Track annual balance credits' },
                { key: 'allow_half_day', label: 'Allow half-day (0.5d AM/PM) applications' },
                { key: 'exclude_weekends_rest_days', label: 'Exclude weekends & shift rest days' },
                { key: 'exclude_holidays', label: 'Exclude campus holidays' },
                { key: 'allow_negative_balance', label: 'Allow negative leave balance (overdraft)' },
              ].map((opt) => (
                <label key={opt.key} className="flex items-center gap-2 text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={Boolean(editingPolicy[opt.key as keyof LeavePolicy])}
                    onChange={(e) =>
                      setEditingPolicy({
                        ...editingPolicy,
                        [opt.key]: e.target.checked ? 1 : 0,
                      })
                    }
                    className="w-4 h-4 accent-[#0B5537]"
                  />
                  <span>{opt.label}</span>
                </label>
              ))}
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingPolicy(null)}
                className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={policySaving}
                className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
              >
                {policySaving ? 'Saving...' : 'Save Policy'}
              </button>
            </div>
          </form>
        )}
      </Modal>

      <ConfirmModal
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={confirmDelete}
        title="Delete Leave Record?"
        message={
          deleting
            ? `Delete ${deleting.leave_type} application for ${deleting.employee_name}? If approved, its attendance entries will be restored first.`
            : ''
        }
        confirmLabel="Delete Leave"
        destructive
      />
    </ModuleFrame>
  );
};
