import React, { useCallback, useEffect, useRef, useState } from 'react';
import { apiFetch, getManilaTodayIso } from '../lib/api';
import {
  useRealtimeStream,
  type RealtimeConnectionStatus,
} from '../lib/realtime';
import { createRefreshCoalescer } from '../lib/refreshCoalescer';
import type {
  AuthUser,
  CorrectionRequest,
  LeavePolicy,
  LeaveRequest,
  PayrollItem,
} from '../types';
import { EmployeeOnboardingFlow } from './employee/EmployeeEntryFlow';
import {
  ConfirmationDialog,
  EmployeeBottomNavigation,
  EmployeeHeader,
  EmployeePageLayout,
  EmployeeSidebar,
} from './employee/EmployeePrimitives';
import {
  MyPayslipsScreen,
  PayslipDetailsScreen,
} from './employee/PayslipsScreens';
import {
  AboutSystemScreen,
  AccountSecurityScreen,
  ChangePasswordScreen,
  MyProfileScreen,
  NotificationsScreen,
} from './employee/ProfileAndUtilityScreens';
import {
  AttendanceCorrectionFormScreen,
  LeaveRequestFormScreen,
  MyRequestsTrackingScreen,
  RequestSuccessScreen,
} from './employee/RequestsScreens';
import {
  AttendanceRecordsScreen,
  TodayDashboardScreen,
} from './employee/TodayAndAttendanceScreens';
import {
  extractErrorMessage,
  type EmployeeMonthRow,
  type EmployeeNotificationItem,
  type EmployeeProfileData,
  type EmployeeScreen,
  type EmployeeTab,
  type EmployeeTodayResponse,
  type RequestSuccessPayload,
} from './employee/types';

const INACTIVITY_STORAGE_KEY = 'savage_rsucaj_emp_timeout_min';

function readStoredInactivityMinutes(): number {
  try {
    const raw = window.localStorage.getItem(INACTIVITY_STORAGE_KEY);
    if (raw === null) return 30;
    const n = Number(raw);
    if ([0, 15, 30, 60].includes(n)) return n;
  } catch {
    // ignore storage errors
  }
  return 30;
}

interface EmployeeMobilePortalProps {
  user: AuthUser;
  onLogout: () => void;
  onUserChanged?: (user: AuthUser) => void;
}

export const EmployeeMobilePortal: React.FC<EmployeeMobilePortalProps> = ({
  user,
  onLogout,
  onUserChanged,
}) => {
  const initialDate = getManilaTodayIso();
  const initialMonth = initialDate.slice(0, 7);

  // Navigation state
  const [activeTab, setActiveTab] = useState<EmployeeTab>('today');
  const [screen, setScreen] = useState<EmployeeScreen>('today');
  const [previousScreen, setPreviousScreen] = useState<EmployeeScreen>('today');
  const [signOutConfirmOpen, setSignOutConfirmOpen] = useState(false);

  // Selected sub-screen payloads
  const [selectedPayslip, setSelectedPayslip] = useState<PayrollItem | null>(null);
  const [lastSubmittedRequest, setLastSubmittedRequest] =
    useState<RequestSuccessPayload | null>(null);
  const [highlightedRequestKey, setHighlightedRequestKey] = useState<string | null>(null);

  // Realtime status & inactivity timeout
  const [realtimeStatus, setRealtimeStatus] =
    useState<RealtimeConnectionStatus>('connecting');
  const [inactivityMinutes, setInactivityMinutes] = useState<number>(
    readStoredInactivityMinutes
  );

  // Live backend data state
  const [todayData, setTodayData] = useState<EmployeeTodayResponse | null>(null);
  const [todayLoading, setTodayLoading] = useState(true);
  const [todayError, setTodayError] = useState<string | null>(null);

  const [selectedMonth, setSelectedMonth] = useState<string>(initialMonth);
  const [monthRows, setMonthRows] = useState<EmployeeMonthRow[]>([]);
  const [monthLoading, setMonthLoading] = useState(true);
  const [monthError, setMonthError] = useState<string | null>(null);

  const [currentMonthRows, setCurrentMonthRows] = useState<EmployeeMonthRow[]>([]);

  const [leaves, setLeaves] = useState<LeaveRequest[]>([]);
  const [corrections, setCorrections] = useState<CorrectionRequest[]>([]);
  const [policies, setPolicies] = useState<LeavePolicy[]>([]);
  const [requestsLoading, setRequestsLoading] = useState(false);
  const [requestsError, setRequestsError] = useState<string | null>(null);

  const [payslips, setPayslips] = useState<PayrollItem[]>([]);
  const [payslipsEmployeeId, setPayslipsEmployeeId] = useState<number | null>(
    user.employee_id ?? null
  );
  const [payslipsLoading, setPayslipsLoading] = useState(false);
  const [payslipsError, setPayslipsError] = useState<string | null>(null);

  const [profile, setProfile] = useState<EmployeeProfileData | null>(null);
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileError, setProfileError] = useState<string | null>(null);

  const [notifications, setNotifications] = useState<EmployeeNotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [notifLoading, setNotifLoading] = useState(false);
  const [notifError, setNotifError] = useState<string | null>(null);

  // Stale-session / user-switch isolation guard
  const activeUserIdRef = useRef<number>(user.id);
  useEffect(() => {
    activeUserIdRef.current = user.id;
  }, [user.id]);

  // Clear state if user ID changes
  useEffect(() => {
    setTodayData(null);
    setMonthRows([]);
    setCurrentMonthRows([]);
    setLeaves([]);
    setCorrections([]);
    setPayslips([]);
    setProfile(null);
    setNotifications([]);
    setUnreadCount(0);
    setSelectedPayslip(null);
    setLastSubmittedRequest(null);
    setActiveTab('today');
    setScreen('today');
  }, [user.id]);

  const loadToday = useCallback(async () => {
    const uid = user.id;
    setTodayLoading(true);
    setTodayError(null);
    try {
      const res = await apiFetch<EmployeeTodayResponse>('/api/employee/today-attendance');
      if (activeUserIdRef.current !== uid) return;
      setTodayData(res);
    } catch (err) {
      if (activeUserIdRef.current !== uid) return;
      setTodayError(extractErrorMessage(err));
    } finally {
      if (activeUserIdRef.current === uid) setTodayLoading(false);
    }
  }, [user.id]);

  const loadMonth = useCallback(
    async (month: string) => {
      const uid = user.id;
      setMonthLoading(true);
      setMonthError(null);
      try {
        const res = await apiFetch<{ data: EmployeeMonthRow[] }>(
          `/api/employee/attendance-month?month=${encodeURIComponent(month)}`
        );
        if (activeUserIdRef.current !== uid) return;
        const rows = res.data || [];
        setMonthRows(rows);
        if (month === getManilaTodayIso().slice(0, 7)) {
          setCurrentMonthRows(rows);
        }
      } catch (err) {
        if (activeUserIdRef.current !== uid) return;
        setMonthError(extractErrorMessage(err));
      } finally {
        if (activeUserIdRef.current === uid) setMonthLoading(false);
      }
    },
    [user.id]
  );

  const loadCurrentMonthSummary = useCallback(async () => {
    const uid = user.id;
    const curMonth = getManilaTodayIso().slice(0, 7);
    try {
      const res = await apiFetch<{ data: EmployeeMonthRow[] }>(
        `/api/employee/attendance-month?month=${encodeURIComponent(curMonth)}`
      );
      if (activeUserIdRef.current !== uid) return;
      setCurrentMonthRows(res.data || []);
    } catch {
      // non-fatal; today error already shown if needed
    }
  }, [user.id]);

  const loadRequests = useCallback(async () => {
    const uid = user.id;
    setRequestsLoading(true);
    setRequestsError(null);
    try {
      const [lvRes, crRes, polRes] = await Promise.all([
        apiFetch<{ data: LeaveRequest[] }>('/api/leaves'),
        apiFetch<{ data: CorrectionRequest[] }>('/api/corrections'),
        apiFetch<{ data: LeavePolicy[] }>('/api/leaves/policies'),
      ]);
      if (activeUserIdRef.current !== uid) return;
      setLeaves(lvRes.data || []);
      setCorrections(crRes.data || []);
      setPolicies(polRes.data || []);
    } catch (err) {
      if (activeUserIdRef.current !== uid) return;
      setRequestsError(extractErrorMessage(err));
    } finally {
      if (activeUserIdRef.current === uid) setRequestsLoading(false);
    }
  }, [user.id]);

  const loadPayslips = useCallback(async () => {
    const uid = user.id;
    setPayslipsLoading(true);
    setPayslipsError(null);
    try {
      const res = await apiFetch<{ employee_id: number; payslips: PayrollItem[] }>(
        '/api/payroll/my-payslips'
      );
      if (activeUserIdRef.current !== uid) return;
      setPayslipsEmployeeId(res.employee_id ?? user.employee_id ?? null);
      setPayslips(res.payslips || []);
    } catch (err) {
      if (activeUserIdRef.current !== uid) return;
      setPayslipsError(extractErrorMessage(err));
    } finally {
      if (activeUserIdRef.current === uid) setPayslipsLoading(false);
    }
  }, [user.id, user.employee_id]);

  const loadProfile = useCallback(async () => {
    const uid = user.id;
    setProfileLoading(true);
    setProfileError(null);
    try {
      const res = await apiFetch<{ employee: EmployeeProfileData }>('/api/employee/profile');
      if (activeUserIdRef.current !== uid) return;
      setProfile(res.employee);
    } catch (err) {
      if (activeUserIdRef.current !== uid) return;
      setProfileError(extractErrorMessage(err));
    } finally {
      if (activeUserIdRef.current === uid) setProfileLoading(false);
    }
  }, [user.id]);

  const loadNotifications = useCallback(async () => {
    const uid = user.id;
    setNotifLoading(true);
    setNotifError(null);
    try {
      const res = await apiFetch<{
        data: EmployeeNotificationItem[];
        unreadCount: number;
      }>('/api/employee/notifications');
      if (activeUserIdRef.current !== uid) return;
      setNotifications(res.data || []);
      setUnreadCount(res.unreadCount || 0);
    } catch (err) {
      if (activeUserIdRef.current !== uid) return;
      setNotifError(extractErrorMessage(err));
    } finally {
      if (activeUserIdRef.current === uid) setNotifLoading(false);
    }
  }, [user.id]);

  // Coalesced attendance/notification refresh for realtime bursts
  const selectedMonthRef = useRef(selectedMonth);
  selectedMonthRef.current = selectedMonth;

  const coalescedRealtimeRefreshRef = useRef<(() => Promise<void>) | null>(null);
  const coalescedNotificationRefreshRef = useRef<(() => Promise<void>) | null>(null);
  useEffect(() => {
    coalescedRealtimeRefreshRef.current = createRefreshCoalescer(async () => {
      await Promise.all([
        loadToday(),
        loadMonth(selectedMonthRef.current),
        loadNotifications(),
      ]);
    });
    coalescedNotificationRefreshRef.current = createRefreshCoalescer(async () => {
      await Promise.all([loadNotifications(), loadRequests(), loadPayslips()]);
    });
  }, [loadToday, loadMonth, loadNotifications, loadRequests, loadPayslips]);

  // Initial data load on mount / user change
  useEffect(() => {
    void loadToday();
    void loadCurrentMonthSummary();
    void loadProfile();
    void loadNotifications();
  }, [loadToday, loadCurrentMonthSummary, loadProfile, loadNotifications]);

  // Load month records when month changes
  useEffect(() => {
    void loadMonth(selectedMonth);
  }, [selectedMonth, loadMonth]);

  // Lazy load tab datasets when navigating to Requests or Payslips
  useEffect(() => {
    if (
      screen === 'requests' ||
      screen === 'leave-form' ||
      screen === 'correction-form'
    ) {
      void loadRequests();
    } else if (screen === 'payslips') {
      void loadPayslips();
    } else if (screen === 'notifications') {
      void loadNotifications();
    }
  }, [screen, loadRequests, loadPayslips, loadNotifications]);

  // Real-time SSE stream with polling fallback
  useRealtimeStream({
    channels: ['attendance:updated', 'employee:notification'],
    enabled: Boolean(user && !user.must_change_password),
    onStatusChange: setRealtimeStatus,
    onEvent: (frame) => {
      if (frame.type === 'employee:notification') {
        void coalescedNotificationRefreshRef.current?.();
      } else {
        void coalescedRealtimeRefreshRef.current?.();
      }
    },
    onResync: () => {
      void coalescedRealtimeRefreshRef.current?.();
    },
  });

  // Manila midnight date rollover watcher
  const lastManilaDateRef = useRef(initialDate);
  useEffect(() => {
    const timer = window.setInterval(() => {
      const nowManila = getManilaTodayIso();
      if (nowManila !== lastManilaDateRef.current) {
        lastManilaDateRef.current = nowManila;
        void loadToday();
        void loadCurrentMonthSummary();
      }
    }, 60_000);
    return () => window.clearInterval(timer);
  }, [loadToday, loadCurrentMonthSummary]);

  // Real configurable inactivity auto sign-out timer
  const onLogoutRef = useRef(onLogout);
  onLogoutRef.current = onLogout;

  useEffect(() => {
    if (inactivityMinutes <= 0) return;
    const timeoutMs = inactivityMinutes * 60 * 1000;
    let timerId: number | null = null;

    const resetTimer = () => {
      if (timerId !== null) window.clearTimeout(timerId);
      timerId = window.setTimeout(() => {
        onLogoutRef.current();
      }, timeoutMs);
    };

    const events: Array<keyof WindowEventMap> = [
      'pointerdown',
      'keydown',
      'touchstart',
      'scroll',
    ];
    for (const ev of events) {
      window.addEventListener(ev, resetTimer, { passive: true });
    }
    resetTimer();

    return () => {
      if (timerId !== null) window.clearTimeout(timerId);
      for (const ev of events) {
        window.removeEventListener(ev, resetTimer);
      }
    };
  }, [inactivityMinutes]);

  const handleChangeInactivityMinutes = (mins: number) => {
    setInactivityMinutes(mins);
    try {
      window.localStorage.setItem(INACTIVITY_STORAGE_KEY, String(mins));
    } catch {
      // ignore storage errors
    }
  };

  // History API synchronization so Browser Back steps cleanly through Employee Portal screens
  const historyInitializedRef = useRef(false);
  const pushPortalHistory = useCallback((nextScreen: EmployeeScreen, nextTab: EmployeeTab) => {
    if (typeof window === 'undefined' || !window.history?.pushState) return;
    try {
      const targetUrl = `/employee${nextScreen === 'today' ? '' : `#${nextScreen}`}`;
      window.history.pushState(
        { empPortal: true, screen: nextScreen, tab: nextTab },
        '',
        targetUrl
      );
    } catch {
      // ignore history restrictions
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined' || !window.history?.replaceState) return;
    if (!historyInitializedRef.current) {
      historyInitializedRef.current = true;
      try {
        window.history.replaceState(
          { empPortal: true, screen: 'today', tab: 'today' },
          '',
          '/employee'
        );
      } catch {
        // ignore history restrictions
      }
    }

    const onPopState = (ev: PopStateEvent) => {
      const state = ev.state as {
        empPortal?: boolean;
        screen?: EmployeeScreen;
        tab?: EmployeeTab;
      } | null;
      if (state?.empPortal && state.screen) {
        // Guard sub-screens that require transient payload state
        if (state.screen === 'payslip-details' && !selectedPayslip) {
          setActiveTab('payslips');
          setScreen('payslips');
          return;
        }
        if (state.screen === 'request-success' && !lastSubmittedRequest) {
          setActiveTab('requests');
          setScreen('requests');
          return;
        }
        if (state.tab) setActiveTab(state.tab);
        setScreen(state.screen);
        window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
      }
    };

    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, [selectedPayslip, lastSubmittedRequest]);

  // Navigation helpers
  const selectTab = (tab: EmployeeTab) => {
    setActiveTab(tab);
    setPreviousScreen(screen);
    setScreen(tab);
    pushPortalHistory(tab, tab);
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  };

  const openSubScreen = (next: EmployeeScreen, parentTab?: EmployeeTab) => {
    const resolvedTab = parentTab ?? activeTab;
    setPreviousScreen(screen);
    if (parentTab) setActiveTab(parentTab);
    setScreen(next);
    pushPortalHistory(next, resolvedTab);
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  };

  const handleBack = () => {
    switch (screen) {
      case 'leave-form':
      case 'correction-form':
      case 'request-success':
        setActiveTab('requests');
        setScreen('requests');
        pushPortalHistory('requests', 'requests');
        return;
      case 'payslip-details':
        setActiveTab('payslips');
        setScreen('payslips');
        pushPortalHistory('payslips', 'payslips');
        return;
      case 'change-password':
      case 'account-security':
      case 'about':
        setActiveTab('profile');
        setScreen('profile');
        pushPortalHistory('profile', 'profile');
        return;
      case 'notifications': {
        const target = previousScreen === 'notifications' ? activeTab : previousScreen;
        setScreen(target);
        pushPortalHistory(target, activeTab);
        return;
      }
      case 'onboarding-preview':
        setScreen('about');
        pushPortalHistory('about', 'profile');
        return;
      default:
        setScreen(activeTab);
        pushPortalHistory(activeTab, activeTab);
    }
  };

  const handleMarkNotificationAndNavigate = async (
    item: EmployeeNotificationItem
  ) => {
    if (!item.is_read) {
      // Optimistic local state while persisting on server
      setNotifications((prev) =>
        prev.map((n) => (n.key === item.key ? { ...n, is_read: true } : n))
      );
      setUnreadCount((c) => Math.max(0, c - 1));
      try {
        await apiFetch(
          `/api/employee/notifications/${encodeURIComponent(item.key)}/read`,
          { method: 'PATCH' }
        );
      } catch {
        void loadNotifications();
      }
    }

    if (item.target_tab === 'requests') {
      if (item.category === 'Leave Update' && item.entity_id) {
        setHighlightedRequestKey(`leave-${item.entity_id}`);
      } else if (item.category === 'Attendance Correction' && item.entity_id) {
        setHighlightedRequestKey(`correction-${item.entity_id}`);
      }
      selectTab('requests');
    } else {
      selectTab(item.target_tab);
    }
  };

  const handleMarkAllNotificationsRead = async () => {
    const keys = notifications.map((n) => n.key);
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
    setUnreadCount(0);
    try {
      await apiFetch('/api/employee/notifications/mark-all-read', {
        method: 'POST',
        body: JSON.stringify({ keys }),
      });
    } catch {
      void loadNotifications();
    }
  };

  // Full-screen Onboarding Guide preview (launched from Screen 18 About System)
  if (screen === 'onboarding-preview') {
    return (
      <EmployeeOnboardingFlow
        previewMode
        onComplete={() => setScreen('about')}
      />
    );
  }

  // Determine Header variant & title matching all 18 approved PNGs
  const isPrimaryTab =
    screen === 'today' ||
    screen === 'attendance' ||
    screen === 'payslips' ||
    screen === 'profile';

  const secondaryHeaderTitle = (() => {
    switch (screen) {
      case 'requests':
        return 'My Requests';
      case 'leave-form':
      case 'request-success':
        return lastSubmittedRequest?.kind === 'correction' && screen === 'request-success'
          ? 'Attendance Correction'
          : 'Leave Request';
      case 'correction-form':
        return 'Attendance Correction';
      case 'payslip-details':
        return 'Payslip Details';
      case 'change-password':
        return 'Change Password';
      case 'account-security':
        return 'Account Security';
      case 'notifications':
        return 'Notifications';
      case 'about':
        return 'About';
      default:
        return 'SAVAGE-RSUCAJ';
    }
  })();

  const showBottomNav =
    isPrimaryTab || screen === 'requests';

  const headerElement = isPrimaryTab ? (
    <EmployeeHeader
      variant="primary"
      unreadCount={unreadCount}
      onOpenNotifications={() => openSubScreen('notifications')}
    />
  ) : (
    <EmployeeHeader
      variant="secondary"
      title={secondaryHeaderTitle}
      onBack={
        screen === 'requests'
          ? () => selectTab('today')
          : handleBack
      }
    />
  );

  const sidebarElement = (
    <EmployeeSidebar
      activeTab={activeTab}
      activeScreen={screen}
      employeeName={profile?.full_name || user.full_name}
      employeeCode={profile?.employee_code || user.username}
      unreadCount={unreadCount}
      onSelectTab={selectTab}
      onOpenNotifications={() => openSubScreen('notifications')}
      onOpenAbout={() => openSubScreen('about', 'profile')}
      onRequestSignOut={() => setSignOutConfirmOpen(true)}
    />
  );

  const bottomNavElement = showBottomNav ? (
    <EmployeeBottomNavigation activeTab={activeTab} onSelectTab={selectTab} />
  ) : null;

  return (
    <>
      <EmployeePageLayout
        header={headerElement}
        sidebar={sidebarElement}
        bottomNav={bottomNavElement}
        hasBottomNav={showBottomNav}
      >
        {screen === 'today' && (
          <TodayDashboardScreen
            todayData={todayData}
            monthRows={currentMonthRows}
            currentMonth={getManilaTodayIso().slice(0, 7)}
            loading={todayLoading}
            error={todayError}
            realtimeStatus={realtimeStatus}
            onRefresh={() => {
              void loadToday();
              void loadCurrentMonthSummary();
            }}
            onOpenAttendance={() => selectTab('attendance')}
            onOpenCorrectionForm={() => openSubScreen('correction-form', 'requests')}
          />
        )}

        {screen === 'attendance' && (
          <AttendanceRecordsScreen
            month={selectedMonth}
            onChangeMonth={setSelectedMonth}
            rows={monthRows}
            loading={monthLoading}
            error={monthError}
            onRefresh={() => void loadMonth(selectedMonth)}
          />
        )}

        {screen === 'requests' && (
          <MyRequestsTrackingScreen
            leaves={leaves}
            corrections={corrections}
            loading={requestsLoading}
            error={requestsError}
            highlightedRefKey={highlightedRequestKey}
            onRefresh={() => void loadRequests()}
            onOpenLeaveForm={() => openSubScreen('leave-form', 'requests')}
            onOpenCorrectionForm={() => openSubScreen('correction-form', 'requests')}
            onLeaveCancelled={async () => {
              await Promise.all([loadRequests(), loadNotifications()]);
            }}
          />
        )}

        {screen === 'leave-form' && (
          <LeaveRequestFormScreen
            policies={policies}
            onSubmitted={(payload) => {
              setLastSubmittedRequest(payload);
              setHighlightedRequestKey(`leave-${payload.id}`);
              void loadRequests();
              void loadNotifications();
              openSubScreen('request-success', 'requests');
            }}
          />
        )}

        {screen === 'correction-form' && (
          <AttendanceCorrectionFormScreen
            onSubmitted={(payload) => {
              setLastSubmittedRequest(payload);
              setHighlightedRequestKey(`correction-${payload.id}`);
              void loadRequests();
              void loadNotifications();
              openSubScreen('request-success', 'requests');
            }}
          />
        )}

        {screen === 'request-success' && lastSubmittedRequest && (
          <RequestSuccessScreen
            payload={lastSubmittedRequest}
            onViewRequest={() => {
              setHighlightedRequestKey(
                `${lastSubmittedRequest.kind}-${lastSubmittedRequest.id}`
              );
              selectTab('requests');
            }}
            onBackToRequests={() => {
              setHighlightedRequestKey(null);
              selectTab('requests');
            }}
          />
        )}

        {screen === 'payslips' && (
          <MyPayslipsScreen
            payslips={payslips}
            employeeId={payslipsEmployeeId}
            loading={payslipsLoading}
            error={payslipsError}
            onRefresh={() => void loadPayslips()}
            onSelectPayslip={(item) => {
              setSelectedPayslip(item);
              openSubScreen('payslip-details', 'payslips');
            }}
          />
        )}

        {screen === 'payslip-details' && selectedPayslip && (
          <PayslipDetailsScreen
            item={selectedPayslip}
            employeeId={payslipsEmployeeId}
          />
        )}

        {screen === 'profile' && (
          <MyProfileScreen
            user={user}
            profile={profile}
            loading={profileLoading}
            error={profileError}
            onRetry={() => void loadProfile()}
            onOpenChangePassword={() => openSubScreen('change-password', 'profile')}
            onOpenAccountSecurity={() => openSubScreen('account-security', 'profile')}
            onOpenAboutSystem={() => openSubScreen('about', 'profile')}
            onRequestSignOut={() => setSignOutConfirmOpen(true)}
          />
        )}

        {screen === 'change-password' && (
          <ChangePasswordScreen
            onPasswordUpdated={(updatedUser) => {
              onUserChanged?.(updatedUser);
            }}
          />
        )}

        {screen === 'account-security' && (
          <AccountSecurityScreen
            inactivityMinutes={inactivityMinutes}
            onChangeInactivityMinutes={handleChangeInactivityMinutes}
          />
        )}

        {screen === 'notifications' && (
          <NotificationsScreen
            items={notifications}
            unreadCount={unreadCount}
            loading={notifLoading}
            error={notifError}
            onRefresh={() => void loadNotifications()}
            onMarkReadAndNavigate={handleMarkNotificationAndNavigate}
            onMarkAllRead={handleMarkAllNotificationsRead}
          />
        )}

        {screen === 'about' && (
          <AboutSystemScreen
            onOpenOnboardingGuide={() => openSubScreen('onboarding-preview', 'profile')}
          />
        )}
      </EmployeePageLayout>

      <ConfirmationDialog
        open={signOutConfirmOpen}
        title="Sign Out of Employee Portal?"
        message="You will need to sign in again with your Employee ID and password to view your attendance and payslips."
        confirmLabel="Sign Out"
        cancelLabel="Stay Signed In"
        destructive
        onConfirm={() => {
          setSignOutConfirmOpen(false);
          onLogout();
        }}
        onCancel={() => setSignOutConfirmOpen(false)}
      />
    </>
  );
};
