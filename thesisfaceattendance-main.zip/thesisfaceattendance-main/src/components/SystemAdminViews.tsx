import React, { useEffect, useState, useCallback } from 'react';
import {
  MonitorSmartphone,
  ShieldAlert,
  Bell,
  Settings,
  Plus,
  Power,
  Trash2,
  Send,
  Search,
  Download,
  CheckCheck,
  KeyRound,
  DatabaseBackup,
  Clock,
  Info,
  Server,
  Sliders,
  AlertCircle,
  Copy,
  Check,
  Pencil,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Square,
  CheckSquare,
  Users,
  UserPlus,
  RefreshCw,
  ShieldCheck,
  HardDrive,
  Lock,
  RotateCcw,
  FileSearch,
  Play,
} from 'lucide-react';
import { ModuleFrame, Modal, ConfirmModal, StatusLabel } from './ModuleFrame';
import { apiFetch, downloadAuthenticatedBlob, downloadJson, getManilaTodayIso, setCsrfToken } from '../lib/api';
import { useRealtimeStream } from '../lib/realtime';
import { SavageLogo } from './SavageLogo';
import type {
  AppNotification,
  AuditHashVerificationResult,
  AuditLog,
  AuthUser,
  BackupArchiveOption,
  DataRetentionPreview,
  Department,
  Employee,
  KioskDevice,
  KioskSyncBatch,
  NavModule,
  PortalUser,
  RetentionJobRow,
  SecretStatusInfo,
} from '../types';

// ============================================================================
// SCREEN 15 — DEVICES (KIOSK) (15_Devices_Kiosk.png)
// ============================================================================
export const DevicesView: React.FC<{ currentUser?: AuthUser }> = ({ currentUser }) => {
  const canWriteDevices = !currentUser || currentUser.permissions?.includes('devices:write') === true;
  const [devices, setDevices] = useState<KioskDevice[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Ephemeral in-memory cache of tokens minted/rotated during this browser tab session ONLY
  const [sessionTokens, setSessionTokens] = useState<Record<number, string>>({});
  const [oneTimeSecret, setOneTimeSecret] = useState<{
    deviceName: string;
    apiToken: string;
    tokenMasked: string;
    fingerprint: string;
    actionLabel: 'Provisioned' | 'Rotated';
  } | null>(null);
  const [secretCopied, setSecretCopied] = useState(false);

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<KioskDevice | null>(null);
  const [deleting, setDeleting] = useState<KioskDevice | null>(null);
  const [rotatingConfirm, setRotatingConfirm] = useState<KioskDevice | null>(null);
  const [inspecting, setInspecting] = useState<KioskDevice | null>(null);
  const [syncBatches, setSyncBatches] = useState<KioskSyncBatch[]>([]);
  const [batchesLoading, setBatchesLoading] = useState(false);
  const [form, setForm] = useState({
    name: '',
    device_type: 'Raspberry Pi' as 'Raspberry Pi' | 'Android',
    model_info: 'Raspberry Pi 3B',
    ip_address: '192.168.1.103',
    location: 'Library Entrance',
  });

  // Live Kiosk Punch Endpoint Tester
  const [punchOpen, setPunchOpen] = useState(false);
  const [punchDevice, setPunchDevice] = useState<KioskDevice | null>(null);
  const [punchTokenInput, setPunchTokenInput] = useState('');

  // BUILD 36: Web Kiosk Activation Code & Admin PIN Management
  const [activationCodeSecret, setActivationCodeSecret] = useState<{
    deviceName: string;
    activationCode: string;
    expiresAtUtc: string;
  } | null>(null);
  const [activationCopied, setActivationCopied] = useState(false);
  const [pinModalOpen, setPinModalOpen] = useState(false);
  const [pinStatus, setPinStatus] = useState<{ configured: boolean; locked: boolean } | null>(null);
  const [pinValue, setPinValue] = useState('');
  const [pinConfirm, setPinConfirm] = useState('');
  const [pinSaving, setPinSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [devs, pinRes] = await Promise.all([
        apiFetch<{ data: KioskDevice[] }>('/api/devices'),
        apiFetch<{ configured: boolean; locked: boolean }>('/api/kiosk/web/admin-pin/status').catch(() => null),
      ]);
      setDevices(devs.data);
      if (pinRes) setPinStatus(pinRes);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to load kiosk devices.' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  // BUILD 10: Real-time heartbeat & sync telemetry updates over authenticated SSE
  useRealtimeStream({
    channels: ['device:telemetry'],
    onEvent: () => {
      load();
    },
    onResync: () => {
      load();
    },
  });

  useEffect(() => {
    if (!inspecting) {
      setSyncBatches([]);
      return;
    }
    let cancelled = false;
    setBatchesLoading(true);
    apiFetch<{ data: KioskSyncBatch[] }>(`/api/devices/${inspecting.id}/sync-batches`)
      .then((res) => {
        if (!cancelled) setSyncBatches(res.data);
      })
      .catch(() => {
        if (!cancelled) setSyncBatches([]);
      })
      .finally(() => {
        if (!cancelled) setBatchesLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [inspecting]);

  const filtered = devices.filter(
    (d) =>
      !search.trim() ||
      d.name.toLowerCase().includes(search.toLowerCase()) ||
      d.device_type.toLowerCase().includes(search.toLowerCase()) ||
      d.ip_address.includes(search.trim())
  );

  const openAdd = () => {
    setEditing(null);
    setForm({
      name: '',
      device_type: 'Raspberry Pi',
      model_info: 'Raspberry Pi 3B',
      ip_address: '192.168.1.103',
      location: 'Campus Gate',
    });
    setModalOpen(true);
  };

  const openEdit = (d: KioskDevice) => {
    setEditing(d);
    setForm({
      name: d.name,
      device_type: d.device_type,
      model_info: d.model_info,
      ip_address: d.ip_address,
      location: d.location,
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canWriteDevices) return;
    setFeedback(null);
    try {
      if (editing) {
        await apiFetch(`/api/devices/${editing.id}`, { method: 'PUT', body: JSON.stringify(form) });
        setFeedback({ type: 'ok', text: `Updated kiosk device "${form.name}".` });
      } else {
        const created = await apiFetch<{
          id: number;
          api_token?: string;
          token_masked: string;
          token_fingerprint: string;
          one_time_secret?: boolean;
        }>('/api/devices', { method: 'POST', body: JSON.stringify(form) });

        if (created.one_time_secret && created.api_token) {
          setSessionTokens((prev) => ({ ...prev, [created.id]: created.api_token! }));
          setSecretCopied(false);
          setOneTimeSecret({
            deviceName: form.name,
            apiToken: created.api_token,
            tokenMasked: created.token_masked,
            fingerprint: created.token_fingerprint,
            actionLabel: 'Provisioned',
          });
        }
        setFeedback({
          type: 'ok',
          text: `Registered kiosk device "${form.name}". Status remains Offline until a verified heartbeat is received.`,
        });
      }
      setModalOpen(false);
      load();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Save failed.' });
    }
  };

  const confirmRotateToken = async () => {
    if (!canWriteDevices) return;
    if (!rotatingConfirm) return;
    setFeedback(null);
    try {
      const rotated = await apiFetch<{
        id: number;
        name: string;
        api_token: string;
        token_masked: string;
        token_fingerprint: string;
        one_time_secret: boolean;
      }>(`/api/devices/${rotatingConfirm.id}/rotate-token`, { method: 'POST' });

      setSessionTokens((prev) => ({ ...prev, [rotated.id]: rotated.api_token }));
      setSecretCopied(false);
      setOneTimeSecret({
        deviceName: rotated.name,
        apiToken: rotated.api_token,
        tokenMasked: rotated.token_masked,
        fingerprint: rotated.token_fingerprint,
        actionLabel: 'Rotated',
      });
      setRotatingConfirm(null);
      setFeedback({
        type: 'ok',
        text: `Rotated credentials for ${rotated.name}. Previous token invalidated immediately.`,
      });
      load();
    } catch (err) {
      setRotatingConfirm(null);
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to rotate device token.' });
    }
  };

  // BUILD 10: Revoke or restore kiosk credentials (NEVER fabricates Online connectivity)
  const handleRevokeToggle = async (d: KioskDevice) => {
    if (!canWriteDevices) return;
    setFeedback(null);
    try {
      if (d.is_revoked === 1) {
        await apiFetch(`/api/devices/${d.id}/restore-access`, { method: 'POST' });
        setFeedback({
          type: 'ok',
          text: `Restored credential access for ${d.name}. Connectivity will turn Online once a verified heartbeat arrives.`,
        });
      } else {
        await apiFetch(`/api/devices/${d.id}/revoke`, { method: 'POST' });
        setFeedback({
          type: 'ok',
          text: `Revoked credentials for ${d.name}. Subsequent heartbeats and sync batches will be rejected.`,
        });
      }
      load();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to update device access.' });
    }
  };

  const confirmDelete = async () => {
    if (!canWriteDevices || !deleting) return;
    setFeedback(null);
    try {
      await apiFetch(`/api/devices/${deleting.id}`, { method: 'DELETE' });
      setFeedback({ type: 'ok', text: `Revoked & removed device ${deleting.name}.` });
      setDeleting(null);
      load();
    } catch (err) {
      setDeleting(null);
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to remove device.' });
    }
  };

  const openPunchTester = (d: KioskDevice) => {
    if (!canWriteDevices) return;
    setPunchDevice(d);
    setPunchTokenInput(sessionTokens[d.id] || '');
    setPunchOpen(true);
  };

  // Read-only, token-authenticated probe: NEVER issues a biometric-less attendance punch.
  const handleTestPunch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!punchDevice || !punchTokenInput.trim()) return;
    setFeedback(null);
    try {
      const res = await apiFetch<{ device_id: number; device_name: string; bridge_contract: string }>(
        '/api/v1/kiosk/device-info', {
          method: 'GET',
          headers: { 'x-kiosk-token': punchTokenInput.trim(), 'X-Kiosk-Device-Id': punchDevice.name },
        },
      );
      if (res.device_id !== punchDevice.id || res.device_name !== punchDevice.name || res.bridge_contract !== 'SAVAGE_ANDROID_V1') {
        throw new Error('Device identity or API contract mismatch.');
      }
      setPunchOpen(false);
      setFeedback({ type: 'ok', text: `Verified authenticated read-only connection for ${res.device_name}. No attendance record created.` });
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Device connection probe failed.' });
    }
  };

  const copyOneTimeToken = () => {
    if (!oneTimeSecret) return;
    navigator.clipboard?.writeText(oneTimeSecret.apiToken);
    setSecretCopied(true);
    setTimeout(() => setSecretCopied(false), 2000);
  };

  const handleMintActivationCode = async (d: KioskDevice) => {
    if (!canWriteDevices) return;
    setFeedback(null);
    try {
      const res = await apiFetch<{
        device_name: string;
        activation_code: string;
        expires_at_utc: string;
      }>(`/api/devices/${d.id}/activation-code`, { method: 'POST' });
      setActivationCopied(false);
      setActivationCodeSecret({
        deviceName: res.device_name,
        activationCode: res.activation_code,
        expiresAtUtc: res.expires_at_utc,
      });
      setFeedback({
        type: 'ok',
        text: `Generated one-time Web Kiosk activation code for ${res.device_name}.`,
      });
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to generate activation code.' });
    }
  };

  const handleSaveKioskAdminPin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canWriteDevices) return;
    if (pinValue !== pinConfirm) {
      setFeedback({ type: 'err', text: 'Kiosk Admin PIN and confirmation do not match.' });
      return;
    }
    setPinSaving(true);
    setFeedback(null);
    try {
      await apiFetch('/api/kiosk/web/admin-pin', {
        method: 'PUT',
        body: JSON.stringify({ pin: pinValue }),
      });
      setPinModalOpen(false);
      setPinValue('');
      setPinConfirm('');
      setPinStatus({ configured: true, locked: false });
      setFeedback({
        type: 'ok',
        text: 'Kiosk Administrator PIN updated (scrypt-hashed) and lockout cleared.',
      });
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to update Kiosk Admin PIN.' });
    } finally {
      setPinSaving(false);
    }
  };

  return (
    <ModuleFrame
      title="Devices (Kiosk)"
      subtitle="Manage registered devices."
      icon={<MonitorSmartphone className="w-5 h-5" />}
    >
      {feedback && (
        <div
          className={`mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Search + Add Device Toolbar matching 15_Devices_Kiosk.png */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            aria-label="Search kiosk devices"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search device name, type, or IP..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-white text-xs shadow-2xs focus:outline-none focus:border-[#0B5537]"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <a
            href="/kiosk"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-[#07442B] text-xs font-bold"
          >
            <MonitorSmartphone className="w-3.5 h-3.5" />
            <span>Open Web Kiosk</span>
          </a>
          <button
            type="button"
            disabled={!canWriteDevices}
            onClick={() => {
              setPinValue('');
              setPinConfirm('');
              setPinModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold cursor-pointer disabled:opacity-40"
          >
            <KeyRound className="w-3.5 h-3.5 text-[#0B5537]" />
            <span>{pinStatus?.configured ? 'Update Kiosk PIN' : 'Set Kiosk Admin PIN'}</span>
          </button>
          <button
            type="button"
            disabled={!canWriteDevices}
            onClick={openAdd}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl btn-rsu-primary text-xs font-bold cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Device</span>
          </button>
        </div>
      </div>

      <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
              <th className="py-3 px-4">Device Name</th>
              <th className="py-3 px-4">Type</th>
              <th className="py-3 px-4">IP Address</th>
              <th className="py-3 px-4">Credential (Masked)</th>
              <th className="py-3 px-4">Heartbeat &amp; Sync</th>
              <th className="py-3 px-4 text-center">Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs">
            {loading ? (
              <tr>
                <td colSpan={7} className="py-8 text-center text-slate-400">
                  Loading kiosk devices...
                </td>
              </tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-8 text-center text-slate-400">
                  {search.trim()
                    ? 'No registered kiosk devices match your search.'
                    : 'No kiosk devices registered yet. Click "Add Device" to register a terminal.'}
                </td>
              </tr>
            ) : (
              filtered.map((d) => {
                const liveState = d.connectivity || d.status;
                const queueCount = d.pending_queue_count ?? 0;
                const driftSec = d.last_clock_drift_seconds;
                return (
                  <tr key={d.id} className="hover:bg-emerald-50/35">
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-900">{d.name}</div>
                      <div className="text-[11px] text-slate-400">{d.location}</div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-700 whitespace-nowrap">{d.device_type}</td>
                    <td className="py-3.5 px-4 font-mono-num text-slate-700 whitespace-nowrap">
                      {d.ip_address}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="inline-flex items-center gap-1.5 font-mono-num text-[11px] text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md">
                        <Lock className="w-3 h-3 text-slate-400 shrink-0" />
                        <span>{d.token_masked || '••••••••'}</span>
                        <button
                          type="button"
                          onClick={() => setRotatingConfirm(d)}
                          className="ml-0.5 text-slate-500 hover:text-[#0B5537] cursor-pointer"
                          aria-label={`Rotate credential token for ${d.name}`}
                          title="Rotate Kiosk Token (One-Time Secret)"
                        >
                          <KeyRound className="w-3 h-3" />
                        </button>
                      </div>
                      {d.token_fingerprint && (
                        <div className="text-[10px] font-mono-num text-slate-400 mt-0.5">
                          sha256:{d.token_fingerprint}
                        </div>
                      )}
                    </td>
                    <td className="py-3.5 px-4 font-mono-num text-slate-600">
                      <div className="whitespace-nowrap">
                        Seen: <span className="font-semibold text-slate-800">{d.last_heartbeat || 'Never'}</span>
                      </div>
                      <div className="text-[10px] text-slate-500 flex flex-wrap items-center gap-1.5 mt-0.5">
                        <span>Sync: {d.last_sync_status || 'Idle'}</span>
                        <span>· Queue: {queueCount}</span>
                        {driftSec !== null && driftSec !== undefined && (
                          <span className={Math.abs(driftSec) > 30 ? 'text-amber-700 font-semibold' : ''}>
                            · Drift: {driftSec > 0 ? '+' : ''}{driftSec}s
                          </span>
                        )}
                      </div>
                      {d.last_sync_error && (
                        <div className="text-[10px] text-red-600 truncate max-w-[240px]" title={d.last_sync_error}>
                          {d.last_sync_error}
                        </div>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <StatusLabel status={liveState} showDot />
                      {d.stale_warning && liveState !== 'Offline' && liveState !== 'Revoked' && (
                        <div className="text-[10px] font-semibold text-amber-700 mt-0.5">Heartbeat stale</div>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setInspecting(d)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-[#0B5537] hover:bg-emerald-50 cursor-pointer"
                          aria-label={`Inspect telemetry for ${d.name}`}
                          title="Inspect Sync Telemetry"
                        >
                          <Info className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={!canWriteDevices || d.is_revoked === 1}
                          onClick={() => handleMintActivationCode(d)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-amber-200 bg-amber-50 hover:bg-amber-100 text-amber-900 text-[11px] font-semibold cursor-pointer disabled:opacity-40"
                          title="Mint one-time Web Kiosk (/kiosk) activation code"
                        >
                          <KeyRound className="w-3 h-3" />
                          <span>Activation Code</span>
                        </button>
                        <button
                          type="button"
                          disabled={!canWriteDevices || d.is_revoked === 1}
                          onClick={() => openPunchTester(d)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[11px] font-semibold cursor-pointer disabled:opacity-40"
                        >
                          <Send className="w-3 h-3" />
                          <span>Test Connection</span>
                        </button>
                        <button
                          type="button"
                          disabled={!canWriteDevices}
                          onClick={() => openEdit(d)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-[#0B5537] hover:bg-emerald-50 cursor-pointer"
                          aria-label={`Configure ${d.name}`}
                          title="Edit Hardware Details"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={!canWriteDevices}
                          onClick={() => handleRevokeToggle(d)}
                          className={`p-1.5 rounded-lg cursor-pointer ${
                            d.is_revoked === 1
                              ? 'text-emerald-700 hover:bg-emerald-50'
                              : 'text-slate-500 hover:text-amber-600 hover:bg-amber-50'
                          }`}
                          aria-label={d.is_revoked === 1 ? `Restore access for ${d.name}` : `Revoke access for ${d.name}`}
                          title={d.is_revoked === 1 ? 'Restore Kiosk Credentials' : 'Revoke Kiosk Credentials'}
                        >
                          <Power className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={!canWriteDevices}
                          onClick={() => setDeleting(d)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                          aria-label={`Delete ${d.name}`}
                          title="Remove Device"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-4 p-4 rounded-xl bg-[#F4F8F6] border border-emerald-950/10 text-xs text-slate-600 space-y-1">
        <p className="font-bold text-[#07442B]">Kiosk Hardware Integration, Secret Protection &amp; Offline Sync</p>
        <p>
          Raspberry Pi &amp; Android Kiosk clients authenticate via{' '}
          <code className="font-mono-num bg-white px-1.5 py-0.5 rounded border border-slate-200">
            x-kiosk-token
          </code>{' '}
          against <code className="font-mono-num">POST /api/kiosk/heartbeat</code>,{' '}
          <code className="font-mono-num">POST /api/kiosk/punch</code>, and{' '}
          <code className="font-mono-num">POST /api/kiosk/sync</code>. Tokens are hashed (SHA-256) for lookup and
          fingerprinting, omitted from all read APIs and backup exports, shown only once upon provisioning or rotation,
          and connectivity status strictly tracks real heartbeat expiry.
        </p>
      </div>

      {/* Register / Edit Device Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Configure Kiosk Device' : 'Register Kiosk Device'}
      >
        <form onSubmit={handleSave} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Device Name *</label>
            <input
              type="text"
              required
              placeholder="Kiosk - Library Entrance"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full px-3 py-2 rounded-lg border border-slate-300"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Device Type</label>
              <select
                value={form.device_type}
                onChange={(e) =>
                  setForm({
                    ...form,
                    device_type: e.target.value as 'Raspberry Pi' | 'Android',
                    model_info: e.target.value === 'Android' ? 'Android Kiosk' : 'Raspberry Pi 3B',
                  })
                }
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
              >
                <option value="Raspberry Pi">Raspberry Pi</option>
                <option value="Android">Android</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">IP Address *</label>
              <input
                type="text"
                required
                value={form.ip_address}
                onChange={(e) => setForm({ ...form, ip_address: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Hardware Model</label>
              <input
                type="text"
                value={form.model_info}
                onChange={(e) => setForm({ ...form, model_info: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Location</label>
              <input
                type="text"
                value={form.location}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
            >
              {editing ? 'Save Configuration' : 'Register Device'}
            </button>
          </div>
        </form>
      </Modal>

      {/* One-Time Kiosk Token Reveal Modal */}
      <Modal
        open={Boolean(oneTimeSecret)}
        onClose={() => setOneTimeSecret(null)}
        title={`One-Time Kiosk Token ${oneTimeSecret?.actionLabel || 'Issued'}`}
        subtitle={oneTimeSecret ? `${oneTimeSecret.deviceName} · SHA-256 fingerprint ${oneTimeSecret.fingerprint}` : undefined}
      >
        {oneTimeSecret && (
          <div className="space-y-4 text-xs">
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <p>
                <strong>Save this token now.</strong> For security, SAVAGE-RSUCAJ stores only a SHA-256 hash in the
                database and will not display this plaintext credential again after you close this dialog.
              </p>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">x-kiosk-token Credential</label>
              <div className="flex items-center gap-2">
                <code className="flex-1 px-3 py-2.5 rounded-xl bg-slate-900 text-emerald-300 font-mono-num text-[12px] break-all select-all">
                  {oneTimeSecret.apiToken}
                </code>
                <button
                  type="button"
                  onClick={copyOneTimeToken}
                  className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 font-semibold text-slate-700 cursor-pointer shrink-0"
                >
                  {secretCopied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  <span>{secretCopied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={() => setOneTimeSecret(null)}
                className="px-4 py-2 rounded-xl btn-rsu-primary font-bold cursor-pointer"
              >
                I Have Saved This Token
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Test Kiosk Punch API Modal */}
      <Modal
        open={punchOpen}
        onClose={() => setPunchOpen(false)}
        title="Test Kiosk Connection (Read Only)"
        subtitle={
          punchDevice
            ? `Checks authenticated GET /api/v1/kiosk/device-info for ${punchDevice.name}. No attendance data is changed.`
            : undefined
        }
      >
        <form onSubmit={handleTestPunch} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Kiosk Credential (x-kiosk-token) *</label>
            <input
              type="password"
              required
              autoComplete="off"
              value={punchTokenInput}
              onChange={(e) => setPunchTokenInput(e.target.value)}
              placeholder="Paste provisioned ksk_... token (or rotate device key)"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
            />
            {!punchTokenInput && (
              <p className="text-[11px] text-slate-500 mt-1">
                Stored kiosk tokens are masked on the server. Paste the provisioned token or click the Rotate Key icon on the device row to issue a new one-time token.
              </p>
            )}
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setPunchOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!punchTokenInput.trim()}
              className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold cursor-pointer disabled:opacity-50"
            >
              Verify Device Connection
            </button>
          </div>
        </form>
      </Modal>

      {/* Telemetry Inspection Modal */}
      <Modal
        open={Boolean(inspecting)}
        onClose={() => setInspecting(null)}
        title="Kiosk Sync & Heartbeat Telemetry"
        subtitle={inspecting ? `${inspecting.name} · ${inspecting.model_info} (${inspecting.ip_address})` : undefined}
        maxWidth="max-w-2xl"
      >
        {inspecting && (
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200/80">
              <div>
                <p className="text-slate-400">Connectivity</p>
                <div className="mt-1">
                  <StatusLabel status={inspecting.connectivity || inspecting.status} showDot />
                </div>
              </div>
              <div>
                <p className="text-slate-400">Last Heartbeat (UTC)</p>
                <p className="font-mono-num font-semibold text-slate-800 mt-0.5">
                  {inspecting.last_heartbeat_utc || 'Never'}
                </p>
              </div>
              <div>
                <p className="text-slate-400">Last Sync (UTC)</p>
                <p className="font-mono-num font-semibold text-slate-800 mt-0.5">
                  {inspecting.last_sync_utc || 'Never'}
                </p>
              </div>
              <div>
                <p className="text-slate-400">Pending Offline Queue</p>
                <p className="font-mono-num font-bold text-[#0B5537] mt-0.5">
                  {inspecting.pending_queue_count ?? 0} event(s)
                </p>
              </div>
              <div>
                <p className="text-slate-400">Clock Drift</p>
                <p className="font-mono-num font-semibold text-slate-800 mt-0.5">
                  {inspecting.last_clock_drift_seconds !== null && inspecting.last_clock_drift_seconds !== undefined
                    ? `${inspecting.last_clock_drift_seconds > 0 ? '+' : ''}${inspecting.last_clock_drift_seconds}s`
                    : 'Not reported'}
                </p>
              </div>
              <div>
                <p className="text-slate-400">Token Rotated (UTC)</p>
                <p className="font-mono-num font-semibold text-slate-800 mt-0.5">
                  {inspecting.token_rotated_at || 'Initial issue'}
                </p>
              </div>
              <div className="col-span-2 sm:col-span-3">
                <p className="text-slate-400">Sync Status / Error State</p>
                <p className="font-medium text-slate-800 mt-0.5">
                  {inspecting.last_sync_status || 'Idle'}
                  {inspecting.last_sync_error ? ` — ${inspecting.last_sync_error}` : ' (No sync errors)'}
                </p>
              </div>
            </div>

            <div>
              <h3 className="font-bold text-[#07442B] mb-2">Recent Offline Sync Batches</h3>
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left border-collapse text-[11px]">
                  <thead>
                    <tr className="bg-[#F4F8F6] border-b border-slate-200 text-slate-700 font-bold">
                      <th className="py-2 px-3">Received (UTC)</th>
                      <th className="py-2 px-3">Batch UID</th>
                      <th className="py-2 px-3">Counts</th>
                      <th className="py-2 px-3">Notes</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {batchesLoading ? (
                      <tr>
                        <td colSpan={4} className="py-5 text-center text-slate-400">
                          Loading sync batch history...
                        </td>
                      </tr>
                    ) : syncBatches.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-5 text-center text-slate-400">
                          No batch sync records received from this terminal yet.
                        </td>
                      </tr>
                    ) : (
                      syncBatches.map((b) => (
                        <tr key={b.id}>
                          <td className="py-2 px-3 font-mono-num whitespace-nowrap">{b.received_at_utc}</td>
                          <td className="py-2 px-3 font-mono-num text-slate-600">{b.batch_uid}</td>
                          <td className="py-2 px-3 font-mono-num whitespace-nowrap">
                            {b.accepted_count}/{b.total_events} ok · {b.duplicate_count} dup · {b.conflict_count} conf · {b.rejected_count} rej
                          </td>
                          <td className="py-2 px-3 text-slate-500">{b.error_summary || 'Clean'}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmModal
        open={Boolean(rotatingConfirm)}
        onClose={() => setRotatingConfirm(null)}
        onConfirm={confirmRotateToken}
        title="Rotate Kiosk Credential Token?"
        message={
          rotatingConfirm
            ? `Issue a new one-time API token for "${rotatingConfirm.name}"? The existing token will be invalidated immediately and the terminal must be updated with the new key.`
            : ''
        }
        confirmLabel="Rotate Token Now"
        destructive
      />

      <ConfirmModal
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={confirmDelete}
        title="Revoke & Remove Kiosk Device?"
        message={
          deleting
            ? `Revoke token and permanently remove "${deleting.name}" (${deleting.ip_address})? The terminal will no longer be able to submit punches.`
            : ''
        }
        confirmLabel="Remove Device"
        destructive
      />

      {/* BUILD 36: One-Time Web Kiosk Activation Code Modal */}
      <Modal
        open={Boolean(activationCodeSecret)}
        onClose={() => setActivationCodeSecret(null)}
        title="Web Kiosk Activation Code (One-Time)"
      >
        {activationCodeSecret && (
          <div className="space-y-4 text-xs">
            <p className="text-slate-600">
              Enter this one-time activation code on <code className="font-mono bg-slate-100 px-1.5 py-0.5 rounded">/kiosk</code> to activate{' '}
              <strong className="text-slate-900">{activationCodeSecret.deviceName}</strong> with an HttpOnly revocable browser session.
            </p>
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between gap-3">
              <span className="font-mono text-lg font-extrabold tracking-wider text-[#07442B]">
                {activationCodeSecret.activationCode}
              </span>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard?.writeText(activationCodeSecret.activationCode);
                  setActivationCopied(true);
                  setTimeout(() => setActivationCopied(false), 2000);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-emerald-300 text-[#07442B] font-bold cursor-pointer"
              >
                {activationCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{activationCopied ? 'Copied' : 'Copy Code'}</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-500">
              Expires UTC: <span className="font-mono">{activationCodeSecret.expiresAtUtc}</span>. Single-use only; stored as SHA-256 hash.
            </p>
          </div>
        )}
      </Modal>

      {/* BUILD 36: Configure / Rotate Web Kiosk Administrator PIN */}
      <Modal
        open={pinModalOpen}
        onClose={() => setPinModalOpen(false)}
        title={pinStatus?.configured ? 'Update Kiosk Administrator PIN' : 'Set Kiosk Administrator PIN'}
      >
        <form onSubmit={handleSaveKioskAdminPin} className="space-y-4 text-xs">
          <p className="text-slate-600">
            This PIN protects Web Kiosk Settings and Touchless Auto-Enrollment (<code className="font-mono">/kiosk</code>). It is stored exclusively as an scrypt salted hash on the server.
          </p>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">New Kiosk Admin PIN (4–8 digits)</label>
            <input
              type="password"
              inputMode="numeric"
              minLength={4}
              maxLength={8}
              required
              value={pinValue}
              onChange={(e) => setPinValue(e.target.value.replace(/\D/g, ''))}
              placeholder="Enter 4–8 digit PIN"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-sm tracking-widest"
            />
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Confirm Kiosk Admin PIN</label>
            <input
              type="password"
              inputMode="numeric"
              minLength={4}
              maxLength={8}
              required
              value={pinConfirm}
              onChange={(e) => setPinConfirm(e.target.value.replace(/\D/g, ''))}
              placeholder="Re-enter PIN"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-sm tracking-widest"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setPinModalOpen(false)}
              className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={pinSaving || pinValue.length < 4}
              className="px-4 py-2 rounded-lg btn-rsu-primary font-bold cursor-pointer disabled:opacity-50"
            >
              {pinSaving ? 'Saving...' : 'Save Kiosk PIN'}
            </button>
          </div>
        </form>
      </Modal>
    </ModuleFrame>
  );
};

// ============================================================================
// SCREEN 14 — AUDIT LOGS (14_Audit_Logs.png)
// ============================================================================
export const AuditLogsView: React.FC = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const limit = 12;

  const [search, setSearch] = useState('');
  const [moduleFilter, setModuleFilter] = useState('All');
  const [dateFilter, setDateFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [verifyResult, setVerifyResult] = useState<AuditHashVerificationResult | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const qs = new URLSearchParams({
        page: String(page),
        limit: String(limit),
      });
      if (search.trim()) qs.set('search', search.trim());
      if (moduleFilter !== 'All') qs.set('module', moduleFilter);
      if (dateFilter) qs.set('date', dateFilter);
      const res = await apiFetch<{ data: AuditLog[]; total?: number }>(`/api/audit-logs?${qs.toString()}`);
      setLogs(res.data);
      setTotal(res.total ?? res.data.length);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load audit logs.');
    } finally {
      setLoading(false);
    }
  }, [search, moduleFilter, dateFilter, page]);

  useEffect(() => {
    load();
  }, [load]);

  const handleVerifyChain = async () => {
    setVerifying(true);
    setError(null);
    try {
      const res = await fetch('/api/audit-logs/verify', { credentials: 'include' });
      const data = (await res.json()) as AuditHashVerificationResult & { error?: string };
      if (!res.ok && typeof data.valid !== 'boolean') {
        throw new Error(data.error || `Verification failed (${res.status})`);
      }
      setVerifyResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to verify audit hash chain.');
    } finally {
      setVerifying(false);
    }
  };

  const handleExportFullCsv = async () => {
    setExporting(true);
    setError(null);
    try {
      const qs = new URLSearchParams();
      if (search.trim()) qs.set('search', search.trim());
      if (moduleFilter !== 'All') qs.set('module', moduleFilter);
      if (dateFilter) {
        qs.set('start_date', dateFilter);
        qs.set('end_date', dateFilter);
      }
      const query = qs.toString();
      await downloadAuthenticatedBlob(
        `/api/reports/audit-logs/export.csv${query ? `?${query}` : ''}`,
        `savage-rsucaj-audit-logs-${getManilaTodayIso()}.csv`
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Audit CSV export failed.');
    } finally {
      setExporting(false);
    }
  };

  const modules = [
    'All',
    'Authentication',
    'Security',
    'Employees',
    'Attendance',
    'Corrections',
    'Leaves',
    'Payroll',
    'Reports',
    'Devices',
    'Notifications',
    'Departments',
    'Positions',
    'Shifts',
    'Holidays',
    'Settings',
  ];

  const totalPages = Math.max(1, Math.ceil(total / limit));
  const startIdx = total === 0 ? 0 : (page - 1) * limit + 1;
  const endIdx = Math.min(total, page * limit);

  return (
    <ModuleFrame
      title="Audit Logs"
      subtitle="Append-only tamper-evident system activities and security logs."
      icon={<ShieldAlert className="w-5 h-5" />}
    >
      {error && (
        <div className="mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border bg-red-50 border-red-200 text-red-800">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {verifyResult && (
        <div
          className={`mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex flex-wrap items-center justify-between gap-2 border ${
            verifyResult.valid
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-red-50 border-red-200 text-red-900'
          }`}
        >
          <div className="flex items-center gap-2">
            <ShieldCheck className={`w-4 h-4 shrink-0 ${verifyResult.valid ? 'text-emerald-600' : 'text-red-600'}`} />
            <span>
              {verifyResult.valid
                ? `SHA-256 hash chain verified intact across ${verifyResult.checkedCount} append-only audit entry(ies).`
                : `INTEGRITY VIOLATION at entry #${verifyResult.brokenRowId}: ${verifyResult.reason}`}
            </span>
          </div>
          <span className="font-mono-num text-[11px] opacity-80">
            Latest hash: {verifyResult.latestHash.slice(0, 14)}…
          </span>
        </div>
      )}

      {/* Filter & Export Toolbar matching 14_Audit_Logs.png */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 mb-4">
        <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[240px]">
          <div className="relative flex-1 min-w-[160px] max-w-xs">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              aria-label="Search audit logs"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Search user, activity, or module..."
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-white text-xs shadow-2xs focus:outline-none focus:border-[#0B5537]"
            />
          </div>
          <input
            type="date"
            aria-label="Filter audit logs by date"
            value={dateFilter}
            onChange={(e) => {
              setDateFilter(e.target.value);
              setPage(1);
            }}
            className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-mono-num shadow-2xs focus:outline-none focus:border-[#0B5537]"
          />
          <select
            aria-label="Filter by module"
            value={moduleFilter}
            onChange={(e) => {
              setModuleFilter(e.target.value);
              setPage(1);
            }}
            className="px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white shadow-2xs focus:outline-none focus:border-[#0B5537]"
          >
            {modules.map((m) => (
              <option key={m} value={m}>
                {m === 'All' ? 'All Activities' : m}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={verifying}
            onClick={handleVerifyChain}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-emerald-700/25 bg-white hover:bg-emerald-50 text-[#07442B] text-xs font-bold cursor-pointer disabled:opacity-60"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#16A34A]" />
            <span>{verifying ? 'Verifying...' : 'Verify Chain'}</span>
          </button>
          <button
            type="button"
            disabled={exporting}
            onClick={handleExportFullCsv}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl btn-rsu-primary text-xs font-bold cursor-pointer disabled:opacity-60"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{exporting ? 'Exporting...' : 'Export Logs'}</span>
          </button>
        </div>
      </div>

      <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
              <th className="py-3 px-4">Date &amp; Time</th>
              <th className="py-3 px-4">User</th>
              <th className="py-3 px-4">Activity</th>
              <th className="py-3 px-4 text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs">
            {loading ? (
              <tr>
                <td colSpan={4} className="py-8 text-center text-slate-400">
                  Loading audit logs...
                </td>
              </tr>
            ) : logs.length === 0 ? (
              <tr>
                <td colSpan={4} className="py-8 text-center text-slate-400">
                  No audit events match your filter.
                </td>
              </tr>
            ) : (
              logs.map((log) => {
                const isExpanded = expandedId === log.id;
                const hasDetails = Boolean(log.before_json || log.after_json || log.entry_hash);
                return (
                  <React.Fragment key={log.id}>
                    <tr className="hover:bg-emerald-50/35">
                      <td className="py-3.5 px-4 font-mono-num text-slate-600 whitespace-nowrap">
                        {log.timestamp}
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-slate-800 whitespace-nowrap">
                        {log.username}
                      </td>
                      <td className="py-3.5 px-4 text-slate-800">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <span className="font-medium">{log.activity}</span>
                            <span className="ml-2 text-[11px] text-slate-400">
                              · {log.module}
                              {log.action_type && log.action_type !== 'EVENT' ? ` (${log.action_type})` : ''}
                            </span>
                          </div>
                          {hasDetails && (
                            <button
                              type="button"
                              onClick={() => setExpandedId(isExpanded ? null : log.id)}
                              className="p-1 rounded-md text-slate-400 hover:text-[#0B5537] hover:bg-emerald-50 shrink-0 cursor-pointer"
                              aria-label="Toggle audit metadata details"
                              title="Inspect redacted metadata & SHA-256 chain hash"
                            >
                              {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                            </button>
                          )}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <StatusLabel status={log.status} />
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr className="bg-slate-50/90">
                        <td colSpan={4} className="px-4 py-3 text-[11px] text-slate-600 space-y-1.5">
                          <div className="flex flex-wrap gap-4 font-mono-num text-slate-500">
                            <span>IP: {log.ip_address}</span>
                            {log.target_type && (
                              <span>
                                Target: {log.target_type}
                                {log.target_id ? ` #${log.target_id}` : ''}
                              </span>
                            )}
                            {log.entry_hash && <span>SHA-256: {log.entry_hash.slice(0, 20)}…</span>}
                          </div>
                          {(log.before_json || log.after_json) && (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-1">
                              {log.before_json && (
                                <div className="bg-white border border-slate-200 rounded-lg p-2">
                                  <div className="font-bold text-slate-500 mb-0.5">Before (Redacted)</div>
                                  <pre className="font-mono-num text-[10px] whitespace-pre-wrap break-all">
                                    {log.before_json}
                                  </pre>
                                </div>
                              )}
                              {log.after_json && (
                                <div className="bg-white border border-slate-200 rounded-lg p-2">
                                  <div className="font-bold text-slate-500 mb-0.5">After (Redacted)</div>
                                  <pre className="font-mono-num text-[10px] whitespace-pre-wrap break-all">
                                    {log.after_json}
                                  </pre>
                                </div>
                              )}
                            </div>
                          )}
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
        <span className="font-semibold font-mono-num">
          Showing {startIdx} – {endIdx} of {total}
        </span>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            disabled={page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="p-1.5 rounded-lg border border-slate-200 bg-white disabled:opacity-40 cursor-pointer"
            aria-label="Previous audit logs page"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="min-w-[30px] h-7 px-2 rounded-lg bg-[#07442B] text-white font-bold font-mono-num flex items-center justify-center">
            {page}
          </span>
          <button
            type="button"
            disabled={page >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            className="p-1.5 rounded-lg border border-slate-200 bg-white disabled:opacity-40 cursor-pointer"
            aria-label="Next audit logs page"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </ModuleFrame>
  );
};

// ============================================================================
// SCREEN 03 — NOTIFICATIONS FULL VIEW (03_Notifications.png)
// ============================================================================
export const NotificationsView: React.FC<{
  currentUser?: AuthUser;
  onNavigate: (module: NavModule) => void;
  onUnreadCountChange: (count: number) => void;
}> = ({ currentUser, onNavigate, onUnreadCountChange }) => {
  const perms = currentUser?.permissions || [];
  const canWriteNotifications = !currentUser || perms.includes('notifications:write');
  const canApproveCorrections = !currentUser || perms.includes('corrections:approve');
  const canApproveLeaves = !currentUser || perms.includes('leaves:approve');

  const [filter, setFilter] = useState('All');
  const [items, setItems] = useState<AppNotification[]>([]);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [clearConfirmOpen, setClearConfirmOpen] = useState(false);
  const pageSize = 6;
  const [counts, setCounts] = useState({
    all: 0,
    unread: 0,
    attendance: 0,
    device: 0,
    system: 0,
  });

  const load = useCallback(async () => {
    setError(null);
    try {
      const res = await apiFetch<{
        data: AppNotification[];
        counts: { all: number; unread: number; attendance: number; device: number; system: number };
      }>(`/api/notifications?filter=${encodeURIComponent(filter)}`);
      setItems(res.data);
      setCounts(res.counts);
      onUnreadCountChange(res.counts.unread);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load notifications.');
    } finally {
      setLoading(false);
    }
  }, [filter, onUnreadCountChange]);

  useEffect(() => {
    load();
  }, [load]);

  useRealtimeStream({
    channels: ['notification:created', 'device:telemetry'],
    onEvent: () => {
      load();
    },
    onResync: () => {
      load();
    },
  });

  const handleMarkRead = async () => {
    setError(null);
    try {
      await apiFetch('/api/notifications/mark-all-read', {
        method: 'POST',
        body: JSON.stringify(selectedIds.length > 0 ? { ids: selectedIds } : {}),
      });
      setSelectedIds([]);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to mark notifications as read.');
    }
  };

  const handleClearAll = async () => {
    setError(null);
    try {
      await apiFetch('/api/notifications', { method: 'DELETE' });
      setClearConfirmOpen(false);
      setSelectedIds([]);
      load();
    } catch (err) {
      setClearConfirmOpen(false);
      setError(err instanceof Error ? err.message : 'Unable to clear notifications.');
    }
  };

  const handleDismissSelected = async () => {
    if (selectedIds.length === 0) return;
    setError(null);
    try {
      await apiFetch('/api/notifications', {
        method: 'DELETE',
        body: JSON.stringify({ ids: selectedIds }),
      });
      setSelectedIds([]);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to dismiss selected notifications.');
    }
  };

  const handleQuickApprove = async (n: AppNotification) => {
    setError(null);
    if (!n.action_entity_id) {
      if (n.action_module) onNavigate(n.action_module);
      return;
    }
    try {
      if (n.action_module === 'corrections') {
        await apiFetch(`/api/corrections/${n.action_entity_id}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ status: 'Approved' }),
        });
      } else if (n.action_module === 'leaves') {
        await apiFetch(`/api/leaves/${n.action_entity_id}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ status: 'Approved' }),
        });
      }
      if (canWriteNotifications) {
        await apiFetch(`/api/notifications/${n.id}/read`, { method: 'PATCH' });
      }
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Quick approval failed.');
      if (n.action_module) onNavigate(n.action_module);
    }
  };

  const handleOpen = async (n: AppNotification) => {
    setError(null);
    try {
      if (!n.is_read && canWriteNotifications) {
        await apiFetch(`/api/notifications/${n.id}/read`, { method: 'PATCH' });
      }
      if (n.action_module) onNavigate(n.action_module);
      else load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to open notification.');
    }
  };

  const handleDismiss = async (id: number) => {
    setError(null);
    try {
      await apiFetch(`/api/notifications/${id}`, { method: 'DELETE' });
      setSelectedIds((prev) => prev.filter((x) => x !== id));
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to dismiss notification.');
    }
  };

  const toggleSelect = (id: number) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const visible = items.slice((safePage - 1) * pageSize, safePage * pageSize);
  const allVisibleSelected = visible.length > 0 && visible.every((v) => selectedIds.includes(v.id));

  const toggleSelectVisible = () => {
    if (allVisibleSelected) {
      const visibleSet = new Set(visible.map((v) => v.id));
      setSelectedIds((prev) => prev.filter((id) => !visibleSet.has(id)));
    } else {
      const merged = new Set([...selectedIds, ...visible.map((v) => v.id)]);
      setSelectedIds(Array.from(merged));
    }
  };

  return (
    <ModuleFrame
      title="Notifications"
      subtitle="Role-scoped attendance exceptions, kiosk alerts, and system notices."
      icon={<Bell className="w-5 h-5" />}
      headerAction={
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={!canWriteNotifications}
            onClick={handleMarkRead}
            title={
              canWriteNotifications
                ? 'Mark selected or all scoped notifications as read'
                : 'Read-only access: your role cannot modify notifications'
            }
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white text-[#0B5537] hover:bg-emerald-50 text-xs font-bold shadow-xs cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <CheckCheck className="w-3.5 h-3.5 text-[#16A34A]" />
            <span>{selectedIds.length > 0 ? `Mark Selected (${selectedIds.length})` : 'Mark as Read'}</span>
          </button>
          {selectedIds.length > 0 && canWriteNotifications && (
            <button
              type="button"
              onClick={handleDismissSelected}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white border border-amber-300 text-amber-800 hover:bg-amber-50 text-xs font-bold shadow-xs cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Dismiss Selected ({selectedIds.length})</span>
            </button>
          )}
          <button
            type="button"
            disabled={!canWriteNotifications}
            onClick={() => setClearConfirmOpen(true)}
            title={
              canWriteNotifications
                ? 'Clear all notifications visible to your role'
                : 'Read-only access: your role cannot clear notifications'
            }
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white border border-red-300 text-red-600 hover:bg-red-50 text-xs font-bold shadow-xs cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear All</span>
          </button>
        </div>
      }
    >
      {!canWriteNotifications && (
        <div className="mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border bg-slate-50 border-slate-200 text-slate-700">
          <Info className="w-4 h-4 shrink-0 text-[#0B5537]" />
          <span>
            Read-only notification access ({currentUser?.role}). You can inspect and open alerts within your role scope;
            Administrator or HR Officer privileges are required to mark read or dismiss alerts.
          </span>
        </div>
      )}
      {error && (
        <div className="mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border bg-red-50 border-red-200 text-red-800">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Filter Pills matching 03_Notifications.png */}
      <div className="flex flex-wrap items-center gap-2 mb-4 pb-3 border-b border-slate-100">
        {[
          { id: 'All', label: `All (${counts.all})` },
          { id: 'Unread', label: `Unread (${counts.unread})`, redDot: counts.unread > 0 },
          { id: 'Attendance Alerts', label: `Attendance Alerts (${counts.attendance})` },
          { id: 'Device Alerts', label: `Device Alerts (${counts.device})` },
          { id: 'System Notices', label: `System Notices (${counts.system})` },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => {
              setFilter(tab.id);
              setPage(1);
            }}
            className={`relative px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer border ${
              filter === tab.id
                ? 'btn-rsu-primary border-transparent'
                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {tab.label}
            {tab.redDot && filter !== tab.id && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-red-500 ring-2 ring-white" />
            )}
          </button>
        ))}
        {canWriteNotifications && visible.length > 0 && (
          <button
            type="button"
            onClick={toggleSelectVisible}
            className="ml-auto inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 cursor-pointer"
          >
            {allVisibleSelected ? (
              <CheckSquare className="w-3.5 h-3.5 text-[#16A34A]" />
            ) : (
              <Square className="w-3.5 h-3.5 text-slate-400" />
            )}
            <span>{allVisibleSelected ? 'Unselect Page' : 'Select Page'}</span>
          </button>
        )}
      </div>

      <div className="divide-y divide-slate-100 border border-slate-200/80 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-10 text-center text-xs text-slate-400">Loading notifications...</div>
        ) : visible.length === 0 ? (
          <div className="p-10 text-center text-xs text-slate-400">
            No notifications to display for this filter.
          </div>
        ) : (
          visible.map((n) => {
            const isSelected = selectedIds.includes(n.id);
            const canApprove =
              Boolean(n.action_entity_id) &&
              !n.is_read &&
              ((n.action_module === 'corrections' && canApproveCorrections) ||
                (n.action_module === 'leaves' && canApproveLeaves));

            return (
              <div
                key={n.id}
                className={`p-4 flex flex-wrap items-start justify-between gap-4 ${
                  n.is_read ? 'bg-white' : 'bg-emerald-50/40'
                }`}
              >
                <div className="flex items-start gap-3 flex-1 min-w-[240px]">
                  <button
                    type="button"
                    disabled={!canWriteNotifications}
                    onClick={() => toggleSelect(n.id)}
                    className="mt-0.5 text-slate-400 hover:text-[#0B5537] cursor-pointer shrink-0 disabled:opacity-40 disabled:cursor-not-allowed"
                    aria-label={`Select ${n.title}`}
                    title={
                      canWriteNotifications
                        ? 'Select notification for bulk action'
                        : 'Read-only access: bulk selection disabled'
                    }
                  >
                    {isSelected ? (
                      <CheckSquare className="w-4 h-4 text-[#16A34A]" />
                    ) : (
                      <Square className="w-4 h-4" />
                    )}
                  </button>
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-sm font-bold text-slate-900">{n.title}</h3>
                      <StatusLabel status={n.priority} />
                    </div>
                    <p className="text-xs text-slate-600">{n.message}</p>
                    <p className="text-[11px] text-slate-400 font-mono-num">
                      {n.created_at} · {n.category} · {n.is_read ? 'Read' : 'Unread'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {canApprove && (
                    <button
                      type="button"
                      onClick={() => handleQuickApprove(n)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg btn-rsu-primary text-xs font-semibold cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Approve</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => handleOpen(n)}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer"
                  >
                    View
                  </button>
                  <button
                    type="button"
                    disabled={!canWriteNotifications}
                    onClick={() => handleDismiss(n.id)}
                    title={
                      canWriteNotifications
                        ? 'Dismiss notification'
                        : 'Read-only access: your role cannot dismiss notifications'
                    }
                    className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-red-50 hover:text-red-600 text-slate-500 text-xs font-semibold cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Pagination Footer matching 03_Notifications.png */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
        <span className="font-semibold font-mono-num">
          Showing {visible.length > 0 ? (safePage - 1) * pageSize + 1 : 0} –{' '}
          {(safePage - 1) * pageSize + visible.length} of {items.length} notifications
        </span>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            disabled={safePage <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="p-1.5 rounded-lg border border-slate-200 bg-white disabled:opacity-40 cursor-pointer"
            aria-label="Previous page"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="min-w-[30px] h-7 px-2 rounded-lg bg-[#07442B] text-white font-bold font-mono-num flex items-center justify-center">
            {safePage}
          </span>
          <button
            type="button"
            disabled={safePage >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            className="p-1.5 rounded-lg border border-slate-200 bg-white disabled:opacity-40 cursor-pointer"
            aria-label="Next page"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <ConfirmModal
        open={clearConfirmOpen}
        onClose={() => setClearConfirmOpen(false)}
        onConfirm={handleClearAll}
        title="Clear Scoped Notifications?"
        message="This will permanently remove notifications visible to your role and record the action in Audit Logs."
        confirmLabel="Clear All"
        destructive
      />
    </ModuleFrame>
  );
};

// ============================================================================
// SCREEN 16 — SYSTEM SETTINGS (16_System_Settings.png)
// ============================================================================
export const SettingsView: React.FC<{ currentUser?: AuthUser }> = ({ currentUser }) => {
  const [activeTab, setActiveTab] = useState<'general' | 'api' | 'security' | 'backup' | 'retention' | 'about'>('general');
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [secretStatus, setSecretStatus] = useState<SecretStatusInfo | null>(null);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });

  // BUILD 05 + 14: Portal user & security change history (Administrator only)
  const canManageUsers = Boolean(currentUser?.permissions?.includes('users:manage'));
  const [portalUsers, setPortalUsers] = useState<PortalUser[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [employeeOptions, setEmployeeOptions] = useState<Array<{
    id: number; employee_code: string; full_name: string; email: string;
    department_id: number; status: string; linked_user_id: number | null;
  }>>([]);
  const [securityHistory, setSecurityHistory] = useState<AuditLog[]>([]);
  const [userModalOpen, setUserModalOpen] = useState(false);
  const [newUserForm, setNewUserForm] = useState({
    username: '',
    email: '',
    full_name: '',
    role: 'HR Officer',
    password: '',
    department_id: '',
    employee_id: '',
    must_change_password: true,
  });

  // BUILD 06 + 14: Backup, WAL Durability & Guarded Live Restore
  interface BackupHistoryRow {
    id: number;
    backup_id: string;
    file_name: string;
    encrypted_file: string;
    sha256: string;
    size_bytes: number;
    encrypted: number;
    integrity_status: string;
    foreign_key_violations: number;
    schema_version: string;
    operation_type: string;
    created_by: string;
    created_at: string;
  }
  interface BackupStatusPayload {
    mode: string;
    backupDir: string;
    backupEncryptionConfigured: boolean;
    backupRetentionCount: number;
    availableArchives: BackupArchiveOption[];
    database: {
      journalMode: string;
      foreignKeys: boolean;
      busyTimeoutMs: number;
      walAutocheckpoint: number;
      schemaVersion: string;
      integrityCheck: string;
      foreignKeyViolations: number;
      dbFileBytes: number;
      walFileBytes: number;
    };
    history: BackupHistoryRow[];
  }
  const [backupStatus, setBackupStatus] = useState<BackupStatusPayload | null>(null);
  const [backupBusy, setBackupBusy] = useState<string | null>(null);
  const [selectedArchive, setSelectedArchive] = useState('');
  const [restoreModalOpen, setRestoreModalOpen] = useState(false);
  const [restoreForm, setRestoreForm] = useState({ confirmText: '', currentPassword: '' });

  // BUILD 14: Data Retention Preview & Policy Execution
  const [retentionPreview, setRetentionPreview] = useState<DataRetentionPreview | null>(null);
  const [retentionJobs, setRetentionJobs] = useState<RetentionJobRow[]>([]);
  const [retentionBusy, setRetentionBusy] = useState<string | null>(null);
  const [retentionConfirmOpen, setRetentionConfirmOpen] = useState(false);

  const loadSettings = useCallback(async () => {
    try {
      const r = await apiFetch<{ settings: Record<string, string>; secretStatus?: SecretStatusInfo }>('/api/settings');
      setSettings(r.settings);
      if (r.secretStatus) setSecretStatus(r.secretStatus);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to load settings.' });
    }
  }, []);

  const loadSecurityData = useCallback(async () => {
    try {
      const secHistPromise = apiFetch<{ data: AuditLog[] }>('/api/security/history?limit=15');
      if (canManageUsers) {
        const [uRes, dRes, eRes, optionsRes, sRes] = await Promise.all([
          apiFetch<{ data: PortalUser[] }>('/api/users'),
          apiFetch<{ data: Department[] }>('/api/departments'),
          apiFetch<{ data: Employee[] }>('/api/employees?limit=100'),
          apiFetch<{ data: typeof employeeOptions }>('/api/users/employee-options'),
          secHistPromise,
        ]);
        setEmployeeOptions(optionsRes.data);
        setPortalUsers(uRes.data);
        setDepartments(dRes.data);
        setEmployees(eRes.data);
        setSecurityHistory(sRes.data);
      } else {
        const sRes = await secHistPromise;
        setSecurityHistory(sRes.data);
      }
    } catch {
      // ignore if user lacks permission
    }
  }, [canManageUsers]);

  const loadBackupStatus = useCallback(async () => {
    try {
      const status = await apiFetch<BackupStatusPayload>('/api/backup/status');
      setBackupStatus(status);
      if (status.availableArchives && status.availableArchives.length > 0) {
        setSelectedArchive((prev) =>
          prev && status.availableArchives.some((a) => a.fileName === prev)
            ? prev
            : status.availableArchives[0].fileName
        );
      } else {
        setSelectedArchive('');
      }
    } catch {
      // ignore if user lacks backup:export permission
    }
  }, []);

  const loadRetentionData = useCallback(async () => {
    try {
      const [prevRes, jobsRes] = await Promise.all([
        apiFetch<DataRetentionPreview>('/api/retention/preview'),
        apiFetch<{ data: RetentionJobRow[] }>('/api/retention/jobs?limit=15'),
      ]);
      setRetentionPreview(prevRes);
      setRetentionJobs(jobsRes.data);
    } catch {
      // ignore if user lacks settings:read
    }
  }, []);

  useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  useEffect(() => {
    if (activeTab === 'security') {
      loadSecurityData();
    } else if (activeTab === 'backup') {
      loadBackupStatus();
    } else if (activeTab === 'retention') {
      loadRetentionData();
    }
  }, [activeTab, loadSecurityData, loadBackupStatus, loadRetentionData]);

  const handleSaveSettings = async (keys: string[]) => {
    setSaving(true);
    setFeedback(null);
    try {
      const updates: Record<string, string> = {};
      for (const k of keys) updates[k] = settings[k] ?? '';
      const res = await apiFetch<{ settings?: Record<string, string>; updatedKeys?: string[] }>('/api/settings', {
        method: 'PUT',
        body: JSON.stringify({ updates }),
      });
      if (res.settings) setSettings(res.settings);
      setFeedback({
        type: 'ok',
        text:
          res.updatedKeys && res.updatedKeys.length > 0
            ? `Saved validated configuration (${res.updatedKeys.join(', ')}) to SQLite.`
            : 'Configuration verified and saved to SQLite database.',
      });
      if (activeTab === 'retention') {
        loadRetentionData();
      }
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Validation failed.' });
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (pwForm.newPassword !== pwForm.confirmPassword) {
      setFeedback({ type: 'err', text: 'New password and confirmation do not match.' });
      return;
    }
    try {
      const res = await apiFetch<{ csrfToken?: string }>('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({
          currentPassword: pwForm.currentPassword,
          newPassword: pwForm.newPassword,
        }),
      });
      if (res.csrfToken) {
        setCsrfToken(res.csrfToken);
      }
      setPwForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
      setFeedback({
        type: 'ok',
        text: 'Password updated securely. All other active sessions for this account were revoked.',
      });
      loadSecurityData();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Password update failed.' });
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    try {
      await apiFetch('/api/users', {
        method: 'POST',
        body: JSON.stringify({
          username: newUserForm.username.trim(),
          email: newUserForm.email.trim(),
          full_name: newUserForm.full_name.trim(),
          role: newUserForm.role,
          password: newUserForm.password,
          department_id: newUserForm.department_id ? Number(newUserForm.department_id) : null,
          employee_id: newUserForm.employee_id ? Number(newUserForm.employee_id) : null,
          must_change_password: newUserForm.must_change_password,
        }),
      });
      setUserModalOpen(false);
      setNewUserForm({
        username: '',
        email: '',
        full_name: '',
        role: 'HR Officer',
        password: '',
        department_id: '',
        employee_id: '',
        must_change_password: true,
      });
      setFeedback({ type: 'ok', text: 'Created new portal user account with server-enforced RBAC role.' });
      loadSecurityData();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to create user.' });
    }
  };

  const handleToggleUserActive = async (target: PortalUser) => {
    setFeedback(null);
    try {
      const nextActive = target.is_active !== 1;
      await apiFetch(`/api/users/${target.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ is_active: nextActive }),
      });
      setFeedback({
        type: 'ok',
        text: nextActive
          ? `Reactivated account "${target.username}".`
          : `Deactivated account "${target.username}" and revoked active sessions.`,
      });
      loadSecurityData();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Update failed.' });
    }
  };

  const handleExportBackup = async () => {
    setFeedback(null);
    try {
      const data = await apiFetch('/api/backup/export');
      downloadJson(`savage-rsucaj-backup-${new Date().toISOString().slice(0, 10)}.json`, data);
      setFeedback({ type: 'ok', text: 'Full JSON database backup downloaded (kiosk secrets masked).' });
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'JSON export failed.' });
    }
  };

  const handleCreateSqliteSnapshot = async () => {
    setBackupBusy('snapshot');
    setFeedback(null);
    try {
      const res = await apiFetch<{ manifest: { sqliteFile: string; sqliteSha256: string; encrypted: boolean } }>(
        '/api/backup/snapshot',
        { method: 'POST' }
      );
      setFeedback({
        type: 'ok',
        text: `Verified online SQLite backup created: ${res.manifest.sqliteFile} (SHA-256: ${res.manifest.sqliteSha256.slice(0, 12)}…${res.manifest.encrypted ? ', AES-256-GCM encrypted' : ''}).`,
      });
      await loadBackupStatus();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Online SQLite backup failed.' });
    } finally {
      setBackupBusy(null);
    }
  };

  const handleCheckpointWal = async () => {
    setBackupBusy('checkpoint');
    setFeedback(null);
    try {
      const res = await apiFetch<{ checkpoint: { checkpointed: number; log: number }; database: { walFileBytes: number } }>(
        '/api/backup/checkpoint',
        { method: 'POST' }
      );
      setFeedback({
        type: 'ok',
        text: `WAL checkpoint (TRUNCATE) completed: ${res.checkpoint.checkpointed}/${res.checkpoint.log} frames flushed (WAL size: ${res.database.walFileBytes} bytes).`,
      });
      await loadBackupStatus();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'WAL checkpoint failed.' });
    } finally {
      setBackupBusy(null);
    }
  };

  const handleRunRestoreDrill = async () => {
    setBackupBusy('drill');
    setFeedback(null);
    try {
      const res = await apiFetch<{
        archiveFile: string;
        verification: { integrityCheck: string; foreignKeyViolations: number; schemaVersion: string };
      }>('/api/backup/verify-drill', {
        method: 'POST',
        body: JSON.stringify(selectedArchive ? { fileName: selectedArchive } : {}),
      });
      setFeedback({
        type: 'ok',
        text: `Dry-run restore drill PASSED on ${res.archiveFile} (integrity=${res.verification.integrityCheck}, FK violations=${res.verification.foreignKeyViolations}, schema v${res.verification.schemaVersion}).`,
      });
      await loadBackupStatus();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Restore drill failed.' });
    } finally {
      setBackupBusy(null);
    }
  };

  const handleExecuteLiveRestore = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedArchive) return;
    setBackupBusy('restore');
    setFeedback(null);
    try {
      const res = await apiFetch<{
        restoredFrom: string;
        preRestoreBackupFile: string | null;
        verification: { integrityCheck: string; schemaVersion: string };
      }>('/api/backup/restore', {
        method: 'POST',
        body: JSON.stringify({
          fileName: selectedArchive,
          confirmText: restoreForm.confirmText,
          currentPassword: restoreForm.currentPassword,
        }),
      });
      setRestoreModalOpen(false);
      setRestoreForm({ confirmText: '', currentPassword: '' });
      setFeedback({
        type: 'ok',
        text: `Live database restored from ${res.restoredFrom} (integrity=${res.verification.integrityCheck}, schema v${res.verification.schemaVersion}). Safety rollback snapshot: ${res.preRestoreBackupFile || 'n/a'}.`,
      });
      await Promise.all([loadBackupStatus(), loadSettings()]);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Live database restore failed.' });
    } finally {
      setBackupBusy(null);
    }
  };

  const handlePreviewRetention = async () => {
    setRetentionBusy('preview');
    setFeedback(null);
    try {
      const qs = new URLSearchParams({
        attendanceDays: settings.attendance_retention_days || '1825',
        auditDays: settings.audit_log_retention_days || '730',
      });
      const prev = await apiFetch<DataRetentionPreview>(`/api/retention/preview?${qs.toString()}`);
      setRetentionPreview(prev);
      setFeedback({
        type: 'ok',
        text: `Retention dry-run evaluated: ${prev.totalEligibleDeletes} eligible record(s) to purge, ${prev.totalPreservedImmutable} immutable/locked record(s) protected.`,
      });
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Retention preview failed.' });
    } finally {
      setRetentionBusy(null);
    }
  };

  const handleExecuteRetention = async () => {
    setRetentionBusy('execute');
    setFeedback(null);
    try {
      const res = await apiFetch<{ job: RetentionJobRow }>('/api/retention/execute', {
        method: 'POST',
        body: JSON.stringify({
          attendanceRetentionDays: Number(settings.attendance_retention_days || '1825'),
          auditLogRetentionDays: Number(settings.audit_log_retention_days || '730'),
          confirmExecute: true,
        }),
      });
      setRetentionConfirmOpen(false);
      setFeedback({
        type: 'ok',
        text: `Retention job ${res.job.job_uid} completed: ${res.job.total_deleted} expired record(s) purged. ${res.job.notes}`,
      });
      await loadRetentionData();
    } catch (err) {
      setRetentionConfirmOpen(false);
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Retention execution failed.' });
    } finally {
      setRetentionBusy(null);
    }
  };

  const navItems = [
    { id: 'general', label: 'General Settings', icon: Sliders },
    { id: 'api', label: 'API (Backend Configuration)', icon: Server },
    { id: 'security', label: 'Security & Access', icon: KeyRound },
    { id: 'backup', label: 'Backup & Restore', icon: DatabaseBackup },
    { id: 'retention', label: 'Data Retention', icon: Clock },
    { id: 'about', label: 'About', icon: Info },
  ] as const;

  return (
    <ModuleFrame
      title="System Settings"
      subtitle="Configure system, security, and integrations."
      icon={<Settings className="w-5 h-5" />}
    >
      {feedback && (
        <div
          className={`mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{feedback.text}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Settings Menu Card matching 16_System_Settings.png */}
        <div className="lg:col-span-4 border border-slate-200/80 rounded-2xl overflow-hidden bg-white divide-y divide-slate-100 h-fit shadow-2xs">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setActiveTab(item.id);
                  setFeedback(null);
                }}
                className={`w-full flex items-center gap-3.5 px-4 py-3.5 text-xs font-bold text-left transition-colors cursor-pointer ${
                  active
                    ? 'bg-emerald-50/90 text-[#07442B]'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-[#16A34A]' : 'text-slate-500'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Right Detail Panel */}
        <div className="lg:col-span-8 bg-[#F8FBFA] rounded-2xl border border-slate-200/80 p-5 text-xs">
          {activeTab === 'general' && (
            <div className="space-y-4">
              <h2 className="font-display text-sm font-extrabold text-[#07442B]">General Settings</h2>
              <div>
                <label htmlFor="set-campus-name" className="block font-semibold text-slate-700 mb-1">Campus Name</label>
                <input
                  id="set-campus-name"
                  type="text"
                  value={settings.campus_name || ''}
                  onChange={(e) => setSettings({ ...settings, campus_name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label htmlFor="set-timezone" className="block font-semibold text-slate-700 mb-1">Timezone (IANA)</label>
                  <input
                    id="set-timezone"
                    type="text"
                    value={settings.timezone || 'Asia/Manila'}
                    onChange={(e) => setSettings({ ...settings, timezone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono-num"
                  />
                </div>
                <div>
                  <label htmlFor="set-grace-minutes" className="block font-semibold text-slate-700 mb-1">Default Grace (min)</label>
                  <input
                    id="set-grace-minutes"
                    type="number"
                    min={0}
                    max={180}
                    value={settings.default_grace_minutes || '15'}
                    onChange={(e) => setSettings({ ...settings, default_grace_minutes: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono-num"
                  />
                </div>
                <div>
                  <label htmlFor="set-work-hours" className="block font-semibold text-slate-700 mb-1">Work Hours / Day</label>
                  <input
                    id="set-work-hours"
                    type="number"
                    min={1}
                    max={24}
                    step="0.5"
                    value={settings.work_hours_per_day || '8'}
                    onChange={(e) => setSettings({ ...settings, work_hours_per_day: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono-num"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="set-cutoff" className="block font-semibold text-slate-700 mb-1">Next-Day Timeout Cutoff (HH:MM)</label>
                  <input
                    id="set-cutoff"
                    type="text"
                    value={settings.next_day_timeout_cutoff || '03:00'}
                    onChange={(e) => setSettings({ ...settings, next_day_timeout_cutoff: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono-num"
                  />
                </div>
                <div>
                  <label htmlFor="set-correction-doc" className="block font-semibold text-slate-700 mb-1">Require Correction Document</label>
                  <select
                    id="set-correction-doc"
                    value={settings.correction_require_document || 'false'}
                    onChange={(e) => setSettings({ ...settings, correction_require_document: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                  >
                    <option value="false">Optional</option>
                    <option value="true">Mandatory Attachment / Ref</option>
                  </select>
                </div>
              </div>
              <div>
                <label htmlFor="set-campus-director" className="block font-semibold text-slate-700 mb-1">
                  Campus Director / Authorized Signatory (for Monthly DTR)
                </label>
                <input
                  id="set-campus-director"
                  type="text"
                  placeholder="Enter official Campus Director name (leave blank for signature line)"
                  value={settings.campus_director_name || ''}
                  onChange={(e) => setSettings({ ...settings, campus_director_name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                />
              </div>
              <div className="p-3 rounded-xl border border-amber-200 bg-amber-50/70 text-[11px] text-amber-950">
                <span className="font-bold">Official CS Form 48 Status:</span>{' '}
                {settings.cs_form_48_reference_verified === 'true'
                  ? 'Verified against approved RSU Cajidiocan CS Form 48 reference.'
                  : 'Pending RSU-approved Civil Service Form 48 reference confirmation. Monthly DTR PDFs render in institutional draft format.'}
              </div>
              <button
                type="button"
                disabled={saving}
                onClick={() =>
                  handleSaveSettings([
                    'campus_name',
                    'campus_director_name',
                    'timezone',
                    'default_grace_minutes',
                    'work_hours_per_day',
                    'next_day_timeout_cutoff',
                    'correction_require_document',
                  ])
                }
                className="px-4 py-2 rounded-xl btn-rsu-primary font-bold cursor-pointer"
              >
                {saving ? 'Saving...' : 'Save General Settings'}
              </button>
            </div>
          )}

          {activeTab === 'api' && (
            <div className="space-y-4">
              <h2 className="font-display text-sm font-extrabold text-[#07442B]">
                API (Backend Configuration)
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="set-kiosk-endpoint" className="block font-semibold text-slate-700 mb-1">Kiosk Punch Endpoint</label>
                  <input
                    id="set-kiosk-endpoint"
                    type="text"
                    value={settings.kiosk_api_endpoint || '/api/kiosk/punch'}
                    onChange={(e) => setSettings({ ...settings, kiosk_api_endpoint: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono-num"
                  />
                </div>
                <div>
                  <label htmlFor="set-require-token" className="block font-semibold text-slate-700 mb-1">Require Kiosk Token</label>
                  <select
                    id="set-require-token"
                    value={settings.require_kiosk_token || 'true'}
                    onChange={(e) => setSettings({ ...settings, require_kiosk_token: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                  >
                    <option value="true">Enabled (Mandatory Policy)</option>
                    <option value="false" disabled>
                      Disabled (Prohibited by Security Policy)
                    </option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label htmlFor="set-hb-interval" className="block font-semibold text-slate-700 mb-1">Heartbeat Interval (sec)</label>
                  <input
                    id="set-hb-interval"
                    type="number"
                    min={5}
                    max={3600}
                    value={settings.kiosk_heartbeat_interval_sec || '60'}
                    onChange={(e) =>
                      setSettings({ ...settings, kiosk_heartbeat_interval_sec: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono-num"
                  />
                </div>
                <div>
                  <label htmlFor="set-stale-warn" className="block font-semibold text-slate-700 mb-1">Stale Warning (sec)</label>
                  <input
                    id="set-stale-warn"
                    type="number"
                    min={5}
                    max={86400}
                    value={settings.device_stale_warning_sec || '60'}
                    onChange={(e) =>
                      setSettings({ ...settings, device_stale_warning_sec: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono-num"
                  />
                </div>
                <div>
                  <label htmlFor="set-offline-timeout" className="block font-semibold text-slate-700 mb-1">Offline Timeout (sec)</label>
                  <input
                    id="set-offline-timeout"
                    type="number"
                    min={15}
                    max={86400}
                    value={settings.device_heartbeat_timeout_sec || '90'}
                    onChange={(e) =>
                      setSettings({ ...settings, device_heartbeat_timeout_sec: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono-num"
                  />
                </div>
              </div>

              {secretStatus && (
                <div className="rounded-xl bg-white border border-slate-200 p-3.5 space-y-2">
                  <div className="flex items-center gap-1.5 font-bold text-[#07442B]">
                    <Lock className="w-3.5 h-3.5 text-[#16A34A]" />
                    <span>Environment Secret Status (Masked)</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono-num">
                    <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
                      <span className="text-slate-400 block">SESSION_SECRET</span>
                      <span className="font-semibold text-slate-800">{secretStatus.sessionSecretMasked}</span>
                    </div>
                    <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
                      <span className="text-slate-400 block">BACKUP_ENCRYPTION_KEY</span>
                      <span className="font-semibold text-slate-800">{secretStatus.backupEncryptionMasked}</span>
                    </div>
                    <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
                      <span className="text-slate-400 block">SMTP Mailer</span>
                      <span className="font-semibold text-slate-800">
                        {secretStatus.smtpConfigured ? 'Configured (Secrets masked)' : 'Not Configured'}
                      </span>
                    </div>
                    <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
                      <span className="text-slate-400 block">Google Workspace SSO</span>
                      <span className="font-semibold text-slate-800">
                        {secretStatus.googleSsoConfigured ? 'Configured (Client ID set)' : 'Not Configured'}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <button
                type="button"
                disabled={saving}
                onClick={() =>
                  handleSaveSettings([
                    'kiosk_api_endpoint',
                    'kiosk_heartbeat_interval_sec',
                    'device_stale_warning_sec',
                    'device_heartbeat_timeout_sec',
                    'require_kiosk_token',
                  ])
                }
                className="px-4 py-2 rounded-xl btn-rsu-primary font-bold cursor-pointer"
              >
                {saving ? 'Saving...' : 'Save API Configuration'}
              </button>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-6">
              <div className="space-y-4">
                <h2 className="font-display text-sm font-extrabold text-[#07442B]">
                  Security &amp; Access — Change Password
                </h2>
                <form onSubmit={handleChangePassword} className="space-y-3 max-w-md">
                  <div>
                    <label htmlFor="sec-cur-pw" className="block font-semibold text-slate-700 mb-1">Current Password</label>
                    <input
                      id="sec-cur-pw"
                      type="password"
                      required
                      autoComplete="current-password"
                      value={pwForm.currentPassword}
                      onChange={(e) => setPwForm({ ...pwForm, currentPassword: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                    />
                  </div>
                  <div>
                    <label htmlFor="sec-new-pw" className="block font-semibold text-slate-700 mb-1">
                      New Password (min 10 chars, upper, lower, digit, symbol)
                    </label>
                    <input
                      id="sec-new-pw"
                      type="password"
                      required
                      minLength={10}
                      autoComplete="new-password"
                      value={pwForm.newPassword}
                      onChange={(e) => setPwForm({ ...pwForm, newPassword: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                    />
                  </div>
                  <div>
                    <label htmlFor="sec-confirm-pw" className="block font-semibold text-slate-700 mb-1">Confirm New Password</label>
                    <input
                      id="sec-confirm-pw"
                      type="password"
                      required
                      minLength={10}
                      autoComplete="new-password"
                      value={pwForm.confirmPassword}
                      onChange={(e) => setPwForm({ ...pwForm, confirmPassword: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                    />
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Updating your password revokes all other active sessions for this account immediately.
                  </p>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl btn-rsu-primary font-bold cursor-pointer"
                  >
                    Update Password
                  </button>
                </form>
              </div>

              {canManageUsers && (
                <div className="pt-5 border-t border-slate-200 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-[#0B5537]" />
                      <h3 className="font-display text-sm font-extrabold text-[#07442B]">
                        Portal User Accounts &amp; RBAC Roles
                      </h3>
                    </div>
                    <button
                      type="button"
                      onClick={() => setUserModalOpen(true)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl btn-rsu-primary text-xs font-bold cursor-pointer"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>Add Portal User</span>
                    </button>
                  </div>

                  <div className="overflow-x-auto border border-slate-200 rounded-xl bg-white">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-[#F4F8F6] border-b border-slate-200 font-bold text-slate-700">
                          <th className="py-2.5 px-3">Account</th>
                          <th className="py-2.5 px-3">Role</th>
                          <th className="py-2.5 px-3">Scope</th>
                          <th className="py-2.5 px-3 text-center">Status</th>
                          <th className="py-2.5 px-3 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {portalUsers.map((u) => (
                          <tr key={u.id} className="hover:bg-emerald-50/30">
                            <td className="py-2.5 px-3">
                              <div className="font-semibold text-slate-900">{u.full_name}</div>
                              <div className="text-[11px] text-slate-500 font-mono-num">
                                {u.username} · {u.email}
                              </div>
                            </td>
                            <td className="py-2.5 px-3 font-semibold text-[#07442B] whitespace-nowrap">
                              {u.role}
                            </td>
                            <td className="py-2.5 px-3 text-slate-600 whitespace-nowrap">
                              {u.department_code
                                ? `Dept: ${u.department_code}`
                                : u.employee_id
                                  ? `Emp #${u.employee_id}`
                                  : 'Campus-wide'}
                            </td>
                            <td className="py-2.5 px-3 text-center whitespace-nowrap">
                              <StatusLabel status={u.is_active === 1 ? 'Active' : 'Inactive'} />
                            </td>
                            <td className="py-2.5 px-3 text-right whitespace-nowrap">
                              {currentUser?.id !== u.id && (
                                <button
                                  type="button"
                                  onClick={() => handleToggleUserActive(u)}
                                  className="px-2.5 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-[11px] font-semibold text-slate-700 cursor-pointer"
                                >
                                  {u.is_active === 1 ? 'Deactivate' : 'Activate'}
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Security & Configuration Change History */}
              <div className="pt-5 border-t border-slate-200 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#0B5537]" />
                    <h3 className="font-display text-sm font-extrabold text-[#07442B]">
                      Security &amp; Configuration Change History (Redacted)
                    </h3>
                  </div>
                  <button
                    type="button"
                    onClick={loadSecurityData}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-[11px] font-semibold text-slate-600 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Refresh</span>
                  </button>
                </div>
                <div className="overflow-x-auto border border-slate-200 rounded-xl bg-white">
                  <table className="w-full text-left border-collapse text-[11px]">
                    <thead>
                      <tr className="bg-[#F4F8F6] border-b border-slate-200 font-bold text-slate-700">
                        <th className="py-2 px-3">Date &amp; Time</th>
                        <th className="py-2 px-3">Actor</th>
                        <th className="py-2 px-3">Security Event</th>
                        <th className="py-2 px-3 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {securityHistory.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="py-5 text-center text-slate-400">
                            No security change events recorded yet.
                          </td>
                        </tr>
                      ) : (
                        securityHistory.map((ev) => (
                          <tr key={ev.id} className="hover:bg-emerald-50/30">
                            <td className="py-2 px-3 font-mono-num whitespace-nowrap text-slate-500">
                              {ev.timestamp}
                            </td>
                            <td className="py-2 px-3 font-semibold text-slate-800 whitespace-nowrap">
                              {ev.username}
                            </td>
                            <td className="py-2 px-3 text-slate-700">
                              <span className="font-medium">{ev.activity}</span>
                              {ev.after_json && (
                                <div className="text-[10px] font-mono-num text-slate-400 truncate max-w-md">
                                  {ev.before_json ? `${ev.before_json} → ` : ''}
                                  {ev.after_json}
                                </div>
                              )}
                            </td>
                            <td className="py-2 px-3 text-center whitespace-nowrap">
                              <StatusLabel status={ev.status} />
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'backup' && (
            <div className="space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h2 className="font-display text-sm font-extrabold text-[#07442B]">
                  Backup, WAL Durability &amp; Verified Live Restore
                </h2>
                <button
                  type="button"
                  onClick={loadBackupStatus}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 font-semibold cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Refresh Status</span>
                </button>
              </div>

              {backupStatus && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="rounded-xl bg-white border border-slate-200 p-3">
                    <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Schema / Mode</p>
                    <p className="font-mono-num text-sm font-extrabold text-[#07442B] mt-1">
                      v{backupStatus.database.schemaVersion} · {backupStatus.mode}
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Journal: {backupStatus.database.journalMode.toUpperCase()}
                    </p>
                  </div>
                  <div className="rounded-xl bg-white border border-slate-200 p-3">
                    <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Integrity &amp; FKs</p>
                    <p className="font-mono-num text-sm font-extrabold text-emerald-700 mt-1">
                      {backupStatus.database.integrityCheck.toUpperCase()}
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      FKs: {backupStatus.database.foreignKeys ? 'ON' : 'OFF'} ({backupStatus.database.foreignKeyViolations} err)
                    </p>
                  </div>
                  <div className="rounded-xl bg-white border border-slate-200 p-3">
                    <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">DB / WAL Size</p>
                    <p className="font-mono-num text-sm font-extrabold text-slate-800 mt-1">
                      {(backupStatus.database.dbFileBytes / 1024).toFixed(1)} KB
                    </p>
                    <p className="text-[11px] text-slate-500 font-mono-num mt-0.5">
                      WAL: {(backupStatus.database.walFileBytes / 1024).toFixed(1)} KB
                    </p>
                  </div>
                  <div className="rounded-xl bg-white border border-slate-200 p-3">
                    <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Offsite Archive</p>
                    <p className="text-sm font-extrabold text-slate-800 mt-1">
                      {backupStatus.backupEncryptionConfigured ? 'AES-256-GCM' : 'Unencrypted'}
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Retain {backupStatus.backupRetentionCount} snapshot(s)
                    </p>
                  </div>
                </div>
              )}

              <p className="text-slate-600 leading-relaxed">
                Create consistent single-file SQLite online snapshots via{' '}
                <code className="font-mono-num bg-white px-1 py-0.5 rounded border border-slate-200">VACUUM INTO</code>{' '}
                with SHA-256 manifests, run dry-run restore drills, or perform an Administrator-authorized live restore
                with automatic pre-restore safety snapshot and rollback protection.
              </p>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  disabled={backupBusy !== null}
                  onClick={handleCreateSqliteSnapshot}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl btn-rsu-primary font-bold cursor-pointer disabled:opacity-60"
                >
                  <DatabaseBackup className="w-4 h-4" />
                  <span>{backupBusy === 'snapshot' ? 'Creating Snapshot...' : 'Create Online SQLite Backup'}</span>
                </button>
                <button
                  type="button"
                  disabled={backupBusy !== null}
                  onClick={handleCheckpointWal}
                  className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-semibold cursor-pointer disabled:opacity-60"
                >
                  <HardDrive className="w-4 h-4 text-slate-500" />
                  <span>{backupBusy === 'checkpoint' ? 'Checkpointing...' : 'Checkpoint WAL'}</span>
                </button>
                <button
                  type="button"
                  disabled={backupBusy !== null}
                  onClick={handleExportBackup}
                  className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-semibold cursor-pointer disabled:opacity-60"
                >
                  <Download className="w-4 h-4 text-slate-500" />
                  <span>Export JSON Snapshot</span>
                </button>
              </div>

              {/* Archive Selector for Restore Drill & Guarded Live Restore */}
              <div className="rounded-xl bg-white border border-slate-200 p-4 space-y-3">
                <h3 className="font-bold text-[#07442B]">Archive Verification &amp; Guarded Live Restore</h3>
                {backupStatus && backupStatus.availableArchives.length > 0 ? (
                  <div className="space-y-3">
                    <div>
                      <label htmlFor="backup-archive-select" className="block font-semibold text-slate-700 mb-1">Select Verified Snapshot Archive</label>
                      <select
                        id="backup-archive-select"
                        value={selectedArchive}
                        onChange={(e) => setSelectedArchive(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono-num"
                      >
                        {backupStatus.availableArchives.map((a) => (
                          <option key={a.fileName} value={a.fileName}>
                            {a.fileName} ({(a.sizeBytes / 1024).toFixed(1)} KB{a.encrypted ? ' · AES-256-GCM' : ''})
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="flex flex-wrap items-center gap-2.5">
                      <button
                        type="button"
                        disabled={backupBusy !== null || !selectedArchive}
                        onClick={handleRunRestoreDrill}
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-emerald-700/25 bg-white hover:bg-emerald-50 text-[#07442B] font-bold cursor-pointer disabled:opacity-60"
                      >
                        <ShieldCheck className="w-4 h-4 text-[#16A34A]" />
                        <span>{backupBusy === 'drill' ? 'Verifying Archive...' : 'Run Restore Drill (Dry Run)'}</span>
                      </button>
                      <button
                        type="button"
                        disabled={backupBusy !== null || !selectedArchive}
                        onClick={() => {
                          setRestoreForm({ confirmText: '', currentPassword: '' });
                          setRestoreModalOpen(true);
                        }}
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-red-300 bg-red-50 hover:bg-red-100 text-red-700 font-bold cursor-pointer disabled:opacity-60"
                      >
                        <RotateCcw className="w-4 h-4" />
                        <span>Restore Live Database...</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="text-slate-500">
                    No backup archives found in <code className="font-mono-num">{backupStatus?.backupDir || 'BACKUP_DIR'}</code>.
                    Create an online SQLite snapshot first before running a dry-run drill or live restore.
                  </p>
                )}
              </div>

              {backupStatus && (
                <div className="space-y-2 pt-2">
                  <h3 className="font-bold text-[#07442B]">Recent Backup, Checkpoint &amp; Restore History</h3>
                  <div className="overflow-x-auto border border-slate-200 rounded-xl bg-white">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-[#F4F8F6] border-b border-slate-200 font-bold text-slate-700">
                          <th className="py-2.5 px-3">Date &amp; Time</th>
                          <th className="py-2.5 px-3">Operation</th>
                          <th className="py-2.5 px-3">Archive / Checksum</th>
                          <th className="py-2.5 px-3 text-center">Integrity</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {backupStatus.history.length === 0 ? (
                          <tr>
                            <td colSpan={4} className="py-6 text-center text-slate-400">
                              No online SQLite backups or restore drills recorded yet.
                            </td>
                          </tr>
                        ) : (
                          backupStatus.history.map((h) => (
                            <tr key={h.id} className="hover:bg-emerald-50/30">
                              <td className="py-2.5 px-3 font-mono-num text-slate-600 whitespace-nowrap">
                                {h.created_at}
                              </td>
                              <td className="py-2.5 px-3 font-semibold text-slate-800 whitespace-nowrap">
                                {h.operation_type}
                                {h.encrypted === 1 && (
                                  <span className="ml-1.5 text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded">
                                    ENC
                                  </span>
                                )}
                              </td>
                              <td className="py-2.5 px-3">
                                <div className="font-mono-num text-slate-800 truncate max-w-[240px]">{h.file_name}</div>
                                <div className="font-mono-num text-[10px] text-slate-400">
                                  sha256: {h.sha256.slice(0, 16)}{h.sha256.length > 16 ? '…' : ''} · {(h.size_bytes / 1024).toFixed(1)} KB
                                </div>
                              </td>
                              <td className="py-2.5 px-3 text-center whitespace-nowrap">
                                <StatusLabel status={h.integrity_status === 'ok' && h.foreign_key_violations === 0 ? 'Success' : 'Error'} />
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'retention' && (
            <div className="space-y-5">
              <div className="space-y-3">
                <h2 className="font-display text-sm font-extrabold text-[#07442B]">
                  Data Retention Policy &amp; Purge Enforcement
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="ret-att-days" className="block font-semibold text-slate-700 mb-1">
                      Attendance Records Retention (min 30 days)
                    </label>
                    <input
                      id="ret-att-days"
                      type="number"
                      min={30}
                      max={36500}
                      value={settings.attendance_retention_days || '1825'}
                      onChange={(e) =>
                        setSettings({ ...settings, attendance_retention_days: e.target.value })
                      }
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono-num"
                    />
                  </div>
                  <div>
                    <label htmlFor="ret-audit-days" className="block font-semibold text-slate-700 mb-1">
                      Audit Archive Horizon (min 90 days)
                    </label>
                    <input
                      id="ret-audit-days"
                      type="number"
                      min={90}
                      max={36500}
                      value={settings.audit_log_retention_days || '730'}
                      onChange={(e) =>
                        setSettings({ ...settings, audit_log_retention_days: e.target.value })
                      }
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono-num"
                    />
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    disabled={saving}
                    onClick={() =>
                      handleSaveSettings(['attendance_retention_days', 'audit_log_retention_days'])
                    }
                    className="px-4 py-2 rounded-xl btn-rsu-primary font-bold cursor-pointer disabled:opacity-60"
                  >
                    {saving ? 'Saving...' : 'Save Retention Policy'}
                  </button>
                  <button
                    type="button"
                    disabled={retentionBusy !== null}
                    onClick={handlePreviewRetention}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-emerald-700/25 bg-white hover:bg-emerald-50 text-[#07442B] font-bold cursor-pointer disabled:opacity-60"
                  >
                    <FileSearch className="w-4 h-4 text-[#16A34A]" />
                    <span>{retentionBusy === 'preview' ? 'Evaluating...' : 'Preview Eligible Deletions (Dry Run)'}</span>
                  </button>
                  <button
                    type="button"
                    disabled={retentionBusy !== null}
                    onClick={() => setRetentionConfirmOpen(true)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold cursor-pointer disabled:opacity-60"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>{retentionBusy === 'execute' ? 'Running Purge...' : 'Run Retention Purge'}</span>
                  </button>
                </div>
              </div>

              {retentionPreview && (
                <div className="space-y-2.5 pt-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="font-bold text-[#07442B]">
                      Dry-Run Preview (Cutoff: Attendance &lt; {retentionPreview.cutoffAttendanceDate})
                    </h3>
                    <span className="font-mono-num text-[11px] font-semibold text-slate-600">
                      Eligible: {retentionPreview.totalEligibleDeletes} · Protected: {retentionPreview.totalPreservedImmutable}
                    </span>
                  </div>
                  <div className="overflow-x-auto border border-slate-200 rounded-xl bg-white">
                    <table className="w-full text-left border-collapse text-[11px]">
                      <thead>
                        <tr className="bg-[#F4F8F6] border-b border-slate-200 font-bold text-slate-700">
                          <th className="py-2 px-3">Dataset Category</th>
                          <th className="py-2 px-3 text-right">Eligible Purge</th>
                          <th className="py-2 px-3 text-right">Protected / Immutable</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {retentionPreview.categories.map((cat) => (
                          <tr key={cat.key}>
                            <td className="py-2 px-3">
                              <div className="font-semibold text-slate-800">{cat.label}</div>
                              <div className="text-[10px] text-slate-500">{cat.policyNote}</div>
                            </td>
                            <td className="py-2 px-3 text-right font-mono-num font-bold text-amber-700">
                              {cat.eligibleDeleteCount}
                            </td>
                            <td className="py-2 px-3 text-right font-mono-num font-semibold text-emerald-700">
                              {cat.preservedCount}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              <div className="space-y-2 pt-2">
                <h3 className="font-bold text-[#07442B]">Recorded Retention Enforcement Jobs</h3>
                <div className="overflow-x-auto border border-slate-200 rounded-xl bg-white">
                  <table className="w-full text-left border-collapse text-[11px]">
                    <thead>
                      <tr className="bg-[#F4F8F6] border-b border-slate-200 font-bold text-slate-700">
                        <th className="py-2 px-3">Job UID</th>
                        <th className="py-2 px-3">Executed (UTC)</th>
                        <th className="py-2 px-3">Actor</th>
                        <th className="py-2 px-3 text-right">Purged Rows</th>
                        <th className="py-2 px-3">Summary</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {retentionJobs.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-5 text-center text-slate-400">
                            No retention purge jobs have been executed yet.
                          </td>
                        </tr>
                      ) : (
                        retentionJobs.map((j) => (
                          <tr key={j.id}>
                            <td className="py-2 px-3 font-mono-num font-semibold text-slate-700">{j.job_uid}</td>
                            <td className="py-2 px-3 font-mono-num text-slate-500 whitespace-nowrap">
                              {j.executed_at_utc}
                            </td>
                            <td className="py-2 px-3 font-semibold text-slate-800">{j.executed_by}</td>
                            <td className="py-2 px-3 text-right font-mono-num font-bold text-[#07442B]">
                              {j.total_deleted}
                            </td>
                            <td className="py-2 px-3 text-slate-600">{j.notes}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'about' && (
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
              <SavageLogo size={96} variant="light" />
              <div className="space-y-1.5 text-center sm:text-left">
                <h2 className="font-display text-base font-extrabold text-[#07442B]">
                  SAVAGE-RSUCAJ Smart Attendance System
                </h2>
                <p className="font-semibold text-slate-700">
                  Romblon State University – Cajidiocan Campus
                </p>
                <p className="text-slate-500 italic">Safe · Secure · Smart</p>
                <p className="text-slate-600 pt-2 font-mono-num">
                  Node.js + Express + SQLite (WAL) + SSE + React 19 · Asia/Manila
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Create Portal User Modal */}
      <Modal
        open={userModalOpen}
        onClose={() => setUserModalOpen(false)}
        title="Create Portal User Account"
        subtitle="Assign a server-enforced RBAC role and temporary password (rotation enforced on first login)."
      >
        <form onSubmit={handleCreateUser} className="space-y-3.5 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Username *</label>
              <input
                type="text"
                required
                value={newUserForm.username}
                onChange={(e) => setNewUserForm({ ...newUserForm, username: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Role *</label>
              <select
                value={newUserForm.role}
                onChange={(e) => setNewUserForm({ ...newUserForm, role: e.target.value, employee_id: '', must_change_password: e.target.value === 'Employee' ? true : newUserForm.must_change_password })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
              >
                <option value="Administrator">Administrator</option>
                <option value="HR Officer">HR Officer</option>
                <option value="Payroll Officer">Payroll Officer</option>
                <option value="Department Head">Department Head</option>
                <option value="Employee">Employee</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Full Name *</label>
            <input
              type="text"
              required
              value={newUserForm.full_name}
              onChange={(e) => setNewUserForm({ ...newUserForm, full_name: e.target.value })}
              className="w-full px-3 py-2 rounded-lg border border-slate-300"
            />
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Institutional Email *</label>
            <input
              type="email"
              required
              value={newUserForm.email}
              onChange={(e) => setNewUserForm({ ...newUserForm, email: e.target.value })}
              className="w-full px-3 py-2 rounded-lg border border-slate-300"
            />
          </div>
          {newUserForm.role === 'Department Head' && (
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Assigned Department</label>
              <select
                value={newUserForm.department_id}
                onChange={(e) => setNewUserForm({ ...newUserForm, department_id: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
              >
                <option value="">Select department...</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.code} — {d.name}
                  </option>
                ))}
              </select>
            </div>
          )}
          {newUserForm.role === 'Employee' && (
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Linked Active Employee Profile *</label>
              <select
                required
                value={newUserForm.employee_id}
                onChange={(e) => {
                  const employee = employeeOptions.find((emp) => emp.id === Number(e.target.value));
                  setNewUserForm({ ...newUserForm, employee_id: e.target.value, full_name: employee?.full_name || '', email: employee?.email || '', department_id: employee ? String(employee.department_id) : '' });
                }}
                className="w-full px-3 py-2.5 rounded-lg border border-slate-300 bg-white"
              >
                <option value="">Select an available employee...</option>
                {employeeOptions.filter((emp) => emp.status === 'Active' && !emp.linked_user_id).map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.employee_code} — {emp.full_name}
                  </option>
                ))}
              </select>
              <p className="mt-1.5 text-[11px] text-slate-500">Employee profiles already linked to an account are excluded. Password rotation is mandatory.</p>
            </div>
          )}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Initial Temporary Password * (min 10 chars, upper/lower/digit/symbol)
            </label>
            <input
              type="password"
              required
              minLength={10}
              value={newUserForm.password}
              onChange={(e) => setNewUserForm({ ...newUserForm, password: e.target.value })}
              className="w-full px-3 py-2 rounded-lg border border-slate-300"
            />
          </div>
          <label className="inline-flex items-center gap-2 text-slate-700 font-medium cursor-pointer">
            <input
              type="checkbox"
              checked={newUserForm.role === 'Employee' ? true : newUserForm.must_change_password}
              disabled={newUserForm.role === 'Employee'}
              onChange={(e) => setNewUserForm({ ...newUserForm, must_change_password: e.target.checked })}
              className="w-4 h-4 rounded border-slate-300 accent-[#0B5537]"
            />
            <span>Require password change on first login (Recommended)</span>
          </label>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setUserModalOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
            >
              Create Account
            </button>
          </div>
        </form>
      </Modal>

      {/* Guarded Live Database Restore Modal */}
      <Modal
        open={restoreModalOpen}
        onClose={() => setRestoreModalOpen(false)}
        title="Restore Live SQLite Database"
        subtitle={`Target archive: ${selectedArchive}`}
      >
        <form onSubmit={handleExecuteLiveRestore} className="space-y-4 text-xs">
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-900 space-y-1">
            <p className="font-bold">Critical Database Operation</p>
            <p>
              This replaces the live SQLite database with the verified snapshot. A{' '}
              <code className="font-mono-num">.pre-restore-*.bak</code> rollback snapshot is created automatically
              before swapping. Sessions created after the backup timestamp will require re-authentication.
            </p>
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Type <code className="font-mono-num bg-slate-100 px-1 rounded">RESTORE LIVE DATABASE</code> to confirm *
            </label>
            <input
              type="text"
              required
              value={restoreForm.confirmText}
              onChange={(e) => setRestoreForm({ ...restoreForm, confirmText: e.target.value })}
              placeholder="RESTORE LIVE DATABASE"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
            />
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Administrator Current Password *</label>
            <input
              type="password"
              required
              autoComplete="current-password"
              value={restoreForm.currentPassword}
              onChange={(e) => setRestoreForm({ ...restoreForm, currentPassword: e.target.value })}
              className="w-full px-3 py-2 rounded-lg border border-slate-300"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setRestoreModalOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={backupBusy === 'restore' || restoreForm.confirmText !== 'RESTORE LIVE DATABASE'}
              className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold cursor-pointer disabled:opacity-50"
            >
              {backupBusy === 'restore' ? 'Restoring Database...' : 'Execute Live Restore'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmModal
        open={retentionConfirmOpen}
        onClose={() => setRetentionConfirmOpen(false)}
        onConfirm={handleExecuteRetention}
        title="Execute Data Retention Purge?"
        message={`This will permanently purge expired sessions, old read notifications, clean sync batches, and unlocked attendance records older than ${settings.attendance_retention_days || '1825'} days. Immutable audit logs, kiosk punch evidence, and payroll-locked attendance records remain protected.`}
        confirmLabel="Run Purge Job"
        destructive
      />
    </ModuleFrame>
  );
};
