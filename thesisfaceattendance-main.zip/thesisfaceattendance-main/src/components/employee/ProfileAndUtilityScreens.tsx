import React, { useEffect, useMemo, useState } from 'react';
import {
  BadgeCheck,
  Bell,
  BookOpen,
  Briefcase,
  Building2,
  CalendarDays,
  Check,
  CheckCheck,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Circle,
  ClipboardEdit,
  Clock,
  Eye,
  EyeOff,
  FileText,
  History,
  Info,
  KeyRound,
  Lock,
  LogOut,
  Mail,
  RefreshCw,
  Shield,
  ShieldCheck,
  Smartphone,
  Trash2,
  User,
  UserRound,
  Wallet,
} from 'lucide-react';
import { apiFetch, setCsrfToken } from '../../lib/api';
import type { AuthUser } from '../../types';
import {
  ConfirmationDialog,
  EMPLOYEE_INPUT_CLASS,
  EMPLOYEE_PRIMARY_BTN_CLASS,
  EmployeeHeader,
  EmployeeShieldLogo,
  EmptyState,
  ErrorState,
  FormField,
  LoadingState,
  StatusBadge,
} from './EmployeePrimitives';
import {
  extractErrorMessage,
  formatRelativeTimestamp,
  formatShortDate,
  parseUserAgentSummary,
  type EmployeeNotificationItem,
  type EmployeeProfileData,
  type EmployeeSecuritySessionsResponse,
  type SystemHealthMeta,
} from './types';

/* -------------------------------------------------------------------------- */
/* Screen 09: My Profile (Matches 09_My_Profile.png)                          */
/* -------------------------------------------------------------------------- */
export const MyProfileScreen: React.FC<{
  user: AuthUser;
  profile: EmployeeProfileData | null;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  onOpenChangePassword: () => void;
  onOpenAccountSecurity: () => void;
  onOpenAboutSystem: () => void;
  onRequestSignOut: () => void;
}> = ({
  user,
  profile,
  loading,
  error,
  onRetry,
  onOpenChangePassword,
  onOpenAccountSecurity,
  onOpenAboutSystem,
  onRequestSignOut,
}) => {
  const fullName = profile?.full_name || user.full_name;
  const employeeCode = profile?.employee_code || user.username;
  const department = profile?.department_name || profile?.department_code || 'Assigned Department';
  const position = profile?.position_name || 'Employee';

  return (
    <div className="mx-auto max-w-xl space-y-4">
      {error && <ErrorState message={error} onRetry={onRetry} />}

      {loading && !profile ? (
        <LoadingState label="Loading your profile..." />
      ) : (
        <>
          {/* Page Header matching 09_My_Profile.png */}
          <div className="flex items-center gap-3 pt-1">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
              <UserRound className="h-6 w-6" strokeWidth={2} />
            </div>
            <div>
              <h1 className="font-display text-[21px] font-extrabold text-slate-950 leading-tight">
                My Profile
              </h1>
              <p className="text-[13px] text-slate-600">
                View and manage your account
              </p>
            </div>
          </div>

          {/* Neutral Circular Avatar + Identity matching 09_My_Profile.png */}
          <div className="flex flex-col items-center pt-2 pb-1 text-center">
            <div className="flex h-24 w-24 items-center justify-center rounded-full bg-slate-200/90 text-slate-400 border-4 border-white shadow-[0_4px_16px_rgba(15,23,42,0.08)]">
              <UserRound className="h-14 w-14" strokeWidth={1.7} />
            </div>
            <h2 className="mt-3 font-display text-[20px] font-extrabold text-slate-950">
              {fullName}
            </h2>
            <p className="text-xs font-semibold text-[#065A32] font-mono-num">
              {employeeCode}
              {profile?.status ? ` · ${profile.status}` : ''}
            </p>
          </div>

          {/* Employee Information Card with outline emerald icons matching 09_My_Profile.png */}
          <section
            aria-label="Employee profile information"
            className="rounded-2xl border border-[#E2ECE6] bg-white px-5 py-1 shadow-[0_2px_12px_rgba(5,71,40,0.05)] divide-y divide-slate-100"
          >
            <div className="flex items-center justify-between gap-4 py-3.5 text-[14px]">
              <span className="inline-flex items-center gap-2.5 text-slate-500">
                <BadgeCheck className="h-4 w-4 text-[#08693B] shrink-0" />
                <span>Employee ID</span>
              </span>
              <span className="font-bold text-slate-950 font-mono-num text-right">
                {employeeCode}
              </span>
            </div>
            <div className="flex items-center justify-between gap-4 py-3.5 text-[14px]">
              <span className="inline-flex items-center gap-2.5 text-slate-500">
                <User className="h-4 w-4 text-[#08693B] shrink-0" />
                <span>Full Name</span>
              </span>
              <span className="font-bold text-slate-950 text-right">{fullName}</span>
            </div>
            <div className="flex items-center justify-between gap-4 py-3.5 text-[14px]">
              <span className="inline-flex items-center gap-2.5 text-slate-500">
                <Building2 className="h-4 w-4 text-[#08693B] shrink-0" />
                <span>Department</span>
              </span>
              <span className="font-bold text-slate-950 text-right">{department}</span>
            </div>
            <div className="flex items-center justify-between gap-4 py-3.5 text-[14px]">
              <span className="inline-flex items-center gap-2.5 text-slate-500">
                <Briefcase className="h-4 w-4 text-[#08693B] shrink-0" />
                <span>Position</span>
              </span>
              <span className="font-bold text-slate-950 text-right">{position}</span>
            </div>
            {profile?.shift_name && (
              <div className="flex items-center justify-between gap-4 py-3.5 text-[14px]">
                <span className="inline-flex items-center gap-2.5 text-slate-500">
                  <Clock className="h-4 w-4 text-[#08693B] shrink-0" />
                  <span>Assigned Shift</span>
                </span>
                <span className="font-bold text-slate-950 text-right">
                  {profile.shift_name} ({profile.shift_time_in}–{profile.shift_time_out})
                </span>
              </div>
            )}
            {profile?.email && (
              <div className="flex items-center justify-between gap-4 py-3.5 text-[14px]">
                <span className="inline-flex items-center gap-2.5 text-slate-500">
                  <Mail className="h-4 w-4 text-[#08693B] shrink-0" />
                  <span>Email</span>
                </span>
                <span className="font-semibold text-slate-800 text-right truncate max-w-[60%]">
                  {profile.email}
                </span>
              </div>
            )}
            {profile?.hired_date && (
              <div className="flex items-center justify-between gap-4 py-3.5 text-[14px]">
                <span className="inline-flex items-center gap-2.5 text-slate-500">
                  <CalendarDays className="h-4 w-4 text-[#08693B] shrink-0" />
                  <span>Date Hired</span>
                </span>
                <span className="font-semibold text-slate-800 text-right">
                  {formatShortDate(profile.hired_date)}
                </span>
              </div>
            )}
          </section>

          {/* Navigation Action Rows matching 09_My_Profile.png */}
          <div className="space-y-2.5">
            <button
              type="button"
              onClick={onOpenChangePassword}
              className="w-full min-h-[54px] flex items-center justify-between gap-3 rounded-2xl border border-[#E2ECE6] bg-white px-4 py-3.5 text-left shadow-[0_2px_8px_rgba(5,71,40,0.04)] hover:border-[#0B7A42]/45 transition cursor-pointer"
            >
              <span className="flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
                  <Lock className="h-5 w-5" />
                </span>
                <span className="text-[14.5px] font-bold text-slate-900">Change Password</span>
              </span>
              <ChevronRight className="h-5 w-5 text-slate-400" />
            </button>

            <button
              type="button"
              onClick={onOpenAccountSecurity}
              className="w-full min-h-[54px] flex items-center justify-between gap-3 rounded-2xl border border-[#E2ECE6] bg-white px-4 py-3.5 text-left shadow-[0_2px_8px_rgba(5,71,40,0.04)] hover:border-[#0B7A42]/45 transition cursor-pointer"
            >
              <span className="flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
                  <ShieldCheck className="h-5 w-5" />
                </span>
                <span className="text-[14.5px] font-bold text-slate-900">Account Security</span>
              </span>
              <ChevronRight className="h-5 w-5 text-slate-400" />
            </button>

            <button
              type="button"
              onClick={onOpenAboutSystem}
              className="w-full min-h-[54px] flex items-center justify-between gap-3 rounded-2xl border border-[#E2ECE6] bg-white px-4 py-3.5 text-left shadow-[0_2px_8px_rgba(5,71,40,0.04)] hover:border-[#0B7A42]/45 transition cursor-pointer"
            >
              <span className="flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
                  <Info className="h-5 w-5" />
                </span>
                <span className="text-[14.5px] font-bold text-slate-900">About System</span>
              </span>
              <ChevronRight className="h-5 w-5 text-slate-400" />
            </button>

            <button
              type="button"
              onClick={onRequestSignOut}
              className="w-full min-h-[54px] flex items-center justify-between gap-3 rounded-2xl border border-red-200/80 bg-white px-4 py-3.5 text-left shadow-[0_2px_8px_rgba(220,38,38,0.04)] hover:bg-red-50/70 transition cursor-pointer"
            >
              <span className="flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-red-50 text-red-600">
                  <LogOut className="h-5 w-5" />
                </span>
                <span className="text-[14.5px] font-bold text-red-600">Sign Out</span>
              </span>
              <ChevronRight className="h-5 w-5 text-red-400" />
            </button>
          </div>
        </>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Screen 15: Change Password (Matches 15_Change_Password.png)                */
/* -------------------------------------------------------------------------- */
interface PasswordPolicyConfig {
  minLength: number;
  requireUppercase: boolean;
  requireLowercase: boolean;
  requireDigit: boolean;
  requireSymbol: boolean;
}

const DEFAULT_POLICY: PasswordPolicyConfig = {
  minLength: 10,
  requireUppercase: true,
  requireLowercase: true,
  requireDigit: true,
  requireSymbol: true,
};

export const ChangePasswordScreen: React.FC<{
  forcedMode?: boolean;
  username?: string;
  onPasswordUpdated: (updatedUser: AuthUser) => void;
  onSignOut?: () => void;
}> = ({ forcedMode = false, username, onPasswordUpdated, onSignOut }) => {
  const [policy, setPolicy] = useState<PasswordPolicyConfig>(DEFAULT_POLICY);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<{ passwordPolicy?: PasswordPolicyConfig }>('/api/auth/config')
      .then((cfg) => {
        if (cfg.passwordPolicy) setPolicy(cfg.passwordPolicy);
      })
      .catch(() => {
        // Keep secure defaults
      });
  }, []);

  const checks = useMemo(() => {
    const items: Array<{ key: string; label: string; met: boolean }> = [
      {
        key: 'length',
        label: `At least ${policy.minLength} characters`,
        met: newPassword.length >= policy.minLength,
      },
    ];
    if (policy.requireUppercase) {
      items.push({
        key: 'upper',
        label: 'Contains an uppercase letter (A–Z)',
        met: /[A-Z]/.test(newPassword),
      });
    }
    if (policy.requireLowercase) {
      items.push({
        key: 'lower',
        label: 'Contains a lowercase letter (a–z)',
        met: /[a-z]/.test(newPassword),
      });
    }
    if (policy.requireDigit) {
      items.push({
        key: 'digit',
        label: 'Contains at least one number (0–9)',
        met: /\d/.test(newPassword),
      });
    }
    if (policy.requireSymbol) {
      items.push({
        key: 'symbol',
        label: 'Contains a special character (!@#$%^&*)',
        met: /[^A-Za-z0-9]/.test(newPassword),
      });
    }
    return items;
  }, [newPassword, policy]);

  const allMet = checks.every((c) => c.met);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (!currentPassword) {
      setError('Please enter your current password.');
      return;
    }
    if (!allMet) {
      setError('Your new password does not meet all security requirements.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('New password and confirmation do not match.');
      return;
    }
    if (currentPassword === newPassword) {
      setError('New password must be different from your current password.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await apiFetch<{ user: AuthUser; csrfToken?: string }>(
        '/api/auth/change-password',
        {
          method: 'POST',
          body: JSON.stringify({
            currentPassword,
            newPassword,
          }),
        }
      );
      setCsrfToken(res.csrfToken ?? null);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setSuccessMsg('Your password has been updated successfully.');
      onPasswordUpdated(res.user);
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  const formContent = (
    <form onSubmit={handleSubmit} className="mx-auto max-w-md space-y-4">
      {forcedMode && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs text-amber-900 flex items-start gap-2.5">
          <KeyRound className="h-4 w-4 shrink-0 mt-0.5 text-amber-700" />
          <div className="space-y-1">
            <p className="font-bold">Initial Password Change Required</p>
            <p className="leading-relaxed">
              Signed in as <strong>{username}</strong>. Please replace your temporary password before entering the Employee Portal.
            </p>
          </div>
        </div>
      )}

      {error && <ErrorState message={error} onDismiss={() => setError(null)} />}

      {successMsg && (
        <div
          role="status"
          className="flex items-center gap-2.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-3 text-xs font-semibold text-emerald-900"
        >
          <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
          <span>{successMsg}</span>
        </div>
      )}

      <FormField id="cp-current" label="Current Password" required>
        <div className="relative">
          <input
            id="cp-current"
            type={showCurrent ? 'text' : 'password'}
            autoComplete="current-password"
            required
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            placeholder="Enter current password"
            className={`${EMPLOYEE_INPUT_CLASS} pr-12`}
          />
          <button
            type="button"
            onClick={() => setShowCurrent((v) => !v)}
            aria-label={showCurrent ? 'Hide current password' : 'Show current password'}
            className="absolute right-2 top-1/2 -translate-y-1/2 flex h-9 w-9 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
          >
            {showCurrent ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
          </button>
        </div>
      </FormField>

      <FormField id="cp-new" label="New Password" required>
        <div className="relative">
          <input
            id="cp-new"
            type={showNew ? 'text' : 'password'}
            autoComplete="new-password"
            required
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="Enter new password"
            className={`${EMPLOYEE_INPUT_CLASS} pr-12`}
          />
          <button
            type="button"
            onClick={() => setShowNew((v) => !v)}
            aria-label={showNew ? 'Hide new password' : 'Show new password'}
            className="absolute right-2 top-1/2 -translate-y-1/2 flex h-9 w-9 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
          >
            {showNew ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
          </button>
        </div>
      </FormField>

      <FormField id="cp-confirm" label="Confirm New Password" required>
        <div className="relative">
          <input
            id="cp-confirm"
            type={showConfirm ? 'text' : 'password'}
            autoComplete="new-password"
            required
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="Confirm new password"
            className={`${EMPLOYEE_INPUT_CLASS} pr-12`}
          />
          <button
            type="button"
            onClick={() => setShowConfirm((v) => !v)}
            aria-label={showConfirm ? 'Hide confirm password' : 'Show confirm password'}
            className="absolute right-2 top-1/2 -translate-y-1/2 flex h-9 w-9 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
          >
            {showConfirm ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
          </button>
        </div>
      </FormField>

      {/* Password Requirements Checklist matching 15_Change_Password.png */}
      <div className="rounded-2xl border border-[#E2ECE6] bg-[#F8FBF9] p-4 space-y-2">
        <div className="text-[13px] font-bold text-slate-900">Password Requirements:</div>
        <ul className="space-y-1.5">
          {checks.map((c) => (
            <li
              key={c.key}
              className={`flex items-center gap-2 text-[12.5px] font-medium ${
                c.met ? 'text-[#066035]' : 'text-slate-600'
              }`}
            >
              {c.met ? (
                <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-[#16A34A] text-white">
                  <Check className="h-3 w-3" strokeWidth={3} />
                </span>
              ) : (
                <Circle className="h-4 w-4 shrink-0 text-slate-300" />
              )}
              <span>{c.label}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="pt-2 space-y-2.5">
        <button type="submit" disabled={submitting} className={EMPLOYEE_PRIMARY_BTN_CLASS}>
          {submitting ? 'Updating Password...' : 'Update Password'}
        </button>

        {forcedMode && onSignOut && (
          <button
            type="button"
            onClick={onSignOut}
            className="w-full min-h-[44px] rounded-xl border border-slate-200 bg-white text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            Sign Out
          </button>
        )}
      </div>
    </form>
  );

  if (forcedMode) {
    return (
      <div className="min-h-[100dvh] w-full bg-[#F7FAF8] flex flex-col">
        <EmployeeHeader variant="secondary" title="Change Password" />
        <main className="flex-1 px-4 py-6 sm:px-6">{formContent}</main>
      </div>
    );
  }

  return formContent;
};

/* -------------------------------------------------------------------------- */
/* Screen 16: Account Security (Matches 16_Account_Security.png)              */
/* Honest 2FA unavailable state + real Login Activity, Linked Devices & Timer */
/* -------------------------------------------------------------------------- */
export const AccountSecurityScreen: React.FC<{
  inactivityMinutes: number;
  onChangeInactivityMinutes: (minutes: number) => void;
}> = ({ inactivityMinutes, onChangeInactivityMinutes }) => {
  const [data, setData] = useState<EmployeeSecuritySessionsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedSection, setExpandedSection] = useState<'activity' | 'devices' | null>('devices');
  const [revokingId, setRevokingId] = useState<string | null>(null);
  const [revokeOthersConfirm, setRevokeOthersConfirm] = useState(false);
  const [revokingOthers, setRevokingOthers] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const loadSessions = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<EmployeeSecuritySessionsResponse>(
        '/api/employee/security/sessions'
      );
      setData(res);
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSessions();
  }, []);

  const activeSessions = useMemo(
    () => (data?.sessions || []).filter((s) => s.is_active),
    [data]
  );

  const otherActiveCount = activeSessions.filter((s) => !s.is_current).length;

  const handleRevokeOne = async (prefix: string) => {
    setRevokingId(prefix);
    setFeedback(null);
    setError(null);
    try {
      await apiFetch(`/api/employee/security/sessions/${encodeURIComponent(prefix)}`, {
        method: 'DELETE',
      });
      setFeedback('Session revoked successfully.');
      await loadSessions();
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setRevokingId(null);
    }
  };

  const handleRevokeOthers = async () => {
    setRevokingOthers(true);
    setFeedback(null);
    setError(null);
    try {
      const res = await apiFetch<{ revoked: number }>(
        '/api/employee/security/sessions/revoke-others',
        { method: 'POST' }
      );
      setFeedback(
        res.revoked > 0
          ? `Signed out ${res.revoked} other active session(s).`
          : 'No other active sessions found.'
      );
      setRevokeOthersConfirm(false);
      await loadSessions();
    } catch (err) {
      setError(extractErrorMessage(err));
      setRevokeOthersConfirm(false);
    } finally {
      setRevokingOthers(false);
    }
  };

  return (
    <div className="mx-auto max-w-xl space-y-4">
      {/* Centered Security Shield Emblem matching 16_Account_Security.png */}
      <div className="flex flex-col items-center pt-2 pb-1 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-[#ECFDF5] text-[#065A32]">
          <ShieldCheck className="h-12 w-12" strokeWidth={1.75} />
        </div>
      </div>

      {error && <ErrorState message={error} onRetry={loadSessions} />}
      {feedback && (
        <div
          role="status"
          className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-2.5 text-xs font-semibold text-emerald-900"
        >
          <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Two-Factor Authentication Row — Honest Unavailable State (NO fake toggle) */}
      <div className="rounded-2xl border border-[#E2ECE6] bg-white p-4 shadow-[0_2px_10px_rgba(5,71,40,0.04)]">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-slate-500">
              <Shield className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[14.5px] font-bold text-slate-900">
                  Two-Factor Authentication
                </span>
                <span className="rounded-full bg-amber-50 border border-amber-200 px-2 py-0.5 text-[10.5px] font-bold text-amber-800">
                  Not enabled on server
                </span>
              </div>
              <div className="text-[12px] text-slate-500 mt-0.5">
                Add an extra layer of security to your account.
              </div>
            </div>
          </div>

          <button
            type="button"
            disabled
            aria-disabled="true"
            aria-label="Two-Factor Authentication unavailable on this server"
            className="relative inline-flex h-7 w-12 shrink-0 items-center rounded-full bg-slate-200 cursor-not-allowed opacity-75"
          >
            <span className="inline-block h-5 w-5 translate-x-1 rounded-full bg-white shadow" />
          </button>
        </div>
        <p className="mt-2.5 text-xs text-slate-500 leading-relaxed border-t border-slate-100 pt-2.5">
          {data?.twoFactorNotice ||
            'Two-Factor Authentication (TOTP/SMS) is not enabled on this campus server deployment. Protect your account with a strong password and active session monitoring.'}
        </p>
      </div>

      {/* Login Activity (Real user_sessions history) */}
      <div className="rounded-2xl border border-[#E2ECE6] bg-white shadow-[0_2px_10px_rgba(5,71,40,0.04)] overflow-hidden">
        <button
          type="button"
          onClick={() =>
            setExpandedSection((cur) => (cur === 'activity' ? null : 'activity'))
          }
          aria-expanded={expandedSection === 'activity'}
          className="w-full min-h-[56px] flex items-center justify-between gap-3 px-4 py-3.5 text-left hover:bg-slate-50/70 cursor-pointer"
        >
          <span className="flex items-center gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
              <History className="h-5 w-5" />
            </span>
            <span>
              <span className="block text-[14.5px] font-bold text-slate-900">
                Login Activity
              </span>
              <span className="block text-[12px] text-slate-500">
                View recent login sessions{data ? ` · ${data.sessions.length} recorded` : ''}
              </span>
            </span>
          </span>
          {expandedSection === 'activity' ? (
            <ChevronDown className="h-5 w-5 text-slate-400" />
          ) : (
            <ChevronRight className="h-5 w-5 text-slate-400" />
          )}
        </button>

        {expandedSection === 'activity' && (
          <div className="border-t border-slate-100 px-4 py-3 space-y-2.5 bg-[#FAFDFB]">
            {loading && !data ? (
              <LoadingState label="Loading login activity..." />
            ) : (data?.sessions || []).length === 0 ? (
              <p className="text-xs text-slate-500 py-2">No session history available.</p>
            ) : (
              (data?.sessions || []).map((sess) => (
                <div
                  key={sess.session_id}
                  className="rounded-xl border border-slate-200/80 bg-white p-3 text-xs space-y-1"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-slate-900">
                      {parseUserAgentSummary(sess.user_agent)}
                      {sess.is_current ? ' (This Device)' : ''}
                    </span>
                    <StatusBadge status={sess.status} />
                  </div>
                  <div className="text-slate-500 font-mono-num">
                    IP: {sess.ip_address} · Signed in {formatRelativeTimestamp(sess.created_at)}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Linked Devices (Real active sessions + Revoke) */}
      <div className="rounded-2xl border border-[#E2ECE6] bg-white shadow-[0_2px_10px_rgba(5,71,40,0.04)] overflow-hidden">
        <button
          type="button"
          onClick={() =>
            setExpandedSection((cur) => (cur === 'devices' ? null : 'devices'))
          }
          aria-expanded={expandedSection === 'devices'}
          className="w-full min-h-[56px] flex items-center justify-between gap-3 px-4 py-3.5 text-left hover:bg-slate-50/70 cursor-pointer"
        >
          <span className="flex items-center gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
              <Smartphone className="h-5 w-5" />
            </span>
            <span>
              <span className="block text-[14.5px] font-bold text-slate-900">
                Linked Devices
              </span>
              <span className="block text-[12px] text-slate-500">
                Manage devices logged into your account{data ? ` · ${data.activeCount} active` : ''}
              </span>
            </span>
          </span>
          {expandedSection === 'devices' ? (
            <ChevronDown className="h-5 w-5 text-slate-400" />
          ) : (
            <ChevronRight className="h-5 w-5 text-slate-400" />
          )}
        </button>

        {expandedSection === 'devices' && (
          <div className="border-t border-slate-100 px-4 py-3 space-y-2.5 bg-[#FAFDFB]">
            {loading && !data ? (
              <LoadingState label="Checking active devices..." />
            ) : activeSessions.length === 0 ? (
              <p className="text-xs text-slate-500 py-2">No active sessions found.</p>
            ) : (
              <>
                {activeSessions.map((sess) => (
                  <div
                    key={sess.session_id}
                    className="flex items-center justify-between gap-3 rounded-xl border border-slate-200/80 bg-white p-3 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="font-bold text-slate-900 truncate">
                        {parseUserAgentSummary(sess.user_agent)}
                        {sess.is_current && (
                          <span className="ml-1.5 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-[#066035]">
                            Current
                          </span>
                        )}
                      </div>
                      <div className="text-slate-500 font-mono-num mt-0.5 truncate">
                        IP: {sess.ip_address} · Active since {formatRelativeTimestamp(sess.created_at)}
                      </div>
                    </div>

                    {!sess.is_current && (
                      <button
                        type="button"
                        disabled={revokingId === sess.session_id}
                        onClick={() => handleRevokeOne(sess.session_id)}
                        className="min-h-[36px] shrink-0 inline-flex items-center gap-1 rounded-lg border border-red-200 bg-red-50 px-2.5 text-[11.5px] font-bold text-red-700 hover:bg-red-100 disabled:opacity-50 cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>{revokingId === sess.session_id ? '...' : 'Revoke'}</span>
                      </button>
                    )}
                  </div>
                ))}

                {otherActiveCount > 0 && (
                  <button
                    type="button"
                    onClick={() => setRevokeOthersConfirm(true)}
                    className="w-full min-h-[42px] rounded-xl border border-red-200 bg-white text-xs font-bold text-red-700 hover:bg-red-50 cursor-pointer"
                  >
                    Sign Out All Other Devices ({otherActiveCount})
                  </button>
                )}
              </>
            )}
          </div>
        )}
      </div>

      {/* Session Timeout Selector matching 16_Account_Security.png */}
      <div className="rounded-2xl border border-[#E2ECE6] bg-white p-4 shadow-[0_2px_10px_rgba(5,71,40,0.04)] flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
            <Clock className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <label
              htmlFor="emp-session-timeout"
              className="block text-[14.5px] font-bold text-slate-900"
            >
              Session Timeout
            </label>
            <span className="block text-[12px] text-slate-500">
              {inactivityMinutes > 0
                ? `Automatically sign out after ${inactivityMinutes} minutes of inactivity`
                : `Server default timeout (${data?.sessionTimeoutHours ?? 12} hours max)`}
            </span>
          </div>
        </div>

        <select
          id="emp-session-timeout"
          value={inactivityMinutes}
          onChange={(e) => onChangeInactivityMinutes(Number(e.target.value))}
          className="min-h-[42px] rounded-xl border border-slate-200 bg-[#F8FBF9] px-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-[#08693B] cursor-pointer"
        >
          <option value={15}>15 min</option>
          <option value={30}>30 min</option>
          <option value={60}>60 min</option>
          <option value={0}>Server Default</option>
        </select>
      </div>

      <ConfirmationDialog
        open={revokeOthersConfirm}
        title="Sign Out Other Devices?"
        message="All other active sessions for your account will be immediately revoked. Your current session will remain signed in."
        confirmLabel="Revoke Other Sessions"
        destructive
        loading={revokingOthers}
        onConfirm={handleRevokeOthers}
        onCancel={() => setRevokeOthersConfirm(false)}
      />
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Screen 17: Notifications (Matches 17_Notifications.png)                    */
/* -------------------------------------------------------------------------- */
function getNotificationIcon(category: EmployeeNotificationItem['category']) {
  switch (category) {
    case 'System Announcement':
      return Bell;
    case 'Leave Update':
      return FileText;
    case 'Attendance Correction':
      return ClipboardEdit;
    case 'Payroll':
      return Wallet;
    default:
      return CalendarDays;
  }
}

export const NotificationsScreen: React.FC<{
  items: EmployeeNotificationItem[];
  unreadCount: number;
  loading: boolean;
  error: string | null;
  onRefresh: () => void;
  onMarkReadAndNavigate: (item: EmployeeNotificationItem) => void;
  onMarkAllRead: () => void;
}> = ({
  items,
  unreadCount,
  loading,
  error,
  onRefresh,
  onMarkReadAndNavigate,
  onMarkAllRead,
}) => {
  return (
    <div className="mx-auto max-w-2xl space-y-3.5">
      <div className="flex items-center justify-between gap-2">
        <p className="text-xs font-semibold text-slate-500">
          {unreadCount > 0 ? `${unreadCount} unread notification(s)` : 'All notifications caught up'}
        </p>
        <div className="flex items-center gap-2">
          {unreadCount > 0 && (
            <button
              type="button"
              onClick={onMarkAllRead}
              className="min-h-[36px] inline-flex items-center gap-1.5 rounded-xl border border-[#CFE4D8] bg-white px-3 text-xs font-bold text-[#065A32] hover:bg-[#F2FAF5] cursor-pointer"
            >
              <CheckCheck className="h-3.5 w-3.5" />
              <span>Mark all read</span>
            </button>
          )}
          <button
            type="button"
            onClick={onRefresh}
            aria-label="Refresh notifications"
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white text-[#065A32] hover:bg-[#F2FAF5] cursor-pointer"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {error && <ErrorState message={error} onRetry={onRefresh} />}

      {loading && items.length === 0 ? (
        <LoadingState label="Loading notifications..." />
      ) : items.length === 0 ? (
        <EmptyState
          icon={Bell}
          title="No Notifications Yet"
          description="Updates on your leave requests, attendance corrections, released payslips, and campus announcements will appear here."
        />
      ) : (
        <div className="space-y-2.5">
          {items.map((item) => {
            const Icon = getNotificationIcon(item.category);
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => onMarkReadAndNavigate(item)}
                className={`w-full text-left flex items-start gap-3.5 rounded-2xl border p-4 shadow-[0_2px_10px_rgba(5,71,40,0.04)] transition hover:border-[#0B7A42]/45 cursor-pointer ${
                  item.is_read
                    ? 'border-[#E5EFEA] bg-white'
                    : 'border-[#BFE3CE] bg-[#F5FBF7]'
                }`}
              >
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#E6F4EC] text-[#08693B]">
                  <Icon className="h-5 w-5" />
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div className="font-display text-[14.5px] font-bold text-slate-950 leading-snug">
                      {item.title}
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0 pt-0.5">
                      <span className="text-[11px] font-medium text-slate-500 whitespace-nowrap">
                        {formatRelativeTimestamp(item.timestamp)}
                      </span>
                      {!item.is_read && (
                        <span
                          aria-label="Unread notification"
                          className="h-2.5 w-2.5 rounded-full bg-[#EF4444]"
                        />
                      )}
                    </div>
                  </div>
                  <p className="mt-1 text-[13px] text-slate-600 leading-relaxed">
                    {item.message}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Screen 18: About System (Matches 18_About_System.png)                      */
/* -------------------------------------------------------------------------- */
export const AboutSystemScreen: React.FC<{
  onOpenOnboardingGuide: () => void;
}> = ({ onOpenOnboardingGuide }) => {
  const [meta, setMeta] = useState<SystemHealthMeta | null>(null);

  useEffect(() => {
    apiFetch<SystemHealthMeta>('/api/health')
      .then((res) => setMeta(res))
      .catch(() => {
        setMeta(null);
      });
  }, []);

  return (
    <div className="mx-auto max-w-md flex flex-col items-center text-center py-6 sm:py-10 px-2 space-y-5">
      <EmployeeShieldLogo
        size={132}
        className="drop-shadow-[0_6px_18px_rgba(5,71,40,0.16)]"
      />

      <div>
        <h1 className="font-display text-[26px] font-extrabold tracking-tight text-slate-950">
          SAVAGE-RSUCAJ
        </h1>
        <p className="mt-1 text-[14px] font-semibold text-[#065A32]">
          Employee Portal
        </p>
      </div>

      <p className="max-w-sm text-[14.5px] leading-relaxed text-slate-600">
        A secure, reliable, and efficient attendance and payroll system for Romblon State University – Cajidiocan Campus.
      </p>

      <div className="w-full rounded-2xl border border-[#E2ECE6] bg-white p-4 text-left text-xs text-slate-600 space-y-2 shadow-[0_2px_10px_rgba(5,71,40,0.04)]">
        <div className="flex items-center justify-between gap-2">
          <span className="text-slate-500">Server Timezone</span>
          <span className="font-bold text-slate-900 font-mono-num">
            {meta?.timezone || 'Asia/Manila'}
          </span>
        </div>
        <div className="flex items-center justify-between gap-2">
          <span className="text-slate-500">Attendance Mode</span>
          <span className="font-bold text-[#065A32]">Read-Only (Kiosk Verified)</span>
        </div>
        <div className="flex items-center justify-between gap-2">
          <span className="text-slate-500">Access Policy</span>
          <span className="font-bold text-slate-900">Role-Based · Self-Scoped</span>
        </div>
      </div>

      <button
        type="button"
        onClick={onOpenOnboardingGuide}
        className="w-full min-h-[46px] inline-flex items-center justify-center gap-2 rounded-xl border border-[#CFE4D8] bg-white px-4 text-sm font-bold text-[#065A32] hover:bg-[#F2FAF5] transition cursor-pointer"
      >
        <BookOpen className="h-4 w-4" />
        <span>View Onboarding Guide</span>
      </button>

      <div className="pt-4 text-[12px] text-slate-500 leading-relaxed">
        <p>© 2026 RSU – Cajidiocan Campus</p>
        <p>All Rights Reserved</p>
      </div>
    </div>
  );
};
