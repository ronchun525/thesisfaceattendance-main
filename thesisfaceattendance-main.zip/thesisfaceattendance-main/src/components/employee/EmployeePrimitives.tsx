import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Bell,
  CalendarDays,
  ChevronRight,
  ClipboardEdit,
  ClipboardList,
  Clock,
  Download,
  FileText,
  Home,
  Info,
  LogOut,
  RefreshCw,
  UserRound,
  Wallet,
  AlertCircle,
  Loader2,
  X,
} from 'lucide-react';
import { formatPeso } from '../../lib/api';
import type { PayrollItem } from '../../types';
import {
  EMPLOYEE_SHIELD_LOGO_URL,
  formatDateRange,
  formatDateWithWeekday,
  formatTime12h,
  type EmployeeTab,
} from './types';

/* -------------------------------------------------------------------------- */
/* Official SAVAGE-RSUCAJ Attendance Shield Logo (Never redrawn or cropped)   */
/* -------------------------------------------------------------------------- */
export const EmployeeShieldLogo: React.FC<{
  size?: number;
  className?: string;
}> = ({ size = 44, className = '' }) => {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        style={{ width: size, height: size }}
        className={`rounded-xl bg-[#054728] text-white font-display font-extrabold flex items-center justify-center text-xs border border-[#F4B400]/60 shrink-0 ${className}`}
        aria-label="SAVAGE-RSUCAJ Official Shield Logo"
      >
        RSU
      </div>
    );
  }

  return (
    <img
      src={EMPLOYEE_SHIELD_LOGO_URL}
      alt="SAVAGE-RSUCAJ Smart Attendance System Shield"
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      style={{ width: size, height: size }}
      className={`object-contain select-none shrink-0 ${className}`}
    />
  );
};

/* -------------------------------------------------------------------------- */
/* Signature Emerald & Gold Sweeping Wave Curves (Matches all 18 PNGs)        */
/* -------------------------------------------------------------------------- */
export const HeaderGoldWave: React.FC<{ className?: string }> = ({ className = '' }) => (
  <svg
    viewBox="0 0 390 22"
    fill="none"
    preserveAspectRatio="none"
    aria-hidden="true"
    className={`block w-full h-[18px] sm:h-[22px] -mt-[1px] ${className}`}
  >
    <defs>
      <linearGradient id="empHeaderGoldGrad" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#F59E0B" />
        <stop offset="48%" stopColor="#FDE047" />
        <stop offset="100%" stopColor="#F4B400" />
      </linearGradient>
    </defs>
    {/* Deep emerald backdrop behind curve */}
    <path d="M0 0H390V11C310 1 180 18 0 15V0Z" fill="#054728" />
    {/* Gold sweeping ribbon */}
    <path
      d="M0 15C95 2 225 14 390 6V16C255 21 120 8 0 21V15Z"
      fill="url(#empHeaderGoldGrad)"
    />
    {/* Crisp white lower cut */}
    <path d="M0 20C115 9 255 20 390 15V22H0V20Z" fill="#FFFFFF" />
  </svg>
);

export const FooterEmeraldGoldWave: React.FC<{
  height?: number;
  className?: string;
}> = ({ height = 56, className = '' }) => (
  <svg
    viewBox="0 0 390 64"
    fill="none"
    preserveAspectRatio="none"
    aria-hidden="true"
    style={{ height }}
    className={`block w-full pointer-events-none select-none ${className}`}
  >
    <defs>
      <linearGradient id="empFooterGoldGrad" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#F59E0B" />
        <stop offset="50%" stopColor="#FDE047" />
        <stop offset="100%" stopColor="#F4B400" />
      </linearGradient>
      <linearGradient id="empFooterEmeraldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#043D22" />
        <stop offset="55%" stopColor="#075B32" />
        <stop offset="100%" stopColor="#0A7642" />
      </linearGradient>
    </defs>
    <path
      d="M0 16C95 -4 195 36 290 22C335 15 368 8 390 12V64H0V16Z"
      fill="url(#empFooterGoldGrad)"
    />
    <path
      d="M0 32C105 12 220 46 390 26V64H0V32Z"
      fill="url(#empFooterEmeraldGrad)"
    />
  </svg>
);

/* -------------------------------------------------------------------------- */
/* EmployeeHeader (Primary Brand Header & Secondary Back-Arrow Header)        */
/* -------------------------------------------------------------------------- */
export interface EmployeeHeaderProps {
  variant: 'primary' | 'secondary';
  title?: string;
  onBack?: () => void;
  onOpenNotifications?: () => void;
  unreadCount?: number;
  rightAction?: React.ReactNode;
}

export const EmployeeHeader: React.FC<EmployeeHeaderProps> = ({
  variant,
  title,
  onBack,
  onOpenNotifications,
  unreadCount = 0,
  rightAction,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white">
      <div className="bg-gradient-to-r from-[#043D22] via-[#06522E] to-[#075F36] text-white">
        {variant === 'primary' ? (
          <div className="mx-auto flex h-[62px] max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
            <div className="flex min-w-0 items-center gap-2.5">
              <EmployeeShieldLogo
                size={42}
                className="drop-shadow-[0_2px_6px_rgba(0,0,0,0.35)]"
              />
              <div className="min-w-0 leading-tight">
                <div className="font-display text-[17px] font-extrabold tracking-tight text-white truncate">
                  SAVAGE-RSUCAJ
                </div>
                <div className="text-[12px] font-medium text-emerald-100/95 truncate">
                  Employee Portal
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              {rightAction}
              {onOpenNotifications && (
                <button
                  type="button"
                  onClick={onOpenNotifications}
                  aria-label={
                    unreadCount > 0
                      ? `Open notifications (${unreadCount} unread)`
                      : 'Open notifications'
                  }
                  className="relative flex h-11 w-11 items-center justify-center rounded-xl text-white hover:bg-white/12 active:scale-95 transition cursor-pointer"
                >
                  <Bell className="h-[22px] w-[22px]" strokeWidth={2.1} />
                  {unreadCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 min-w-[17px] h-[17px] px-1 rounded-full bg-[#EF4444] text-[10px] font-bold text-white font-mono-num flex items-center justify-center ring-2 ring-[#06522E]">
                      {unreadCount > 99 ? '99+' : unreadCount}
                    </span>
                  )}
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="mx-auto grid h-[58px] max-w-6xl grid-cols-[44px_minmax(0,1fr)_auto] items-center gap-2 px-3 sm:px-6">
            <div className="flex items-center justify-start">
              {onBack ? (
                <button
                  type="button"
                  onClick={onBack}
                  aria-label="Go back"
                  className="flex h-11 w-11 items-center justify-center rounded-xl text-white hover:bg-white/12 active:scale-95 transition cursor-pointer"
                >
                  <ArrowLeft className="h-[22px] w-[22px]" strokeWidth={2.3} />
                </button>
              ) : (
                <span className="h-11 w-11" aria-hidden="true" />
              )}
            </div>
            <h1 className="font-display text-[18px] font-bold text-white text-center truncate">
              {title || 'SAVAGE-RSUCAJ'}
            </h1>
            <div className="flex min-w-[44px] items-center justify-end">
              {rightAction || <span className="w-11" aria-hidden="true" />}
            </div>
          </div>
        )}
      </div>
      <HeaderGoldWave />
    </header>
  );
};

/* -------------------------------------------------------------------------- */
/* EmployeeBottomNavigation (Exact 5 Tabs matching Section 4 & PNGs)          */
/* -------------------------------------------------------------------------- */
export const EMPLOYEE_NAV_TABS: Array<{
  id: EmployeeTab;
  label: string;
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
}> = [
  { id: 'today', label: 'Today', icon: Home },
  { id: 'attendance', label: 'Attendance', icon: CalendarDays },
  { id: 'requests', label: 'Requests', icon: ClipboardList },
  { id: 'payslips', label: 'Payslips', icon: Wallet },
  { id: 'profile', label: 'Profile', icon: UserRound },
];

export const EmployeeBottomNavigation: React.FC<{
  activeTab: EmployeeTab;
  onSelectTab: (tab: EmployeeTab) => void;
}> = ({ activeTab, onSelectTab }) => {
  return (
    <nav
      aria-label="Employee bottom navigation"
      className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-gradient-to-r from-[#043D22] via-[#06522E] to-[#054728] text-white shadow-[0_-6px_22px_rgba(4,45,25,0.24)] border-t border-emerald-400/15 pb-[env(safe-area-inset-bottom)]"
    >
      <div className="mx-auto grid max-w-lg grid-cols-5 items-center gap-1 px-2 py-1.5">
        {EMPLOYEE_NAV_TABS.map(({ id, label, icon: Icon }) => {
          const active = activeTab === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => onSelectTab(id)}
              aria-current={active ? 'page' : undefined}
              className={`flex min-w-0 min-h-[54px] flex-col items-center justify-center gap-1 rounded-xl px-1 py-1.5 transition-all cursor-pointer ${
                active
                  ? 'bg-gradient-to-b from-[#139B56] to-[#0B7740] text-white shadow-inner shadow-emerald-200/20 ring-1 ring-emerald-300/30'
                  : 'text-emerald-100/85 hover:bg-white/8 hover:text-white'
              }`}
            >
              <Icon className="h-[20px] w-[20px] shrink-0" strokeWidth={active ? 2.3 : 1.9} />
              <span className="w-full truncate text-center text-[10.5px] font-semibold leading-none tracking-tight">
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

/* -------------------------------------------------------------------------- */
/* EmployeeSidebar (Desktop lg: Navigation preserving institutional motif)    */
/* -------------------------------------------------------------------------- */
export const EmployeeSidebar: React.FC<{
  activeTab: EmployeeTab;
  activeScreen: string;
  employeeName: string;
  employeeCode?: string;
  unreadCount: number;
  onSelectTab: (tab: EmployeeTab) => void;
  onOpenNotifications: () => void;
  onOpenAbout: () => void;
  onRequestSignOut: () => void;
}> = ({
  activeTab,
  activeScreen,
  employeeName,
  employeeCode,
  unreadCount,
  onSelectTab,
  onOpenNotifications,
  onOpenAbout,
  onRequestSignOut,
}) => {
  return (
    <aside
      aria-label="Employee desktop navigation"
      className="hidden lg:flex lg:w-64 lg:shrink-0 lg:flex-col bg-gradient-to-b from-[#043B21] via-[#064E2C] to-[#04331C] text-white sticky top-0 h-screen shadow-xl shadow-emerald-950/15"
    >
      <div className="px-5 pt-6 pb-5 border-b border-white/10 flex flex-col items-center text-center">
        <EmployeeShieldLogo
          size={72}
          className="drop-shadow-[0_4px_12px_rgba(0,0,0,0.38)]"
        />
        <div className="font-display text-[16px] font-extrabold tracking-tight text-white mt-3">
          SAVAGE-RSUCAJ
        </div>
        <div className="text-[11px] font-semibold text-emerald-200/90 mt-0.5">
          Employee Portal
        </div>
        <div className="mt-3 w-full rounded-xl bg-white/8 px-3 py-2 text-left">
          <div className="text-xs font-bold text-white truncate">{employeeName}</div>
          <div className="text-[11px] text-emerald-200/85 font-mono-num truncate">
            {employeeCode || 'Linked Employee'}
          </div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {EMPLOYEE_NAV_TABS.map(({ id, label, icon: Icon }) => {
          const active =
            activeTab === id &&
            activeScreen !== 'notifications' &&
            activeScreen !== 'about';
          return (
            <button
              key={id}
              type="button"
              onClick={() => onSelectTab(id)}
              aria-current={active ? 'page' : undefined}
              className={`w-full min-h-[44px] flex items-center gap-3 rounded-xl px-3.5 text-sm font-semibold transition cursor-pointer ${
                active
                  ? 'bg-gradient-to-r from-[#139B56] to-[#0C7D44] text-white shadow-md shadow-black/20 ring-1 ring-emerald-300/30'
                  : 'text-emerald-100/90 hover:bg-white/10 hover:text-white'
              }`}
            >
              <Icon className="h-[18px] w-[18px] shrink-0" />
              <span className="truncate">{label}</span>
            </button>
          );
        })}

        <div className="pt-3 mt-3 border-t border-white/10 space-y-1">
          <button
            type="button"
            onClick={onOpenNotifications}
            aria-current={activeScreen === 'notifications' ? 'page' : undefined}
            className={`w-full min-h-[44px] flex items-center justify-between gap-2 rounded-xl px-3.5 text-sm font-semibold transition cursor-pointer ${
              activeScreen === 'notifications'
                ? 'bg-gradient-to-r from-[#139B56] to-[#0C7D44] text-white shadow-md'
                : 'text-emerald-100/90 hover:bg-white/10 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-3 min-w-0">
              <Bell className="h-[18px] w-[18px] shrink-0" />
              <span className="truncate">Notifications</span>
            </span>
            {unreadCount > 0 && (
              <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-[#EF4444] text-[10px] font-bold font-mono-num text-white flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={onOpenAbout}
            aria-current={activeScreen === 'about' ? 'page' : undefined}
            className={`w-full min-h-[44px] flex items-center gap-3 rounded-xl px-3.5 text-sm font-semibold transition cursor-pointer ${
              activeScreen === 'about'
                ? 'bg-gradient-to-r from-[#139B56] to-[#0C7D44] text-white shadow-md'
                : 'text-emerald-100/90 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Info className="h-[18px] w-[18px] shrink-0" />
            <span className="truncate">About System</span>
          </button>
        </div>
      </nav>

      <div className="p-3 border-t border-white/10">
        <button
          type="button"
          onClick={onRequestSignOut}
          className="w-full min-h-[44px] flex items-center gap-3 rounded-xl px-3.5 text-sm font-semibold text-rose-200 hover:bg-rose-500/20 hover:text-white transition cursor-pointer"
        >
          <LogOut className="h-[18px] w-[18px] shrink-0" />
          <span>Sign Out</span>
        </button>
      </div>
      <FooterEmeraldGoldWave height={22} />
    </aside>
  );
};

/* -------------------------------------------------------------------------- */
/* EmployeePageLayout                                                         */
/* -------------------------------------------------------------------------- */
export const EmployeePageLayout: React.FC<{
  header: React.ReactNode;
  sidebar?: React.ReactNode;
  bottomNav?: React.ReactNode;
  hasBottomNav?: boolean;
  children: React.ReactNode;
}> = ({ header, sidebar, bottomNav, hasBottomNav = false, children }) => {
  return (
    <div className="min-h-[100dvh] w-full overflow-x-clip bg-[#F7FAF8] lg:flex text-slate-900">
      {sidebar}
      <div className="flex min-w-0 flex-1 flex-col bg-white lg:bg-[#F7FAF8]">
        {header}
        <main
          id="employee-portal-main"
          className={`mx-auto w-full max-w-4xl flex-1 px-4 pt-3 sm:px-6 lg:px-8 lg:pt-6 ${
            hasBottomNav
              ? 'pb-[calc(5.75rem+env(safe-area-inset-bottom))] lg:pb-10'
              : 'pb-[calc(2rem+env(safe-area-inset-bottom))] lg:pb-10'
          }`}
        >
          {children}
        </main>
      </div>
      {bottomNav}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* StatusBadge (Reference-matched semantic badges with text labels)           */
/* -------------------------------------------------------------------------- */
export const StatusBadge: React.FC<{
  status: string;
  size?: 'sm' | 'md';
  showClockIcon?: boolean;
}> = ({ status, size = 'sm', showClockIcon = false }) => {
  const normalized = status.trim();
  const displayLabel = normalized === 'Pending' ? 'Pending Approval' : normalized;

  let tone = 'bg-slate-100 text-slate-700 border border-slate-200/80';
  if (['Present', 'Approved', 'Released', 'ACCEPTED', 'Active'].includes(normalized)) {
    tone = 'bg-[#DCFCE7] text-[#066035] border border-[#BBF7D0]';
  } else if (
    ['Pending', 'Pending Approval', 'Not Recorded', 'Undertime', 'Missing Time Out', 'Missing Time In'].includes(
      normalized
    )
  ) {
    tone = 'bg-[#FEF08A] text-[#422006] border border-[#FDE047]';
  } else if (['Late', 'Absent', 'Rejected', 'REJECTED', 'Revoked'].includes(normalized)) {
    tone = 'bg-[#FEE2E2] text-[#C81E1E] border border-[#FECACA]';
  } else if (['On Leave', 'OB', 'Holiday'].includes(normalized)) {
    tone = 'bg-[#E0F2FE] text-[#075985] border border-[#BAE6FD]';
  }

  return (
    <span
      className={`inline-flex items-center justify-center gap-1.5 rounded-full font-bold whitespace-nowrap ${
        size === 'md' ? 'px-4 py-1.5 text-[13px]' : 'px-3 py-1 text-[11.5px]'
      } ${tone}`}
    >
      {showClockIcon && <Clock className="h-3.5 w-3.5 shrink-0" />}
      <span>{displayLabel}</span>
    </span>
  );
};

/* -------------------------------------------------------------------------- */
/* AttendanceCard (Matches 07_Attendance_Records.png daily record cards)      */
/* -------------------------------------------------------------------------- */
export const AttendanceCard: React.FC<{
  date: string;
  status: string;
  timeIn: string | null;
  timeOut: string | null;
  workHours?: string;
  lateMinutes?: number | null;
  undertimeMinutes?: number | null;
}> = ({ date, status, timeIn, timeOut, workHours, lateMinutes, undertimeMinutes }) => {
  const hasTimes = Boolean(timeIn || timeOut);
  const timeRange = hasTimes
    ? `${formatTime12h(timeIn)} – ${formatTime12h(timeOut)}`
    : null;

  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl border border-[#E5EFEA] bg-white px-4 py-3.5 shadow-[0_2px_10px_rgba(5,71,40,0.04)]">
      <div className="flex min-w-0 items-center gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
          <CalendarDays className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <div className="text-[14px] font-bold text-slate-900 truncate">
            {formatDateWithWeekday(date)}
          </div>
          <div className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[11.5px] text-slate-500">
            <span>{workHours && workHours !== '-' ? `Hours: ${workHours}` : 'No shift hours logged'}</span>
            {lateMinutes && lateMinutes > 0 ? (
              <span className="text-red-600 font-semibold">· Late {lateMinutes}m</span>
            ) : null}
            {undertimeMinutes && undertimeMinutes > 0 ? (
              <span className="text-amber-700 font-semibold">· UT {undertimeMinutes}m</span>
            ) : null}
          </div>
        </div>
      </div>

      <div className="flex shrink-0 flex-col items-end gap-1 text-right">
        {status && status !== 'Rest Day' ? (
          <StatusBadge status={status} />
        ) : (
          <span className="text-sm font-bold text-slate-400">—</span>
        )}
        {timeRange && (
          <span className="text-[11px] font-medium text-slate-500 font-mono-num">
            {timeRange}
          </span>
        )}
      </div>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* RequestCard (Matches 13_My_Requests_Tracking.png)                          */
/* -------------------------------------------------------------------------- */
export const RequestCard: React.FC<{
  kind: 'leave' | 'correction';
  referenceNo: string;
  subtitle?: string;
  startDate: string;
  endDate?: string;
  status: string;
  highlighted?: boolean;
  onClick?: () => void;
}> = ({
  kind,
  referenceNo,
  subtitle,
  startDate,
  endDate,
  status,
  highlighted = false,
  onClick,
}) => {
  const Icon = kind === 'leave' ? CalendarDays : ClipboardEdit;
  const heading = kind === 'leave' ? 'Leave Request' : 'Attendance Correction';

  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full text-left flex items-center gap-3.5 rounded-2xl border bg-white p-4 shadow-[0_2px_10px_rgba(5,71,40,0.05)] transition hover:border-[#0B7A42]/40 cursor-pointer ${
        highlighted
          ? 'border-[#0B7A42] ring-2 ring-[#0B7A42]/20 bg-emerald-50/20'
          : 'border-[#E5EFEA]'
      }`}
    >
      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
        <Icon className="h-[22px] w-[22px]" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <div className="font-display text-[15px] font-bold text-slate-900 truncate">
            {heading}
          </div>
          <ChevronRight className="h-4 w-4 shrink-0 text-slate-400" />
        </div>
        <div className="mt-0.5 text-[12.5px] font-semibold text-slate-700 font-mono-num">
          {referenceNo}
          {subtitle ? (
            <span className="font-sans font-normal text-slate-500"> · {subtitle}</span>
          ) : null}
        </div>
        <div className="mt-0.5 text-[12px] text-slate-500">
          {formatDateRange(startDate, endDate || startDate)}
        </div>
        <div className="mt-2.5">
          <StatusBadge status={status} />
        </div>
      </div>
    </button>
  );
};

/* -------------------------------------------------------------------------- */
/* PayslipCard (Matches 08_My_Payslips.png)                                   */
/* -------------------------------------------------------------------------- */
export const PayslipCard: React.FC<{
  item: PayrollItem;
  downloading?: boolean;
  onViewDetails: () => void;
  onDownloadPdf: () => void;
}> = ({ item, downloading = false, onViewDetails, onDownloadPdf }) => {
  const periodTitle = item.period_label || `${item.start_date || ''} – ${item.end_date || ''}`;

  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl border border-[#E5EFEA] bg-white px-4 py-4 shadow-[0_2px_10px_rgba(5,71,40,0.05)] hover:border-[#0B7A42]/40 transition">
      <button
        type="button"
        onClick={onViewDetails}
        className="flex min-w-0 flex-1 items-center gap-3.5 text-left cursor-pointer"
      >
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
          <FileText className="h-6 w-6" />
        </div>
        <div className="min-w-0">
          <div className="font-display text-[15px] font-bold text-slate-900 truncate">
            Payslip – {periodTitle}
          </div>
          <div className="text-[12.5px] font-semibold text-[#0B7A42] mt-0.5">
            {item.run_status || 'Released'}
          </div>
          <div className="font-display text-[16px] font-extrabold text-slate-900 font-mono-num mt-1">
            {formatPeso(item.net_pay)}
          </div>
        </div>
      </button>

      <button
        type="button"
        disabled={downloading}
        onClick={(e) => {
          e.stopPropagation();
          onDownloadPdf();
        }}
        aria-label={`Download PDF for ${periodTitle}`}
        title="Download Official Payslip PDF"
        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-[#D8E9DF] bg-[#F4FAF6] text-[#065A32] hover:bg-[#DCFCE7] active:scale-95 transition disabled:opacity-50 cursor-pointer"
      >
        {downloading ? (
          <Loader2 className="h-5 w-5 animate-spin" />
        ) : (
          <Download className="h-5 w-5" />
        )}
      </button>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* FormField                                                                  */
/* -------------------------------------------------------------------------- */
export const FormField: React.FC<{
  id: string;
  label: string;
  required?: boolean;
  hint?: string;
  error?: string | null;
  children: React.ReactNode;
}> = ({ id, label, required, hint, error, children }) => (
  <div>
    <label htmlFor={id} className="block text-[13.5px] font-bold text-slate-900 mb-1.5">
      {label}
      {required && <span className="text-red-600 ml-0.5">*</span>}
    </label>
    {children}
    {error ? (
      <p className="mt-1 text-xs font-medium text-red-600" role="alert">
        {error}
      </p>
    ) : hint ? (
      <p className="mt-1 text-[11.5px] text-slate-500">{hint}</p>
    ) : null}
  </div>
);

export const EMPLOYEE_INPUT_CLASS =
  'w-full min-h-[46px] rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[14px] text-slate-900 placeholder:text-slate-400 shadow-[0_1px_2px_rgba(0,0,0,0.03)] focus:outline-none focus:border-[#08693B] focus:ring-2 focus:ring-[#08693B]/15 transition';

export const EMPLOYEE_PRIMARY_BTN_CLASS =
  'w-full min-h-[48px] rounded-xl bg-gradient-to-b from-[#0A7742] to-[#054A29] text-white font-display text-[15px] font-bold shadow-[0_4px_12px_rgba(5,71,40,0.28)] hover:from-[#0C884C] hover:to-[#075B33] active:scale-[0.99] transition disabled:opacity-55 disabled:cursor-not-allowed cursor-pointer flex items-center justify-center gap-2';

/* -------------------------------------------------------------------------- */
/* LoadingState, EmptyState, ErrorState, ConfirmationDialog                   */
/* -------------------------------------------------------------------------- */
export const LoadingState: React.FC<{ label?: string }> = ({ label = 'Loading records...' }) => (
  <div
    role="status"
    className="flex flex-col items-center justify-center gap-2.5 rounded-2xl border border-[#E5EFEA] bg-white py-12 px-4 text-center"
  >
    <Loader2 className="h-7 w-7 animate-spin text-[#08693B]" />
    <p className="text-sm font-medium text-slate-600">{label}</p>
  </div>
);

export const EmptyState: React.FC<{
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  action?: React.ReactNode;
}> = ({ icon: Icon, title, description, action }) => (
  <div className="flex flex-col items-center justify-center rounded-2xl border border-[#E5EFEA] bg-white py-10 px-6 text-center">
    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#ECFDF5] text-[#08693B]">
      <Icon className="h-6 w-6" />
    </div>
    <h3 className="mt-3 font-display text-[15px] font-bold text-slate-900">{title}</h3>
    <p className="mt-1 max-w-xs text-xs text-slate-500 leading-relaxed">{description}</p>
    {action && <div className="mt-4">{action}</div>}
  </div>
);

export const ErrorState: React.FC<{
  message: string;
  onRetry?: () => void;
  onDismiss?: () => void;
}> = ({ message, onRetry, onDismiss }) => (
  <div
    role="alert"
    className="flex items-start gap-2.5 rounded-xl border border-red-200 bg-red-50 px-3.5 py-3 text-xs text-red-800"
  >
    <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-red-600" />
    <div className="min-w-0 flex-1">
      <p className="font-medium leading-relaxed">{message}</p>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="mt-1.5 inline-flex items-center gap-1 font-bold text-red-700 underline hover:text-red-900 cursor-pointer"
        >
          <RefreshCw className="h-3 w-3" />
          Try again
        </button>
      )}
    </div>
    {onDismiss && (
      <button
        type="button"
        onClick={onDismiss}
        aria-label="Dismiss error"
        className="p-1 rounded-lg text-red-600 hover:bg-red-100 cursor-pointer"
      >
        <X className="h-4 w-4" />
      </button>
    )}
  </div>
);

export const ConfirmationDialog: React.FC<{
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  destructive?: boolean;
  loading?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}> = ({
  open,
  title,
  message,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  destructive = false,
  loading = false,
  onConfirm,
  onCancel,
}) => {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !loading) onCancel();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, loading, onCancel]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-4 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="emp-confirm-title"
    >
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl">
        <h2 id="emp-confirm-title" className="font-display text-lg font-extrabold text-slate-900">
          {title}
        </h2>
        <p className="mt-2 text-sm text-slate-600 leading-relaxed">{message}</p>
        <div className="mt-5 flex items-center justify-end gap-2.5">
          <button
            type="button"
            disabled={loading}
            onClick={onCancel}
            className="min-h-[44px] rounded-xl border border-slate-200 px-4 text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            disabled={loading}
            onClick={onConfirm}
            className={`min-h-[44px] rounded-xl px-5 text-sm font-bold text-white cursor-pointer disabled:opacity-60 ${
              destructive
                ? 'bg-red-600 hover:bg-red-700'
                : 'bg-[#065A32] hover:bg-[#086E3E]'
            }`}
          >
            {loading ? 'Please wait...' : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
};
