import React, { useMemo, useRef, useState } from 'react';
import {
  CalendarDays,
  Check,
  ClipboardEdit,
  ClipboardList,
  Clock,
  Paperclip,
  Plus,
  RefreshCw,
  Trash2,
  X,
} from 'lucide-react';
import { apiFetch, getManilaTodayIso } from '../../lib/api';
import type {
  CorrectionRequest,
  LeaveDayPortion,
  LeavePolicy,
  LeaveRequest,
} from '../../types';
import {
  ConfirmationDialog,
  EMPLOYEE_INPUT_CLASS,
  EMPLOYEE_PRIMARY_BTN_CLASS,
  EmptyState,
  ErrorState,
  FormField,
  LoadingState,
  RequestCard,
  StatusBadge,
} from './EmployeePrimitives';
import {
  extractErrorMessage,
  formatCorrectionReference,
  formatDateRange,
  formatLeaveReference,
  formatShortDate,
  formatTime12h,
  type RequestSuccessPayload,
} from './types';

const MAX_ATTACHMENT_BYTES = 2 * 1024 * 1024; // 2 MB

interface AttachmentPayload {
  name: string;
  mime: string;
  data: string;
}

function readFileAsBase64(file: File): Promise<AttachmentPayload> {
  return new Promise((resolve, reject) => {
    if (file.size > MAX_ATTACHMENT_BYTES) {
      reject(new Error('Attachment exceeds the 2 MB maximum file size.'));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const base64 = result.includes(',') ? result.split(',')[1] : result;
      resolve({
        name: file.name,
        mime: file.type || 'application/octet-stream',
        data: base64,
      });
    };
    reader.onerror = () => reject(new Error('Unable to read the selected file.'));
    reader.readAsDataURL(file);
  });
}

/* -------------------------------------------------------------------------- */
/* Screen 13: My Requests Tracking (Matches 13_My_Requests_Tracking.png)      */
/* -------------------------------------------------------------------------- */
type UnifiedRequestItem =
  | {
      kind: 'leave';
      key: string;
      id: number;
      referenceNo: string;
      subtitle: string;
      startDate: string;
      endDate: string;
      status: string;
      createdAt: string;
      raw: LeaveRequest;
    }
  | {
      kind: 'correction';
      key: string;
      id: number;
      referenceNo: string;
      subtitle: string;
      startDate: string;
      endDate: string;
      status: string;
      createdAt: string;
      raw: CorrectionRequest;
    };

export const MyRequestsTrackingScreen: React.FC<{
  leaves: LeaveRequest[];
  corrections: CorrectionRequest[];
  loading: boolean;
  error: string | null;
  highlightedRefKey?: string | null;
  onRefresh: () => void;
  onOpenLeaveForm: () => void;
  onOpenCorrectionForm: () => void;
  onLeaveCancelled: () => Promise<void>;
}> = ({
  leaves,
  corrections,
  loading,
  error,
  highlightedRefKey,
  onRefresh,
  onOpenLeaveForm,
  onOpenCorrectionForm,
  onLeaveCancelled,
}) => {
  const [typeTab, setTypeTab] = useState<'all' | 'leave' | 'correction'>('all');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'Approved' | 'Rejected' | 'Cancelled'>('All');
  const [selectedItem, setSelectedItem] = useState<UnifiedRequestItem | null>(null);
  const [cancelConfirmOpen, setCancelConfirmOpen] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const [cancelError, setCancelError] = useState<string | null>(null);

  const unified = useMemo<UnifiedRequestItem[]>(() => {
    const leaveItems: UnifiedRequestItem[] = leaves.map((l) => ({
      kind: 'leave',
      key: `leave-${l.id}`,
      id: l.id,
      referenceNo: formatLeaveReference(l.id, l.start_date || l.created_at),
      subtitle: `${l.leave_type} (${l.days_count}d)`,
      startDate: l.start_date,
      endDate: l.end_date,
      status: l.status,
      createdAt: l.created_at || l.start_date,
      raw: l,
    }));

    const correctionItems: UnifiedRequestItem[] = corrections.map((c) => ({
      kind: 'correction',
      key: `correction-${c.id}`,
      id: c.id,
      referenceNo: formatCorrectionReference(c.id, c.attendance_date || c.created_at),
      subtitle: c.request_type,
      startDate: c.attendance_date,
      endDate: c.attendance_date,
      status: c.status,
      createdAt: c.created_at || c.attendance_date,
      raw: c,
    }));

    return [...leaveItems, ...correctionItems].sort((a, b) =>
      (b.createdAt || '').localeCompare(a.createdAt || '')
    );
  }, [leaves, corrections]);

  const filtered = useMemo(() => {
    return unified.filter((item) => {
      if (typeTab !== 'all' && item.kind !== typeTab) return false;
      if (statusFilter !== 'All' && item.status !== statusFilter) return false;
      return true;
    });
  }, [unified, typeTab, statusFilter]);

  const handleConfirmCancelLeave = async () => {
    if (!selectedItem || selectedItem.kind !== 'leave') return;
    setCancelling(true);
    setCancelError(null);
    try {
      await apiFetch(`/api/leaves/${selectedItem.id}/cancel`, {
        method: 'POST',
        body: JSON.stringify({ cancel_reason: 'Cancelled by employee from Employee Portal' }),
      });
      setCancelConfirmOpen(false);
      setSelectedItem(null);
      await onLeaveCancelled();
    } catch (err) {
      setCancelError(extractErrorMessage(err));
      setCancelConfirmOpen(false);
    } finally {
      setCancelling(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Segmented Tabs (All | Leave | Correction) matching 13_My_Requests_Tracking.png */}
      <div
        role="tablist"
        aria-label="Filter request type"
        className="grid grid-cols-3 rounded-2xl bg-[#EEF3F0] p-1 border border-[#E0EBE4]"
      >
        {(
          [
            { id: 'all', label: 'All' },
            { id: 'leave', label: 'Leave' },
            { id: 'correction', label: 'Correction' },
          ] as const
        ).map((tab) => {
          const active = typeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setTypeTab(tab.id)}
              className={`min-h-[42px] rounded-xl text-[13.5px] font-bold transition cursor-pointer ${
                active
                  ? 'bg-white text-[#065A32] shadow-sm ring-1 ring-[#065A32]/15 border-b-2 border-[#065A32]'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Quick Request Action Buttons */}
      <div className="grid grid-cols-2 gap-2.5">
        <button
          type="button"
          onClick={onOpenLeaveForm}
          className="min-h-[46px] inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-b from-[#0A7742] to-[#054A29] px-3 text-[13px] font-bold text-white shadow-sm hover:from-[#0C884C] hover:to-[#075B33] cursor-pointer"
        >
          <Plus className="h-4 w-4 shrink-0" />
          <span className="truncate">Leave Request</span>
        </button>
        <button
          type="button"
          onClick={onOpenCorrectionForm}
          className="min-h-[46px] inline-flex items-center justify-center gap-2 rounded-xl border border-[#08693B] bg-white px-3 text-[13px] font-bold text-[#065A32] hover:bg-[#F2FAF5] cursor-pointer"
        >
          <ClipboardEdit className="h-4 w-4 shrink-0" />
          <span className="truncate">Correction</span>
        </button>
      </div>

      {/* Status Filter Strip + Refresh */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1.5">
          {(['All', 'Pending', 'Approved', 'Rejected', 'Cancelled'] as const).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`min-h-[34px] rounded-lg px-3 text-xs font-bold transition cursor-pointer ${
                statusFilter === st
                  ? 'bg-[#065A32] text-white'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
        <button
          type="button"
          onClick={onRefresh}
          aria-label="Refresh requests"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white text-[#065A32] hover:bg-[#F2FAF5] cursor-pointer"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {error && <ErrorState message={error} onRetry={onRefresh} />}
      {cancelError && <ErrorState message={cancelError} onDismiss={() => setCancelError(null)} />}

      {/* Requests List */}
      {loading && unified.length === 0 ? (
        <LoadingState label="Loading your requests..." />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={ClipboardList}
          title="No Requests Yet"
          description={
            statusFilter === 'All' && typeTab === 'all'
              ? 'You have not submitted any leave or attendance correction requests yet.'
              : 'No requests match your selected filter.'
          }
          action={
            <button
              type="button"
              onClick={typeTab === 'correction' ? onOpenCorrectionForm : onOpenLeaveForm}
              className="min-h-[42px] rounded-xl bg-[#065A32] px-4 text-xs font-bold text-white hover:bg-[#086E3E] cursor-pointer"
            >
              {typeTab === 'correction' ? 'Submit Correction Request' : 'Submit Leave Request'}
            </button>
          }
        />
      ) : (
        <div className="space-y-3">
          {filtered.map((item) => (
            <RequestCard
              key={item.key}
              kind={item.kind}
              referenceNo={item.referenceNo}
              subtitle={item.subtitle}
              startDate={item.startDate}
              endDate={item.endDate}
              status={item.status}
              highlighted={highlightedRefKey === item.key}
              onClick={() => {
                setCancelError(null);
                setSelectedItem(item);
              }}
            />
          ))}
        </div>
      )}

      {/* Request Detail Modal */}
      {selectedItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-4 backdrop-blur-[2px]"
          role="dialog"
          aria-modal="true"
          aria-labelledby="emp-req-detail-title"
        >
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between gap-2 bg-[#054728] px-5 py-4 text-white">
              <div className="min-w-0">
                <h2 id="emp-req-detail-title" className="font-display text-base font-bold truncate">
                  {selectedItem.kind === 'leave' ? 'Leave Request Details' : 'Attendance Correction Details'}
                </h2>
                <p className="text-xs text-emerald-100 font-mono-num">{selectedItem.referenceNo}</p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedItem(null)}
                aria-label="Close request details"
                className="flex h-9 w-9 items-center justify-center rounded-xl text-white hover:bg-white/15 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="p-5 space-y-3.5 text-sm">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-500">Status</span>
                <StatusBadge status={selectedItem.status} />
              </div>

              {selectedItem.kind === 'leave' ? (
                <>
                  <div className="grid grid-cols-2 gap-3 rounded-xl bg-[#F8FBF9] border border-[#E5EFEA] p-3 text-xs">
                    <div>
                      <div className="text-slate-500">Leave Type</div>
                      <div className="font-bold text-slate-900 mt-0.5">{selectedItem.raw.leave_type}</div>
                    </div>
                    <div>
                      <div className="text-slate-500">Duration</div>
                      <div className="font-bold text-slate-900 mt-0.5">
                        {selectedItem.raw.days_count} day(s)
                      </div>
                    </div>
                    <div className="col-span-2">
                      <div className="text-slate-500">Inclusive Dates</div>
                      <div className="font-bold text-slate-900 mt-0.5">
                        {formatDateRange(selectedItem.raw.start_date, selectedItem.raw.end_date)}
                      </div>
                    </div>
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-700 mb-1">Reason</div>
                    <p className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">
                      {selectedItem.raw.reason}
                    </p>
                  </div>
                  {selectedItem.raw.attachment_name && (
                    <div className="flex items-center gap-2 text-xs text-[#065A32] font-semibold">
                      <Paperclip className="h-3.5 w-3.5" />
                      <span className="truncate">{selectedItem.raw.attachment_name}</span>
                    </div>
                  )}
                  {selectedItem.raw.reviewer_notes && (
                    <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
                      <div className="font-bold">Reviewer Notes ({selectedItem.raw.reviewed_by || 'HR'})</div>
                      <p className="mt-1">{selectedItem.raw.reviewer_notes}</p>
                    </div>
                  )}
                </>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-3 rounded-xl bg-[#F8FBF9] border border-[#E5EFEA] p-3 text-xs">
                    <div>
                      <div className="text-slate-500">Attendance Date</div>
                      <div className="font-bold text-slate-900 mt-0.5">
                        {formatShortDate(selectedItem.raw.attendance_date)}
                      </div>
                    </div>
                    <div>
                      <div className="text-slate-500">Correction Type</div>
                      <div className="font-bold text-slate-900 mt-0.5">{selectedItem.raw.request_type}</div>
                    </div>
                    <div className="col-span-2">
                      <div className="text-slate-500">Requested Time</div>
                      <div className="font-bold text-slate-900 font-mono-num mt-0.5">
                        {selectedItem.raw.request_type === 'Full Day'
                          ? `${formatTime12h(selectedItem.raw.requested_time)} – ${formatTime12h(selectedItem.raw.requested_time_out)}`
                          : formatTime12h(selectedItem.raw.requested_time)}
                      </div>
                    </div>
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-700 mb-1">Reason</div>
                    <p className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">
                      {selectedItem.raw.reason}
                    </p>
                  </div>
                  {selectedItem.raw.attachment_name && (
                    <div className="flex items-center gap-2 text-xs text-[#065A32] font-semibold">
                      <Paperclip className="h-3.5 w-3.5" />
                      <span className="truncate">{selectedItem.raw.attachment_name}</span>
                    </div>
                  )}
                  {selectedItem.raw.reviewer_notes && (
                    <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
                      <div className="font-bold">Reviewer Notes ({selectedItem.raw.reviewed_by || 'HR'})</div>
                      <p className="mt-1">{selectedItem.raw.reviewer_notes}</p>
                    </div>
                  )}
                </>
              )}

              <div className="pt-2 flex items-center justify-end gap-2">
                {selectedItem.kind === 'leave' && selectedItem.status === 'Pending' && (
                  <button
                    type="button"
                    onClick={() => setCancelConfirmOpen(true)}
                    className="min-h-[42px] inline-flex items-center gap-1.5 rounded-xl border border-red-200 bg-red-50 px-3.5 text-xs font-bold text-red-700 hover:bg-red-100 cursor-pointer"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>Cancel Request</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setSelectedItem(null)}
                  className="min-h-[42px] rounded-xl bg-[#065A32] px-5 text-xs font-bold text-white hover:bg-[#086E3E] cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <ConfirmationDialog
        open={cancelConfirmOpen}
        title="Cancel Leave Request?"
        message="This will withdraw your pending leave request. You can submit a new request later if needed."
        confirmLabel="Yes, Cancel Request"
        cancelLabel="Keep Request"
        destructive
        loading={cancelling}
        onConfirm={handleConfirmCancelLeave}
        onCancel={() => setCancelConfirmOpen(false)}
      />
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Screen 10: Leave Request Form (Matches 10_Leave_Request_Form.png)          */
/* -------------------------------------------------------------------------- */
function getDefaultLeaveWeekdayIso(): string {
  const todayIso = getManilaTodayIso();
  const [y, m, d] = todayIso.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
  const dow = dt.getUTCDay();
  if (dow === 6) dt.setUTCDate(dt.getUTCDate() + 2); // Sat -> Mon
  else if (dow === 0) dt.setUTCDate(dt.getUTCDate() + 1); // Sun -> Mon
  return dt.toISOString().slice(0, 10);
}

function countWeekdaysInclusive(startIso: string, endIso: string): number {
  if (!startIso || !endIso || endIso < startIso) return 0;
  const [sy, sm, sd] = startIso.split('-').map(Number);
  const [ey, em, ed] = endIso.split('-').map(Number);
  const cur = new Date(Date.UTC(sy, sm - 1, sd, 12, 0, 0));
  const end = new Date(Date.UTC(ey, em - 1, ed, 12, 0, 0));
  let count = 0;
  let guard = 0;
  while (cur <= end && guard < 366) {
    const dow = cur.getUTCDay();
    if (dow !== 0 && dow !== 6) count += 1;
    cur.setUTCDate(cur.getUTCDate() + 1);
    guard += 1;
  }
  return count;
}

export const LeaveRequestFormScreen: React.FC<{
  policies: LeavePolicy[];
  onSubmitted: (payload: RequestSuccessPayload) => void;
}> = ({ policies, onSubmitted }) => {
  const defaultDate = useMemo(() => getDefaultLeaveWeekdayIso(), []);
  const activePolicies = useMemo(
    () => policies.filter((p) => p.is_active === 1),
    [policies]
  );

  const defaultLeaveType =
    activePolicies[0]?.leave_type || 'Vacation Leave';

  const [leaveType, setLeaveType] = useState(defaultLeaveType);
  const [startDate, setStartDate] = useState(defaultDate);
  const [endDate, setEndDate] = useState(defaultDate);
  const [dayPortion, setDayPortion] = useState<LeaveDayPortion>('FULL');
  const [reason, setReason] = useState('');
  const [attachment, setAttachment] = useState<AttachmentPayload | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const selectedPolicy = activePolicies.find((p) => p.leave_type === leaveType);
  const canHalfDay =
    selectedPolicy?.allow_half_day === 1 && startDate === endDate;
  const estimatedWorkdays = useMemo(() => {
    const base = countWeekdaysInclusive(startDate, endDate);
    if (canHalfDay && dayPortion !== 'FULL' && base > 0) return 0.5;
    return base;
  }, [startDate, endDate, canHalfDay, dayPortion]);
  const docThreshold = selectedPolicy?.requires_document_after_days ?? 0;
  const isAttachmentRequired = docThreshold > 0 && estimatedWorkdays >= docThreshold;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    try {
      const encoded = await readFileAsBase64(file);
      setAttachment(encoded);
    } catch (err) {
      setError(extractErrorMessage(err));
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!leaveType) {
      setError('Please select a leave type.');
      return;
    }
    if (!startDate || !endDate) {
      setError('Please select both Date From and Date To.');
      return;
    }
    if (endDate < startDate) {
      setError('Date To cannot be earlier than Date From.');
      return;
    }
    if (reason.trim().length < 5) {
      setError('Please provide a clear reason (at least 5 characters).');
      return;
    }
    if (isAttachmentRequired && !attachment) {
      setError(
        `${leaveType} of ${estimatedWorkdays} day(s) requires a supporting document (policy threshold: ${docThreshold} day(s)).`
      );
      return;
    }

    setSubmitting(true);
    try {
      const created = await apiFetch<{ id: number; status: string; days_count?: number }>(
        '/api/leaves',
        {
          method: 'POST',
          body: JSON.stringify({
            leave_type: leaveType,
            start_date: startDate,
            end_date: endDate,
            day_portion: canHalfDay ? dayPortion : 'FULL',
            reason: reason.trim(),
            ...(attachment
              ? {
                  attachment_name: attachment.name,
                  attachment_mime: attachment.mime,
                  attachment_data: attachment.data,
                }
              : {}),
          }),
        }
      );

      // Only transition to Screen 11 after confirmed backend creation with real ID
      onSubmitted({
        kind: 'leave',
        id: created.id,
        referenceNo: formatLeaveReference(created.id, startDate),
        subtitle: `${leaveType} · ${formatDateRange(startDate, endDate)}`,
      });
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-xl mx-auto">
      {error && <ErrorState message={error} onDismiss={() => setError(null)} />}

      <FormField id="leave-type" label="Leave Type" required>
        <select
          id="leave-type"
          value={leaveType}
          onChange={(e) => setLeaveType(e.target.value)}
          className={EMPLOYEE_INPUT_CLASS}
        >
          {activePolicies.length > 0 ? (
            activePolicies.map((p) => (
              <option key={p.id} value={p.leave_type}>
                {p.leave_type}
              </option>
            ))
          ) : (
            <>
              <option value="Vacation Leave">Vacation Leave</option>
              <option value="Sick Leave">Sick Leave</option>
              <option value="Emergency Leave">Emergency Leave</option>
              <option value="Official Business">Official Business</option>
            </>
          )}
        </select>
      </FormField>

      <FormField id="leave-start" label="Date From" required>
        <div className="relative">
          <CalendarDays className="h-4 w-4 text-[#08693B] pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="leave-start"
            type="date"
            required
            value={startDate}
            onChange={(e) => {
              const next = e.target.value;
              setStartDate(next);
              if (endDate < next) setEndDate(next);
            }}
            className={`${EMPLOYEE_INPUT_CLASS} pl-10`}
          />
        </div>
      </FormField>

      <FormField id="leave-end" label="Date To" required>
        <div className="relative">
          <CalendarDays className="h-4 w-4 text-[#08693B] pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="leave-end"
            type="date"
            required
            min={startDate}
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className={`${EMPLOYEE_INPUT_CLASS} pl-10`}
          />
        </div>
      </FormField>

      {canHalfDay && (
        <FormField id="leave-portion" label="Day Portion">
          <select
            id="leave-portion"
            value={dayPortion}
            onChange={(e) => setDayPortion(e.target.value as LeaveDayPortion)}
            className={EMPLOYEE_INPUT_CLASS}
          >
            <option value="FULL">Full Day (1.0 day)</option>
            <option value="HALF_AM">Half Day – Morning (0.5 day)</option>
            <option value="HALF_PM">Half Day – Afternoon (0.5 day)</option>
          </select>
        </FormField>
      )}

      <FormField id="leave-reason" label="Reason" required>
        <textarea
          id="leave-reason"
          required
          rows={4}
          maxLength={2000}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Describe the reason for your leave request..."
          className={`${EMPLOYEE_INPUT_CLASS} min-h-[110px] resize-y`}
        />
        <div className="mt-1 text-right text-[11.5px] font-medium text-slate-500 font-mono-num">
          {reason.length}/2000
        </div>
      </FormField>

      <FormField
        id="leave-attachment"
        label={isAttachmentRequired ? 'Supporting Document' : 'Attachment (Optional)'}
        required={isAttachmentRequired}
        hint={
          isAttachmentRequired
            ? `Required by campus HR policy for ${leaveType} (${docThreshold}+ day(s)). PDF, JPG, or PNG up to 2 MB.`
            : 'PDF, JPG, or PNG up to 2 MB'
        }
      >
        <input
          ref={fileInputRef}
          id="leave-attachment"
          type="file"
          accept=".pdf,image/png,image/jpeg,image/webp"
          onChange={handleFileChange}
          className="sr-only"
        />
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className={`${EMPLOYEE_INPUT_CLASS} flex items-center justify-between gap-2 text-left cursor-pointer hover:border-[#08693B]/60`}
          >
            <span className="flex items-center gap-2.5 min-w-0">
              <Paperclip className="h-4 w-4 text-[#08693B] shrink-0" />
              <span className="truncate font-semibold text-slate-700">
                {attachment ? attachment.name : 'Choose File'}
              </span>
            </span>
            <span className="text-xs font-bold text-[#08693B] shrink-0">
              {attachment ? 'Change' : 'Browse'}
            </span>
          </button>
          {attachment && (
            <button
              type="button"
              onClick={() => {
                setAttachment(null);
                if (fileInputRef.current) fileInputRef.current.value = '';
              }}
              aria-label="Remove attachment"
              className="flex h-[46px] w-[46px] shrink-0 items-center justify-center rounded-xl border border-red-200 bg-red-50 text-red-600 hover:bg-red-100 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </FormField>

      <div className="pt-2">
        <button type="submit" disabled={submitting} className={EMPLOYEE_PRIMARY_BTN_CLASS}>
          {submitting ? 'Submitting Request...' : 'Submit Request'}
        </button>
      </div>
    </form>
  );
};

/* -------------------------------------------------------------------------- */
/* Screen 12: Attendance Correction Form (Matches 12_Attendance_Correction_Form.png) */
/* -------------------------------------------------------------------------- */
export const AttendanceCorrectionFormScreen: React.FC<{
  onSubmitted: (payload: RequestSuccessPayload) => void;
}> = ({ onSubmitted }) => {
  const today = getManilaTodayIso();
  const [attendanceDate, setAttendanceDate] = useState(today);
  const [requestType, setRequestType] = useState<'Time Out' | 'Time In' | 'Full Day'>('Time Out');
  const [timeIn, setTimeIn] = useState('08:00');
  const [timeOut, setTimeOut] = useState('17:00');
  const [reason, setReason] = useState('');
  const [attachment, setAttachment] = useState<AttachmentPayload | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    try {
      const encoded = await readFileAsBase64(file);
      setAttachment(encoded);
    } catch (err) {
      setError(extractErrorMessage(err));
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!attendanceDate) {
      setError('Please select the attendance date.');
      return;
    }
    if (requestType === 'Time In' && !timeIn) {
      setError('Please enter the correct Time In.');
      return;
    }
    if (requestType === 'Time Out' && !timeOut) {
      setError('Please enter the correct Time Out.');
      return;
    }
    if (requestType === 'Full Day' && (!timeIn || !timeOut)) {
      setError('Please enter both Time In and Time Out for a Full Day correction.');
      return;
    }
    if (requestType === 'Full Day' && !attachment) {
      setError('Supporting documentation (attachment) is required for Full Day attendance corrections.');
      return;
    }
    if (reason.trim().length < 5) {
      setError('Please provide a reason for this correction (at least 5 characters).');
      return;
    }

    setSubmitting(true);
    try {
      const payload: Record<string, unknown> = {
        attendance_date: attendanceDate,
        request_type: requestType,
        requested_time: requestType === 'Time Out' ? timeOut : timeIn,
        ...(requestType === 'Full Day' ? { requested_time_out: timeOut } : {}),
        reason: reason.trim(),
        ...(attachment
          ? {
              attachment_name: attachment.name,
              attachment_mime: attachment.mime,
              attachment_data: attachment.data,
            }
          : {}),
      };

      const created = await apiFetch<{ id: number; status: string }>('/api/corrections', {
        method: 'POST',
        body: JSON.stringify(payload),
      });

      onSubmitted({
        kind: 'correction',
        id: created.id,
        referenceNo: formatCorrectionReference(created.id, attendanceDate),
        subtitle: `${requestType} · ${formatShortDate(attendanceDate)}`,
      });
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-xl mx-auto">
      <div className="rounded-xl border border-[#DCEAE2] bg-[#F4FAF6] px-3.5 py-2.5 text-xs text-[#065A32]">
        Attendance records are read-only. Submitted corrections require HR/Admin approval before updating your DTR.
      </div>

      {error && <ErrorState message={error} onDismiss={() => setError(null)} />}

      <FormField id="corr-date" label="Date" required>
        <div className="relative">
          <CalendarDays className="h-4 w-4 text-[#08693B] pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="corr-date"
            type="date"
            required
            max={today}
            value={attendanceDate}
            onChange={(e) => setAttendanceDate(e.target.value)}
            className={`${EMPLOYEE_INPUT_CLASS} pl-10`}
          />
        </div>
      </FormField>

      <FormField id="corr-type" label="Correction Type" required>
        <select
          id="corr-type"
          value={requestType}
          onChange={(e) => setRequestType(e.target.value as 'Time Out' | 'Time In' | 'Full Day')}
          className={EMPLOYEE_INPUT_CLASS}
        >
          <option value="Time Out">Missing Time Out</option>
          <option value="Time In">Missing Time In</option>
          <option value="Full Day">Full Day Correction</option>
        </select>
      </FormField>

      {(requestType === 'Time In' || requestType === 'Full Day') && (
        <FormField
          id="corr-time-in"
          label="Correct Time In"
          required
          hint={timeIn ? `12-hour preview: ${formatTime12h(timeIn)}` : undefined}
        >
          <div className="relative">
            <Clock className="h-4 w-4 text-[#08693B] pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="corr-time-in"
              type="time"
              required
              value={timeIn}
              onChange={(e) => setTimeIn(e.target.value)}
              className={`${EMPLOYEE_INPUT_CLASS} pl-10 font-mono-num`}
            />
          </div>
        </FormField>
      )}

      {(requestType === 'Time Out' || requestType === 'Full Day') && (
        <FormField
          id="corr-time-out"
          label="Correct Time Out"
          required
          hint={timeOut ? `12-hour preview: ${formatTime12h(timeOut)}` : undefined}
        >
          <div className="relative">
            <Clock className="h-4 w-4 text-[#08693B] pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="corr-time-out"
              type="time"
              required
              value={timeOut}
              onChange={(e) => setTimeOut(e.target.value)}
              className={`${EMPLOYEE_INPUT_CLASS} pl-10 font-mono-num`}
            />
          </div>
        </FormField>
      )}

      <FormField id="corr-reason" label="Reason" required>
        <textarea
          id="corr-reason"
          required
          rows={4}
          maxLength={2000}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Explain why an attendance correction is needed (e.g., forgot to time out due to official meeting)..."
          className={`${EMPLOYEE_INPUT_CLASS} min-h-[110px] resize-y`}
        />
        <div className="mt-1 text-right text-[11.5px] font-medium text-slate-500 font-mono-num">
          {reason.length}/2000
        </div>
      </FormField>

      <FormField
        id="corr-attachment"
        label={requestType === 'Full Day' ? 'Supporting Document' : 'Attachment (Optional)'}
        required={requestType === 'Full Day'}
        hint={
          requestType === 'Full Day'
            ? 'Required for Full Day corrections (PDF, JPG, or PNG up to 2 MB)'
            : 'Supporting memo or document (up to 2 MB)'
        }
      >
        <input
          ref={fileInputRef}
          id="corr-attachment"
          type="file"
          accept=".pdf,image/png,image/jpeg,image/webp"
          onChange={handleFileChange}
          className="sr-only"
        />
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className={`${EMPLOYEE_INPUT_CLASS} flex items-center justify-between gap-2 text-left cursor-pointer hover:border-[#08693B]/60`}
          >
            <span className="flex items-center gap-2.5 min-w-0">
              <Paperclip className="h-4 w-4 text-[#08693B] shrink-0" />
              <span className="truncate font-semibold text-slate-700">
                {attachment ? attachment.name : 'Choose File'}
              </span>
            </span>
            <span className="text-xs font-bold text-[#08693B] shrink-0">
              {attachment ? 'Change' : 'Browse'}
            </span>
          </button>
          {attachment && (
            <button
              type="button"
              onClick={() => {
                setAttachment(null);
                if (fileInputRef.current) fileInputRef.current.value = '';
              }}
              aria-label="Remove attachment"
              className="flex h-[46px] w-[46px] shrink-0 items-center justify-center rounded-xl border border-red-200 bg-red-50 text-red-600 hover:bg-red-100 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </FormField>

      <div className="pt-2">
        <button type="submit" disabled={submitting} className={EMPLOYEE_PRIMARY_BTN_CLASS}>
          {submitting ? 'Submitting Correction...' : 'Submit Correction'}
        </button>
      </div>
    </form>
  );
};

/* -------------------------------------------------------------------------- */
/* Screen 11: Request Submitted Success (Matches 11_Leave_Request_Success.png) */
/* -------------------------------------------------------------------------- */
export const RequestSuccessScreen: React.FC<{
  payload: RequestSuccessPayload;
  onViewRequest: () => void;
  onBackToRequests: () => void;
}> = ({ payload, onViewRequest, onBackToRequests }) => {
  const isLeave = payload.kind === 'leave';

  return (
    <div className="mx-auto max-w-md flex flex-col items-center text-center py-8 sm:py-12 px-2">
      <div className="flex h-28 w-28 items-center justify-center rounded-full bg-gradient-to-b from-[#11A350] to-[#087E3B] text-white shadow-[0_10px_28px_rgba(13,159,79,0.32)]">
        <Check className="h-14 w-14" strokeWidth={3.2} />
      </div>

      <h1 className="mt-7 font-display text-[26px] font-extrabold text-slate-950">
        Request Submitted!
      </h1>
      <p className="mt-2.5 max-w-[300px] text-[15px] leading-relaxed text-slate-600">
        {isLeave
          ? 'Your leave request has been successfully submitted.'
          : 'Your attendance correction request has been successfully submitted.'}
      </p>

      <div className="mt-6 rounded-2xl border border-[#DCEAE2] bg-[#F7FBF8] px-6 py-4 w-full">
        <div className="text-[13px] font-medium text-slate-500">Reference No.</div>
        <div className="mt-1 font-display text-[22px] font-extrabold tracking-tight text-slate-950 font-mono-num">
          {payload.referenceNo}
        </div>
        {payload.subtitle && (
          <div className="mt-1 text-xs font-medium text-[#065A32]">{payload.subtitle}</div>
        )}
      </div>

      <div className="mt-8 w-full space-y-3">
        <button
          type="button"
          onClick={onViewRequest}
          className="w-full min-h-[48px] rounded-xl border-2 border-[#08693B] bg-white text-[#065A32] font-display text-[15px] font-bold hover:bg-[#F2FAF5] active:scale-[0.99] transition cursor-pointer"
        >
          View Request
        </button>
        <button
          type="button"
          onClick={onBackToRequests}
          className={EMPLOYEE_PRIMARY_BTN_CLASS}
        >
          Back to Requests
        </button>
      </div>
    </div>
  );
};
