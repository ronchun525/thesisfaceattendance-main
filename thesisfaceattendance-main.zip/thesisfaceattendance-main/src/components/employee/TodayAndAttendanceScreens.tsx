import React, { useMemo, useState } from 'react';
import {
  BarChart3,
  CalendarCheck2,
  CalendarDays,
  ChevronRight,
  Clock,
  Download,
  FileText,
  Filter,
  Home,
  Loader2,
  LogIn,
  LogOut,
  Moon,
  RefreshCw,
  ShieldCheck,
  Wifi,
  WifiOff,
  X,
  XCircle,
} from 'lucide-react';
import { apiFetch, downloadAuthenticatedBlob } from '../../lib/api';
import type { RealtimeConnectionStatus } from '../../lib/realtime';
import type { MonthlyDtrEmployeeReport } from '../../types';
import {
  AttendanceCard,
  EmptyState,
  ErrorState,
  LoadingState,
  StatusBadge,
} from './EmployeePrimitives';
import {
  extractErrorMessage,
  formatFullMonthLabel,
  formatMonthLabel,
  formatShortDate,
  formatTime12h,
  type EmployeeMonthRow,
  type EmployeeTodayResponse,
} from './types';

/* -------------------------------------------------------------------------- */
/* Screen 06: Today Dashboard (Matches 06_Today_Dashboard.png)                */
/* STRICTLY READ-ONLY — ZERO manual Time In / Time Out controls               */
/* -------------------------------------------------------------------------- */
export const TodayDashboardScreen: React.FC<{
  todayData: EmployeeTodayResponse | null;
  monthRows: EmployeeMonthRow[];
  currentMonth: string;
  loading: boolean;
  error: string | null;
  realtimeStatus: RealtimeConnectionStatus;
  onRefresh: () => void;
  onOpenAttendance: () => void;
  onOpenCorrectionForm: () => void;
}> = ({
  todayData,
  monthRows,
  currentMonth,
  loading,
  error,
  realtimeStatus,
  onRefresh,
  onOpenAttendance,
  onOpenCorrectionForm,
}) => {
  const attendance = todayData?.attendance || null;
  const todayStatus = attendance?.status || 'Not Recorded';
  const timeInDisplay = attendance?.time_in ? formatTime12h(attendance.time_in) : '—';
  const timeOutDisplay = attendance?.time_out ? formatTime12h(attendance.time_out) : '—';

  const monthlySummary = useMemo(() => {
    let daysPresent = 0;
    let daysAbsent = 0;
    let totalRecords = 0;

    for (const row of monthRows) {
      if (row.status === 'Rest Day' || row.status === 'No Schedule') continue;
      totalRecords += 1;
      if (
        ['Present', 'Late', 'Undertime', 'OB', 'Missing Time Out', 'Missing Time In'].includes(
          row.status
        )
      ) {
        daysPresent += 1;
      } else if (row.status === 'Absent') {
        daysAbsent += 1;
      }
    }
    return { daysPresent, daysAbsent, totalRecords };
  }, [monthRows]);

  const syncDisplay = useMemo(() => {
    switch (realtimeStatus) {
      case 'live':
        return {
          label: 'Live Sync: Connected',
          dotClass: 'bg-[#16A34A]',
          textClass: 'text-[#065F33]',
          icon: Wifi,
        };
      case 'polling':
        return {
          label: 'Live Sync: Polling Fallback',
          dotClass: 'bg-amber-500',
          textClass: 'text-amber-800',
          icon: WifiOff,
        };
      case 'reconnecting':
        return {
          label: 'Live Sync: Reconnecting...',
          dotClass: 'bg-amber-500 animate-pulse',
          textClass: 'text-amber-800',
          icon: Wifi,
        };
      default:
        return {
          label: 'Live Sync: Connecting...',
          dotClass: 'bg-emerald-500 animate-pulse',
          textClass: 'text-[#065F33]',
          icon: Wifi,
        };
    }
  }, [realtimeStatus]);

  return (
    <div className="space-y-4">
      {/* Page Heading matching 06_Today_Dashboard.png */}
      <div className="flex items-start justify-between gap-3 pt-1">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#065A32] text-white shadow-sm">
            <Home className="h-5 w-5" strokeWidth={2.2} />
          </div>
          <div className="min-w-0">
            <h1 className="font-display text-[21px] sm:text-[23px] font-extrabold text-slate-950 leading-tight truncate">
              Employee Dashboard
            </h1>
            <p className="text-[13px] text-slate-600 mt-0.5 truncate">
              Your attendance and quick overview
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={onRefresh}
          aria-label="Refresh today attendance"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#DCEAE2] bg-white text-[#065A32] hover:bg-[#F2FAF5] active:scale-95 transition cursor-pointer"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {error && <ErrorState message={error} onRetry={onRefresh} />}

      {loading && !todayData ? (
        <LoadingState label="Syncing today's attendance..." />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Today Attendance Card (READ-ONLY) */}
          <section
            aria-label="Today Attendance"
            className="rounded-2xl border border-[#E2ECE6] bg-white p-5 shadow-[0_3px_14px_rgba(5,71,40,0.06)] flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2 pb-3.5 border-b border-slate-100">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
                    <CalendarDays className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <h2 className="font-display text-[17px] font-bold text-slate-950 leading-tight">
                      Today Attendance
                    </h2>
                    {todayData?.date && (
                      <p className="text-[11.5px] text-slate-500">
                        {formatShortDate(todayData.date)}
                        {todayData.employee?.shift_name ? ` · ${todayData.employee.shift_name}` : ''}
                      </p>
                    )}
                  </div>
                </div>
                <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-1 text-[10.5px] font-semibold text-slate-600 shrink-0">
                  <ShieldCheck className="h-3 w-3 text-[#08693B]" />
                  Read-Only
                </span>
              </div>

              {todayData?.active_prior_shift && (
                <div className="mt-3 flex items-center gap-2 rounded-xl border border-indigo-200 bg-indigo-50 px-3 py-2 text-xs text-indigo-900">
                  <Moon className="h-4 w-4 shrink-0 text-indigo-600" />
                  <span>
                    Showing active overnight shift from{' '}
                    <strong>{formatShortDate(todayData.date)}</strong>.
                  </span>
                </div>
              )}

              {/* Centered Status Pill matching 06_Today_Dashboard.png */}
              <div className="mt-4 mb-4 flex justify-center">
                <StatusBadge
                  status={todayStatus}
                  size="md"
                  showClockIcon={todayStatus === 'Not Recorded'}
                />
              </div>

              {/* Side-by-side Time In & Time Out Boxes (Strictly Display Only) matching 06_Today_Dashboard.png */}
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl border border-[#E5EFEA] bg-[#F8FBF9] p-3.5 flex flex-col items-center text-center">
                  <LogIn className="h-5 w-5 text-[#08693B]" strokeWidth={2.1} />
                  <span className="mt-1.5 text-[12px] font-semibold text-slate-600">
                    Time In
                  </span>
                  <div className="mt-1 font-display text-[19px] font-extrabold text-slate-950 font-mono-num">
                    {timeInDisplay}
                  </div>
                </div>

                <div className="rounded-xl border border-[#E5EFEA] bg-[#F8FBF9] p-3.5 flex flex-col items-center text-center">
                  <LogOut className="h-5 w-5 text-[#08693B]" strokeWidth={2.1} />
                  <span className="mt-1.5 text-[12px] font-semibold text-slate-600">
                    Time Out
                  </span>
                  <div className="mt-1 font-display text-[19px] font-extrabold text-slate-950 font-mono-num">
                    {timeOutDisplay}
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2 text-[11.5px] text-slate-500">
              <span>Recorded via Campus Face Recognition Kiosk</span>
              <button
                type="button"
                onClick={onOpenCorrectionForm}
                className="font-bold text-[#08693B] hover:underline shrink-0 cursor-pointer"
              >
                Need correction?
              </button>
            </div>
          </section>

          {/* My Attendance (This Month) Summary Card matching 06_Today_Dashboard.png */}
          <section
            aria-label="My Attendance This Month"
            className="rounded-2xl border border-[#E2ECE6] bg-white p-5 shadow-[0_3px_14px_rgba(5,71,40,0.06)] flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2 pb-3.5 border-b border-slate-100">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
                    <BarChart3 className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <h2 className="font-display text-[17px] font-bold text-slate-950 leading-tight">
                      My Attendance
                    </h2>
                    <p className="text-[12px] font-medium text-slate-500">
                      This Month ({formatMonthLabel(currentMonth)})
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onOpenAttendance}
                  className="inline-flex items-center gap-0.5 text-xs font-bold text-[#08693B] hover:underline shrink-0 cursor-pointer"
                >
                  <span>View All</span>
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>

              <div className="divide-y divide-slate-100 mt-1">
                <div className="flex items-center justify-between py-3.5">
                  <span className="inline-flex items-center gap-2.5 text-[14px] font-medium text-slate-700">
                    <CalendarCheck2 className="h-4 w-4 text-[#08693B] shrink-0" />
                    <span>Days Present</span>
                  </span>
                  <span className="font-display text-[17px] font-extrabold text-[#066035] font-mono-num">
                    {monthlySummary.daysPresent}
                  </span>
                </div>
                <div className="flex items-center justify-between py-3.5">
                  <span className="inline-flex items-center gap-2.5 text-[14px] font-medium text-slate-700">
                    <XCircle className="h-4 w-4 text-red-600 shrink-0" />
                    <span>Days Absent</span>
                  </span>
                  <span className="font-display text-[17px] font-extrabold text-red-600 font-mono-num">
                    {monthlySummary.daysAbsent}
                  </span>
                </div>
                <div className="flex items-center justify-between py-3.5">
                  <span className="inline-flex items-center gap-2.5 text-[14px] font-medium text-slate-700">
                    <CalendarDays className="h-4 w-4 text-[#08693B] shrink-0" />
                    <span>Total Records</span>
                  </span>
                  <span className="font-display text-[17px] font-extrabold text-slate-900 font-mono-num">
                    {monthlySummary.totalRecords}
                  </span>
                </div>
              </div>
            </div>

            {todayData?.events && todayData.events.length > 0 && (
              <div className="mt-3 pt-3 border-t border-slate-100">
                <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Today&apos;s Kiosk Events
                </div>
                <div className="space-y-1.5">
                  {todayData.events.slice(0, 3).map((ev) => (
                    <div
                      key={ev.id}
                      className="flex items-center justify-between text-xs text-slate-700 bg-[#F8FBF9] rounded-lg px-2.5 py-1.5"
                    >
                      <span className="font-semibold flex items-center gap-1.5">
                        <Clock className="h-3.5 w-3.5 text-[#08693B]" />
                        {ev.punch_type.replace(/_/g, ' ')}
                      </span>
                      <span className="font-mono-num text-slate-600">
                        {formatTime12h(ev.punch_time)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </section>
        </div>
      )}

      {/* Live Sync Status Strip matching 06_Today_Dashboard.png */}
      <div className="flex items-center justify-between gap-2 rounded-2xl border border-[#DCEAE2] bg-white px-4 py-3 shadow-[0_2px_8px_rgba(5,71,40,0.04)]">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className={`h-2.5 w-2.5 rounded-full shrink-0 ${syncDisplay.dotClass}`} />
          <span className={`text-[13px] font-bold truncate ${syncDisplay.textClass}`}>
            {syncDisplay.label}
          </span>
        </div>
        <span className="text-[11px] text-slate-500 font-mono-num shrink-0">
          {todayData?.timezone || 'Asia/Manila'}
        </span>
      </div>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Screen 07: Attendance Records (Matches 07_Attendance_Records.png)          */
/* -------------------------------------------------------------------------- */
const STATUS_FILTER_OPTIONS = [
  'All Records',
  'Present',
  'Late',
  'Absent',
  'On Leave',
  'Undertime',
  'Missing Time Out',
  'Missing Time In',
  'Holiday',
  'Rest Day',
] as const;

export const AttendanceRecordsScreen: React.FC<{
  month: string;
  onChangeMonth: (nextMonth: string) => void;
  rows: EmployeeMonthRow[];
  loading: boolean;
  error: string | null;
  onRefresh: () => void;
}> = ({ month, onChangeMonth, rows, loading, error, onRefresh }) => {
  const [statusFilter, setStatusFilter] = useState<string>('All Records');
  const [dtrOpen, setDtrOpen] = useState(false);
  const [dtrLoading, setDtrLoading] = useState(false);
  const [dtrError, setDtrError] = useState<string | null>(null);
  const [dtrReport, setDtrReport] = useState<MonthlyDtrEmployeeReport | null>(null);
  const [downloadingDtr, setDownloadingDtr] = useState(false);
  const [downloadErr, setDownloadErr] = useState<string | null>(null);

  const filteredRows = useMemo(() => {
    const sorted = [...rows].sort((a, b) => b.date.localeCompare(a.date));
    if (statusFilter === 'All Records') return sorted;
    return sorted.filter((r) => r.status === statusFilter);
  }, [rows, statusFilter]);

  const handleOpenDtr = async () => {
    setDtrOpen(true);
    setDtrLoading(true);
    setDtrError(null);
    try {
      const res = await apiFetch<{ report: MonthlyDtrEmployeeReport }>(
        `/api/reports/my-dtr?month=${encodeURIComponent(month)}`
      );
      setDtrReport(res.report);
    } catch (err) {
      setDtrError(extractErrorMessage(err));
      setDtrReport(null);
    } finally {
      setDtrLoading(false);
    }
  };

  const handleDownloadDtrPdf = async () => {
    setDownloadingDtr(true);
    setDownloadErr(null);
    try {
      await downloadAuthenticatedBlob(
        `/api/reports/my-dtr/export.pdf?month=${encodeURIComponent(month)}`,
        `DTR-${month}.pdf`
      );
    } catch (err) {
      setDownloadErr(extractErrorMessage(err));
    } finally {
      setDownloadingDtr(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header matching 07_Attendance_Records.png */}
      <div className="flex flex-wrap items-start justify-between gap-3 pt-1">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#ECFDF5] text-[#08693B]">
            <CalendarDays className="h-6 w-6" />
          </div>
          <div>
            <h1 className="font-display text-[21px] font-extrabold text-slate-950 leading-tight">
              My Attendance
            </h1>
            <p className="text-[13px] text-slate-600">
              View your daily attendance records
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleOpenDtr}
            className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl border border-[#CFE4D8] bg-white px-3 text-xs font-bold text-[#065A32] hover:bg-[#F2FAF5] cursor-pointer"
          >
            <FileText className="h-4 w-4" />
            <span>Monthly DTR</span>
          </button>
          <button
            type="button"
            disabled={downloadingDtr}
            onClick={handleDownloadDtrPdf}
            className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl bg-[#065A32] px-3 text-xs font-bold text-white hover:bg-[#086E3E] disabled:opacity-60 cursor-pointer"
          >
            {downloadingDtr ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Download className="h-4 w-4" />
            )}
            <span>DTR PDF</span>
          </button>
        </div>
      </div>

      {/* Month Selector & Filter Dropdown Row matching 07_Attendance_Records.png */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        <label className="flex items-center gap-2 rounded-xl border border-[#DCEAE2] bg-white px-3.5 min-h-[46px] shadow-[0_1px_3px_rgba(0,0,0,0.03)]">
          <CalendarDays className="h-4 w-4 text-[#08693B] shrink-0" />
          <span className="sr-only">Select Month</span>
          <input
            type="month"
            aria-label="Select attendance month"
            value={month}
            onChange={(e) => e.target.value && onChangeMonth(e.target.value)}
            className="w-full bg-transparent text-[13.5px] font-semibold text-slate-800 focus:outline-none cursor-pointer"
          />
        </label>

        <label className="flex items-center gap-2 rounded-xl border border-[#DCEAE2] bg-white px-3.5 min-h-[46px] shadow-[0_1px_3px_rgba(0,0,0,0.03)]">
          <Filter className="h-4 w-4 text-[#08693B] shrink-0" />
          <span className="sr-only">Filter by Status</span>
          <select
            aria-label="Filter attendance records"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full bg-transparent text-[13.5px] font-semibold text-slate-800 focus:outline-none cursor-pointer"
          >
            {STATUS_FILTER_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </label>
      </div>

      {downloadErr && (
        <ErrorState message={downloadErr} onDismiss={() => setDownloadErr(null)} />
      )}
      {error && <ErrorState message={error} onRetry={onRefresh} />}

      {/* Daily Attendance List */}
      {loading ? (
        <LoadingState label={`Loading ${formatFullMonthLabel(month)} records...`} />
      ) : filteredRows.length === 0 ? (
        <EmptyState
          icon={CalendarDays}
          title="No Attendance Records Found"
          description={
            statusFilter === 'All Records'
              ? `No attendance logs are recorded for ${formatFullMonthLabel(month)}.`
              : `No "${statusFilter}" entries found for ${formatFullMonthLabel(month)}.`
          }
          action={
            statusFilter !== 'All Records' ? (
              <button
                type="button"
                onClick={() => setStatusFilter('All Records')}
                className="min-h-[40px] rounded-xl bg-[#065A32] px-4 text-xs font-bold text-white hover:bg-[#086E3E] cursor-pointer"
              >
                Show All Records
              </button>
            ) : undefined
          }
        />
      ) : (
        <div className="space-y-2.5">
          {filteredRows.map((row) => (
            <AttendanceCard
              key={row.date}
              date={row.date}
              status={row.status}
              timeIn={row.time_in}
              timeOut={row.time_out}
              workHours={row.work_hours}
              lateMinutes={row.late_minutes}
              undertimeMinutes={row.undertime_minutes}
            />
          ))}
        </div>
      )}

      {/* Monthly DTR Modal */}
      {dtrOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-3 sm:p-5 backdrop-blur-[2px]"
          role="dialog"
          aria-modal="true"
          aria-labelledby="emp-dtr-modal-title"
        >
          <div className="w-full max-w-2xl max-h-[88dvh] flex flex-col rounded-2xl border border-slate-200 bg-white shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between gap-3 bg-[#054728] px-5 py-4 text-white">
              <div className="min-w-0">
                <h2 id="emp-dtr-modal-title" className="font-display text-base font-bold truncate">
                  Monthly Daily Time Record (DTR)
                </h2>
                <p className="text-xs text-emerald-100">{formatFullMonthLabel(month)}</p>
              </div>
              <button
                type="button"
                onClick={() => setDtrOpen(false)}
                aria-label="Close DTR preview"
                className="flex h-9 w-9 items-center justify-center rounded-xl text-white hover:bg-white/15 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
              {dtrLoading ? (
                <LoadingState label="Generating Monthly DTR..." />
              ) : dtrError ? (
                <ErrorState message={dtrError} onRetry={handleOpenDtr} />
              ) : dtrReport ? (
                <>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
                    <div className="rounded-xl border border-[#E2ECE6] bg-[#F8FBF9] p-3">
                      <div className="text-[11px] font-semibold text-slate-500">Present</div>
                      <div className="font-display text-lg font-extrabold text-[#066035] font-mono-num">
                        {dtrReport.totals.days_present}
                      </div>
                    </div>
                    <div className="rounded-xl border border-[#E2ECE6] bg-[#F8FBF9] p-3">
                      <div className="text-[11px] font-semibold text-slate-500">Late</div>
                      <div className="font-display text-lg font-extrabold text-amber-700 font-mono-num">
                        {dtrReport.totals.days_late}
                      </div>
                    </div>
                    <div className="rounded-xl border border-[#E2ECE6] bg-[#F8FBF9] p-3">
                      <div className="text-[11px] font-semibold text-slate-500">Absent</div>
                      <div className="font-display text-lg font-extrabold text-red-600 font-mono-num">
                        {dtrReport.totals.days_absent}
                      </div>
                    </div>
                    <div className="rounded-xl border border-[#E2ECE6] bg-[#F8FBF9] p-3">
                      <div className="text-[11px] font-semibold text-slate-500">Worked</div>
                      <div className="font-display text-base font-extrabold text-slate-900 font-mono-num">
                        {dtrReport.totals.total_worked_hours_formatted}
                      </div>
                    </div>
                  </div>

                  <div className="overflow-x-auto rounded-xl border border-slate-200">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                        <tr>
                          <th className="px-3 py-2">Day</th>
                          <th className="px-3 py-2">Time In</th>
                          <th className="px-3 py-2">Time Out</th>
                          <th className="px-3 py-2">Hours</th>
                          <th className="px-3 py-2">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {dtrReport.rows.map((r) => (
                          <tr key={r.date} className="hover:bg-slate-50/80">
                            <td className="px-3 py-2 font-mono-num font-semibold text-slate-800 whitespace-nowrap">
                              {String(r.day).padStart(2, '0')} ({r.day_code})
                            </td>
                            <td className="px-3 py-2 font-mono-num text-slate-700">
                              {formatTime12h(r.time_in)}
                            </td>
                            <td className="px-3 py-2 font-mono-num text-slate-700">
                              {formatTime12h(r.time_out)}
                            </td>
                            <td className="px-3 py-2 font-mono-num text-slate-600">
                              {r.work_hours || '—'}
                            </td>
                            <td className="px-3 py-2">
                              <StatusBadge status={r.status} />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              ) : null}
            </div>

            <div className="flex items-center justify-end gap-2.5 border-t border-slate-200 bg-slate-50 px-5 py-3.5">
              <button
                type="button"
                onClick={() => setDtrOpen(false)}
                className="min-h-[40px] rounded-xl border border-slate-200 bg-white px-4 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                disabled={downloadingDtr}
                onClick={handleDownloadDtrPdf}
                className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl bg-[#065A32] px-4 text-xs font-bold text-white hover:bg-[#086E3E] disabled:opacity-60 cursor-pointer"
              >
                {downloadingDtr ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Download className="h-4 w-4" />
                )}
                <span>Download Official DTR PDF</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
