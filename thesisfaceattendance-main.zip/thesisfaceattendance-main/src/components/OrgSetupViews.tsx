import React, { useEffect, useState, useCallback } from 'react';
import {
  Clock,
  Building2,
  Briefcase,
  CalendarHeart,
  Plus,
  Pencil,
  Trash2,
  Search,
  AlertCircle,
} from 'lucide-react';
import { ModuleFrame, Modal, ConfirmModal, StatusLabel } from './ModuleFrame';
import { apiFetch, formatDisplayDate, formatPeso } from '../lib/api';
import type { AuthUser, Department, Holiday, Position, Shift } from '../types';

// ============================================================================
// SCREEN 10 — SHIFTS & SCHEDULES (10_Shifts_and_Schedules.png)
// ============================================================================
export const ShiftsView: React.FC<{ currentUser?: AuthUser }> = ({ currentUser }) => {
  const canWriteOrg = !currentUser || currentUser.permissions?.includes('org:write') === true;
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Shift | null>(null);
  const [deleting, setDeleting] = useState<Shift | null>(null);
  const [form, setForm] = useState({
    name: '',
    time_in: '08:00 AM',
    time_out: '05:00 PM',
    grace_minutes: '15',
    status: 'Active' as 'Active' | 'Inactive',
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch<{ data: Shift[] }>('/api/shifts');
      setShifts(res.data);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to load shifts.' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = shifts.filter(
    (s) =>
      !search.trim() ||
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.status.toLowerCase().includes(search.toLowerCase())
  );

  const openAdd = () => {
    setEditing(null);
    setForm({ name: '', time_in: '08:00 AM', time_out: '05:00 PM', grace_minutes: '15', status: 'Active' });
    setModalOpen(true);
  };

  const openEdit = (s: Shift) => {
    setEditing(s);
    setForm({
      name: s.name,
      time_in: s.time_in,
      time_out: s.time_out,
      grace_minutes: String(s.grace_minutes),
      status: s.status,
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canWriteOrg) return;
    setFeedback(null);
    try {
      const payload = { ...form, grace_minutes: Number(form.grace_minutes) };
      if (editing) {
        await apiFetch(`/api/shifts/${editing.id}`, { method: 'PUT', body: JSON.stringify(payload) });
        setFeedback({ type: 'ok', text: `Updated shift "${form.name}".` });
      } else {
        await apiFetch('/api/shifts', { method: 'POST', body: JSON.stringify(payload) });
        setFeedback({ type: 'ok', text: `Added shift "${form.name}".` });
      }
      setModalOpen(false);
      load();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Save failed.' });
    }
  };

  const confirmDelete = async () => {
    if (!canWriteOrg || !deleting) return;
    setFeedback(null);
    try {
      await apiFetch(`/api/shifts/${deleting.id}`, { method: 'DELETE' });
      setFeedback({ type: 'ok', text: `Deleted shift "${deleting.name}".` });
      setDeleting(null);
      load();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Delete failed.' });
      setDeleting(null);
    }
  };

  return (
    <ModuleFrame
      title="Shifts & Schedules"
      subtitle="Manage work shifts and employee schedules."
      icon={<Clock className="w-5 h-5" />}
    >
      {feedback && (
        <div
          className={`mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Search + Add Shift Toolbar matching 10_Shifts_and_Schedules.png */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            aria-label="Search shifts"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search shift name or status..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-white text-xs shadow-2xs focus:outline-none focus:border-[#0B5537]"
          />
        </div>
        <button
          type="button"
          disabled={!canWriteOrg}
          onClick={openAdd}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl btn-rsu-primary text-xs font-bold cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Shift</span>
        </button>
      </div>

      <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
              <th className="py-3 px-4">Shift Name</th>
              <th className="py-3 px-4">Time In</th>
              <th className="py-3 px-4">Time Out</th>
              <th className="py-3 px-4">Grace</th>
              <th className="py-3 px-4 text-center">Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs">
            {loading ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-400">
                  Loading shifts...
                </td>
              </tr>
            ) : (
              filtered.map((s) => (
                <tr key={s.id} className="hover:bg-emerald-50/35">
                  <td className="py-3.5 px-4 font-semibold text-slate-900">{s.name}</td>
                  <td className="py-3.5 px-4 font-mono-num text-slate-700">{s.time_in}</td>
                  <td className="py-3.5 px-4 font-mono-num text-slate-700">{s.time_out}</td>
                  <td className="py-3.5 px-4 font-mono-num text-slate-700">{s.grace_minutes}</td>
                  <td className="py-3.5 px-4 text-center">
                    <StatusLabel status={s.status} />
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <button
                      type="button"
                      disabled={!canWriteOrg}
                      onClick={() => openEdit(s)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-[#0B5537] hover:bg-emerald-50 cursor-pointer"
                      aria-label={`Edit ${s.name}`}
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={!canWriteOrg}
                      onClick={() => setDeleting(s)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                      aria-label={`Delete ${s.name}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Shift' : 'Add Shift'}>
        <form onSubmit={handleSave} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Shift Name *</label>
            <input
              type="text"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full px-3 py-2 rounded-lg border border-slate-300"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Time In *</label>
              <input
                type="text"
                required
                value={form.time_in}
                onChange={(e) => setForm({ ...form, time_in: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Time Out *</label>
              <input
                type="text"
                required
                value={form.time_out}
                onChange={(e) => setForm({ ...form, time_out: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Grace (min)</label>
              <input
                type="number"
                min="0"
                value={form.grace_minutes}
                onChange={(e) => setForm({ ...form, grace_minutes: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Status</label>
            <select
              value={form.status}
              onChange={(e) => setForm({ ...form, status: e.target.value as 'Active' | 'Inactive' })}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
            >
              Save Shift
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmModal
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={confirmDelete}
        title="Delete Shift?"
        message={deleting ? `Delete shift "${deleting.name}"? Shifts currently assigned to employees cannot be removed.` : ''}
        confirmLabel="Delete Shift"
        destructive
      />
    </ModuleFrame>
  );
};

// ============================================================================
// SCREEN 11 — DEPARTMENTS (11_Departments.png)
// ============================================================================
export const DepartmentsView: React.FC<{ currentUser?: AuthUser }> = ({ currentUser }) => {
  const canWriteOrg = !currentUser || currentUser.permissions?.includes('org:write') === true;
  const [departments, setDepartments] = useState<Department[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Department | null>(null);
  const [deleting, setDeleting] = useState<Department | null>(null);
  const [form, setForm] = useState({ code: '', name: '', head_name: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch<{ data: Department[] }>('/api/departments');
      setDepartments(res.data);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to load departments.' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = departments.filter(
    (d) =>
      !search.trim() ||
      d.code.toLowerCase().includes(search.toLowerCase()) ||
      d.name.toLowerCase().includes(search.toLowerCase()) ||
      (d.head_name || '').toLowerCase().includes(search.toLowerCase())
  );

  const openAdd = () => {
    setEditing(null);
    setForm({ code: '', name: '', head_name: '' });
    setModalOpen(true);
  };

  const openEdit = (d: Department) => {
    setEditing(d);
    setForm({ code: d.code, name: d.name, head_name: d.head_name || '' });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canWriteOrg) return;
    setFeedback(null);
    try {
      if (editing) {
        await apiFetch(`/api/departments/${editing.id}`, { method: 'PUT', body: JSON.stringify(form) });
        setFeedback({ type: 'ok', text: `Updated department ${form.code.toUpperCase()}.` });
      } else {
        await apiFetch('/api/departments', { method: 'POST', body: JSON.stringify(form) });
        setFeedback({ type: 'ok', text: `Added department ${form.code.toUpperCase()}.` });
      }
      setModalOpen(false);
      load();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Save failed.' });
    }
  };

  const confirmDelete = async () => {
    if (!canWriteOrg || !deleting) return;
    setFeedback(null);
    try {
      await apiFetch(`/api/departments/${deleting.id}`, { method: 'DELETE' });
      setFeedback({ type: 'ok', text: `Deleted department ${deleting.code}.` });
      setDeleting(null);
      load();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Delete failed.' });
      setDeleting(null);
    }
  };

  return (
    <ModuleFrame
      title="Departments"
      subtitle="Manage campus departments."
      icon={<Building2 className="w-5 h-5" />}
    >
      {feedback && (
        <div
          className={`mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Search + Add Department Toolbar matching 11_Departments.png */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            aria-label="Search departments"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search department code or name..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-white text-xs shadow-2xs focus:outline-none focus:border-[#0B5537]"
          />
        </div>
        <button
          type="button"
          disabled={!canWriteOrg}
          onClick={openAdd}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl btn-rsu-primary text-xs font-bold cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Department</span>
        </button>
      </div>

      <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
              <th className="py-3 px-4">Department Code</th>
              <th className="py-3 px-4">Department Name</th>
              <th className="py-3 px-4">Department Head</th>
              <th className="py-3 px-4 text-right">Employees</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs">
            {loading ? (
              <tr>
                <td colSpan={5} className="py-8 text-center text-slate-400">
                  Loading departments...
                </td>
              </tr>
            ) : (
              filtered.map((d) => (
                <tr key={d.id} className="hover:bg-emerald-50/35">
                  <td className="py-3.5 px-4 font-mono-num font-bold text-[#07442B]">{d.code}</td>
                  <td className="py-3.5 px-4 font-semibold text-slate-900">{d.name}</td>
                  <td className="py-3.5 px-4 text-slate-600">{d.head_name || '-'}</td>
                  <td className="py-3.5 px-4 text-right font-mono-num font-bold text-slate-800">
                    {d.employee_count}
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <button
                      type="button"
                      disabled={!canWriteOrg}
                      onClick={() => openEdit(d)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-[#0B5537] hover:bg-emerald-50 cursor-pointer"
                      aria-label={`Edit ${d.name}`}
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={!canWriteOrg}
                      onClick={() => setDeleting(d)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                      aria-label={`Delete ${d.name}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Department' : 'Add Department'}>
        <form onSubmit={handleSave} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Code *</label>
              <input
                type="text"
                required
                placeholder="BSIT"
                value={form.code}
                onChange={(e) => setForm({ ...form, code: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num uppercase"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Department Name *</label>
              <input
                type="text"
                required
                placeholder="Information Technology"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300"
              />
            </div>
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Department Head</label>
            <input
              type="text"
              placeholder="Dr. / Engr. Name"
              value={form.head_name}
              onChange={(e) => setForm({ ...form, head_name: e.target.value })}
              className="w-full px-3 py-2 rounded-lg border border-slate-300"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
            >
              Save Department
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmModal
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={confirmDelete}
        title="Delete Department?"
        message={deleting ? `Delete department ${deleting.code} (${deleting.name})? Departments with assigned employees cannot be deleted.` : ''}
        confirmLabel="Delete Department"
        destructive
      />
    </ModuleFrame>
  );
};

// ============================================================================
// SCREEN 12 — POSITIONS (12_Positions.png)
// ============================================================================
export const PositionsView: React.FC<{ currentUser?: AuthUser }> = ({ currentUser }) => {
  const canWriteOrg = !currentUser || currentUser.permissions?.includes('org:write') === true;
  const [positions, setPositions] = useState<Position[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Position | null>(null);
  const [deleting, setDeleting] = useState<Position | null>(null);
  const [form, setForm] = useState({
    code: '',
    name: '',
    type: 'Regular' as 'Regular' | 'Contractual' | 'Part-Time',
    base_salary: '30000',
    allowance: '2000',
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch<{ data: Position[] }>('/api/positions');
      setPositions(res.data);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to load positions.' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = positions.filter(
    (p) =>
      !search.trim() ||
      p.code.toLowerCase().includes(search.toLowerCase()) ||
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.type.toLowerCase().includes(search.toLowerCase())
  );

  const openAdd = () => {
    setEditing(null);
    setForm({ code: '', name: '', type: 'Regular', base_salary: '30000', allowance: '2000' });
    setModalOpen(true);
  };

  const openEdit = (p: Position) => {
    setEditing(p);
    setForm({
      code: p.code,
      name: p.name,
      type: p.type,
      base_salary: String(p.base_salary),
      allowance: String(p.allowance),
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canWriteOrg) return;
    setFeedback(null);
    try {
      const payload = {
        ...form,
        base_salary: Number(form.base_salary),
        allowance: Number(form.allowance),
      };
      if (editing) {
        await apiFetch(`/api/positions/${editing.id}`, { method: 'PUT', body: JSON.stringify(payload) });
        setFeedback({ type: 'ok', text: `Updated position ${form.code.toUpperCase()}.` });
      } else {
        await apiFetch('/api/positions', { method: 'POST', body: JSON.stringify(payload) });
        setFeedback({ type: 'ok', text: `Added position ${form.code.toUpperCase()}.` });
      }
      setModalOpen(false);
      load();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Save failed.' });
    }
  };

  const confirmDelete = async () => {
    if (!canWriteOrg || !deleting) return;
    setFeedback(null);
    try {
      await apiFetch(`/api/positions/${deleting.id}`, { method: 'DELETE' });
      setFeedback({ type: 'ok', text: `Deleted position ${deleting.code}.` });
      setDeleting(null);
      load();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Delete failed.' });
      setDeleting(null);
    }
  };

  return (
    <ModuleFrame
      title="Positions"
      subtitle="Manage employee positions."
      icon={<Briefcase className="w-5 h-5" />}
    >
      {feedback && (
        <div
          className={`mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Search + Add Position Toolbar matching 12_Positions.png */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            aria-label="Search positions"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search position code, name, or type..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-white text-xs shadow-2xs focus:outline-none focus:border-[#0B5537]"
          />
        </div>
        <button
          type="button"
          disabled={!canWriteOrg}
          onClick={openAdd}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl btn-rsu-primary text-xs font-bold cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Position</span>
        </button>
      </div>

      <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
              <th className="py-3 px-4">Position Code</th>
              <th className="py-3 px-4">Position Name</th>
              <th className="py-3 px-4">Type</th>
              <th className="py-3 px-4 text-right">Base Salary</th>
              <th className="py-3 px-4 text-right">Allowance</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs">
            {loading ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-400">
                  Loading positions...
                </td>
              </tr>
            ) : (
              filtered.map((p) => (
                <tr key={p.id} className="hover:bg-emerald-50/35">
                  <td className="py-3.5 px-4 font-mono-num font-bold text-[#07442B]">{p.code}</td>
                  <td className="py-3.5 px-4 font-semibold text-slate-900">{p.name}</td>
                  <td className="py-3.5 px-4">
                    <StatusLabel status={p.type} />
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono-num text-slate-800">
                    {formatPeso(p.base_salary)}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono-num text-slate-600">
                    {formatPeso(p.allowance)}
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <button
                      type="button"
                      disabled={!canWriteOrg}
                      onClick={() => openEdit(p)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-[#0B5537] hover:bg-emerald-50 cursor-pointer"
                      aria-label={`Edit ${p.name}`}
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={!canWriteOrg}
                      onClick={() => setDeleting(p)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                      aria-label={`Delete ${p.name}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Position' : 'Add Position'}>
        <form onSubmit={handleSave} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Code *</label>
              <input
                type="text"
                required
                placeholder="INST"
                value={form.code}
                onChange={(e) => setForm({ ...form, code: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num uppercase"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Position Name *</label>
              <input
                type="text"
                required
                placeholder="Instructor I"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Employment Type</label>
              <select
                value={form.type}
                onChange={(e) =>
                  setForm({ ...form, type: e.target.value as 'Regular' | 'Contractual' | 'Part-Time' })
                }
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
              >
                <option value="Regular">Regular</option>
                <option value="Contractual">Contractual</option>
                <option value="Part-Time">Part-Time</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Base Salary (₱)</label>
              <input
                type="number"
                min="0"
                value={form.base_salary}
                onChange={(e) => setForm({ ...form, base_salary: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Allowance (₱)</label>
              <input
                type="number"
                min="0"
                value={form.allowance}
                onChange={(e) => setForm({ ...form, allowance: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
            >
              Save Position
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmModal
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={confirmDelete}
        title="Delete Position?"
        message={deleting ? `Delete position ${deleting.code} (${deleting.name})?` : ''}
        confirmLabel="Delete Position"
        destructive
      />
    </ModuleFrame>
  );
};

// ============================================================================
// SCREEN 13 — HOLIDAYS (13_Holidays.png)
// ============================================================================
export const HolidaysView: React.FC<{ currentUser?: AuthUser }> = ({ currentUser }) => {
  const canWriteOrg = !currentUser || currentUser.permissions?.includes('org:write') === true;
  const [holidays, setHolidays] = useState<Holiday[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Holiday | null>(null);
  const [deleting, setDeleting] = useState<Holiday | null>(null);
  const [form, setForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    name: '',
    type: 'Regular' as 'Regular' | 'Special Non-Working',
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch<{ data: Holiday[] }>('/api/holidays');
      setHolidays(res.data);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to load holidays.' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = holidays.filter(
    (h) =>
      !search.trim() ||
      h.name.toLowerCase().includes(search.toLowerCase()) ||
      h.date.includes(search.trim()) ||
      h.type.toLowerCase().includes(search.toLowerCase())
  );

  const openAdd = () => {
    setEditing(null);
    setForm({ date: new Date().toISOString().slice(0, 10), name: '', type: 'Regular' });
    setModalOpen(true);
  };

  const openEdit = (h: Holiday) => {
    setEditing(h);
    setForm({ date: h.date, name: h.name, type: h.type });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canWriteOrg) return;
    setFeedback(null);
    try {
      if (editing) {
        await apiFetch(`/api/holidays/${editing.id}`, { method: 'PUT', body: JSON.stringify(form) });
        setFeedback({ type: 'ok', text: `Updated holiday "${form.name}".` });
      } else {
        await apiFetch('/api/holidays', { method: 'POST', body: JSON.stringify(form) });
        setFeedback({ type: 'ok', text: `Added holiday "${form.name}".` });
      }
      setModalOpen(false);
      load();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Save failed.' });
    }
  };

  const confirmDelete = async () => {
    if (!canWriteOrg || !deleting) return;
    setFeedback(null);
    try {
      await apiFetch(`/api/holidays/${deleting.id}`, { method: 'DELETE' });
      setFeedback({ type: 'ok', text: `Deleted holiday "${deleting.name}".` });
      setDeleting(null);
      load();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Delete failed.' });
      setDeleting(null);
    }
  };

  return (
    <ModuleFrame
      title="Holidays"
      subtitle="Manage official holidays."
      icon={<CalendarHeart className="w-5 h-5" />}
    >
      {feedback && (
        <div
          className={`mb-4 px-3.5 py-2.5 rounded-xl text-xs font-medium flex items-center gap-2 border ${
            feedback.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Search + Add Holiday Toolbar matching 13_Holidays.png */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            aria-label="Search holidays"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search holiday name or date..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-white text-xs shadow-2xs focus:outline-none focus:border-[#0B5537]"
          />
        </div>
        <button
          type="button"
          disabled={!canWriteOrg}
          onClick={openAdd}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl btn-rsu-primary text-xs font-bold cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Holiday</span>
        </button>
      </div>

      <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#F4F8F6] border-b border-slate-200/80 text-xs font-bold text-slate-700">
              <th className="py-3 px-4">Date</th>
              <th className="py-3 px-4">Holiday Name</th>
              <th className="py-3 px-4">Type</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs">
            {loading ? (
              <tr>
                <td colSpan={4} className="py-8 text-center text-slate-400">
                  Loading holidays...
                </td>
              </tr>
            ) : (
              filtered.map((h) => (
                <tr key={h.id} className="hover:bg-emerald-50/35">
                  <td className="py-3.5 px-4 font-mono-num font-semibold text-slate-800">
                    {formatDisplayDate(h.date)}
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-slate-900">{h.name}</td>
                  <td className="py-3.5 px-4">
                    <StatusLabel status={h.type} />
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <button
                      type="button"
                      disabled={!canWriteOrg}
                      onClick={() => openEdit(h)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-[#0B5537] hover:bg-emerald-50 cursor-pointer"
                      aria-label={`Edit ${h.name}`}
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={!canWriteOrg}
                      onClick={() => setDeleting(h)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                      aria-label={`Delete ${h.name}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Holiday' : 'Add Holiday'}>
        <form onSubmit={handleSave} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Date *</label>
              <input
                type="date"
                required
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Type</label>
              <select
                value={form.type}
                onChange={(e) =>
                  setForm({ ...form, type: e.target.value as 'Regular' | 'Special Non-Working' })
                }
                className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
              >
                <option value="Regular">Regular</option>
                <option value="Special Non-Working">Special Non-Working</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Holiday Name *</label>
            <input
              type="text"
              required
              placeholder="Independence Day"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full px-3 py-2 rounded-lg border border-slate-300"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg btn-rsu-primary font-semibold cursor-pointer"
            >
              Save Holiday
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmModal
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={confirmDelete}
        title="Delete Holiday?"
        message={deleting ? `Delete official holiday "${deleting.name}"?` : ''}
        confirmLabel="Delete Holiday"
        destructive
      />
    </ModuleFrame>
  );
};
