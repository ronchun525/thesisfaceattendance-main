# Changelog

All notable changes to the **SAVAGE-RSUCAJ Smart Attendance System** are documented in this file.

## [1.14.0 — BUILD 36: Complete 16-Screen Web Face Recognition Kiosk (`/kiosk`)] (2026-11-22)

> **Production Readiness Verdict: `NOT PRODUCTION READY`** — All 16 Web Kiosk screens, backend security/activation/PIN/enrollment/attendance routes, BUILD 20 tensor codecs, Playwright 16-screen × 4-viewport Chromium E2E, and core regressions PASS; however, the three real `.tflite` model binaries and server-side TFLite inference runtime are not yet deployed, and physical Windows/Android/Raspberry Pi 3B camera & anti-spoofing trials remain `BLOCKED`. Production biometric endpoints fail closed (`503`).

### Complete 16-Screen Browser Kiosk, Migration `011`, BUILD 20 Biometric Core & Admin Provisioning
- **16-Screen Web Kiosk UI (`/src/components/WebKioskPortal.tsx`, `/src/components/kiosk/KioskScreens.tsx`, `/src/components/kiosk/KioskPrimitives.tsx`, `/src/components/kiosk/types.ts`, `/src/lib/kioskBiometrics.ts`):**
  - Implemented all 16 approved Web Kiosk screens (`01_Splash_Screen` through `16_Attendance_Scan_Ready`) matched to the emerald-green/gold SAVAGE-RSUCAJ theme and original uncropped Attendance Shield logo.
  - Enforced **FRONT FACE ONLY** capture with zero left/right head-turn prompts and zero manual capture shutter buttons during touchless enrollment.
  - Implemented real WebRTC front-camera acquisition (`getUserMedia` with constraint ladder & `OverconstrainedError` fallback), `visibilitychange` camera pause/resume, offscreen `<canvas>` frame quality/frozen-frame diagnostics (`FrontalFrameAnalyzer`), and strict attendance-only voice prompts (`"Thank you."` / `"Try again."` via `KioskVoiceController`).
  - Wired `/kiosk` and `/?portal=kiosk` routing in `/src/App.tsx` without disturbing Admin (`/`) or Employee (`/employee`) portals.
- **Backend Web Kiosk Engine, Security & Schema Migration `011` (`/server/webKioskRoutes.ts`, `/server/webKioskBiometrics.ts`, `/server/db.ts`, `/server/security.ts`, `/server/api.ts`, `/.env.example`):**
  - Added Migration `011` (`web_kiosk_sessions`, `web_kiosk_challenges`, additive `devices` activation/settings/health columns, and `kiosk_admin_pin_*` / `kiosk_require_server_biometric_attestation` settings).
  - Updated `Permissions-Policy` in `server/security.ts` so `/kiosk` emits `camera=(self)` while `/` and `/employee` keep `camera=()`.
  - Implemented BUILD 20 tensor encoders, softmax/NaN fail-closed classifier decoder, 192D L2-normalized cosine 1:N matcher, `TFL3`+SHA-256 model inspection (`KIOSK_MODELS_DIR`), and AES-256-GCM encrypted template storage.
  - Implemented one-time device activation -> signed `HttpOnly` `savage_kiosk_session` cookie (omitting raw `api_token`), scrypt Admin PIN unlock with 5-strike 15-minute lockout, single-use 30s nonces, cross-employee duplicate enrollment rejection (`409`), server-side 1:N identity resolution (ignoring client `employee_id`/`match_verified`), canonical `processKioskPunch` + `realtimeHub.emitAttendanceUpdated()`, duplicate `"Already taken attendance"` (`409 ALREADY_TAKEN`), instant session revocation on `POST /api/devices/:id/revoke`, and production fail-closed guards (`503` missing server attestation, `403` liveness toggle lock).
- **Admin Portal Device Provisioning (`/src/components/SystemAdminViews.tsx`):**
  - Added `Open Web Kiosk` (`/kiosk`), `Set/Update Kiosk Admin PIN` modal (`PUT /api/kiosk/web/admin-pin`), and per-device one-time `Activation Code` modal (`POST /api/devices/:id/activation-code`) inside `DevicesView`.
- **Automated Verification (`/tests/web-kiosk-build36.test.mjs`, `/tests/web-kiosk-browser-e2e.test.mjs`):**
  - Verified `12/12` backend/biometric/security tests and `19/19` Playwright Chromium 16-screen & 4-viewport (`1024×600`, `390×844`, `768×1024`, `1366×768`) visual/functional checks (`0` page errors, `0` broken images, `0px` overflow), catching and fixing a swapped `verifyPassword` argument bug and `1024×600` fold spacing on Screens `03`, `11`, and `15`.

## [1.13.0 — Employee Portal Master Prompt 03 Real Functionality & Hardening] (2026-11-22)

### Real Backend Workflows, Duplicate Prevention, Supporting Documents, Realtime Notifications & Security Hygiene
- **Backend Duplicate & Date Enforcement (`/server/correctionsLeavesEngine.ts`):**
  - Added atomic `BEGIN IMMEDIATE` duplicate Pending correction prevention (`409 DUPLICATE_PENDING_CORRECTION`) blocking identical or conflicting Full Day pending corrections on the same employee and date.
  - Added server-side future-date guard (`400 FUTURE_DATE_NOT_ALLOWED`) using `Asia/Manila` current date on `POST /api/corrections`.
- **Policy-Aligned Leave & Correction Forms (`/src/components/employee/RequestsScreens.tsx`):**
  - Screen `10` (`LeaveRequestFormScreen`): defaults to the next weekday (Mon–Fri) when opened on weekends; dynamically enforces `requires_document_after_days` policy thresholds with clear supporting-document labels and validation.
  - Screen `12` (`AttendanceCorrectionFormScreen`): dynamically marks and validates required supporting documentation when `Full Day` correction is selected.
  - Screen `13` (`MyRequestsTrackingScreen`): added `Cancelled` status filter alongside `All`, `Pending`, `Approved`, and `Rejected`.
- **Realtime Notification Coalescing (`/src/components/EmployeeMobilePortal.tsx`):**
  - Added dedicated `createRefreshCoalescer` for `employee:notification` SSE events so bursts of approvals or payroll releases never spawn duplicate concurrent fetches.
- **Accessibility & Credential Hygiene (`/src/components/employee/EmployeeEntryFlow.tsx`, `/.env.example`):**
  - Added explicit `id`/`htmlFor` label binding on Screen `05` Remember Me checkbox so all 18 screens pass automated WCAG label/button checks (`0` nameless buttons, `0` unlabeled controls).
  - Removed literal credentials from `/.env.example`, restoring clean empty variable placeholders.
- **Expanded Verification (`/tests/employee-portal-master-audit.test.mjs`):**
  - Added executable verification for duplicate Pending correction rejection (API + UI), future-date rejection, Full Day supporting document requirement & SQLite persistence, live `employee:notification` SSE push from Admin approval + persistent Mark All Read, and automated accessibility sweeps across all 18 screens × 4 viewports.

## [1.13.0 — Employee Portal Master Prompt 02 Functional & Visual Audit] (2026-11-22)

### Screen-by-Screen Visual Fidelity, Browser Back Navigation, Session Expiration & Security Audit
- **AUDIT 01 Visual Fidelity Corrections (Matched to all 18 approved PNG references):**
  - Removed opaque white square boxes wrapping the transparent RGBA SAVAGE-RSUCAJ shield logo across Screens `01`, `05`, `06`–`09`, `18`, and Desktop Sidebar (`EmployeePrimitives.tsx`, `EmployeeEntryFlow.tsx`, `ProfileAndUtilityScreens.tsx`), applying subtle drop shadows directly on emerald/white surfaces.
  - Updated Screen `06` (`TodayDashboardScreen` in `TodayAndAttendanceScreens.tsx`) with solid emerald `Home` page icon, centered stacked `LogIn`/`LogOut` icons above `Time In`/`Time Out`, `BarChart3` heading icon + `This Month` subtitle on `My Attendance`, and semantic row icons (`CalendarCheck2`, red `XCircle`, `CalendarDays`).
  - Updated Screen `09` (`MyProfileScreen` in `ProfileAndUtilityScreens.tsx`) with top `My Profile` header + icon, neutral soft-gray circular profile silhouette, and emerald outline icons on every employee attribute row.
  - Updated Screen `10` & Screen `12` (`RequestsScreens.tsx`) date/time input icon placement from right (`pr-10`) to left (`pl-10`) to eliminate overlap with native Chromium/Edge/Safari date/time picker indicators.
  - Updated Screen `16` (`AccountSecurityScreen`), Screen `17` (`NotificationsScreen`), and Screen `18` (`AboutSystemScreen` + `"About"` header title in `EmployeeMobilePortal.tsx`) to match exact reference icons, emblem framing, and institutional copy while keeping honest disabled 2FA state and live `/api/health` data.
- **AUDIT 02 Navigation & Session Expiration Fixes:**
  - Added History API (`pushState` / `replaceState` / `popstate`) synchronization across `EmployeeMobilePortal.tsx` and `EmployeeEntryFlow.tsx` so Browser Back steps cleanly through onboarding slides and all Employee Portal screens without leaving the portal.
  - Updated `src/App.tsx` and `EmployeeEntryFlow.tsx` so expired Employee sessions (`401`) reliably return to `/employee` Screen `05` (skipping onboarding) with an explicit amber `"Your session has expired. Please sign in again."` banner.
- **AUDIT 03–06 Exhaustive Automated Verification:**
  - Added `/tests/employee-portal-master-audit.test.mjs` verifying all RBAC/security boundaries, overnight-shift date handling (`active_prior_shift: true`), real-time SSE attendance updates without reload, DTR & Payslip PDF `%PDF-` binary downloads, Browser Back navigation, mid-session expiration, password rotation, and `0px` overflow across **all 18 screens** at `360×800`, `393×852`, `768×1024`, and `1440×900`, plus capturing and visually inspecting runtime PNG screenshots of all 18 screens.

## [1.13.0 — Employee Portal 18-Screen Rebuild] (2026-11-22)

### Complete 18-Screen Employee Portal UI/UX Rebuild & Self-Service API Hardening
- Completely rebuilt the Employee Portal UI/UX across all **18 approved reference screens** (`01_Splash_Screen` through `18_About_System`) using the official SAVAGE-RSUCAJ Attendance Shield logo (`/assets/aistudio/Savage-Rsucaj_Attendance_Shield_bca5b40c.png`), deep emerald (`#043D22`–`#0A7742`) and gold (`#F4B400`–`#FEF08A`) sweeping wave headers/footers, and exact 5-tab mobile bottom navigation (`Today`, `Attendance`, `Requests`, `Payslips`, `Profile`) + desktop `lg:` sidebar.
- Added modular Employee Portal architecture under `src/components/employee/`:
  - `types.ts`: Shared contracts, reference ID formatters (`LV-YYYY-00001`, `AC-YYYY-00001`), 12-hour time/date/relative timestamp helpers, and user-agent parser.
  - `EmployeePrimitives.tsx`: Reusable `EmployeeShieldLogo`, `HeaderGoldWave`, `FooterEmeraldGoldWave`, `EmployeeHeader`, `EmployeeBottomNavigation`, `EmployeeSidebar`, `EmployeePageLayout`, `StatusBadge`, `AttendanceCard`, `RequestCard`, `PayslipCard`, `FormField`, `LoadingState`, `EmptyState`, `ErrorState`, `ConfirmationDialog`.
  - `EmployeeEntryFlow.tsx`: Screen 01 (`EmployeeSplashScreen`), Screens 02–04 (`EmployeeOnboardingFlow`), Screen 05 (`EmployeeLoginScreen` supporting Employee ID / username / email login, password visibility toggle, Remember Me, and Forgot Password modal).
  - `TodayAndAttendanceScreens.tsx`: Screen 06 (`TodayDashboardScreen` — strictly read-only, zero manual punch controls, live SSE sync indicator, monthly summary) and Screen 07 (`AttendanceRecordsScreen` — month picker, status filter, Monthly DTR modal & official PDF download).
  - `RequestsScreens.tsx`: Screen 10 (`LeaveRequestFormScreen` with attachment upload), Screen 11 (`RequestSuccessScreen` displaying real backend-confirmed reference numbers), Screen 12 (`AttendanceCorrectionFormScreen`), and Screen 13 (`MyRequestsTrackingScreen` with `All | Leave | Correction` tabs, detail modal, and leave cancellation).
  - `PayslipsScreens.tsx`: Screen 08 (`MyPayslipsScreen` with released-only listing & direct PDF download) and Screen 14 (`PayslipDetailsScreen` with full earnings/deductions/Net Pay breakdown & official PDF export).
  - `ProfileAndUtilityScreens.tsx`: Screen 09 (`MyProfileScreen`), Screen 15 (`ChangePasswordScreen` dynamically matched to server password policy & forced-rotation support), Screen 16 (`AccountSecurityScreen` with honest disabled 2FA state, real Login Activity, real Linked Devices revocation, and configurable Session Timeout), Screen 17 (`NotificationsScreen` with persisted read state & Mark All Read), and Screen 18 (`AboutSystemScreen` backed by `/api/health`).
- Rewrote `src/components/EmployeeMobilePortal.tsx` and updated `src/App.tsx` + `src/components/LoginView.tsx` to wire `/employee` routing, Splash/Onboarding/Login entry flow, forced Screen 15 rotation for Employee accounts, and live SSE (`attendance:updated`, `employee:notification`) + polling fallback without modifying Admin Portal modules.
- Enhanced backend self-service endpoints (`server/api.ts`, `server/db.ts`, `server/realtimeHub.ts`):
  - Enabled Employee ID (`employee_code`) sign-in alongside username/email in `POST /api/auth/login`.
  - Added idempotent `employee_notification_reads` table and strictly self-scoped `GET /api/employee/notifications`, `PATCH /api/employee/notifications/:key/read`, `POST /api/employee/notifications/mark-all-read`.
  - Added strictly self-scoped `GET /api/employee/security/sessions`, `DELETE /api/employee/security/sessions/:sessionPrefix`, and `POST /api/employee/security/sessions/revoke-others`.
  - Added official PDF payslip generator `GET /api/payroll/:runId/payslip/:employeeId/pdf` (`pdfkit`) with strict RBAC & `status='Released'` enforcement.
  - Added `employee:notification` SSE channel scoped strictly to the target `employeeId`.
- Added automated tests: `tests/employee-portal-18screens.test.mjs` (API, RBAC, PDF & isolation — PASS) and `tests/employee-portal-browser-e2e.test.mjs` (Playwright Chromium 18-screen & 5-viewport E2E — PASS).

## [1.13.0] — BUILD 17 (2026-11-21)

> **Mandatory Go/No-Go Verdict: `NO-GO` (`PRODUCTION RELEASE STATUS: BLOCKED`)** — All `142/142` automated software, security, staging load/impairment/DR, startup smoke, and Playwright Chromium 16-screen/4-viewport E2E checks PASS with `0` dependency vulnerabilities (`bun audit`), **however** production deployment remains formally **BLOCKED (`NO-GO`)** (`RG-05` through `RG-10` blocked: BUILD 09 real biometrics, physical Raspberry Pi/Android kiosk/Android employee/Windows acceptance, RSU HRMO CS Form 48 approval, RSU Finance payroll policy sign-off, production VPS/DNS/TLS provisioning, offsite encrypted backup replication, on-call roster, and Project Owner Go-Live sign-off).

### Mandatory Go/No-Go Release Gate & Production Operations Pack
- Added automated 10-gate release evaluator (`scripts/release-gate.ts`, `npm run release:gate`) writing `test-results/release-gate-report.json` and exiting with code `2` on `NO-GO`.
- Authored complete production deployment, operations, security, release notes, and staging acceptance documentation: `DEPLOYMENT.md` (Linux VPS `systemd`/Nginx/Caddy/UFW/logrotate/backups, Hostinger Single static alternative, Windows PowerShell SOP, rollback rehearsal), `OPERATIONS_RUNBOOK.md` (proposed SLO/RPO/RTO targets, checklists, incident playbooks, on-call roster), `SECURITY.md`, `RELEASE_NOTES.md`, `docs/STAGING_ACCEPTANCE_MATRIX.md`, and updated `docs/RELEASE_CHECKLIST.md`.
- Aligned runtime metadata, health probes, backup manifests, PDF generators, and UI version footers to `1.13.0` (`BUILD 17`, Schema `009`).

## [1.12.0] — BUILD 16 (2026-11-21)

### Production-Like Staging Runtime, Security Audit, Controllable Impairment, Load & Audit Bugfix
- Added `server/stagingRuntime.ts` with `X-Request-Id` correlation headers, structured JSON logging with strict secret redaction, live p50/p95/p99 latency stats, and a **staging-only** controllable network impairment controller (`GET/PUT /api/staging/impairment`, `GET /api/staging/logs`) strictly returning `403 STAGING_ONLY_ENDPOINT` in `APP_MODE=production`.
- Extended `server/env.ts` and `.env.example` with `APP_MODE=staging`, `LOG_FORMAT`, `STAGING_PUBLIC_URL`, `STAGING_LOG_FILE`, and fail-secure rejection of `STAGING_IMPAIRMENT_ENABLED=true` in production.
- Added server-authoritative `backend_confirmed: true`, `voice_cue` (`DUPLICATE_ALREADY_RECORDED`, `TIME_IN_RECORDED`, `TIME_OUT_RECORDED`, `ESCALATED_TO_HR`, `PUNCH_REJECTED`), and `request_id` on `/api/kiosk/punch`.
- Added sanitized staging bootstrapper (`scripts/staging-setup.ts`, `npm run staging:setup`) refusing to touch `./data/savage_rsucaj.db` and labeling staging payroll policy `[STAGING TEST-ONLY — FAKE CURRENCY]`.
- **Critical Cross-Module Audit Bug Fixed (`server/correctionsLeavesEngine.ts`):** Replaced raw `INSERT INTO audit_logs` inside `recordGeneralAudit()` with `logAudit()`, fixing broken SHA-256 audit hash-chain verification (`409`) after correction/leave approvals.
- Added `tests/staging-security-load.test.ts` (`npm run test:staging`, `7/7` PASS; 200 concurrent reads `p95=585.17 ms` at `295.9 req/s`, 50 concurrent kiosk punches `p95=199.31 ms` with `25/25` dedup and `0` HTTP 5xx, encrypted backup `69.09 ms`, guarded live restore `261.98 ms`, `auditChainValid=true`).

## [1.11.0] — BUILD 15 (2026-11-21)

### 16-Screen Playwright Chromium E2E, Accessibility (WCAG 2.1 AA) & 4-Viewport Responsive Polish
- Added `:focus-visible` keyboard focus rings, skip-to-main-content link, modal Escape handling, explicit `htmlFor`/`id` and `aria-label` associations, and responsive wrapping across all 16 reference screens without redesigning any approved screen or adding Admin Biometrics.
- Fixed DTR sign-off & revocation success confirmation banners being cleared immediately by `runReport()` (`src/components/PayrollReportsViews.tsx`) and defaulted the Leave filing modal date to the nearest Mon–Fri weekday when opened on a weekend (`src/components/CorrectionsLeavesViews.tsx`).
- Added `tests/e2e.browser.test.ts` (`npm run test:browser`, `22/22` PASS) exercising real compiled `dist/` + Express + SQLite across all 16 screens and 4 viewports (`1366×768`, `1920×1080`, `768×1024`, `390×844`) with `41` audited screenshots, `0` page errors, `0` blocking console errors, and `0px` horizontal overflow.

## [1.10.0] — BUILD 14 (2026-11-21)

> **Release Gate Notice:** System Settings validation & secret masking, Administrator-only guarded live SQLite restore with rollback safety snapshot, policy-compliant Data Retention dry-run/purge jobs, Device credential one-time display/rotation/revocation & heartbeat-driven alerting, event-driven role-targeted Notifications (with RBAC-gated UI actions & zero false `"successful sync"` alerts), and append-only SHA-256 tamper-evident Audit Logs are verified (**113/113 automated checks PASS**). **Production Release Status remains BLOCKED** pending verified RSU Cajidiocan official Civil Service Form 48 layout confirmation, RSU Finance payroll policy sign-off, BUILD 09 real biometrics, Browser E2E, physical kiosk hardware, external Google SSO/SMTP, and live production host verification.

### System Settings, Maintenance, Guarded Live Restore & Data Retention
- Added `/server/adminOpsEngine.ts` with allowlisted, validated settings persistence (`validateAndApplySettingsUpdates`), masked environment secret status (`SESSION_SECRET`, `BACKUP_ENCRYPTION_KEY`, SMTP, Google SSO), and Security & Configuration Change History (`GET /api/security/history`).
- Added Administrator-only guarded live SQLite restore (`POST /api/backup/restore`) enforcing Administrator password re-verification, exact `RESTORE LIVE DATABASE` confirmation phrase, strict `BACKUP_DIR` path confinement (blocking path traversal), pre-restore archive/AES-256-GCM integrity validation, automatic `.pre-restore-*.bak` safety snapshot, atomic handle swap & router/auth handle rebinding (`onDatabaseReplaced` in `server.ts` + `createRequireAuth(() => db)`), and automatic rollback on failure.
- Added policy-compliant Data Retention dry-run preview (`GET /api/retention/preview`), recorded purge execution (`POST /api/retention/execute` requiring `confirmExecute: true`), and job history (`GET /api/retention/jobs` backed by `retention_jobs`), preserving payroll-locked attendance (`Finalized`/`Released`), pending corrections, immutable `attendance_events`, and append-only `audit_logs`.

### Kiosk Device Credentials, Role-Targeted Notifications & Tamper-Evident Audit Logs
- Added **Migration `009`** (`build14_tamper_evident_audit_retention_notifications_and_device_secrets`, `CURRENT_SCHEMA_VERSION = '009'`) in `/server/db.ts` adding SHA-256 hash-chain columns and SQLite `BEFORE UPDATE`/`BEFORE DELETE` immutability triggers (`IMMUTABLE_AUDIT_VIOLATION`) on `audit_logs`, audience/event/dedupe columns on `notifications`, token hash/mask/alert-state columns on `devices`, and `retention_jobs`.
- Added `/server/auditHelpers.ts` implementing SHA-256 chain computation, secret redaction in audit `before_json`/`after_json` diffs, migration backfill, and `GET /api/audit-logs/verify` tamper detection (`409` on broken links).
- Hardened kiosk device lifecycle (`POST /api/devices`, `POST /api/devices/:id/rotate-token`, `POST /api/devices/:id/revoke`, `POST /api/devices/:id/restore-access`): one-time plaintext display on create/rotate, SHA-256 hashing & masked reads across `/api/devices`, `/api/dashboard`, and `/api/backup/export`, heartbeat-derived `Online`/`Stale`/`Offline`/`Revoked` connectivity (no seeded always-Online state), and deduplicated stale/offline alerting evaluated on `/api/devices`, `/api/dashboard`, and `/api/notifications`.
- Upgraded Notifications (`GET /api/notifications`, `POST /api/notifications/mark-all-read`, `DELETE /api/notifications` with optional selective `{ ids }`, `AdminDashboardView.tsx`, `SystemAdminViews.tsx`, `App.tsx`) with role targeting, attendance exception & kiosk sync-failure alerts, zero false `"successful sync"` messages, RBAC-gated disabled controls with honest explanations for read-only roles, and all 5 filter tabs (`All`, `Unread`, `Attendance`, `Devices`, `System`) on both Dashboard and Notifications screens.
- Added `/tests/admin-ops.test.ts` (8/8 PASS) covering multi-user RBAC, invalid settings, secret masking, device rotation/revocation/stale-offline alerts, role notifications & read-only enforcement, selective bulk dismiss, retention dry-run/purge, audit immutability/tamper detection/CSV export, encrypted backup/traversal/tamper rejection/guarded live restore, and simulated server restart persistence.

## [1.9.0] — BUILD 13 (2026-11-20)

> **Release Gate Notice:** Institutional DB-backed reports (all 6 modules), Monthly DTR engine (`28`/`29`/`30`/`31` calendar days, leap year, overnight cutoff, corrections/leaves/OB/holidays/rest days, draft blocker rejection, SHA-256 signoff tracking), server-side A4 portrait `pdfkit` PDF generation, and unclipped formula-safe streaming CSV exports are verified (**105/105 automated checks PASS**). **Production Release Status remains BLOCKED** pending verified RSU Cajidiocan official Civil Service Form 48 layout confirmation (`cs_form_48_reference_verified='false'`), RSU Finance payroll policy sign-off, BUILD 09 real biometrics, Browser E2E, and physical kiosk hardware verification.

### Institutional DB-Backed Reports, Monthly DTR Engine & Hardened CSV/PDF Exports
- Added `server/reportsEngine.ts` implementing full DB-backed query/reconciliation (`queryReport`), calendar-complete Monthly DTR generation (`buildMonthlyDtrReports`), electronic sign-off & revocation (`signMonthlyDtr`, `revokeMonthlyDtrSignoff`), unclipped streaming RFC 4180 CSV export with spreadsheet formula neutralization (`streamCsvReportResponse`, `escapeCsvCell`), and server-side A4 portrait `pdfkit` PDF rendering (`generateReportPdfBuffer`) embedding the official SAVAGE-RSUCAJ RSU emblem (`/public/assets/aistudio/SAVAGE-RSUCAJ_Smart_Attendance_Emblem_39488c28.png`).
- Enforced honest CS Form 48 compliance guardrails: `settings.cs_form_48_reference_verified` defaults to `'false'`; Monthly DTR previews and PDFs clearly display *"MONTHLY DAILY TIME RECORD (DRAFT INSTITUTIONAL FORMAT - CS FORM 48 REFERENCE PENDING RSU APPROVAL)"* rather than falsely claiming verified Civil Service Form 48 compliance.
- Enforced zero silent time fabrication and strict unresolved-draft controls: `Missing Time In` / `Missing Time Out` punches stay `null`/`MISSING`; unresolved punches, pending corrections, pending leaves, or escalated events mark the DTR `DRAFT_UNRESOLVED`, apply a `DRAFT - UNRESOLVED` PDF watermark, and return `409 DTR_UNRESOLVED_DRAFT` when `strict=true` or when attempting `POST /api/reports/dtr/sign`. Signing binds a SHA-256 snapshot hash (`dtr_signoffs.dtr_snapshot_sha256`); post-sign attendance edits automatically flip state to `SIGNED_STALE`.
- Added **Migration `008`** (`build13_dtr_signoffs_and_reporting_controls`, `CURRENT_SCHEMA_VERSION = '008'`) creating `dtr_signoffs` + `idx_dtr_signoffs_emp_month` and baseline settings (`campus_director_name`, `cs_form_48_reference_verified`, `cs_form_48_reference_note`).
- Upgraded `server/api.ts` report endpoints (`GET /api/reports/my-dtr`, `GET /api/reports/my-dtr/export.pdf`, `GET /api/reports/dtr/monthly`, `POST /api/reports/dtr/sign`, `POST /api/reports/dtr/revoke`, `GET /api/reports/dtr/pdf`, `GET /api/reports/:type`, `GET /api/reports/:type/export.csv`, `GET /api/reports/:type/export.pdf`) with strict RBAC (`401`/`403` + Department Head cross-department blocking), `Cache-Control: no-store`, `X-Content-Type-Options: nosniff`, sanitized filenames, and full pagination/unclipped streaming (removing legacy `LIMIT 2000`/`LIMIT 200` truncations). Preserved `GET /api/reports/dtr` missing-punch `'-'` coercion for BUILD 11 compatibility while marking `MISSING` in Monthly DTR sheets, CSV, and PDFs.
- Upgraded `src/components/PayrollReportsViews.tsx` (`ReportsView`), `src/components/SystemAdminViews.tsx` (General Settings Campus Director & CS Form 48 status banner + About tab `1.9.0` / `BUILD 13`), `src/lib/api.ts` (`downloadAuthenticatedBlob`), `src/types.ts`, and `src/index.css` (`@page { size: A4 portrait; margin: 10mm; }`, `.dtr-print-sheet`) while preserving all 16 reference screens and RSU branding.
- Added `tests/reports.test.ts` (8/8 PASS covering 28/29/30/31-day months, leap year, overnight/03:00 cutoff, corrections/leaves/OB/holidays/rest days, missing-punch draft blocking & stale sign-off detection, 401/403 RBAC, host-TZ invariance, 5,200+ row CSV streaming & formula neutralization, multi-page PDF inspection via `zlib`, and SQLite reconciliation).

## [1.8.0] — BUILD 12 (2026-11-20)

> **Release Gate Notice:** Institutional payroll calculation, reconciliation, maker-checker governance, SQLite immutability, payslip privacy, and CSV hardening are verified (**97/97 automated checks PASS**). **Production Release Status remains BLOCKED** pending RSU Cajidiocan Finance sign-off on the institutional payroll policy & scenario outputs, BUILD 09 real biometrics, and physical kiosk hardware verification.

### Institutional Policy-Driven Payroll Engine & Controls
- Added `server/payrollEngine.ts` (`BUILD12-v1.0`) permanently removing hard-coded `11.5% + ₱200` and `salary / 22` placeholders.
- Added blank **Institutional Policy Input Template** (`GET /api/payroll/policy-template`) and effective-dated institutional policy CRUD + Finance approval (`GET/POST /api/payroll/policies`, `PUT /api/payroll/policies/:id`, `POST /api/payroll/policies/:id/finance-approve`). Missing policy returns `422 PAYROLL_POLICY_REQUIRED`; draft unapproved policies stamp runs `NOT APPROVED FOR PRODUCTION` and block Finalize & Release (`409 PAYROLL_POLICY_NOT_APPROVED`).
- Implemented split-month and partial-period proration per scheduled working day per month (respecting `hired_date`, shift `rest_days`, holidays, approved `leave_day_allocations` + `leave_policies.is_paid`, backdated corrections, late/undertime, overtime multipliers, holiday/rest-day premiums, statutory contributions, progressive withholding tax, and special pay exceptions).
- Added pre-compute reconciliation (`GET /api/payroll/precheck`) blocking computation on pending corrections (`409 PENDING_CORRECTIONS_EXIST`), pending leaves (`409 PENDING_LEAVES_EXIST`), and unresolved `Missing Time In` / `Missing Time Out` (`409 UNRESOLVED_MISSING_PUNCHES`).
- Added period uniqueness (`idx_payroll_runs_period_unique`, `409 DUPLICATE_PAYROLL_PERIOD` / `OVERLAPPING_PAYROLL_PERIOD`), idempotent recompute (`recompute: true`), SHA-256 snapshot hashing, `calculation_version` tracking, and atomic `BEGIN IMMEDIATE` transaction rollback on partial failure.
- Enforced **Maker-Checker Separation** (`computed_by_user_id !== actor.userId` -> `403 MAKER_CHECKER_VIOLATION`) and mandatory **Finance Sign-Off Gate** (`POST /api/payroll/:id/finance-signoff`, `409 FINANCE_SIGNOFF_REQUIRED` before release).
- Added **Migration `007`** (`build12_payroll_policies_immutability_maker_checker_and_audit`, `CURRENT_SCHEMA_VERSION = '007'`) creating `payroll_policies`, `payroll_audit_log`, extended `payroll_runs`/`payroll_items`, and strict SQLite immutability triggers (`PAYROLL_LOCKED_VIOLATION` and `IMMUTABLE_AUDIT_VIOLATION`).
- Added Employee self-service Released-only payslips (`payroll:read_self`, `GET /api/payroll/my-payslips`, `GET /api/payroll/:runId/payslip/:employeeId`), formula-injection-safe server CSV export (`GET /api/payroll/:id/export.csv`, `Cache-Control: no-store`, zero secrets), client `downloadCsv` formula hardening, and reconciled `GET /api/reports/payroll`.
- Added RBAC permissions `payroll:read_self`, `payroll:policy_manage`, and `payroll:finance_signoff` in `server/rbac.ts` (38 permissions across 6 roles).
- Upgraded `src/components/PayrollReportsViews.tsx` while preserving `08_Payroll_Processing_09a407ae.png` and `09_Reports_6eabab71.png` layouts.

### Cross-Suite Reliability Fixes & Verification
- Fixed pre-existing BUILD 11 `attendance_events` `punch_type` SQLite `CHECK` constraint failures in `server/correctionsLeavesEngine.ts` (using valid `'correction'` and `'reconcile'` types while preserving `'CORRECTION_REVERSED'`, `'LEAVE_APPROVED'`, and `'LEAVE_CANCELLED'` `decision_code` values) plus response field aliases and report camelCase/snake_case filter support (`server/api.ts`).
- Fixed pre-existing BUILD 10 `tests/sync.test.ts` batch payload (`device_timestamp`) and SSE stream reader cleanup.
- Added `tests/payroll.test.ts` (10/10 PASS including golden vectors verified to `0.01`) and `docs/PAYROLL_POLICY_AND_CONTROLS.md`, `docs/CORRECTIONS_AND_LEAVES_POLICY.md`, `docs/KIOSK_SYNC_AND_REALTIME.md`. Total verified automated checks: **97/97 PASS**.

## [1.7.0] — BUILD 11 (2026-11-20)

- Added `server/correctionsLeavesEngine.ts` and **Migration `006`** (`leave_policies`, `leave_day_allocations`, `correction_audit_log`, `leave_audit_log` with SQLite immutability triggers).
- Eliminated fabricated counterpart punches (`Missing Time Out` / `Missing Time In`), added audit-safe correction reversal, configurable HR leave policies, multi-day/half-day/cross-year leave allocations, punch-conflict controls (`BLOCK` / `PRESERVE_PUNCHES`), atomic leave cancellation, and `tests/corrections-leaves.test.ts` (13/13 PASS).

## [1.6.0] — BUILD 10 (2026-11-20)

- Added `server/kioskOfflineQueue.ts`, `server/realtime.ts`, and **Migration `005`** (`kiosk_sync_batches`, heartbeat telemetry, and HMAC biometric evidence binding fields).
- Added AES-256-GCM encrypted offline queue, `POST /api/kiosk/sync` chronological batch sync, Online -> Stale -> Offline heartbeat lifecycle, revoked kiosk blocking (`403 DEVICE_REVOKED`), RBAC-scoped authenticated SSE (`GET /api/realtime/stream`), and `tests/sync.test.ts` (6/6 PASS).

## [1.5.0] — BUILD 08 (2026-11-20)

> **Build Sequence Note:** Continued directly from verified BUILD 06 (`v1.4.0`) as requested. No BUILD 07 changes were executed or fabricated. Real biometric liveness/verification is NOT claimed in BUILD 08 (reserved for BUILD 09).

### Attendance Policy Engine, Asia/Manila Timezone & 03:00 Cutoff
- Added `server/attendanceEngine.ts`: pure `Asia/Manila` (UTC+08:00, host-OS timezone independent) time math, shift window calculation, `processKioskPunch()` atomic `IMMEDIATE` SQLite transaction engine, and separate `reconcileAttendanceForDate()` day-rollover reconciliation engine.
- Formalized explicit attendance actions: `TIME_IN`, `TIME_OUT`, `BREAK_OUT`, `BREAK_IN`, `OVERTIME_OUT`. Missing or unapproved actions return HTTP `400` (`INVALID_ACTION`). Eliminated the legacy BUILD 03 bug that implicitly converted repeated `TIME_IN` into `TIME_OUT` or overwrote valid existing punches.
- Assigned every punch to the correct **work/shift date** in `Asia/Manila` (supporting overnight shifts crossing midnight such as `10:00 PM – 07:00 AM` and late-night `11:59 PM -> 12:01 AM` transitions).
- Enforced the **03:00 `Asia/Manila` next calendar day** final `TIME_OUT` cutoff for day shifts: `02:59 AM` next-day `TIME_OUT` attaches cleanly to the prior shift date, while `03:01 AM` (or unmatched `TIME_OUT` without `TIME_IN`) is rejected and automatically escalated to HR (`Pending` correction + high-priority `Attendance Alerts` notification + immutable `ESCALATED` event) without overwriting or fabricating punches.
- Enforced server-authoritative clock validation: client-supplied `punch_time` strings are ignored; live punches enforce configurable ±120s `device_timestamp` drift (`422 CLOCK_DRIFT_EXCEEDED`); offline replays enforce chronological ordering (`409 OUT_OF_ORDER_TIMESTAMP`) and a bounded 72-hour window (`422 OFFLINE_REPLAY_EXPIRED` escalation).
- Standardized all 10 approved attendance statuses (`Present`, `Late`, `Absent`, `Undertime`, `On Leave`, `OB`, `Rest Day`, `Holiday`, `Missing Time Out`, `No Schedule`) across DB constraint triggers, kiosk/manual/correction/leave routes, reconciliation, reports, dashboard, and UI.

### Database Migration 004 & Immutable Audit History
- Added idempotent transactional **Migration `004`** (`build08_attendance_policy_and_immutable_events`) in `server/db.ts` (bumped `CURRENT_SCHEMA_VERSION = '004'`):
  - Added `shifts.rest_days`, extended `attendance_records` with `break_out`, `break_in`, `overtime_out`, UTC forensic timestamps, `late_minutes`, `undertime_minutes`, `overtime_minutes`, and `reconciled_at`.
  - Updated status constraint triggers (`trg_att_status_valid_ins`, `trg_att_status_valid_upd`) for all 10 approved statuses.
  - Non-destructively rebuilt `attendance_events` with forensic fields (`server_timestamp_utc`, `manila_timestamp`, `device_timestamp_utc`, `clock_drift_seconds`, `offline_replay`, `decision`, `decision_code`, `decision_reason`), partial unique index `idx_att_events_accepted_unique` on `(employee_id, attendance_date, punch_type) WHERE decision = 'ACCEPTED'`, and SQLite `BEFORE UPDATE`/`BEFORE DELETE` immutability triggers (`IMMUTABLE_AUDIT_VIOLATION`).
- Fixed `server/db.ts` `getTodayDateString()` / `formatIsoDate()`, `server/api.ts` `/api/dashboard`, `src/components/AttendanceView.tsx`, `src/components/CorrectionsLeavesViews.tsx`, and `src/components/SystemAdminViews.tsx` to use `Asia/Manila` instead of host-local or UTC dates.
- Fixed `PATCH /api/corrections/:id/status` in `server/api.ts` so approving a `Time In` or `Time Out` correction never fabricates a counterpart `'08:00 AM'` / `'05:00 PM'` punch and always logs an immutable `'correction'` event.

### New Endpoints, Frontend & Deterministic Tests
- Added `GET /api/attendance/:id/events` (RBAC + scope enforced) and `POST /api/attendance/reconcile` (`attendance:write`) in `server/api.ts`.
- Enhanced `src/components/AttendanceView.tsx` (preserving `05_Attendance_Records` layout) with `Asia/Manila` default date, all 10 approved statuses, **Reconcile Day** action, and immutable punch history timeline inside the **Attendance Record Details** modal.
- Updated `DevicesView` "Test Kiosk Punch API" modal (`src/components/SystemAdminViews.tsx`) to require explicit `punch_type` selection and attach unique `event_uid` + `device_timestamp`.
- Added `tests/attendance.test.ts` (18 deterministic `Asia/Manila` tests) and `docs/ATTENDANCE_POLICY.md`, bringing total verified automated checks to **68/68** (15 unit + 10 DB durability + 18 attendance policy + 20 API/security/RBAC + 5 startup smoke).

### Preserved
- Preserved all 16 approved reference screens, official SAVAGE-RSUCAJ emblem, sidebar navigation (no Admin Biometrics), BUILD 05 auth/CSRF/RBAC, BUILD 06 durability/encrypted backups, and live `./data/savage_rsucaj.db` intact.

## [1.4.0] — BUILD 06 (2026-11-20)

### Database Durability, Migrations & Mode Separation
- Added idempotent transactional **Migration `003`** (`build06_event_identity_and_integrity_constraints`) in `server/db.ts`: created `attendance_events` (`event_uid UNIQUE` + composite `(employee_id, attendance_date, punch_type, punch_time)` uniqueness), `backup_history`, unique/lookup indexes (`idx_holidays_date_name`, `idx_payroll_items_run_emp`, `idx_devices_api_token`), and 12 `BEFORE INSERT`/`BEFORE UPDATE` SQLite constraint triggers enforcing non-negative salary/allowance, valid status enums, and valid date ranges.
- Hardened SQLite durability in `server/db.ts`: `PRAGMA foreign_keys = ON`, `PRAGMA journal_mode = WAL`, `PRAGMA synchronous = FULL`, configurable `SQLITE_BUSY_TIMEOUT_MS` and `SQLITE_WAL_AUTOCHECKPOINT`, filesystem directory/file read-write permission checks, `PRAGMA wal_checkpoint(TRUNCATE)` on graceful shutdown (`closeDatabaseSafely`), typed errors (`DatabaseUnavailableError`, `DatabaseMigrationError`, `DemoSeedForbiddenError`), and HTTP `503` (`DATABASE_UNAVAILABLE`) error handling across `/api/health` and Express error middleware.
- Enforced strict `APP_MODE` (`production` | `demo` | `test`) and persistent production storage validation in `server/env.ts`: `NODE_ENV=production` rejects `APP_MODE !== 'production'`, relative/`:memory:`/ephemeral-build-dir `DATABASE_PATH` (`dist/`, `build/`, `node_modules/`, `.git/`), and throws `DemoSeedForbiddenError` if demo seeding is attempted.
- Added authentic empty states in `src/components/AdminDashboardView.tsx` (Device Status) and `src/components/SystemAdminViews.tsx` (`DevicesView`) so fresh production deployments display authentic empty states until real records exist.
- Upgraded `POST /api/kiosk/punch` to run inside an atomic transaction recording `attendance_events` with idempotent `event_uid` replay protection (`200`, `duplicate_ignored`).

### Backup, Encryption, Recovery & Operational CLIs
- Implemented `server/backup.ts`: consistent online SQLite snapshots via `VACUUM INTO`, `PRAGMA integrity_check` + `PRAGMA foreign_key_check` verification, SHA-256 `.manifest.json`, optional **AES-256-GCM** (`scrypt` + `SVB1` header + random salt/IV + auth tag) offsite encryption via `BACKUP_ENCRYPTION_KEY`, retention pruning, restore dry-run drill, pre-restore `.bak` snapshot, automatic rollback on post-restore failure, and isolated migration rollback dry-run (`runMigrationRollbackDryRun`).
- Added Administrator-only (`backup:export`) endpoints in `server/api.ts` and UI controls in **System Settings -> Backup & Recovery** (`src/components/SystemAdminViews.tsx`): `GET /api/backup/status`, `POST /api/backup/snapshot`, `POST /api/backup/checkpoint`, and `POST /api/backup/verify-drill`.
- Added cross-platform CLI scripts: `scripts/db-migrate.ts` (`npm run db:migrate`), `scripts/db-backup.ts` (`npm run db:backup`), `scripts/db-restore.ts` (`npm run db:restore`), and `scripts/db-seed-demo.ts` (`npm run db:seed-demo`, strictly non-production sandbox only).
- Added `docs/BACKUP_AND_RECOVERY.md` documenting persistent storage permissions, WAL checkpointing, online encrypted backups, restore drills, proposed RPO/RTO targets (pending project owner approval), and an 8-step Legacy-Data Import Plan (explicitly acknowledging the original ZIP was WAL-only with zero fabricated records).
- Expanded automated test suites to 50 checks: 15 unit tests (`tests/unit.test.ts`), 10 DB durability/migration/backup/restore tests (`tests/db.test.ts`), 20 API/security/RBAC/backup-endpoint tests (`tests/api.test.ts`), and 5 isolated production startup/empty-state/auth smoke checks (`scripts/verify-startup.mjs`).

### Preserved
- Preserved all 16 approved reference screens, official SAVAGE-RSUCAJ emblem, sidebar navigation (no Admin Biometrics), BUILD 05 auth/CSRF/RBAC hardening, and live `./data/savage_rsucaj.db` intact.

## [1.3.0] — BUILD 05 (2026-11-20)

### Security & Authentication Hardening
- Eliminated hardcoded `admin` / `Admin@2025` fallback credentials (`server/db.ts`), deterministic fallback `SESSION_SECRET` (`server/auth.ts`), and credential prefill on the Login screen (`src/components/LoginView.tsx`).
- Implemented fail-secure startup validation (`server/env.ts`, `server.ts`): server aborts cleanly when `SESSION_SECRET` (<32 chars or placeholder) is missing, or when a fresh empty `users` table lacks `ADMIN_INITIAL_USERNAME`, `ADMIN_INITIAL_EMAIL`, and a strong `ADMIN_INITIAL_PASSWORD`.
- Added zero-downtime secret rotation (`SESSION_SECRET_PREVIOUS`) with automatic seamless cookie re-signing and forced initial password change (`must_change_password = 1`) enforced both server-side (`403 PASSWORD_CHANGE_REQUIRED`) and in `src/App.tsx`.
- Replaced stateless auth tokens and `localStorage`/`sessionStorage` token duplication with server-backed revocable `HttpOnly` sessions (`user_sessions` table, `savage_rsucaj_session` cookie) and double-submit CSRF protection (`savage_rsucaj_csrf` + `X-CSRF-Token` header + `Origin`/`Referer` allowlist).
- Added session fixation prevention on login, immediate server-side session revocation on logout, all-session invalidation on password change, sliding-window IP rate limiting, per-account brute-force lockout (`429 ACCOUNT_LOCKED` + `Retry-After`), HTTP security headers (`server/security.ts`), and audit trail logging.
- Visibly disabled unconfigured Google Sign-In and SMTP password reset controls (`GET /api/auth/config`, HTTP `503` on `/api/auth/forgot-password`); removed kiosk `api_token` from `/api/dashboard` payload.

### Added
- Server-side RBAC policy (`server/rbac.ts`) and idempotent transactional SQLite schema migrations (`schema_migrations`, migrations `001` & `002`) implementing 6 canonical roles (`Administrator`, `HR Officer`, `Payroll Officer`, `Department Head`, `Employee`, `Kiosk Device`) and 35 fine-grained permissions enforced independently across all 60 API routes (plus department/self scoping).
- Administrator Portal User & RBAC management endpoints (`GET/POST /api/users`, `PATCH /api/users/:id`) and UI table/modal inside **System Settings -> Security & Access**.
- Non-destructive existing admin account recovery CLI (`scripts/admin-recover.ts`, `npm run admin:recover`).
- Expanded automated verification to 37 checks: 13 unit tests (`tests/unit.test.ts`), 20 API/security/RBAC integration tests (`tests/api.test.ts`), and 4 isolated production startup smoke checks (`scripts/verify-startup.mjs`).

### Preserved
- Preserved all 16 approved UI screens, official SAVAGE-RSUCAJ emblem, sidebar navigation (no Admin Biometrics), cross-platform scripts, and existing `./data/savage_rsucaj.db` data intact.

## [1.2.0] — BUILD 04 (2026-11-20)

### Fixed
- Resolved genuine `npm ERESOLVE` dependency conflict between root `devDependencies.esbuild: "^0.25.0"` and `vite@8.3.8` (`peerOptional esbuild@"^0.27.0 || ^0.28.0"`) / `tsx@4.23.15` (`esbuild: "~0.28.0"`) by updating `esbuild` to `"^0.28.0"`.
- Fixed non-cross-platform npm scripts (`NODE_ENV=production tsx server.ts` and `rm -rf dist server.js`) that failed on Windows PowerShell/CMD by replacing them with pure Node.js ESM scripts (`scripts/start.mjs`, `scripts/clean.mjs`, `scripts/run-tsx.mjs`).
- Updated `server/auth.ts` to read `SESSION_SECRET` dynamically via `getSessionSecret()` instead of capturing it once before `dotenv` initialization.
- Added graceful `SIGINT`/`SIGTERM` shutdown in `server.ts` so HTTP listener, Vite middleware, and SQLite WAL database handles close cleanly on stop/restart.

### Added
- Committed `package-lock.json` and verified clean deterministic `npm ci` (0 vulnerabilities) with declared `engines` (`node: ^20.19.0 || >=22.12.0`, `npm: >=10.0.0`).
- Documented non-secret `.env.example` and implemented centralized startup & CLI environment validation (`server/env.ts`, `scripts/check-env.ts`, `npm run check:env` / `--strict`) with secret redaction.
- Added repeatable health and isolated production startup smoke verification (`scripts/healthcheck.mjs`, `scripts/verify-startup.mjs`, `npm run health`, `npm run test:startup`).
- Separated test suites into pure Unit Tests (`tests/unit.test.ts` — 8 cases), API/SQLite Integration Tests (`tests/api.test.ts` — 13 cases), Startup Smoke (`scripts/verify-startup.mjs` — 3 checks), and explicit honest status reporters (`npm run test:browser` -> `NOT TESTED`, `npm run test:hardware` -> `BLOCKED`) orchestrated by `scripts/run-tests.mjs`.
- Added engineering documentation: `docs/ARCHITECTURE.md`, `docs/RELEASE_CHECKLIST.md`, and `docs/TEST_INVENTORY.md`.

### Changed
- Updated `package.json` name (`savage-rsucaj-admin-portal`), version (`1.2.0`), and `metadata.json` portal title/description.
- Updated `GET /api/health` in `server/api.ts` to report `version: "1.2.0"`, `build: "BUILD 04"`, `uptimeSeconds`, and `timestamp` while keeping `status` and `database` backward-compatible.
- Preserved 100% of BUILD 03 UI components, 16 reference screens, official RSU emblem, employee IDs, and SQLite database files under `./data/`.

## [1.1.0] — BUILD 03 (2026-11-19)

### Changed
- Completed full 16-screen UI/UX migration aligning every Admin Web Portal screen (`01_Login` through `16_System_Settings`) to the newly uploaded approved 16-screen reference set while preserving all existing Express + SQLite backend functionality, authentication, and the official uploaded SAVAGE-RSUCAJ emblem.
- Upgraded shared layout shell (`src/components/ModuleFrame.tsx`, `src/App.tsx`, `src/index.css`) with sculpted emerald/gold `RsuBottomWave` borders, circular emerald module header badges, curved body shoulders, glossy emerald action buttons, reference-matched status pills, and reusable `ConfirmModal` dialogs for critical/destructive actions.
- Enhanced Dashboard & Notifications with checkboxes, selective mark-as-read, inline Approve actions for pending leave/correction items, pagination, and `Clear All` confirmation.
- Enhanced Employees Management with View Employee Profile Details modal, quick Activate/Deactivate toggle, and delete confirmation.
- Enhanced Attendance Records and Audit Logs with server-backed pagination (`page`, `limit`, `total`) and date/module filtering.
- Enhanced Leaves Management with real SQL-computed `Leave Balances` view (15 VL / 15 SL minus approved leave days).
- Enhanced Reports preview modal with live Date Range and Department filtering across all 6 report types.
- Enhanced Shifts & Schedules, Departments, Positions, Holidays, and Devices (Kiosk) with live search bars, edit/configuration modals, masked API tokens with copy button, and confirmation dialogs.
- Hardened `POST /api/notifications/mark-all-read` to sanitize selective `{ ids }` arrays to positive integers before SQL execution.
- Expanded `tests/api.test.ts` from 12 to 13 automated integration tests covering BUILD 03 API enhancements.

## [1.0.1] — BUILD 02 (2026-11-19)

### Changed
- Replaced the placeholder inline SVG crest in `src/components/SavageLogo.tsx` with the official uploaded SAVAGE-RSUCAJ emblem (`/assets/aistudio/SAVAGE-RSUCAJ_Smart_Attendance_Emblem_39488c28.png`) across the Login screen, Sidebar header, loading screen, About panel, and browser favicon.

## [1.0.0] — BUILD 01 (2026-11-19)

### Added
- Full-stack Express + Vite + SQLite (`better-sqlite3`) backend (`server.ts`, `server/db.ts`, `server/auth.ts`, `server/api.ts`).
- Reference-matched UI/UX implementation based on `SAVAGE-RSUCAJ_Smart_Attendance_Dashboard__3__71baa0e9.png`:
  - Institutional Login screen with custom SAVAGE-RSUCAJ SVG shield crest and emerald/gold waves.
  - Admin Dashboard with 6 KPI cards, Today's Attendance SVG Donut, Weekly Attendance Trend Bar Chart, Device Status, Recent Attendance, and Notifications feed.
  - Full CRUD & workflow modules: Employees (with CSV import/export), Departments, Positions, Shifts & Schedules, Holidays, Attendance Records, Corrections, Leaves, Payroll Processing (Compute -> Finalize -> Release + printable payslips), Reports (6 live reports + CSV/Print), Devices (Kiosk), Audit Logs, Notifications, and System Settings (with JSON backup export & password update).
- Token-authenticated hardware kiosk integration routes (`POST /api/kiosk/heartbeat`, `POST /api/kiosk/punch`).
- Automated Express + SQLite API integration test suite (`tests/api.test.ts` — 12 test cases).

### Security & Governance
- Enforced server-side `scrypt` password hashing and signed `HttpOnly` cookie sessions.
- Excluded the Admin Biometrics sidebar module per mandatory project directive.
