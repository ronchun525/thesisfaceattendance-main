/** Pure display-only shift selection: does not alter canonical punch/shift policy. */
import { addDaysIso, computeShiftWindow } from './attendanceEngine.ts';

export interface PriorOpenAttendance {
  date: string;
  time_in: string | null;
  time_out: string | null;
}

export function resolveEmployeeTodayShiftDate(
  nowMs: number,
  calendarDate: string,
  shift: { time_in: string; time_out: string },
  previous: PriorOpenAttendance | null,
  hasCurrentShiftRecord: boolean,
): string {
  if (hasCurrentShiftRecord || !previous?.time_in || previous.time_out) return calendarDate;
  if (previous.date !== addDaysIso(calendarDate, -1)) return calendarDate;
  const window = computeShiftWindow(previous.date, {
    id: 0, name: 'Employee display', time_in: shift.time_in,
    time_out: shift.time_out, grace_minutes: 0, status: 'Active',
  });
  return nowMs >= window.scheduledStartUtc && nowMs <= window.finalTimeOutCutoffUtc
    ? previous.date : calendarDate;
}
