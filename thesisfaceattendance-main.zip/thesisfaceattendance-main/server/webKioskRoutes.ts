import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { NextFunction, Request, Response, Router } from 'express';
import type Database from 'better-sqlite3';
import {
  AuthenticatedRequest,
  constantTimeEqualString,
  hashPassword,
  parseCookies,
  requirePermission,
  verifyPassword,
} from './auth.ts';
import { logAudit } from './db.ts';
import type { AppMode } from './env.ts';
import { formatManilaDateTime } from './auditHelpers.ts';
import { getClientIp, isRequestOriginAllowed, parsePositiveIntId, SlidingWindowRateLimiter } from './security.ts';
import { processKioskPunch, toManilaParts } from './attendanceEngine.ts';
import type { RealtimeHub } from './realtimeHub.ts';
import {
  BIOMETRIC_THRESHOLDS,
  encryptFaceEmbedding,
  inspectKioskModels,
  KIOSK_MODEL_SPECS,
  matchEmbeddingAgainstTemplates,
  resolveModelsDirectory,
  resolveTemplateEncryptionKey,
  validateL2NormalizedEmbedding,
  type KioskModelKey,
} from './webKioskBiometrics.ts';
import {
  evaluateMultiFrameBiometricEvidence,
  WEB_KIOSK_POLICY,
  type BiometricFrameEvidence,
} from './webKioskPolicy.ts';

export const KIOSK_SESSION_COOKIE_NAME = 'savage_kiosk_session';
const KIOSK_SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days (revocable anytime from Admin Portal)
const ADMIN_UNLOCK_TTL_MS = 10 * 60 * 1000; // 10 minutes per Admin PIN unlock
const CHALLENGE_TTL_MS = 30 * 1000; // 30 seconds single-use verification nonce
const ACTIVATION_CODE_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
const ADMIN_PIN_MAX_FAILURES = 5;
const ADMIN_PIN_LOCKOUT_MS = 15 * 60 * 1000;

interface WebKioskSessionRow {
  sid: string;
  device_id: number;
  csrf_token: string;
  admin_unlocked_until: number | null;
  admin_user_id: number | null;
  admin_username: string;
  created_at_utc: string;
  expires_at: number;
  revoked_at: string | null;
  revoked_reason: string | null;
}

interface WebKioskDeviceRow {
  id: number;
  name: string;
  device_type: string;
  model_info: string;
  ip_address: string;
  location: string;
  api_token: string;
  status: string;
  last_heartbeat: string;
  last_heartbeat_utc: string | null;
  last_sync_utc: string | null;
  last_sync_status: string;
  is_revoked: number;
  activation_code_hash: string;
  activation_code_expires_at: string | null;
  activation_code_used_at: string | null;
  face_capture_enabled: number;
  voice_prompt_enabled: number;
  liveness_enforced: number;
  camera_health: string;
  model_readiness_json: string;
  kiosk_app_version: string;
}

export interface WebKioskRouteDeps {
  db: () => Database.Database;
  appMode: AppMode;
  nowMs: () => number;
  realtimeHub: RealtimeHub;
  broadcastDeviceTelemetryById: (deviceId: number) => void;
  rateLimit: (req: Request, res: Response, next: NextFunction) => void;
}

function getSigningSecret(): string {
  const s = (process.env.SESSION_SECRET || '').trim();
  if (s.length >= 16) return s;
  return 'savage-dev-kiosk-ephemeral-signing-fallback';
}

function signKioskSessionId(sid: string): string {
  const sig = crypto.createHmac('sha256', getSigningSecret()).update(`web-kiosk:${sid}`).digest('base64url');
  return `${sid}.${sig}`;
}

function verifySignedKioskCookie(raw: string | undefined): string | null {
  if (!raw || typeof raw !== 'string') return null;
  const idx = raw.lastIndexOf('.');
  if (idx <= 0) return null;
  const sid = raw.slice(0, idx);
  const sig = raw.slice(idx + 1);
  if (!sid || !sig) return null;
  const expected = crypto.createHmac('sha256', getSigningSecret()).update(`web-kiosk:${sid}`).digest('base64url');
  return constantTimeEqualString(sig, expected) ? sid : null;
}

function isRequestHttps(req: Request): boolean {
  if (req.secure) return true;
  const proto = req.headers['x-forwarded-proto'];
  if (typeof proto === 'string' && proto.split(',')[0].trim().toLowerCase() === 'https') {
    return true;
  }
  return false;
}

function setKioskSessionCookie(req: Request, res: Response, sid: string): void {
  const parts = [
    `${KIOSK_SESSION_COOKIE_NAME}=${encodeURIComponent(signKioskSessionId(sid))}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    `Max-Age=${Math.floor(KIOSK_SESSION_TTL_MS / 1000)}`,
  ];
  if (isRequestHttps(req) || process.env.NODE_ENV === 'production') {
    parts.push('Secure');
  }
  res.setHeader('Set-Cookie', parts.join('; '));
}

function clearKioskSessionCookie(req: Request, res: Response): void {
  const parts = [
    `${KIOSK_SESSION_COOKIE_NAME}=`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    'Max-Age=0',
  ];
  if (isRequestHttps(req) || process.env.NODE_ENV === 'production') {
    parts.push('Secure');
  }
  res.setHeader('Set-Cookie', parts.join('; '));
}

function sha256Hex(value: string): string {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function normalizeActivationCode(code: string): string {
  return code.trim().toUpperCase().replace(/\s+/g, '');
}

function generateActivationCode(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = crypto.randomBytes(8);
  let out = '';
  for (let i = 0; i < 8; i++) {
    out += alphabet[bytes[i] % alphabet.length];
    if (i === 3) out += '-';
  }
  return `RSU-${out}`;
}

function readSetting(db: Database.Database, key: string): string {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as { value: string } | undefined;
  return row ? String(row.value) : '';
}

function writeSetting(db: Database.Database, key: string, value: string, category = 'security'): void {
  db.prepare(
    `INSERT INTO settings (key, value, category) VALUES (?, ?, ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value`
  ).run(key, value, category);
}

function loadActiveKioskContext(
  db: Database.Database,
  req: Request,
  nowMs: number
): { session: WebKioskSessionRow; device: WebKioskDeviceRow } | null {
  const cookies = parseCookies(req.headers.cookie);
  const sid = verifySignedKioskCookie(cookies[KIOSK_SESSION_COOKIE_NAME]);
  if (!sid) return null;

  const session = db
    .prepare(
      `SELECT sid, device_id, csrf_token, admin_unlocked_until, admin_user_id, admin_username,
              created_at_utc, expires_at, revoked_at, revoked_reason
       FROM web_kiosk_sessions
       WHERE sid = ?`
    )
    .get(sid) as WebKioskSessionRow | undefined;

  if (!session || session.revoked_at || session.expires_at <= nowMs) {
    return null;
  }

  const device = db
    .prepare(
      `SELECT id, name, device_type, model_info, ip_address, location, api_token, status,
              last_heartbeat, last_heartbeat_utc, last_sync_utc, last_sync_status, is_revoked,
              activation_code_hash, activation_code_expires_at, activation_code_used_at,
              face_capture_enabled, voice_prompt_enabled, liveness_enforced,
              camera_health, model_readiness_json, kiosk_app_version
       FROM devices
       WHERE id = ?`
    )
    .get(session.device_id) as WebKioskDeviceRow | undefined;

  if (!device || device.is_revoked === 1) {
    return null;
  }

  return { session, device };
}

function verifyKioskCsrf(req: Request, session: WebKioskSessionRow): boolean {
  if (!isRequestOriginAllowed(req)) return false;
  const headerToken = typeof req.headers['x-kiosk-csrf'] === 'string' ? req.headers['x-kiosk-csrf'].trim() : '';
  if (!headerToken) return false;
  return constantTimeEqualString(headerToken, session.csrf_token);
}

function consumeSingleUseChallenge(
  db: Database.Database,
  deviceId: number,
  nonce: unknown,
  scope: 'ATTENDANCE' | 'ENROLLMENT',
  nowMs: number
): { ok: true } | { ok: false; status: number; code: string; error: string } {
  if (typeof nonce !== 'string' || !/^[0-9a-fA-F]{32,128}$/.test(nonce.trim())) {
    return { ok: false, status: 400, code: 'INVALID_CHALLENGE_NONCE', error: 'A valid single-use challenge nonce is required.' };
  }
  const cleanNonce = nonce.trim().toLowerCase();
  const existing = db
    .prepare(
      `SELECT nonce, device_id, action_scope, expires_at_ms, used_at_ms
       FROM web_kiosk_challenges
       WHERE nonce = ?`
    )
    .get(cleanNonce) as
    | { nonce: string; device_id: number; action_scope: string; expires_at_ms: number; used_at_ms: number | null }
    | undefined;

  if (!existing || existing.device_id !== deviceId || existing.action_scope !== scope) {
    return { ok: false, status: 403, code: 'CHALLENGE_NOT_FOUND', error: 'Verification challenge is invalid for this device.' };
  }
  if (existing.used_at_ms !== null) {
    return { ok: false, status: 409, code: 'NONCE_ALREADY_USED', error: 'Verification challenge nonce has already been consumed.' };
  }
  if (existing.expires_at_ms < nowMs) {
    return { ok: false, status: 410, code: 'NONCE_EXPIRED', error: 'Verification challenge expired. Please scan again.' };
  }

  const updateInfo = db
    .prepare(
      `UPDATE web_kiosk_challenges
       SET used_at_ms = ?
       WHERE nonce = ? AND device_id = ? AND action_scope = ? AND used_at_ms IS NULL AND expires_at_ms >= ?`
    )
    .run(nowMs, cleanNonce, deviceId, scope, nowMs);

  if (updateInfo.changes !== 1) {
    return { ok: false, status: 409, code: 'NONCE_ALREADY_USED', error: 'Verification challenge nonce was concurrently consumed.' };
  }
  return { ok: true };
}

function buildDeviceSessionPayload(
  db: Database.Database,
  device: WebKioskDeviceRow,
  session: WebKioskSessionRow,
  appMode: AppMode,
  nowMs: number
) {
  const models = inspectKioskModels();
  const adminUnlocked = Boolean(session.admin_unlocked_until && session.admin_unlocked_until > nowMs);
  const adminPinConfigured = Boolean(readSetting(db, 'kiosk_admin_pin_hash').trim());
  const requireServerAttestation =
    appMode === 'production' || readSetting(db, 'kiosk_require_server_biometric_attestation') !== 'false';
  const productionAttendanceBlocked = appMode === 'production' && !models.production_attendance_ready;

  const enrolledCountRow = db
    .prepare(
      `SELECT COUNT(*) AS cnt
       FROM kiosk_face_templates t
       JOIN employees e ON e.id = t.employee_id
       WHERE e.status = 'Active'`
    )
    .get() as { cnt: number };

  return {
    activated: true,
    csrf_token: session.csrf_token,
    app_mode: appMode,
    device: {
      id: device.id,
      device_code: `KIOSK-${String(device.id).padStart(4, '0')}`,
      name: device.name,
      device_type: device.device_type,
      model_info: device.model_info,
      location: device.location,
      status: device.is_revoked ? 'Revoked' : 'Online',
      last_heartbeat: device.last_heartbeat,
      last_heartbeat_utc: device.last_heartbeat_utc,
      last_sync_utc: device.last_sync_utc,
      last_sync_display: device.last_sync_utc ? formatManilaDateTime(Date.parse(device.last_sync_utc)) : 'Never',
      version: device.kiosk_app_version || 'v5.0.0 (Web)',
      camera_health: device.camera_health || 'unknown',
    },
    settings: {
      face_capture_enabled: device.face_capture_enabled === 1,
      liveness_enforced: appMode === 'production' ? true : device.liveness_enforced === 1,
      liveness_locked_by_policy: appMode === 'production',
      voice_prompt_enabled: device.voice_prompt_enabled === 1,
    },
    admin_unlocked: adminUnlocked,
    admin_unlocked_until: adminUnlocked ? session.admin_unlocked_until : null,
    admin_pin_configured: adminPinConfigured,
    enrolled_employee_count: Number(enrolledCountRow?.cnt || 0),
    models,
    biometric_policy: {
      require_server_biometric_attestation: requireServerAttestation,
      production_attendance_blocked: productionAttendanceBlocked,
      production_block_reason: productionAttendanceBlocked
        ? 'Official production biometric attendance is fail-closed until verified TFLite model binaries and server-side biometric attestation are deployed.'
        : null,
      calibration_status: WEB_KIOSK_POLICY.calibration_status,
      certified_for_production: WEB_KIOSK_POLICY.certified_for_production,
      aggregation_rule: WEB_KIOSK_POLICY.multi_frame.aggregation_rule,
      thresholds: BIOMETRIC_THRESHOLDS,
    },
    server_time_utc: new Date(nowMs).toISOString(),
  };
}

/**
 * Public & Kiosk-Cookie Authenticated Routes — mounted BEFORE user session `requireAuth`.
 */
export function registerWebKioskPublicRoutes(router: Router, deps: WebKioskRouteDeps): void {
  const pinRateLimiter = new SlidingWindowRateLimiter({
    maxRequests: 15,
    windowMs: 60_000,
    message: 'Too many Administrator PIN attempts. Please wait a minute and try again.',
  });
  const activateRateLimiter = new SlidingWindowRateLimiter({
    maxRequests: 20,
    windowMs: 60_000,
    message: 'Too many device activation attempts. Please wait a minute and try again.',
  });

  // 1. Model Readiness Inspection, Policy Contract & Verified Binary Serving
  router.get('/kiosk/web/policy', (_req, res) => {
    const models = inspectKioskModels();
    res.json({
      app_mode: deps.appMode,
      policy: WEB_KIOSK_POLICY,
      models,
      production_attendance_blocked: deps.appMode === 'production' && !models.production_attendance_ready,
    });
  });

  router.get('/kiosk/web/models/status', (_req, res) => {
    const inspection = inspectKioskModels();
    res.json({
      app_mode: deps.appMode,
      ...inspection,
    });
  });

  router.get('/kiosk/web/models/:filename', (req, res) => {
    const filename = String(req.params.filename || '').trim();
    const spec = Object.values(KIOSK_MODEL_SPECS).find((s) => s.filename === filename);
    if (!spec) {
      res.status(404).json({ error: 'Unknown kiosk model artifact.', code: 'UNKNOWN_MODEL' });
      return;
    }
    const inspection = inspectKioskModels();
    const info = inspection.models[spec.key as KioskModelKey];
    if (info.status !== 'VERIFIED_ON_DISK') {
      res.status(404).json({
        error: info.reason,
        code: `MODEL_${info.status}`,
        expected_sha256: spec.expectedSha256,
      });
      return;
    }
    const fullPath = path.join(resolveModelsDirectory(), spec.filename);
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('X-Model-Sha256', spec.expectedSha256);
    res.setHeader('Cache-Control', 'public, max-age=86400');
    fs.createReadStream(fullPath).pipe(res);
  });

  // 2. Current Kiosk Device Session Probe
  router.get('/kiosk/web/session', (req, res) => {
    const db = deps.db();
    const nowMs = deps.nowMs();
    const ctx = loadActiveKioskContext(db, req, nowMs);
    if (!ctx) {
      const models = inspectKioskModels();
      res.json({
        activated: false,
        app_mode: deps.appMode,
        models,
        server_time_utc: new Date(nowMs).toISOString(),
      });
      return;
    }
    res.json(buildDeviceSessionPayload(db, ctx.device, ctx.session, deps.appMode, nowMs));
  });

  // 3. One-Time Device Code Activation -> HttpOnly Kiosk Session Cookie (never sends raw api_token to browser)
  router.post(
    '/kiosk/web/activate',
    activateRateLimiter.middleware((req) => getClientIp(req)),
    (req, res) => {
      if (!isRequestOriginAllowed(req)) {
        res.status(403).json({ error: 'Cross-origin activation request blocked.', code: 'ORIGIN_BLOCKED' });
        return;
      }
      const db = deps.db();
      const nowMs = deps.nowMs();
      const rawCode = typeof req.body?.device_code === 'string' ? req.body.device_code : '';
      const normalizedCode = normalizeActivationCode(rawCode);
      if (normalizedCode.length < 6) {
        res.status(400).json({ error: 'Please enter a valid device activation code.', code: 'INVALID_ACTIVATION_CODE' });
        return;
      }

      const codeHash = sha256Hex(normalizedCode);
      const device = db
        .prepare(
          `SELECT id, name, device_type, model_info, ip_address, location, api_token, status,
                  last_heartbeat, last_heartbeat_utc, last_sync_utc, last_sync_status, is_revoked,
                  activation_code_hash, activation_code_expires_at, activation_code_used_at,
                  face_capture_enabled, voice_prompt_enabled, liveness_enforced,
                  camera_health, model_readiness_json, kiosk_app_version
           FROM devices
           WHERE activation_code_hash = ?`
        )
        .get(codeHash) as WebKioskDeviceRow | undefined;

      if (!device) {
        logAudit(db, 'web-kiosk', 'Rejected Web Kiosk activation with unrecognized device code', 'Devices', 'Warning', getClientIp(req));
        res.status(401).json({ error: 'Invalid device activation code. Contact your Administrator.', code: 'ACTIVATION_CODE_INVALID' });
        return;
      }
      if (device.is_revoked === 1) {
        logAudit(db, device.name, 'Rejected Web Kiosk activation on revoked device', 'Devices', 'Warning', getClientIp(req));
        res.status(403).json({ error: 'This kiosk device has been revoked by an Administrator.', code: 'DEVICE_REVOKED' });
        return;
      }
      if (device.activation_code_used_at) {
        logAudit(db, device.name, 'Rejected replay of already-used Web Kiosk activation code', 'Devices', 'Warning', getClientIp(req));
        res.status(409).json({
          error: 'This activation code has already been used. Ask your Administrator to generate a new one.',
          code: 'ACTIVATION_CODE_USED',
        });
        return;
      }
      if (device.activation_code_expires_at && Date.parse(device.activation_code_expires_at) < nowMs) {
        res.status(410).json({
          error: 'This activation code has expired. Ask your Administrator to generate a new one.',
          code: 'ACTIVATION_CODE_EXPIRED',
        });
        return;
      }

      const nowIso = new Date(nowMs).toISOString();
      const manilaHeartbeat = formatManilaDateTime(nowMs);
      const sid = crypto.randomBytes(32).toString('hex');
      const csrfToken = crypto.randomBytes(24).toString('hex');
      const expiresAt = nowMs + KIOSK_SESSION_TTL_MS;

      const activateTx = db.transaction(() => {
        const consumed = db
          .prepare(
            `UPDATE devices
             SET activation_code_used_at = ?, status = 'Online', last_heartbeat = ?, last_heartbeat_utc = ?,
                 last_sync_utc = ?, last_sync_status = 'Synced', last_sync_error = ''
             WHERE id = ? AND activation_code_used_at IS NULL`
          )
          .run(nowIso, manilaHeartbeat, nowIso, nowIso, device.id);
        if (consumed.changes !== 1) {
          throw new Error('ACTIVATION_CODE_CONCURRENTLY_USED');
        }

        db.prepare(
          `INSERT INTO web_kiosk_sessions
            (sid, device_id, csrf_token, admin_unlocked_until, admin_user_id, admin_username,
             created_at_utc, expires_at, ip_address, user_agent)
           VALUES (?, ?, ?, NULL, NULL, '', ?, ?, ?, ?)`
        ).run(
          sid,
          device.id,
          csrfToken,
          nowIso,
          expiresAt,
          getClientIp(req),
          String(req.headers['user-agent'] || '').slice(0, 240)
        );
      });

      try {
        activateTx();
      } catch {
        res.status(409).json({ error: 'Activation code was already used.', code: 'ACTIVATION_CODE_USED' });
        return;
      }

      logAudit(db, device.name, `Activated Web Face Recognition Kiosk session for "${device.name}"`, 'Devices', 'Success', getClientIp(req), {
        actionType: 'WEB_KIOSK_ACTIVATED',
        targetType: 'device',
        targetId: device.id,
        isSecurityEvent: true,
      });

      deps.broadcastDeviceTelemetryById(device.id);
      setKioskSessionCookie(req, res, sid);

      const refreshedDevice = db
        .prepare(
          `SELECT id, name, device_type, model_info, ip_address, location, api_token, status,
                  last_heartbeat, last_heartbeat_utc, last_sync_utc, last_sync_status, is_revoked,
                  activation_code_hash, activation_code_expires_at, activation_code_used_at,
                  face_capture_enabled, voice_prompt_enabled, liveness_enforced,
                  camera_health, model_readiness_json, kiosk_app_version
           FROM devices WHERE id = ?`
        )
        .get(device.id) as WebKioskDeviceRow;

      const sessionRow: WebKioskSessionRow = {
        sid,
        device_id: device.id,
        csrf_token: csrfToken,
        admin_unlocked_until: null,
        admin_user_id: null,
        admin_username: '',
        created_at_utc: nowIso,
        expires_at: expiresAt,
        revoked_at: null,
        revoked_reason: null,
      };

      res.status(200).json(buildDeviceSessionPayload(db, refreshedDevice, sessionRow, deps.appMode, nowMs));
    }
  );

  // 4. Deactivate Current Kiosk Browser Session
  router.post('/kiosk/web/deactivate', (req, res) => {
    const db = deps.db();
    const nowMs = deps.nowMs();
    const ctx = loadActiveKioskContext(db, req, nowMs);
    if (!ctx) {
      clearKioskSessionCookie(req, res);
      res.json({ success: true, deactivated: true });
      return;
    }
    if (!verifyKioskCsrf(req, ctx.session)) {
      res.status(403).json({ error: 'Invalid kiosk CSRF token.', code: 'CSRF_INVALID' });
      return;
    }
    if (!ctx.session.admin_unlocked_until || ctx.session.admin_unlocked_until <= nowMs) {
      res.status(403).json({ error: 'Administrator PIN unlock is required to deactivate this kiosk.', code: 'ADMIN_UNLOCK_REQUIRED' });
      return;
    }

    const nowIso = new Date(nowMs).toISOString();
    db.prepare(`UPDATE web_kiosk_sessions SET revoked_at = ?, revoked_reason = 'admin_deactivated' WHERE sid = ?`).run(
      nowIso,
      ctx.session.sid
    );
    logAudit(db, ctx.device.name, `Deactivated Web Kiosk session on "${ctx.device.name}"`, 'Devices', 'Warning', getClientIp(req), {
      actionType: 'WEB_KIOSK_DEACTIVATED',
      targetType: 'device',
      targetId: ctx.device.id,
      isSecurityEvent: true,
    });
    clearKioskSessionCookie(req, res);
    res.json({ success: true, deactivated: true });
  });

  // 5. Real Heartbeat & Telemetry Update
  router.post('/kiosk/web/heartbeat', deps.rateLimit, (req, res) => {
    const db = deps.db();
    const nowMs = deps.nowMs();
    const ctx = loadActiveKioskContext(db, req, nowMs);
    if (!ctx) {
      res.status(401).json({ error: 'Kiosk device session is not active or has been revoked.', code: 'KIOSK_SESSION_INVALID' });
      return;
    }
    if (!verifyKioskCsrf(req, ctx.session)) {
      res.status(403).json({ error: 'Invalid kiosk CSRF token.', code: 'CSRF_INVALID' });
      return;
    }

    const cameraHealth = typeof req.body?.camera_health === 'string' ? req.body.camera_health.slice(0, 64) : ctx.device.camera_health;
    const modelReadinessJson =
      req.body?.model_readiness && typeof req.body.model_readiness === 'object'
        ? JSON.stringify(req.body.model_readiness).slice(0, 2000)
        : ctx.device.model_readiness_json;

    const nowIso = new Date(nowMs).toISOString();
    const manilaHeartbeat = formatManilaDateTime(nowMs);
    db.prepare(
      `UPDATE devices
       SET status = 'Online', last_heartbeat = ?, last_heartbeat_utc = ?,
           camera_health = ?, model_readiness_json = ?
       WHERE id = ?`
    ).run(manilaHeartbeat, nowIso, cameraHealth, modelReadinessJson, ctx.device.id);

    deps.broadcastDeviceTelemetryById(ctx.device.id);
    res.json({
      ok: true,
      status: 'Online',
      last_heartbeat: manilaHeartbeat,
      last_heartbeat_utc: nowIso,
      server_time_utc: nowIso,
    });
  });

  // 6. Real Sync Now Action (Never fakes sync — verifies DB connectivity, refreshes metadata & records last_sync_utc)
  router.post('/kiosk/web/sync', deps.rateLimit, (req, res) => {
    const db = deps.db();
    const nowMs = deps.nowMs();
    const ctx = loadActiveKioskContext(db, req, nowMs);
    if (!ctx) {
      res.status(401).json({ error: 'Kiosk device session is not active or has been revoked.', code: 'KIOSK_SESSION_INVALID' });
      return;
    }
    if (!verifyKioskCsrf(req, ctx.session)) {
      res.status(403).json({ error: 'Invalid kiosk CSRF token.', code: 'CSRF_INVALID' });
      return;
    }

    const nowIso = new Date(nowMs).toISOString();
    const manilaNow = formatManilaDateTime(nowMs);
    const enrolledCount = (
      db
        .prepare(
          `SELECT COUNT(*) AS cnt FROM kiosk_face_templates t JOIN employees e ON e.id = t.employee_id WHERE e.status = 'Active'`
        )
        .get() as { cnt: number }
    ).cnt;
    const activeEmployees = (
      db.prepare(`SELECT COUNT(*) AS cnt FROM employees WHERE status = 'Active'`).get() as { cnt: number }
    ).cnt;

    db.prepare(
      `UPDATE devices
       SET status = 'Online', last_heartbeat = ?, last_heartbeat_utc = ?,
           last_sync_utc = ?, last_sync_status = 'Synced', last_sync_error = ''
       WHERE id = ?`
    ).run(manilaNow, nowIso, nowIso, ctx.device.id);

    logAudit(db, ctx.device.name, `Completed Web Kiosk manual sync (${enrolledCount}/${activeEmployees} enrolled)`, 'Devices', 'Success', getClientIp(req));
    deps.broadcastDeviceTelemetryById(ctx.device.id);

    res.json({
      ok: true,
      synced_at_utc: nowIso,
      last_sync_display: manilaNow,
      enrolled_employee_count: enrolledCount,
      active_employee_count: activeEmployees,
      models: inspectKioskModels(),
    });
  });

  // 7. Administrator PIN Unlock (Screen 09) — Backend scrypt verification + lockout
  router.post(
    '/kiosk/web/admin/unlock',
    pinRateLimiter.middleware((req) => getClientIp(req)),
    (req, res) => {
      const db = deps.db();
      const nowMs = deps.nowMs();
      const ctx = loadActiveKioskContext(db, req, nowMs);
      if (!ctx) {
        res.status(401).json({ error: 'Activate this kiosk device before unlocking Administrator mode.', code: 'KIOSK_SESSION_INVALID' });
        return;
      }
      if (!verifyKioskCsrf(req, ctx.session)) {
        res.status(403).json({ error: 'Invalid kiosk CSRF token.', code: 'CSRF_INVALID' });
        return;
      }

      const lockedUntilRaw = readSetting(db, 'kiosk_admin_pin_locked_until').trim();
      const lockedUntilMs = lockedUntilRaw ? Number(lockedUntilRaw) : 0;
      if (Number.isFinite(lockedUntilMs) && lockedUntilMs > nowMs) {
        const remainingSec = Math.ceil((lockedUntilMs - nowMs) / 1000);
        res.status(429).json({
          error: `Too many failed Admin PIN attempts. Try again in ${Math.ceil(remainingSec / 60)} minute(s).`,
          code: 'ADMIN_PIN_LOCKED',
          retry_after_seconds: remainingSec,
        });
        return;
      }

      const pinHash = readSetting(db, 'kiosk_admin_pin_hash').trim();
      const pinSalt = readSetting(db, 'kiosk_admin_pin_salt').trim();
      if (!pinHash || !pinSalt) {
        res.status(409).json({
          error: 'Kiosk Administrator PIN is not configured yet. Configure it in Admin Portal → Devices (Kiosk).',
          code: 'ADMIN_PIN_NOT_CONFIGURED',
        });
        return;
      }

      const submittedPin = typeof req.body?.pin === 'string' ? req.body.pin.trim() : '';
      if (!/^\d{4,8}$/.test(submittedPin)) {
        res.status(400).json({ error: 'Enter a valid 4 to 8 digit Administrator PIN.', code: 'INVALID_PIN_FORMAT' });
        return;
      }

      const valid = verifyPassword(submittedPin, pinHash, pinSalt);
      if (!valid) {
        const prevFails = Number(readSetting(db, 'kiosk_admin_pin_failed_attempts') || '0') || 0;
        const nextFails = prevFails + 1;
        writeSetting(db, 'kiosk_admin_pin_failed_attempts', String(nextFails));
        let locked = false;
        if (nextFails >= ADMIN_PIN_MAX_FAILURES) {
          writeSetting(db, 'kiosk_admin_pin_locked_until', String(nowMs + ADMIN_PIN_LOCKOUT_MS));
          locked = true;
        }
        logAudit(
          db,
          ctx.device.name,
          `Failed Kiosk Administrator PIN attempt (${nextFails}/${ADMIN_PIN_MAX_FAILURES})${locked ? ' — LOCKED' : ''}`,
          'Security',
          'Warning',
          getClientIp(req),
          { actionType: 'KIOSK_ADMIN_PIN_FAILED', targetType: 'device', targetId: ctx.device.id, isSecurityEvent: true }
        );
        res.status(locked ? 429 : 401).json({
          error: locked
            ? 'Too many incorrect Admin PIN attempts. Kiosk Admin access is locked for 15 minutes.'
            : `Incorrect Administrator PIN. (${Math.max(0, ADMIN_PIN_MAX_FAILURES - nextFails)} attempt(s) remaining)`,
          code: locked ? 'ADMIN_PIN_LOCKED' : 'ADMIN_PIN_INVALID',
          attempts_remaining: Math.max(0, ADMIN_PIN_MAX_FAILURES - nextFails),
        });
        return;
      }

      const unlockedUntil = nowMs + ADMIN_UNLOCK_TTL_MS;
      writeSetting(db, 'kiosk_admin_pin_failed_attempts', '0');
      writeSetting(db, 'kiosk_admin_pin_locked_until', '');
      db.prepare(`UPDATE web_kiosk_sessions SET admin_unlocked_until = ?, admin_username = 'kiosk-admin-pin' WHERE sid = ?`).run(
        unlockedUntil,
        ctx.session.sid
      );

      logAudit(db, ctx.device.name, `Unlocked Kiosk Administrator mode on "${ctx.device.name}"`, 'Security', 'Success', getClientIp(req), {
        actionType: 'KIOSK_ADMIN_UNLOCKED',
        targetType: 'device',
        targetId: ctx.device.id,
        isSecurityEvent: true,
      });

      res.json({
        unlocked: true,
        admin_unlocked_until: unlockedUntil,
        expires_in_seconds: Math.floor(ADMIN_UNLOCK_TTL_MS / 1000),
      });
    }
  );

  router.post('/kiosk/web/admin/lock', (req, res) => {
    const db = deps.db();
    const nowMs = deps.nowMs();
    const ctx = loadActiveKioskContext(db, req, nowMs);
    if (!ctx) {
      res.status(401).json({ error: 'Kiosk device session is not active.', code: 'KIOSK_SESSION_INVALID' });
      return;
    }
    if (!verifyKioskCsrf(req, ctx.session)) {
      res.status(403).json({ error: 'Invalid kiosk CSRF token.', code: 'CSRF_INVALID' });
      return;
    }
    db.prepare(`UPDATE web_kiosk_sessions SET admin_unlocked_until = NULL WHERE sid = ?`).run(ctx.session.sid);
    res.json({ unlocked: false });
  });

  // 8. Persisted Kiosk Settings (Screen 14) — Requires Admin Unlock
  router.patch('/kiosk/web/settings', (req, res) => {
    const db = deps.db();
    const nowMs = deps.nowMs();
    const ctx = loadActiveKioskContext(db, req, nowMs);
    if (!ctx) {
      res.status(401).json({ error: 'Kiosk device session is not active.', code: 'KIOSK_SESSION_INVALID' });
      return;
    }
    if (!verifyKioskCsrf(req, ctx.session)) {
      res.status(403).json({ error: 'Invalid kiosk CSRF token.', code: 'CSRF_INVALID' });
      return;
    }
    if (!ctx.session.admin_unlocked_until || ctx.session.admin_unlocked_until <= nowMs) {
      res.status(403).json({ error: 'Administrator PIN unlock is required to change kiosk settings.', code: 'ADMIN_UNLOCK_REQUIRED' });
      return;
    }

    const body = req.body || {};
    let nextFaceCapture = ctx.device.face_capture_enabled === 1;
    let nextVoicePrompt = ctx.device.voice_prompt_enabled === 1;
    let nextLiveness = ctx.device.liveness_enforced === 1;

    if (typeof body.face_capture_enabled === 'boolean') {
      nextFaceCapture = body.face_capture_enabled;
    }
    if (typeof body.voice_prompt_enabled === 'boolean') {
      nextVoicePrompt = body.voice_prompt_enabled;
    }
    if (typeof body.liveness_enforced === 'boolean') {
      if (deps.appMode === 'production' && body.liveness_enforced === false) {
        res.status(403).json({
          error: 'Liveness / Anti-Spoofing enforcement cannot be disabled in production mode.',
          code: 'LIVENESS_ENFORCEMENT_LOCKED',
        });
        return;
      }
      nextLiveness = body.liveness_enforced;
    }

    db.prepare(
      `UPDATE devices
       SET face_capture_enabled = ?, voice_prompt_enabled = ?, liveness_enforced = ?
       WHERE id = ?`
    ).run(nextFaceCapture ? 1 : 0, nextVoicePrompt ? 1 : 0, nextLiveness ? 1 : 0, ctx.device.id);

    logAudit(
      db,
      ctx.device.name,
      `Updated Web Kiosk settings (face_capture=${nextFaceCapture}, liveness=${nextLiveness}, voice=${nextVoicePrompt})`,
      'Devices',
      'Success',
      getClientIp(req),
      {
        actionType: 'WEB_KIOSK_SETTINGS_UPDATED',
        targetType: 'device',
        targetId: ctx.device.id,
        after: { face_capture_enabled: nextFaceCapture, liveness_enforced: nextLiveness, voice_prompt_enabled: nextVoicePrompt },
        isSecurityEvent: true,
      }
    );

    res.json({
      ok: true,
      settings: {
        face_capture_enabled: nextFaceCapture,
        liveness_enforced: deps.appMode === 'production' ? true : nextLiveness,
        liveness_locked_by_policy: deps.appMode === 'production',
        voice_prompt_enabled: nextVoicePrompt,
      },
    });
  });

  // 9. Active Employees List for Enrollment (Screen 10) — Strictly Requires Admin Unlock
  router.get('/kiosk/web/employees', (req, res) => {
    const db = deps.db();
    const nowMs = deps.nowMs();
    const ctx = loadActiveKioskContext(db, req, nowMs);
    if (!ctx) {
      res.status(401).json({ error: 'Kiosk device session is not active.', code: 'KIOSK_SESSION_INVALID' });
      return;
    }
    if (!ctx.session.admin_unlocked_until || ctx.session.admin_unlocked_until <= nowMs) {
      res.status(403).json({ error: 'Administrator authorization is required to view employee enrollment list.', code: 'ADMIN_UNLOCK_REQUIRED' });
      return;
    }

    const search = typeof req.query.q === 'string' ? req.query.q.trim().toLowerCase() : '';
    const rows = db
      .prepare(
        `SELECT e.id, e.employee_code, e.full_name, e.status,
                COALESCE(d.name, '') AS department_name,
                COALESCE(p.name, '') AS position_name,
                t.enrolled_at_utc,
                t.template_sha256
         FROM employees e
         LEFT JOIN departments d ON d.id = e.department_id
         LEFT JOIN positions p ON p.id = e.position_id
         LEFT JOIN kiosk_face_templates t ON t.employee_id = e.id
         WHERE e.status = 'Active'
         ORDER BY e.employee_code ASC`
      )
      .all() as Array<{
      id: number;
      employee_code: string;
      full_name: string;
      status: string;
      department_name: string;
      position_name: string;
      enrolled_at_utc: string | null;
      template_sha256: string | null;
    }>;

    const filtered = search
      ? rows.filter(
          (r) =>
            r.employee_code.toLowerCase().includes(search) ||
            r.full_name.toLowerCase().includes(search) ||
            r.department_name.toLowerCase().includes(search)
        )
      : rows;

    res.json({
      data: filtered.map((r) => ({
        id: r.id,
        employee_code: r.employee_code,
        full_name: r.full_name,
        department: r.department_name,
        position: r.position_name,
        is_face_enrolled: Boolean(r.enrolled_at_utc),
        enrolled_at_utc: r.enrolled_at_utc,
      })),
    });
  });

  // 10. Single-Use Expiring Verification Challenge Nonce
  router.post('/kiosk/web/challenge', deps.rateLimit, (req, res) => {
    const db = deps.db();
    const nowMs = deps.nowMs();
    const ctx = loadActiveKioskContext(db, req, nowMs);
    if (!ctx) {
      res.status(401).json({ error: 'Kiosk device session is not active.', code: 'KIOSK_SESSION_INVALID' });
      return;
    }
    if (!verifyKioskCsrf(req, ctx.session)) {
      res.status(403).json({ error: 'Invalid kiosk CSRF token.', code: 'CSRF_INVALID' });
      return;
    }

    const scopeRaw = String(req.body?.scope || 'ATTENDANCE').trim().toUpperCase();
    const scope: 'ATTENDANCE' | 'ENROLLMENT' = scopeRaw === 'ENROLLMENT' ? 'ENROLLMENT' : 'ATTENDANCE';

    if (scope === 'ENROLLMENT' && (!ctx.session.admin_unlocked_until || ctx.session.admin_unlocked_until <= nowMs)) {
      res.status(403).json({ error: 'Administrator authorization is required for enrollment challenges.', code: 'ADMIN_UNLOCK_REQUIRED' });
      return;
    }

    // Prune expired challenges opportunistically
    db.prepare(`DELETE FROM web_kiosk_challenges WHERE expires_at_ms < ?`).run(nowMs - 60_000);

    const nonce = crypto.randomBytes(24).toString('hex');
    const expiresAtMs = nowMs + CHALLENGE_TTL_MS;
    db.prepare(
      `INSERT INTO web_kiosk_challenges (nonce, device_id, action_scope, created_at_ms, expires_at_ms)
       VALUES (?, ?, ?, ?, ?)`
    ).run(nonce, ctx.device.id, scope, nowMs, expiresAtMs);

    res.status(201).json({
      challenge_nonce: nonce,
      scope,
      expires_at_ms: expiresAtMs,
      ttl_seconds: Math.floor(CHALLENGE_TTL_MS / 1000),
    });
  });

  // 11. Front-Facing Touchless Auto-Enrollment Persistence (Screens 11 -> 12 -> 13)
  router.post('/kiosk/web/enroll', deps.rateLimit, (req, res) => {
    const db = deps.db();
    const nowMs = deps.nowMs();
    const ctx = loadActiveKioskContext(db, req, nowMs);
    if (!ctx) {
      res.status(401).json({ error: 'Kiosk device session is not active.', code: 'KIOSK_SESSION_INVALID' });
      return;
    }
    if (!verifyKioskCsrf(req, ctx.session)) {
      res.status(403).json({ error: 'Invalid kiosk CSRF token.', code: 'CSRF_INVALID' });
      return;
    }
    if (!ctx.session.admin_unlocked_until || ctx.session.admin_unlocked_until <= nowMs) {
      res.status(403).json({
        error: 'Administrator PIN authorization is required before enrolling any employee.',
        code: 'ADMIN_UNLOCK_REQUIRED',
      });
      return;
    }

    // Fail-closed in production when verified TFLite inference is not deployed
    const models = inspectKioskModels();
    if (deps.appMode === 'production' && !models.production_attendance_ready) {
      res.status(503).json({
        error: 'Production biometric enrollment is blocked until verified TFLite model binaries and server-side biometric attestation are deployed.',
        code: 'PRODUCTION_BIOMETRIC_ATTESTATION_BLOCKED',
        blocking_reasons: models.blocking_reasons,
      });
      return;
    }

    const challengeCheck = consumeSingleUseChallenge(db, ctx.device.id, req.body?.challenge_nonce, 'ENROLLMENT', nowMs);
    if (!challengeCheck.ok) {
      res.status(challengeCheck.status).json({ error: challengeCheck.error, code: challengeCheck.code });
      return;
    }

    const employeeId = Number(req.body?.employee_id);
    if (!Number.isSafeInteger(employeeId) || employeeId <= 0) {
      res.status(400).json({ error: 'A valid employee_id is required for enrollment.', code: 'INVALID_EMPLOYEE_ID' });
      return;
    }

    const employee = db
      .prepare(`SELECT id, employee_code, full_name, status FROM employees WHERE id = ?`)
      .get(employeeId) as { id: number; employee_code: string; full_name: string; status: string } | undefined;

    if (!employee) {
      res.status(404).json({ error: 'Selected employee was not found.', code: 'EMPLOYEE_NOT_FOUND' });
      return;
    }
    if (employee.status !== 'Active') {
      res.status(409).json({ error: 'Inactive employees cannot be enrolled.', code: 'EMPLOYEE_INACTIVE' });
      return;
    }

    // Enforce FRONT FACE ONLY multi-frame capture metadata (no left/right steps)
    if (req.body?.frontal_only !== true) {
      res.status(422).json({
        error: 'Enrollment must capture front-facing frames only.',
        code: 'FRONTAL_ONLY_REQUIRED',
      });
      return;
    }

    const enforceLiveness = deps.appMode === 'production' || ctx.device.liveness_enforced === 1;
    let detectionConfidence = Number(req.body?.detection_confidence);
    let qualityScore = Number(req.body?.quality_score);
    let livenessScore = Number(req.body?.liveness_score);
    let antiSpoofScore = Number(req.body?.anti_spoof_score);
    let capturedFrames = Number(req.body?.captured_frames || 0);

    // Preferred multi-frame evidence contract (anti-averaging per-frame floor + median + bbox stability)
    if (Array.isArray(req.body?.frames)) {
      const multiEval = evaluateMultiFrameBiometricEvidence(req.body.frames as BiometricFrameEvidence[], {
        enforceLiveness,
      });
      if (!multiEval.ok) {
        res.status(422).json({
          error: multiEval.error || 'Multi-frame biometric verification failed during enrollment.',
          code: multiEval.code || 'PAD_REJECTED',
        });
        return;
      }
      capturedFrames = multiEval.frame_count;
      detectionConfidence = multiEval.median_detection_confidence;
      qualityScore = multiEval.median_quality_score;
      livenessScore = multiEval.median_liveness_score;
      antiSpoofScore = multiEval.median_pad_score;
    } else {
      const frameTimestamps: unknown[] = Array.isArray(req.body?.frame_timestamps_ms) ? req.body.frame_timestamps_ms : [];
      capturedFrames = Number(req.body?.captured_frames || frameTimestamps.length);
      if (!Number.isInteger(capturedFrames) || capturedFrames < BIOMETRIC_THRESHOLDS.MIN_ENROLLMENT_FRAMES) {
        res.status(422).json({
          error: `At least ${BIOMETRIC_THRESHOLDS.MIN_ENROLLMENT_FRAMES} distinct frontal frames are required for touchless enrollment.`,
          code: 'INSUFFICIENT_ENROLLMENT_FRAMES',
        });
        return;
      }
      if (frameTimestamps.length >= BIOMETRIC_THRESHOLDS.MIN_ENROLLMENT_FRAMES) {
        let prevTs = -Infinity;
        for (const rawTs of frameTimestamps) {
          const ts = Number(rawTs);
          if (!Number.isFinite(ts) || ts <= prevTs) {
            res.status(422).json({
              error: 'Enrollment frames must be distinct sequential live captures (duplicate/frozen frames rejected).',
              code: 'FROZEN_FRAME',
            });
            return;
          }
          prevTs = ts;
        }
      }

      if (req.body?.face_count !== undefined) {
        const fc = Number(req.body.face_count);
        if (fc === 0) {
          res.status(422).json({ error: 'No face detected during enrollment.', code: 'NO_FACE' });
          return;
        }
        if (fc > 1) {
          res.status(422).json({ error: 'Multiple faces detected during enrollment.', code: 'MULTIPLE_FACES' });
          return;
        }
      }

      if (!Number.isFinite(detectionConfidence) || detectionConfidence < BIOMETRIC_THRESHOLDS.FACE_DETECTION_MIN_CONFIDENCE) {
        res.status(422).json({ error: 'Frontal face detection confidence below enrollment threshold.', code: 'NO_FACE' });
        return;
      }
      if (!Number.isFinite(qualityScore) || qualityScore < BIOMETRIC_THRESHOLDS.FACE_QUALITY_MIN_SCORE) {
        res.status(422).json({ error: 'Face image quality (lighting/sharpness/centering) below enrollment threshold.', code: 'BLURRY_IMAGE' });
        return;
      }
      if (enforceLiveness) {
        if (!Number.isFinite(antiSpoofScore) || antiSpoofScore < 0 || antiSpoofScore > 1) {
          res.status(422).json({ error: 'Invalid or non-finite PAD model output.', code: 'MODEL_ERROR' });
          return;
        }
        if (antiSpoofScore < BIOMETRIC_THRESHOLDS.ANTI_SPOOF_MIN_SCORE) {
          res.status(422).json({ error: 'Anti-spoofing (PAD) check failed during enrollment.', code: 'PAD_REJECTED' });
          return;
        }
        if (!Number.isFinite(livenessScore) || livenessScore < 0 || livenessScore > 1) {
          res.status(422).json({ error: 'Invalid or non-finite passive liveness model output.', code: 'MODEL_ERROR' });
          return;
        }
        if (livenessScore < BIOMETRIC_THRESHOLDS.LIVENESS_MIN_SCORE) {
          res.status(422).json({ error: 'Passive liveness verification failed during enrollment.', code: 'LIVENESS_UNVERIFIED' });
          return;
        }
      }
    }

    const embCheck = validateL2NormalizedEmbedding(req.body?.embedding);
    if (!embCheck.valid || !embCheck.embedding) {
      res.status(422).json({ error: embCheck.reason || 'Invalid face embedding vector.', code: 'INVALID_EMBEDDING' });
      return;
    }

    const resolvedKey = resolveTemplateEncryptionKey(deps.appMode);
    if (!resolvedKey) {
      res.status(503).json({
        error: 'KIOSK_TEMPLATE_ENCRYPTION_KEY (64 lowercase hex characters) must be configured for encrypted face enrollment.',
        code: 'ENROLLMENT_ENCRYPTION_UNCONFIGURED',
      });
      return;
    }

    // Check existing enrollment for this employee
    const existingOwn = db
      .prepare(`SELECT employee_id, enrolled_at_utc FROM kiosk_face_templates WHERE employee_id = ?`)
      .get(employee.id) as { employee_id: number; enrolled_at_utc: string } | undefined;

    if (existingOwn && req.body?.confirm_re_enroll !== true) {
      res.status(409).json({
        error: `${employee.full_name} (${employee.employee_code}) already has a registered face profile. Confirm re-enrollment to replace it.`,
        code: 'ALREADY_ENROLLED',
        enrolled_at_utc: existingOwn.enrolled_at_utc,
      });
      return;
    }

    // Server-side cross-employee duplicate-identity check
    const crossMatch = matchEmbeddingAgainstTemplates(
      db,
      resolvedKey.key,
      embCheck.embedding,
      BIOMETRIC_THRESHOLDS.DUPLICATE_IDENTITY_MIN_SIMILARITY,
      employee.id
    );
    if (crossMatch.matched) {
      logAudit(
        db,
        ctx.device.name,
        `Blocked duplicate cross-employee face enrollment for ${employee.employee_code} (matched existing ${crossMatch.employee_code}, sim=${crossMatch.similarity})`,
        'Security',
        'Warning',
        getClientIp(req),
        {
          actionType: 'KIOSK_ENROLLMENT_DUPLICATE_BLOCKED',
          targetType: 'employee',
          targetId: employee.id,
          isSecurityEvent: true,
        }
      );
      res.status(409).json({
        error: `This face matches an already enrolled employee (${crossMatch.employee_code}). Duplicate identity registration is blocked.`,
        code: 'CROSS_EMPLOYEE_DUPLICATE',
        matched_employee_code: crossMatch.employee_code,
        similarity: crossMatch.similarity,
      });
      return;
    }

    const encrypted = encryptFaceEmbedding(resolvedKey.key, employee.employee_code, embCheck.embedding);
    const enrolledAtUtc = new Date(nowMs).toISOString();

    db.prepare(
      `INSERT INTO kiosk_face_templates
        (employee_id, template_sha256, encrypted_embedding, iv_hex, tag_hex, device_id, enrolled_at_utc)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(employee_id) DO UPDATE SET
        template_sha256 = excluded.template_sha256,
        encrypted_embedding = excluded.encrypted_embedding,
        iv_hex = excluded.iv_hex,
        tag_hex = excluded.tag_hex,
        device_id = excluded.device_id,
        enrolled_at_utc = excluded.enrolled_at_utc`
    ).run(
      employee.id,
      encrypted.templateSha256,
      encrypted.encryptedEmbeddingB64,
      encrypted.ivHex,
      encrypted.tagHex,
      ctx.device.id,
      enrolledAtUtc
    );

    // Read-back confirmation from DB before claiming success
    const confirmed = db
      .prepare(`SELECT employee_id, template_sha256, enrolled_at_utc FROM kiosk_face_templates WHERE employee_id = ?`)
      .get(employee.id) as { employee_id: number; template_sha256: string; enrolled_at_utc: string } | undefined;

    if (!confirmed || confirmed.template_sha256 !== encrypted.templateSha256) {
      res.status(500).json({ error: 'Database read-back verification failed after enrollment write.', code: 'ENROLLMENT_PERSISTENCE_FAILED' });
      return;
    }

    logAudit(
      db,
      ctx.device.name,
      `${existingOwn ? 'Re-enrolled' : 'Enrolled'} frontal face template for ${employee.full_name} (${employee.employee_code}) via Web Kiosk`,
      'Employees',
      'Success',
      getClientIp(req),
      {
        actionType: existingOwn ? 'WEB_KIOSK_FACE_REENROLLED' : 'WEB_KIOSK_FACE_ENROLLED',
        targetType: 'employee',
        targetId: employee.id,
        after: {
          device_id: ctx.device.id,
          captured_frames: capturedFrames,
          template_sha256_prefix: confirmed.template_sha256.slice(0, 12),
          frontal_only: true,
        },
        isSecurityEvent: true,
      }
    );

    res.status(201).json({
      enrolled: true,
      backend_confirmed: true,
      re_enrolled: Boolean(existingOwn),
      employee: {
        id: employee.id,
        employee_code: employee.employee_code,
        full_name: employee.full_name,
      },
      template_sha256_prefix: confirmed.template_sha256.slice(0, 12),
      enrolled_at_utc: confirmed.enrolled_at_utc,
      ephemeral_dev_encryption_key: resolvedKey.ephemeralNonProduction,
    });
  });

  // 12. Attendance Verification & Recording (Screens 04 -> 05 / 06 / 07 / 08)
  // SECURITY: NEVER accepts client-asserted employee_id or match_verified!
  router.post('/kiosk/web/attendance', deps.rateLimit, (req, res) => {
    const db = deps.db();
    const nowMs = deps.nowMs();
    const ctx = loadActiveKioskContext(db, req, nowMs);
    if (!ctx) {
      res.status(401).json({ error: 'Kiosk device session is not active or has been revoked.', code: 'KIOSK_SESSION_INVALID' });
      return;
    }
    if (!verifyKioskCsrf(req, ctx.session)) {
      res.status(403).json({ error: 'Invalid kiosk CSRF token.', code: 'CSRF_INVALID' });
      return;
    }

    if (ctx.device.face_capture_enabled !== 1) {
      res.status(409).json({
        error: 'Face capture is currently disabled in Kiosk Settings.',
        code: 'FACE_CAPTURE_DISABLED',
        voice_cue: 'TRY_AGAIN',
      });
      return;
    }

    // Detect and log any attempt to pass client-asserted employee identity or success flags
    if (
      req.body?.employee_id !== undefined ||
      req.body?.employee_code !== undefined ||
      req.body?.match_verified !== undefined ||
      req.body?.success !== undefined
    ) {
      logAudit(
        db,
        ctx.device.name,
        'Ignored untrusted client-asserted identity/success fields on /api/kiosk/web/attendance',
        'Security',
        'Warning',
        getClientIp(req),
        { actionType: 'UNTRUSTED_CLIENT_BIOMETRIC_CLAIM_IGNORED', targetType: 'device', targetId: ctx.device.id, isSecurityEvent: true }
      );
    }

    // CRITICAL SECTION 8 GATE: Fail-closed in production when server biometric attestation is unavailable
    const models = inspectKioskModels();
    if (deps.appMode === 'production' && !models.production_attendance_ready) {
      res.status(503).json({
        error: 'Official production attendance via Web Kiosk is blocked until verified TFLite model binaries and server-side biometric attestation are deployed.',
        code: 'PRODUCTION_BIOMETRIC_ATTESTATION_BLOCKED',
        blocking_reasons: models.blocking_reasons,
        voice_cue: 'TRY_AGAIN',
      });
      return;
    }

    const challengeCheck = consumeSingleUseChallenge(db, ctx.device.id, req.body?.challenge_nonce, 'ATTENDANCE', nowMs);
    if (!challengeCheck.ok) {
      res.status(challengeCheck.status).json({
        error: challengeCheck.error,
        code: challengeCheck.code,
        voice_cue: 'TRY_AGAIN',
      });
      return;
    }

    const rawAction = String(req.body?.action || '').trim().toUpperCase();
    if (rawAction !== 'TIME_IN' && rawAction !== 'TIME_OUT') {
      res.status(400).json({ error: 'Explicit attendance action (TIME_IN or TIME_OUT) is required.', code: 'INVALID_ACTION', voice_cue: 'TRY_AGAIN' });
      return;
    }

    const enforceLiveness = deps.appMode === 'production' || ctx.device.liveness_enforced === 1;
    let detectionConfidence = Number(req.body?.detection_confidence);
    let qualityScore = Number(req.body?.quality_score);
    let livenessScore = Number(req.body?.liveness_score);
    let antiSpoofScore = Number(req.body?.anti_spoof_score);

    // Multi-frame PAD + passive liveness validation (anti-averaging per-frame floor + median + bbox stability)
    if (Array.isArray(req.body?.frames)) {
      const multiEval = evaluateMultiFrameBiometricEvidence(req.body.frames as BiometricFrameEvidence[], {
        enforceLiveness,
      });
      if (!multiEval.ok) {
        res.status(422).json({
          error: multiEval.error || 'Multi-frame biometric verification failed.',
          code: multiEval.code || 'PAD_REJECTED',
          voice_cue: 'TRY_AGAIN',
        });
        return;
      }
      detectionConfidence = multiEval.median_detection_confidence;
      qualityScore = multiEval.median_quality_score;
      livenessScore = multiEval.median_liveness_score;
      antiSpoofScore = multiEval.median_pad_score;
    } else {
      if (req.body?.face_count !== undefined) {
        const fc = Number(req.body.face_count);
        if (fc === 0) {
          res.status(422).json({ error: 'No face detected. Position your face inside the green frame.', code: 'NO_FACE', voice_cue: 'TRY_AGAIN' });
          return;
        }
        if (fc > 1) {
          res.status(422).json({ error: 'Multiple faces detected. Only one person at a time.', code: 'MULTIPLE_FACES', voice_cue: 'TRY_AGAIN' });
          return;
        }
      }

      if (!Number.isFinite(detectionConfidence) || detectionConfidence < BIOMETRIC_THRESHOLDS.FACE_DETECTION_MIN_CONFIDENCE) {
        res.status(422).json({ error: 'No valid frontal face detected. Please align your face inside the frame.', code: 'NO_FACE', voice_cue: 'TRY_AGAIN' });
        return;
      }
      if (!Number.isFinite(qualityScore) || qualityScore < BIOMETRIC_THRESHOLDS.FACE_QUALITY_MIN_SCORE) {
        res.status(422).json({ error: 'Face image quality is too low. Hold still with even lighting.', code: 'BLURRY_IMAGE', voice_cue: 'TRY_AGAIN' });
        return;
      }
      if (enforceLiveness) {
        if (!Number.isFinite(antiSpoofScore) || antiSpoofScore < 0 || antiSpoofScore > 1) {
          res.status(422).json({ error: 'PAD model output is malformed or non-finite.', code: 'MODEL_ERROR', voice_cue: 'TRY_AGAIN' });
          return;
        }
        if (antiSpoofScore < BIOMETRIC_THRESHOLDS.ANTI_SPOOF_MIN_SCORE) {
          res.status(422).json({ error: 'Anti-spoofing (PAD) check failed. Photos and screens are not allowed.', code: 'PAD_REJECTED', voice_cue: 'TRY_AGAIN' });
          return;
        }
        if (!Number.isFinite(livenessScore) || livenessScore < 0 || livenessScore > 1) {
          res.status(422).json({ error: 'Passive liveness model output is malformed or non-finite.', code: 'MODEL_ERROR', voice_cue: 'TRY_AGAIN' });
          return;
        }
        if (livenessScore < BIOMETRIC_THRESHOLDS.LIVENESS_MIN_SCORE) {
          res.status(422).json({ error: 'Passive liveness verification failed. Please look directly at the camera.', code: 'LIVENESS_UNVERIFIED', voice_cue: 'TRY_AGAIN' });
          return;
        }
      }
    }

    const embCheck = validateL2NormalizedEmbedding(req.body?.embedding);
    if (!embCheck.valid || !embCheck.embedding) {
      res.status(422).json({ error: embCheck.reason || 'Invalid face embedding.', code: 'MODEL_ERROR', voice_cue: 'TRY_AGAIN' });
      return;
    }

    const resolvedKey = resolveTemplateEncryptionKey(deps.appMode);
    if (!resolvedKey) {
      res.status(503).json({
        error: 'Kiosk template encryption key is not configured on the server.',
        code: 'ENROLLMENT_ENCRYPTION_UNCONFIGURED',
        voice_cue: 'TRY_AGAIN',
      });
      return;
    }

    // Server-side 1:N identity matching against encrypted enrolled templates
    const match = matchEmbeddingAgainstTemplates(
      db,
      resolvedKey.key,
      embCheck.embedding,
      BIOMETRIC_THRESHOLDS.RECOGNITION_MATCH_MIN_SIMILARITY
    );

    if (!match.matched || !match.employee_code || !match.employee_id) {
      logAudit(
        db,
        ctx.device.name,
        `Unmatched face scan on Web Kiosk (evaluated=${match.evaluated_templates}, best_sim=${match.similarity})`,
        'Attendance',
        'Warning',
        getClientIp(req)
      );
      res.status(404).json({
        error: 'Your face is not yet registered in the system. Please ask the administrator to enroll your face.',
        code: 'NOT_ENROLLED',
        voice_cue: 'TRY_AGAIN',
      });
      return;
    }

    const eventUid =
      typeof req.body?.idempotency_key === 'string' && req.body.idempotency_key.trim().length >= 8
        ? `webkiosk-${ctx.device.id}-${req.body.idempotency_key.trim().slice(0, 64)}`
        : `webkiosk-${ctx.device.id}-${crypto.randomUUID()}`;

    const evidenceDigest = sha256Hex(
      JSON.stringify({
        device_id: ctx.device.id,
        employee_code: match.employee_code,
        action: rawAction,
        similarity: match.similarity,
        liveness_score: livenessScore,
        anti_spoof_score: antiSpoofScore,
        now_ms: nowMs,
      })
    );

    const outcome = processKioskPunch(db, {
      device: ctx.device,
      employeeCode: match.employee_code,
      actionRaw: rawAction,
      eventUid,
      deviceTimestamp: new Date(nowMs).toISOString(),
      offlineReplay: false,
      clientIp: getClientIp(req),
      serverNowUtc: nowMs,
      biometricEvidenceHash: evidenceDigest,
      biometricBound: true,
      captureMetadataJson: JSON.stringify({
        source: 'web_kiosk_build36',
        device_id: ctx.device.id,
        similarity: match.similarity,
        detection_confidence: detectionConfidence,
        quality_score: qualityScore,
        liveness_score: livenessScore,
        anti_spoof_score: antiSpoofScore,
      }),
    });

    const nowIso = new Date(nowMs).toISOString();
    const manilaParts = toManilaParts(nowMs);

    if (outcome.statusCode === 200 || outcome.statusCode === 201) {
      db.prepare(
        `UPDATE devices SET status = 'Online', last_heartbeat = ?, last_heartbeat_utc = ?, last_sync_utc = ?, last_sync_status = 'Synced', last_sync_error = '' WHERE id = ?`
      ).run(formatManilaDateTime(nowMs), nowIso, nowIso, ctx.device.id);

      if (outcome.body.action !== 'duplicate_ignored' && typeof outcome.body.employee_id === 'number') {
        deps.realtimeHub.emitAttendanceUpdated({
          event_uid: String(outcome.body.event_uid || eventUid),
          employee_id: outcome.body.employee_id,
          employee_code: match.employee_code,
          department_id: typeof outcome.body.department_id === 'number' ? outcome.body.department_id : null,
          shift_date: String(outcome.body.shift_date || manilaParts.isoDate),
          action: String(outcome.body.action || rawAction.toLowerCase()),
          status: typeof outcome.body.status === 'string' ? outcome.body.status : undefined,
          time: typeof outcome.body.time === 'string' ? outcome.body.time : null,
          source: 'kiosk',
          offline_replay: false,
        });
      }
      deps.broadcastDeviceTelemetryById(ctx.device.id);

      res.status(200).json({
        recorded: true,
        backend_confirmed: true,
        code: 'RECORDED',
        action: rawAction,
        employee_id: match.employee_id,
        employee_code: match.employee_code,
        employee_name: match.full_name,
        shift_date: String(outcome.body.shift_date || manilaParts.isoDate),
        recorded_time: String(outcome.body.time || ''),
        status: String(outcome.body.status || 'Present'),
        similarity: match.similarity,
        event_uid: String(outcome.body.event_uid || eventUid),
        voice_cue: 'THANK_YOU',
      });
      return;
    }

    // Duplicate Time In / Time Out confirmed by backend attendance engine -> exact message "Already taken attendance"
    const outcomeCode = String(outcome.body.code || '');
    if (
      outcome.statusCode === 409 &&
      (outcomeCode === 'DUPLICATE_TIME_IN' || outcomeCode === 'DUPLICATE_TIME_OUT' || outcomeCode === 'DUPLICATE_PUNCH')
    ) {
      res.status(409).json({
        recorded: false,
        backend_confirmed: true,
        code: 'ALREADY_TAKEN',
        error: 'Already taken attendance',
        detail: String(outcome.body.error || 'Attendance for this action has already been recorded today.'),
        employee_name: match.full_name,
        action: rawAction,
        voice_cue: 'TRY_AGAIN',
      });
      return;
    }

    res.status(outcome.statusCode).json({
      recorded: false,
      backend_confirmed: true,
      code: outcomeCode || 'ATTENDANCE_REJECTED',
      error: String(outcome.body.error || 'Verification failed. Please try again.'),
      voice_cue: 'TRY_AGAIN',
    });
  });
}

/**
 * Admin-Authenticated Management Routes — mounted AFTER `router.use(requireAuth)`.
 */
export function registerWebKioskAdminRoutes(router: Router, deps: WebKioskRouteDeps): void {
  // Mint one-time Device Activation Code for a registered Kiosk Device
  router.post('/devices/:id/activation-code', requirePermission('devices:write'), (req: AuthenticatedRequest, res) => {
    const id = parsePositiveIntId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid device ID.' });
      return;
    }
    const db = deps.db();
    const nowMs = deps.nowMs();
    const device = db
      .prepare('SELECT id, name, is_revoked FROM devices WHERE id = ?')
      .get(id) as { id: number; name: string; is_revoked: number } | undefined;

    if (!device) {
      res.status(404).json({ error: 'Device not found.' });
      return;
    }
    if (device.is_revoked === 1) {
      res.status(409).json({ error: 'Restore device access before generating an activation code.', code: 'DEVICE_REVOKED' });
      return;
    }

    const activationCode = generateActivationCode();
    const codeHash = sha256Hex(normalizeActivationCode(activationCode));
    const expiresAtIso = new Date(nowMs + ACTIVATION_CODE_TTL_MS).toISOString();

    db.prepare(
      `UPDATE devices
       SET activation_code_hash = ?, activation_code_expires_at = ?, activation_code_used_at = NULL
       WHERE id = ?`
    ).run(codeHash, expiresAtIso, id);

    logAudit(
      db,
      req.user!.username,
      `Generated one-time Web Kiosk activation code for "${device.name}" (expires ${expiresAtIso})`,
      'Devices',
      'Success',
      getClientIp(req),
      {
        actionType: 'WEB_KIOSK_ACTIVATION_CODE_GENERATED',
        targetType: 'device',
        targetId: id,
        isSecurityEvent: true,
      }
    );

    res.status(201).json({
      device_id: id,
      device_name: device.name,
      activation_code: activationCode,
      expires_at_utc: expiresAtIso,
      one_time_secret: true,
      kiosk_url: '/kiosk',
    });
  });

  // Read Kiosk Admin PIN configuration status (never returns hash or plaintext)
  router.get('/kiosk/web/admin-pin/status', requirePermission('devices:read'), (_req: AuthenticatedRequest, res) => {
    const db = deps.db();
    const nowMs = deps.nowMs();
    const configured = Boolean(readSetting(db, 'kiosk_admin_pin_hash').trim());
    const failedAttempts = Number(readSetting(db, 'kiosk_admin_pin_failed_attempts') || '0') || 0;
    const lockedUntilMs = Number(readSetting(db, 'kiosk_admin_pin_locked_until') || '0') || 0;
    const locked = Number.isFinite(lockedUntilMs) && lockedUntilMs > nowMs;

    res.json({
      configured,
      failed_attempts: failedAttempts,
      locked,
      locked_until_ms: locked ? lockedUntilMs : null,
    });
  });

  // Set or Rotate Kiosk Administrator PIN (scrypt hashed; clears lockout)
  router.put('/kiosk/web/admin-pin', requirePermission('devices:write'), (req: AuthenticatedRequest, res) => {
    const db = deps.db();
    const pin = typeof req.body?.pin === 'string' ? req.body.pin.trim() : '';
    if (!/^\d{4,8}$/.test(pin)) {
      res.status(400).json({ error: 'Kiosk Administrator PIN must be 4 to 8 numeric digits.', code: 'INVALID_PIN_FORMAT' });
      return;
    }
    // Disallow trivial sequential/repeated PINs
    if (/^(\d)\1+$/.test(pin) || pin === '1234' || pin === '123456' || pin === '0000' || pin === '000000') {
      res.status(400).json({
        error: 'Choose a stronger Kiosk Administrator PIN (avoid repeated or simple sequential digits like 0000 or 1234).',
        code: 'WEAK_ADMIN_PIN',
      });
      return;
    }

    const { hash, salt } = hashPassword(pin);
    writeSetting(db, 'kiosk_admin_pin_hash', hash, 'security');
    writeSetting(db, 'kiosk_admin_pin_salt', salt, 'security');
    writeSetting(db, 'kiosk_admin_pin_failed_attempts', '0', 'security');
    writeSetting(db, 'kiosk_admin_pin_locked_until', '', 'security');

    logAudit(
      db,
      req.user!.username,
      'Configured/rotated Web Kiosk Administrator PIN (scrypt-hashed)',
      'Security',
      'Success',
      getClientIp(req),
      { actionType: 'KIOSK_ADMIN_PIN_UPDATED', targetType: 'settings', isSecurityEvent: true }
    );

    res.json({
      ok: true,
      configured: true,
    });
  });
}
