import crypto from 'node:crypto';
import type Database from 'better-sqlite3';
import { addDaysIso, getManilaDateString } from './attendanceEngine.ts';
import { formatManilaDateTime, logAudit } from './auditHelpers.ts';
import type { RealtimeHub } from './realtimeHub.ts';

export class AdminOpsError extends Error {
  statusCode: number;
  code: string;
  fieldErrors?: Array<{ key: string; message: string }>;

  constructor(
    statusCode: number,
    code: string,
    message: string,
    fieldErrors?: Array<{ key: string; message: string }>
  ) {
    super(message);
    this.name = 'AdminOpsError';
    this.statusCode = statusCode;
    this.code = code;
    this.fieldErrors = fieldErrors;
  }
}

export interface SettingValidationRule {
  category: 'general' | 'api' | 'security' | 'retention';
  label: string;
  validate: (raw: string) => { ok: true; normalized: string } | { ok: false; message: string };
}

const VALID_WEEKDAY_TOKENS = new Set(['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']);

function validateIntRange(min: number, max: number, label: string) {
  return (raw: string): { ok: true; normalized: string } | { ok: false; message: string } => {
    const trimmed = raw.trim();
    if (!/^-?\d+$/.test(trimmed)) {
      return { ok: false, message: `${label} must be an integer between ${min} and ${max}.` };
    }
    const n = Number(trimmed);
    if (!Number.isSafeInteger(n) || n < min || n > max) {
      return { ok: false, message: `${label} must be between ${min} and ${max}.` };
    }
    return { ok: true, normalized: String(n) };
  };
}

function validateNumberRange(min: number, max: number, label: string) {
  return (raw: string): { ok: true; normalized: string } | { ok: false; message: string } => {
    const trimmed = raw.trim();
    const n = Number(trimmed);
    if (!trimmed || !Number.isFinite(n) || n < min || n > max) {
      return { ok: false, message: `${label} must be a number between ${min} and ${max}.` };
    }
    return { ok: true, normalized: String(n) };
  };
}

function validateBooleanString(label: string) {
  return (raw: string): { ok: true; normalized: string } | { ok: false; message: string } => {
    const norm = raw.trim().toLowerCase();
    if (norm !== 'true' && norm !== 'false') {
      return { ok: false, message: `${label} must be either "true" or "false".` };
    }
    return { ok: true, normalized: norm };
  };
}

function validateNonEmptyText(maxLen: number, label: string, allowEmpty = false) {
  return (raw: string): { ok: true; normalized: string } | { ok: false; message: string } => {
    const trimmed = raw.trim();
    if (!allowEmpty && trimmed.length === 0) {
      return { ok: false, message: `${label} cannot be empty.` };
    }
    if (trimmed.length > maxLen) {
      return { ok: false, message: `${label} must be at most ${maxLen} characters.` };
    }
    return { ok: true, normalized: trimmed };
  };
}

export const ALLOWED_SETTINGS_RULES: Record<string, SettingValidationRule> = {
  campus_name: {
    category: 'general',
    label: 'Campus Name',
    validate: validateNonEmptyText(140, 'Campus Name'),
  },
  system_title: {
    category: 'general',
    label: 'System Title',
    validate: validateNonEmptyText(140, 'System Title'),
  },
  timezone: {
    category: 'general',
    label: 'Timezone',
    validate: (raw: string) => {
      const tz = raw.trim();
      if (!tz || tz.length > 64) {
        return { ok: false, message: 'Timezone must be a valid IANA timezone (e.g. Asia/Manila).' };
      }
      try {
        new Intl.DateTimeFormat('en-US', { timeZone: tz });
        return { ok: true, normalized: tz };
      } catch {
        return { ok: false, message: `Invalid IANA timezone "${tz}". Use a canonical zone like Asia/Manila.` };
      }
    },
  },
  campus_director_name: {
    category: 'general',
    label: 'Campus Director / Official Signatory',
    validate: validateNonEmptyText(120, 'Campus Director Name', true),
  },
  cs_form_48_reference_verified: {
    category: 'general',
    label: 'CS Form 48 Verified Flag',
    validate: (raw: string) => {
      const norm = raw.trim().toLowerCase();
      if (norm !== 'true' && norm !== 'false') {
        return { ok: false, message: 'cs_form_48_reference_verified must be "true" or "false".' };
      }
      if (norm === 'true' && process.env.ALLOW_CS_FORM_48_REFERENCE_VERIFIED !== 'true') {
        return {
          ok: false,
          message:
            'Official CS Form 48 verification cannot be enabled from UI settings until an RSU-approved reference template is provisioned (ALLOW_CS_FORM_48_REFERENCE_VERIFIED).',
        };
      }
      return { ok: true, normalized: norm };
    },
  },
  cs_form_48_reference_note: {
    category: 'general',
    label: 'CS Form 48 Reference Note',
    validate: validateNonEmptyText(240, 'CS Form 48 Reference Note', true),
  },
  default_grace_minutes: {
    category: 'general',
    label: 'Default Grace Minutes',
    validate: validateIntRange(0, 180, 'Default Grace Minutes'),
  },
  work_hours_per_day: {
    category: 'general',
    label: 'Work Hours Per Day',
    validate: validateNumberRange(1, 24, 'Work Hours Per Day'),
  },
  next_day_timeout_cutoff: {
    category: 'general',
    label: 'Next-Day Timeout Cutoff',
    validate: (raw: string) => {
      const val = raw.trim();
      if (!/^([01]\d|2[0-3]):([0-5]\d)$/.test(val)) {
        return { ok: false, message: 'Next-day timeout cutoff must use 24-hour HH:MM format (00:00–23:59).' };
      }
      return { ok: true, normalized: val };
    },
  },
  correction_require_document: {
    category: 'general',
    label: 'Require Correction Document',
    validate: validateBooleanString('Require Correction Document'),
  },
  leave_weekend_days: {
    category: 'general',
    label: 'Leave Weekend Days',
    validate: (raw: string) => {
      const tokens = raw
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
      if (tokens.length === 0 || tokens.some((t) => !VALID_WEEKDAY_TOKENS.has(t))) {
        return {
          ok: false,
          message: 'Leave Weekend Days must be a comma-separated list from Sun,Mon,Tue,Wed,Thu,Fri,Sat.',
        };
      }
      return { ok: true, normalized: Array.from(new Set(tokens)).join(',') };
    },
  },
  kiosk_api_endpoint: {
    category: 'api',
    label: 'Kiosk Punch Endpoint',
    validate: (raw: string) => {
      const val = raw.trim();
      if (!val.startsWith('/api/') || /\s/.test(val) || val.length > 120) {
        return { ok: false, message: 'Kiosk Punch Endpoint must start with /api/ and contain no whitespace.' };
      }
      return { ok: true, normalized: val };
    },
  },
  kiosk_sync_endpoint: {
    category: 'api',
    label: 'Kiosk Sync Endpoint',
    validate: (raw: string) => {
      const val = raw.trim();
      if (!val.startsWith('/api/') || /\s/.test(val) || val.length > 120) {
        return { ok: false, message: 'Kiosk Sync Endpoint must start with /api/ and contain no whitespace.' };
      }
      return { ok: true, normalized: val };
    },
  },
  kiosk_heartbeat_interval_sec: {
    category: 'api',
    label: 'Kiosk Heartbeat Interval (sec)',
    validate: validateIntRange(5, 3600, 'Kiosk Heartbeat Interval'),
  },
  device_heartbeat_timeout_sec: {
    category: 'api',
    label: 'Device Offline Timeout (sec)',
    validate: validateIntRange(15, 86400, 'Device Offline Timeout'),
  },
  device_stale_warning_sec: {
    category: 'api',
    label: 'Device Stale Warning (sec)',
    validate: validateIntRange(5, 86400, 'Device Stale Warning'),
  },
  kiosk_sync_max_batch_size: {
    category: 'api',
    label: 'Kiosk Sync Max Batch Size',
    validate: validateIntRange(1, 500, 'Kiosk Sync Max Batch Size'),
  },
  kiosk_max_clock_drift_sec: {
    category: 'api',
    label: 'Max Kiosk Clock Drift (sec)',
    validate: validateIntRange(5, 3600, 'Max Kiosk Clock Drift'),
  },
  kiosk_offline_replay_max_hours: {
    category: 'api',
    label: 'Max Offline Replay Age (hrs)',
    validate: validateIntRange(1, 720, 'Max Offline Replay Age'),
  },
  require_kiosk_token: {
    category: 'api',
    label: 'Require Kiosk Token',
    validate: (raw: string) => {
      const norm = raw.trim().toLowerCase();
      if (norm !== 'true') {
        return {
          ok: false,
          message: 'Disabling kiosk API token authentication is prohibited by SAVAGE-RSUCAJ security policy.',
        };
      }
      return { ok: true, normalized: 'true' };
    },
  },
  session_timeout_hours: {
    category: 'security',
    label: 'Session Timeout (hours)',
    validate: validateIntRange(1, 168, 'Session Timeout (hours)'),
  },
  enforce_strong_passwords: {
    category: 'security',
    label: 'Enforce Strong Passwords',
    validate: (raw: string) => {
      const norm = raw.trim().toLowerCase();
      if (norm !== 'true') {
        return {
          ok: false,
          message: 'Weak passwords cannot be enabled; strong password enforcement is mandatory.',
        };
      }
      return { ok: true, normalized: 'true' };
    },
  },
  attendance_retention_days: {
    category: 'retention',
    label: 'Attendance Retention (days)',
    validate: validateIntRange(30, 36500, 'Attendance Retention (days)'),
  },
  audit_log_retention_days: {
    category: 'retention',
    label: 'Audit Log Retention (days)',
    validate: validateIntRange(90, 36500, 'Audit Log Retention (days)'),
  },
};

export function validateAndApplySettingsUpdates(
  db: Database.Database,
  updates: Record<string, unknown>,
  actor: { username: string; ipAddress: string }
): { updatedKeys: string[]; settings: Record<string, string> } {
  const entries = Object.entries(updates);
  if (entries.length === 0) {
    throw new AdminOpsError(400, 'EMPTY_SETTINGS', 'At least one setting update must be provided.');
  }

  const existingRows = db.prepare('SELECT key, value, category FROM settings').all() as Array<{
    key: string;
    value: string;
    category: string;
  }>;
  const existingMap: Record<string, string> = {};
  for (const r of existingRows) existingMap[r.key] = r.value;

  const fieldErrors: Array<{ key: string; message: string }> = [];
  const normalizedUpdates: Array<{ key: string; value: string; category: string }> = [];

  for (const [key, rawVal] of entries) {
    const rule = ALLOWED_SETTINGS_RULES[key];
    if (!rule) {
      fieldErrors.push({
        key,
        message: `Unknown or protected setting key "${key}" is not allowed.`,
      });
      continue;
    }
    if (rawVal === null || rawVal === undefined || typeof rawVal === 'object') {
      fieldErrors.push({ key, message: `${rule.label} must be a scalar value.` });
      continue;
    }
    const res = rule.validate(String(rawVal));
    if (!res.ok) {
      fieldErrors.push({ key, message: res.message });
    } else {
      normalizedUpdates.push({ key, value: res.normalized, category: rule.category });
    }
  }

  // Cross-field checks
  const effectiveMap = { ...existingMap };
  for (const item of normalizedUpdates) {
    effectiveMap[item.key] = item.value;
  }

  const staleSec = Number(effectiveMap.device_stale_warning_sec ?? 60);
  const timeoutSec = Number(effectiveMap.device_heartbeat_timeout_sec ?? 90);
  if (Number.isFinite(staleSec) && Number.isFinite(timeoutSec) && staleSec >= timeoutSec) {
    fieldErrors.push({
      key: 'device_stale_warning_sec',
      message: `Device Stale Warning (${staleSec}s) must be strictly less than Device Offline Timeout (${timeoutSec}s).`,
    });
  }

  if (fieldErrors.length > 0) {
    throw new AdminOpsError(400, 'INVALID_SETTINGS', fieldErrors[0].message, fieldErrors);
  }

  const beforeDiff: Record<string, string> = {};
  const afterDiff: Record<string, string> = {};
  const changedKeys: string[] = [];

  const stmt = db.prepare(
    `INSERT INTO settings (key, value, category, updated_at)
     VALUES (?, ?, ?, datetime('now', 'localtime'))
     ON CONFLICT(key) DO UPDATE
       SET value = excluded.value,
           category = excluded.category,
           updated_at = datetime('now', 'localtime')`
  );

  const tx = db.transaction(() => {
    for (const item of normalizedUpdates) {
      const prev = existingMap[item.key] ?? '';
      stmt.run(item.key, item.value, item.category);
      if (prev !== item.value) {
        beforeDiff[item.key] = prev;
        afterDiff[item.key] = item.value;
        changedKeys.push(item.key);
      }
    }

    const isSecSetting = normalizedUpdates.some((u) => u.category === 'security' || u.category === 'api' || u.category === 'retention');
    logAudit(
      db,
      actor.username,
      changedKeys.length > 0
        ? `Updated system setting(s): ${changedKeys.join(', ')}`
        : `Saved system settings (${normalizedUpdates.length} verified key(s), unchanged)`,
      'Settings',
      'Success',
      actor.ipAddress,
      {
        actionType: 'SETTINGS_UPDATE',
        targetType: 'settings',
        targetId: changedKeys.join(',') || 'batch',
        before: changedKeys.length > 0 ? beforeDiff : undefined,
        after: changedKeys.length > 0 ? afterDiff : undefined,
        isSecurityEvent: isSecSetting || changedKeys.includes('timezone'),
      }
    );
  });
  tx();

  return { updatedKeys: changedKeys, settings: effectiveMap };
}

export function listSecurityChangeHistory(db: Database.Database, limit = 30) {
  const safeLimit = Math.min(100, Math.max(1, limit));
  const rows = db
    .prepare(
      `SELECT id, timestamp, username, activity, module, status, ip_address,
              COALESCE(action_type, 'EVENT') as action_type,
              COALESCE(target_type, '') as target_type,
              COALESCE(target_id, '') as target_id,
              COALESCE(before_json, '') as before_json,
              COALESCE(after_json, '') as after_json,
              COALESCE(entry_hash, '') as entry_hash
       FROM audit_logs
       WHERE is_security_event = 1 OR module IN ('Security', 'Authentication', 'Devices', 'Settings')
       ORDER BY id DESC
       LIMIT ?`
    )
    .all(safeLimit);
  return rows;
}

// ============================================================================
// KIOSK CREDENTIAL ROTATION & REAL CONNECTIVITY ALERTING
// ============================================================================

export function hashKioskToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export function formatMaskedKioskToken(token: string): string {
  if (!token || token.length < 4) return '••••••••';
  return `••••••••${token.slice(-4)}`;
}

export function rotateDeviceToken(
  db: Database.Database,
  realtimeHub: RealtimeHub | undefined,
  deviceId: number,
  actor: { username: string; ipAddress: string },
  nowMs: number
) {
  const dev = db.prepare('SELECT id, name, token_masked, is_revoked FROM devices WHERE id = ?').get(deviceId) as
    | { id: number; name: string; token_masked: string; is_revoked: number }
    | undefined;
  if (!dev) {
    throw new AdminOpsError(404, 'DEVICE_NOT_FOUND', 'Kiosk device not found.');
  }

  const newToken = 'ksk_' + crypto.randomBytes(16).toString('hex');
  const newHash = hashKioskToken(newToken);
  const newMasked = formatMaskedKioskToken(newToken);
  const nowIso = new Date(nowMs).toISOString();

  db.prepare(
    `UPDATE devices
     SET api_token = ?,
         token_hash = ?,
         token_masked = ?,
         token_rotated_at = ?
     WHERE id = ?`
  ).run(newToken, newHash, newMasked, nowIso, deviceId);

  logAudit(
    db,
    actor.username,
    `Rotated kiosk credential token for "${dev.name}" (old=${dev.token_masked || '••••'}, new=${newMasked})`,
    'Devices',
    'Warning',
    actor.ipAddress,
    {
      actionType: 'DEVICE_TOKEN_ROTATED',
      targetType: 'device',
      targetId: deviceId,
      before: { token_masked: dev.token_masked || '••••••••' },
      after: { token_masked: newMasked, token_rotated_at: nowIso },
      isSecurityEvent: true,
    }
  );

  createTargetedNotification(db, realtimeHub, {
    title: `${dev.name} credentials rotated`,
    message: `New one-time kiosk token (${newMasked}) issued by ${actor.username}. Previous token invalidated immediately.`,
    category: 'Device Alerts',
    priority: 'High',
    actionModule: 'devices',
    actionEntityId: deviceId,
    targetRoles: ['Administrator'],
    eventType: 'device_token_rotated',
    createdAt: formatManilaDateTime(nowMs),
  });

  return {
    id: deviceId,
    name: dev.name,
    api_token: newToken,
    token_masked: newMasked,
    token_fingerprint: newHash.slice(0, 12),
    token_rotated_at: nowIso,
    one_time_secret: true,
  };
}

// ============================================================================
// ROLE-TARGETED NOTIFICATIONS & CONNECTIVITY ALERT EVALUATION
// ============================================================================

export interface CreateNotificationInput {
  title: string;
  message: string;
  category: 'Attendance Alerts' | 'Device Alerts' | 'System Notices';
  priority: 'Low' | 'Medium' | 'High';
  actionModule?: string | null;
  actionEntityId?: number | null;
  targetRoles?: string[];
  eventType?: string;
  dedupeKey?: string;
  metadata?: Record<string, unknown>;
  createdAt?: string;
}

export function createTargetedNotification(
  db: Database.Database,
  realtimeHub: RealtimeHub | undefined,
  input: CreateNotificationInput
): { id: number; deduplicated: boolean } {
  const dedupeKey = (input.dedupeKey || '').trim();
  if (dedupeKey) {
    const existing = db
      .prepare('SELECT id FROM notifications WHERE dedupe_key = ? AND is_read = 0 ORDER BY id DESC LIMIT 1')
      .get(dedupeKey) as { id: number } | undefined;
    if (existing) {
      return { id: existing.id, deduplicated: true };
    }
  }

  const targetRolesCsv =
    Array.isArray(input.targetRoles) && input.targetRoles.length > 0
      ? input.targetRoles.map((r) => r.trim()).filter(Boolean).join(',')
      : '';

  const info = db
    .prepare(
      `INSERT INTO notifications
        (title, message, category, priority, is_read, action_module, action_entity_id,
         target_roles, event_type, dedupe_key, metadata_json, created_at)
       VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      input.title,
      input.message,
      input.category,
      input.priority,
      input.actionModule ?? null,
      input.actionEntityId ?? null,
      targetRolesCsv,
      input.eventType || 'general',
      dedupeKey,
      JSON.stringify(input.metadata || {}),
      input.createdAt || formatManilaDateTime()
    );

  const id = Number(info.lastInsertRowid);
  realtimeHub?.emitNotificationCreated({
    id,
    title: input.title,
    category: input.category,
    priority: input.priority,
    action_module: input.actionModule ?? undefined,
  });

  return { id, deduplicated: false };
}

function buildNotificationRolePredicate(role: string): { sql: string; params: unknown[] } {
  return {
    sql: "(COALESCE(target_roles, '') = '' OR (',' || target_roles || ',') LIKE ?)",
    params: [`%,${role},%`],
  };
}

export function getUnreadNotificationCountForRole(db: Database.Database, role: string): number {
  const scope = buildNotificationRolePredicate(role);
  const row = db
    .prepare(`SELECT COUNT(*) as c FROM notifications WHERE is_read = 0 AND ${scope.sql}`)
    .get(...scope.params) as { c: number };
  return row.c;
}

export function queryNotificationsForRole(db: Database.Database, role: string, filter = 'All') {
  const scope = buildNotificationRolePredicate(role);
  const where: string[] = [scope.sql];
  const params: unknown[] = [...scope.params];

  if (filter === 'Unread') {
    where.push('is_read = 0');
  } else if (filter !== 'All') {
    where.push('category = ?');
    params.push(filter);
  }

  const wSql = `WHERE ${where.join(' AND ')}`;
  const rows = db.prepare(`SELECT * FROM notifications ${wSql} ORDER BY is_read ASC, id DESC`).all(...params);
  const allCounts = db
    .prepare(`SELECT category, is_read FROM notifications WHERE ${scope.sql}`)
    .all(...scope.params) as Array<{ category: string; is_read: number }>;

  return {
    data: rows,
    counts: {
      all: allCounts.length,
      unread: allCounts.filter((n) => n.is_read === 0).length,
      attendance: allCounts.filter((n) => n.category === 'Attendance Alerts').length,
      device: allCounts.filter((n) => n.category === 'Device Alerts').length,
      system: allCounts.filter((n) => n.category === 'System Notices').length,
    },
  };
}

export function markNotificationReadForRole(db: Database.Database, role: string, id: number): boolean {
  const scope = buildNotificationRolePredicate(role);
  const res = db
    .prepare(`UPDATE notifications SET is_read = 1 WHERE id = ? AND ${scope.sql}`)
    .run(id, ...scope.params);
  return res.changes > 0;
}

export function markNotificationsReadForRole(db: Database.Database, role: string, ids: number[]): number {
  const scope = buildNotificationRolePredicate(role);
  if (ids.length > 0) {
    const placeholders = ids.map(() => '?').join(',');
    const res = db
      .prepare(`UPDATE notifications SET is_read = 1 WHERE id IN (${placeholders}) AND ${scope.sql}`)
      .run(...ids, ...scope.params);
    return res.changes;
  }
  const res = db.prepare(`UPDATE notifications SET is_read = 1 WHERE is_read = 0 AND ${scope.sql}`).run(...scope.params);
  return res.changes;
}

export function deleteNotificationForRole(db: Database.Database, role: string, id: number): boolean {
  const scope = buildNotificationRolePredicate(role);
  const res = db.prepare(`DELETE FROM notifications WHERE id = ? AND ${scope.sql}`).run(id, ...scope.params);
  return res.changes > 0;
}

export function deleteNotificationsForRole(db: Database.Database, role: string, ids: number[]): number {
  if (ids.length === 0) return 0;
  const scope = buildNotificationRolePredicate(role);
  const placeholders = ids.map(() => '?').join(',');
  const res = db
    .prepare(`DELETE FROM notifications WHERE id IN (${placeholders}) AND ${scope.sql}`)
    .run(...ids, ...scope.params);
  return res.changes;
}

export function clearNotificationsForRole(db: Database.Database, role: string): number {
  const scope = buildNotificationRolePredicate(role);
  const res = db.prepare(`DELETE FROM notifications WHERE ${scope.sql}`).run(...scope.params);
  return res.changes;
}

/**
 * Evaluates all active non-revoked kiosks that have previously established a heartbeat.
 * When a terminal transitions to Stale or Offline, emits a deduplicated persisted Device Alert
 * without spamming repeated alerts on every poll.
 */
export function evaluateDeviceConnectivityAlerts(
  db: Database.Database,
  realtimeHub: RealtimeHub | undefined,
  nowMs: number,
  thresholds: { heartbeatTimeoutSec: number; staleWarningSec: number }
): { alertsCreated: number } {
  const rows = db
    .prepare(
      `SELECT id, name, location, ip_address, last_heartbeat_utc, is_revoked,
              COALESCE(offline_alert_state, 'NONE') as offline_alert_state
       FROM devices
       WHERE is_revoked = 0`
    )
    .all() as Array<{
    id: number;
    name: string;
    location: string;
    ip_address: string;
    last_heartbeat_utc: string | null;
    is_revoked: number;
    offline_alert_state: string;
  }>;

  let alertsCreated = 0;
  const nowIso = new Date(nowMs).toISOString();
  const updState = db.prepare(
    'UPDATE devices SET offline_alert_state = ?, last_alerted_at_utc = ? WHERE id = ?'
  );

  for (const dev of rows) {
    if (!dev.last_heartbeat_utc) {
      continue;
    }
    const lastMs = Date.parse(dev.last_heartbeat_utc);
    if (Number.isNaN(lastMs)) continue;

    const ageSec = Math.max(0, Math.floor((nowMs - lastMs) / 1000));
    if (ageSec <= thresholds.staleWarningSec) {
      if (dev.offline_alert_state !== 'NONE') {
        updState.run('NONE', null, dev.id);
      }
      continue;
    }

    if (ageSec > thresholds.heartbeatTimeoutSec) {
      if (dev.offline_alert_state !== 'OFFLINE') {
        updState.run('OFFLINE', nowIso, dev.id);
        const created = createTargetedNotification(db, realtimeHub, {
          title: `${dev.name} heartbeat timeout (Offline)`,
          message: `Terminal at ${dev.ip_address} (${dev.location}) has not reported a heartbeat for ${ageSec}s (threshold ${thresholds.heartbeatTimeoutSec}s).`,
          category: 'Device Alerts',
          priority: 'High',
          actionModule: 'devices',
          actionEntityId: dev.id,
          targetRoles: ['Administrator', 'HR Officer'],
          eventType: 'device_offline',
          dedupeKey: `device_offline_${dev.id}`,
          metadata: { deviceId: dev.id, ageSec, timeoutSec: thresholds.heartbeatTimeoutSec },
          createdAt: formatManilaDateTime(nowMs),
        });
        if (!created.deduplicated) alertsCreated += 1;
      }
      continue;
    }

    // Between staleWarningSec and heartbeatTimeoutSec
    if (dev.offline_alert_state === 'NONE') {
      updState.run('STALE', nowIso, dev.id);
      const created = createTargetedNotification(db, realtimeHub, {
        title: `${dev.name} heartbeat delayed (Stale)`,
        message: `Terminal at ${dev.ip_address} last checked in ${ageSec}s ago (stale threshold ${thresholds.staleWarningSec}s).`,
        category: 'Device Alerts',
        priority: 'Medium',
        actionModule: 'devices',
        actionEntityId: dev.id,
        targetRoles: ['Administrator'],
        eventType: 'device_stale',
        dedupeKey: `device_stale_${dev.id}`,
        metadata: { deviceId: dev.id, ageSec, staleWarningSec: thresholds.staleWarningSec },
        createdAt: formatManilaDateTime(nowMs),
      });
      if (!created.deduplicated) alertsCreated += 1;
    }
  }

  return { alertsCreated };
}

// ============================================================================
// DATA RETENTION PREVIEW (DRY-RUN) & POLICY-COMPLIANT EXECUTION
// ============================================================================

export interface RetentionCategorySummary {
  key: string;
  label: string;
  eligibleDeleteCount: number;
  preservedCount: number;
  policyNote: string;
}

export interface DataRetentionPreview {
  dryRun: boolean;
  evaluatedAtUtc: string;
  attendanceRetentionDays: number;
  auditLogRetentionDays: number;
  cutoffAttendanceDate: string;
  cutoffAuditDate: string;
  totalEligibleDeletes: number;
  totalPreservedImmutable: number;
  categories: RetentionCategorySummary[];
}

function readRetentionDays(
  db: Database.Database,
  overrides?: { attendanceRetentionDays?: number; auditLogRetentionDays?: number }
): { attendanceDays: number; auditDays: number } {
  const getSettingInt = (key: string, fallback: number): number => {
    const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as { value: string } | undefined;
    const n = row ? Number(row.value) : NaN;
    return Number.isSafeInteger(n) && n >= 30 ? n : fallback;
  };

  let attendanceDays = getSettingInt('attendance_retention_days', 1825);
  let auditDays = getSettingInt('audit_log_retention_days', 730);

  if (overrides?.attendanceRetentionDays !== undefined) {
    const n = Number(overrides.attendanceRetentionDays);
    if (!Number.isSafeInteger(n) || n < 30 || n > 36500) {
      throw new AdminOpsError(400, 'INVALID_RETENTION', 'attendanceRetentionDays must be between 30 and 36500.');
    }
    attendanceDays = n;
  }
  if (overrides?.auditLogRetentionDays !== undefined) {
    const n = Number(overrides.auditLogRetentionDays);
    if (!Number.isSafeInteger(n) || n < 90 || n > 36500) {
      throw new AdminOpsError(400, 'INVALID_RETENTION', 'auditLogRetentionDays must be between 90 and 36500.');
    }
    auditDays = n;
  }

  return { attendanceDays, auditDays };
}

export function previewDataRetention(
  db: Database.Database,
  nowMs: number,
  overrides?: { attendanceRetentionDays?: number; auditLogRetentionDays?: number }
): DataRetentionPreview {
  const { attendanceDays, auditDays } = readRetentionDays(db, overrides);
  const todayManila = getManilaDateString(nowMs);
  const cutoffAttendanceDate = addDaysIso(todayManila, -attendanceDays);
  const cutoffAuditDate = addDaysIso(todayManila, -auditDays);
  const cutoffNotificationDate = addDaysIso(todayManila, -90);
  const expiredSessionCutoffMs = nowMs - 7 * 24 * 60 * 60 * 1000;

  const expiredSessions = (
    db
      .prepare('SELECT COUNT(*) as c FROM user_sessions WHERE revoked_at IS NOT NULL OR expires_at < ?')
      .get(expiredSessionCutoffMs) as { c: number }
  ).c;

  const readNotifications = (
    db
      .prepare('SELECT COUNT(*) as c FROM notifications WHERE is_read = 1 AND date(created_at) <= ?')
      .get(cutoffNotificationDate) as { c: number }
  ).c;

  const cleanSyncBatches = (
    db
      .prepare(
        `SELECT COUNT(*) as c FROM kiosk_sync_batches
         WHERE date(received_at_utc) < ? AND rejected_count = 0 AND conflict_count = 0`
      )
      .get(cutoffAttendanceDate) as { c: number }
  ).c;

  const unlockedAttendance = (
    db
      .prepare(
        `SELECT COUNT(*) as c FROM attendance_records a
         WHERE a.date < ?
           AND NOT EXISTS (
             SELECT 1 FROM payroll_runs r
             WHERE r.status IN ('Finalized', 'Released')
               AND a.date BETWEEN r.start_date AND r.end_date
           )
           AND NOT EXISTS (
             SELECT 1 FROM corrections c
             WHERE c.employee_id = a.employee_id AND c.attendance_date = a.date AND c.status = 'Pending'
           )`
      )
      .get(cutoffAttendanceDate) as { c: number }
  ).c;

  const lockedAttendance = (
    db
      .prepare(
        `SELECT COUNT(*) as c FROM attendance_records a
         WHERE a.date < ?
           AND (
             EXISTS (
               SELECT 1 FROM payroll_runs r
               WHERE r.status IN ('Finalized', 'Released')
                 AND a.date BETWEEN r.start_date AND r.end_date
             )
             OR EXISTS (
               SELECT 1 FROM corrections c
               WHERE c.employee_id = a.employee_id AND c.attendance_date = a.date AND c.status = 'Pending'
             )
           )`
      )
      .get(cutoffAttendanceDate) as { c: number }
  ).c;

  const oldAuditLogs = (
    db.prepare('SELECT COUNT(*) as c FROM audit_logs WHERE date(timestamp) < ?').get(cutoffAuditDate) as { c: number }
  ).c;

  const oldAttendanceEvents = (
    db
      .prepare('SELECT COUNT(*) as c FROM attendance_events WHERE attendance_date < ?')
      .get(cutoffAttendanceDate) as { c: number }
  ).c;

  const categories: RetentionCategorySummary[] = [
    {
      key: 'expired_sessions',
      label: 'Revoked & Expired Auth Sessions (revoked or >7d expired)',
      eligibleDeleteCount: expiredSessions,
      preservedCount: 0,
      policyNote: 'Safe to purge obsolete authentication tokens.',
    },
    {
      key: 'read_notifications',
      label: `Read Notifications (<= ${cutoffNotificationDate})`,
      eligibleDeleteCount: readNotifications,
      preservedCount: 0,
      policyNote: 'Unread and recent (<90d) alerts are preserved.',
    },
    {
      key: 'unlocked_attendance_records',
      label: `Unlocked Attendance Records (< ${cutoffAttendanceDate})`,
      eligibleDeleteCount: unlockedAttendance,
      preservedCount: lockedAttendance,
      policyNote:
        lockedAttendance > 0
          ? `${lockedAttendance} old record(s) locked to Finalized/Released payroll or Pending corrections are protected.`
          : 'Excludes records covered by Finalized/Released payroll runs or Pending corrections.',
    },
    {
      key: 'synced_kiosk_batches',
      label: `Clean Kiosk Sync Batch Receipts (< ${cutoffAttendanceDate})`,
      eligibleDeleteCount: cleanSyncBatches,
      preservedCount: 0,
      policyNote: 'Batches with rejections or conflicts remain preserved for investigation.',
    },
    {
      key: 'audit_logs_immutable',
      label: `Tamper-Evident Audit Logs (< ${cutoffAuditDate})`,
      eligibleDeleteCount: 0,
      preservedCount: oldAuditLogs,
      policyNote:
        'PROTECTED BY IMMUTABILITY TRIGGER: Append-only audit logs cannot be deleted; export CSV before archival.',
    },
    {
      key: 'attendance_events_immutable',
      label: `Immutable Kiosk Punch Evidence Ledger (< ${cutoffAttendanceDate})`,
      eligibleDeleteCount: 0,
      preservedCount: oldAttendanceEvents,
      policyNote: 'PROTECTED BY IMMUTABILITY TRIGGER: Biometric/kiosk event receipts are permanently preserved.',
    },
  ];

  const totalEligibleDeletes =
    expiredSessions + readNotifications + unlockedAttendance + cleanSyncBatches;
  const totalPreservedImmutable = lockedAttendance + oldAuditLogs + oldAttendanceEvents;

  return {
    dryRun: true,
    evaluatedAtUtc: new Date(nowMs).toISOString(),
    attendanceRetentionDays: attendanceDays,
    auditLogRetentionDays: auditDays,
    cutoffAttendanceDate,
    cutoffAuditDate,
    totalEligibleDeletes,
    totalPreservedImmutable,
    categories,
  };
}

export function executeDataRetention(
  db: Database.Database,
  realtimeHub: RealtimeHub | undefined,
  actor: { username: string; ipAddress: string },
  nowMs: number,
  overrides?: { attendanceRetentionDays?: number; auditLogRetentionDays?: number }
) {
  const preview = previewDataRetention(db, nowMs, overrides);
  const cutoffNotificationDate = addDaysIso(getManilaDateString(nowMs), -90);
  const expiredSessionCutoffMs = nowMs - 7 * 24 * 60 * 60 * 1000;
  const jobUid = `ret-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
  const executedAtUtc = new Date(nowMs).toISOString();

  let deletedSessions = 0;
  let deletedNotifications = 0;
  let deletedAttendance = 0;
  let deletedBatches = 0;

  const tx = db.transaction(() => {
    deletedSessions = db
      .prepare('DELETE FROM user_sessions WHERE revoked_at IS NOT NULL OR expires_at < ?')
      .run(expiredSessionCutoffMs).changes;

    deletedNotifications = db
      .prepare('DELETE FROM notifications WHERE is_read = 1 AND date(created_at) <= ?')
      .run(cutoffNotificationDate).changes;

    deletedAttendance = db
      .prepare(
        `DELETE FROM attendance_records
         WHERE date < ?
           AND NOT EXISTS (
             SELECT 1 FROM payroll_runs r
             WHERE r.status IN ('Finalized', 'Released')
               AND attendance_records.date BETWEEN r.start_date AND r.end_date
           )
           AND NOT EXISTS (
             SELECT 1 FROM corrections c
             WHERE c.employee_id = attendance_records.employee_id
               AND c.attendance_date = attendance_records.date
               AND c.status = 'Pending'
           )`
      )
      .run(preview.cutoffAttendanceDate).changes;

    deletedBatches = db
      .prepare(
        `DELETE FROM kiosk_sync_batches
         WHERE date(received_at_utc) < ? AND rejected_count = 0 AND conflict_count = 0`
      )
      .run(preview.cutoffAttendanceDate).changes;

    const deletedCounts = {
      expired_sessions: deletedSessions,
      read_notifications: deletedNotifications,
      unlocked_attendance_records: deletedAttendance,
      synced_kiosk_batches: deletedBatches,
    };
    const skippedCounts: Record<string, number> = {};
    for (const c of preview.categories) {
      if (c.preservedCount > 0) skippedCounts[c.key] = c.preservedCount;
    }

    const totalDeleted =
      deletedSessions + deletedNotifications + deletedAttendance + deletedBatches;

    db.prepare(
      `INSERT INTO retention_jobs
        (job_uid, mode, attendance_retention_days, audit_log_retention_days,
         cutoff_attendance_date, cutoff_audit_date, deleted_counts_json, skipped_counts_json,
         total_deleted, status, executed_by, executed_at_utc, notes)
       VALUES (?, 'EXECUTE', ?, ?, ?, ?, ?, ?, ?, 'Completed', ?, ?, ?)`
    ).run(
      jobUid,
      preview.attendanceRetentionDays,
      preview.auditLogRetentionDays,
      preview.cutoffAttendanceDate,
      preview.cutoffAuditDate,
      JSON.stringify(deletedCounts),
      JSON.stringify(skippedCounts),
      totalDeleted,
      actor.username,
      executedAtUtc,
      `Purged ${totalDeleted} eligible expired rows; preserved ${preview.totalPreservedImmutable} immutable/locked records.`
    );

    logAudit(
      db,
      actor.username,
      `Executed data retention job ${jobUid} (deleted=${totalDeleted}, preserved_immutable=${preview.totalPreservedImmutable})`,
      'Settings',
      'Warning',
      actor.ipAddress,
      {
        actionType: 'RETENTION_EXECUTE',
        targetType: 'retention_job',
        targetId: jobUid,
        before: { eligible: preview.totalEligibleDeletes, cutoffAttendanceDate: preview.cutoffAttendanceDate },
        after: { deletedCounts, skippedCounts, totalDeleted },
        isSecurityEvent: true,
      }
    );

    createTargetedNotification(db, realtimeHub, {
      title: `Data retention job completed (${totalDeleted} purged)`,
      message: `Job ${jobUid} purged ${totalDeleted} expired records before ${preview.cutoffAttendanceDate}. ${preview.totalPreservedImmutable} immutable audit/event/payroll-locked records were preserved.`,
      category: 'System Notices',
      priority: 'Medium',
      actionModule: 'settings',
      targetRoles: ['Administrator'],
      eventType: 'retention_executed',
      createdAt: formatManilaDateTime(nowMs),
    });
  });

  tx();

  return listRetentionJobs(db, 1)[0];
}

export function listRetentionJobs(db: Database.Database, limit = 20) {
  const safeLimit = Math.min(100, Math.max(1, limit));
  return db.prepare('SELECT * FROM retention_jobs ORDER BY id DESC LIMIT ?').all(safeLimit);
}
