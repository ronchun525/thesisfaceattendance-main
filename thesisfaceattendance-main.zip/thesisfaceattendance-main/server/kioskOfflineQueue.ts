import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { AttendanceAction } from './attendanceEngine.ts';

/**
 * Cryptographic Biometric Capture Evidence Envelope (BUILD 10).
 *
 * SECURITY HONESTY NOTICE:
 * This envelope cryptographically binds kiosk capture metadata (device_id, device_boot_id,
 * monotonic_seq, event_uid, employee_code, punch_type, captured_at_utc, evidence_hash)
 * using HMAC-SHA256 keyed by the provisioned kiosk device credential so offline-queued
 * punches cannot have their timestamps, identities, or actions tampered with or rebound.
 *
 * Real camera/neural face recognition & anti-spoof liveness verification remain reserved
 * for BUILD 09 / physical kiosk hardware (NOT claimed in BUILD 10).
 */
export interface BiometricEvidenceEnvelope {
  schema_version: '1.0';
  capture_device_id: number;
  device_boot_id: string;
  monotonic_seq: number;
  event_uid: string;
  employee_code: string;
  punch_type: AttendanceAction;
  captured_at_utc: string;
  evidence_hash: string;
  capture_nonce: string;
  liveness_verified: boolean;
  match_verified: boolean;
  attestation_hmac: string;
}

export interface CreateBiometricEvidenceParams {
  apiToken: string;
  deviceId: number;
  deviceBootId: string;
  monotonicSeq: number;
  eventUid: string;
  employeeCode: string;
  punchType: AttendanceAction;
  capturedAtUtc: string;
  biometricTemplateHash?: string;
  livenessVerified?: boolean;
  matchVerified?: boolean;
  captureNonce?: string;
}

const BIOMETRIC_BINDING_DOMAIN = 'savage-rsucaj-kiosk-biometric-binding-v1';

function computeBindingHmac(
  apiToken: string,
  fields: {
    capture_device_id: number;
    device_boot_id: string;
    monotonic_seq: number;
    event_uid: string;
    employee_code: string;
    punch_type: string;
    captured_at_utc: string;
    evidence_hash: string;
    capture_nonce: string;
    liveness_verified: boolean;
    match_verified: boolean;
  }
): string {
  const canonical = [
    BIOMETRIC_BINDING_DOMAIN,
    String(fields.capture_device_id),
    fields.device_boot_id,
    String(fields.monotonic_seq),
    fields.event_uid,
    fields.employee_code.trim().toUpperCase(),
    fields.punch_type.trim().toUpperCase(),
    fields.captured_at_utc,
    fields.evidence_hash,
    fields.capture_nonce,
    fields.liveness_verified ? '1' : '0',
    fields.match_verified ? '1' : '0',
  ].join('|');

  const derivedKey = crypto
    .createHmac('sha256', apiToken)
    .update(BIOMETRIC_BINDING_DOMAIN)
    .digest();

  return crypto.createHmac('sha256', derivedKey).update(canonical).digest('hex');
}

export function createBiometricEvidenceEnvelope(
  params: CreateBiometricEvidenceParams
): BiometricEvidenceEnvelope {
  const captureNonce = params.captureNonce ?? crypto.randomBytes(12).toString('hex');
  const evidenceHash =
    params.biometricTemplateHash ??
    crypto
      .createHash('sha256')
      .update(
        `${params.deviceId}|${params.deviceBootId}|${params.monotonicSeq}|${params.employeeCode}|${params.capturedAtUtc}|${captureNonce}`
      )
      .digest('hex');

  const livenessVerified = params.livenessVerified ?? false;
  const matchVerified = params.matchVerified ?? false;

  const attestationHmac = computeBindingHmac(params.apiToken, {
    capture_device_id: params.deviceId,
    device_boot_id: params.deviceBootId,
    monotonic_seq: params.monotonicSeq,
    event_uid: params.eventUid,
    employee_code: params.employeeCode,
    punch_type: params.punchType,
    captured_at_utc: params.capturedAtUtc,
    evidence_hash: evidenceHash,
    capture_nonce: captureNonce,
    liveness_verified: livenessVerified,
    match_verified: matchVerified,
  });

  return {
    schema_version: '1.0',
    capture_device_id: params.deviceId,
    device_boot_id: params.deviceBootId,
    monotonic_seq: params.monotonicSeq,
    event_uid: params.eventUid,
    employee_code: params.employeeCode.trim(),
    punch_type: params.punchType,
    captured_at_utc: params.capturedAtUtc,
    evidence_hash: evidenceHash,
    capture_nonce: captureNonce,
    liveness_verified: livenessVerified,
    match_verified: matchVerified,
    attestation_hmac: attestationHmac,
  };
}

export interface VerifyBiometricEvidenceExpected {
  deviceId: number;
  eventUid: string;
  employeeCode: string;
  punchType: string;
  capturedAtUtc: string;
  monotonicSeq?: number;
  deviceBootId?: string;
}

export interface VerifyBiometricEvidenceResult {
  valid: boolean;
  reason?: string;
  evidenceHash?: string;
}

export function verifyBiometricEvidenceEnvelope(
  apiToken: string,
  expected: VerifyBiometricEvidenceExpected,
  rawEnvelope: unknown
): VerifyBiometricEvidenceResult {
  if (!rawEnvelope || typeof rawEnvelope !== 'object') {
    return { valid: false, reason: 'Missing biometric_evidence object.' };
  }
  const env = rawEnvelope as Partial<BiometricEvidenceEnvelope>;
  if (env.schema_version !== '1.0') {
    return { valid: false, reason: 'Unsupported biometric_evidence schema_version.' };
  }
  if (
    typeof env.capture_device_id !== 'number' ||
    env.capture_device_id !== expected.deviceId
  ) {
    return { valid: false, reason: 'biometric_evidence capture_device_id does not match authenticated device.' };
  }
  if (typeof env.device_boot_id !== 'string' || env.device_boot_id.trim().length < 4) {
    return { valid: false, reason: 'biometric_evidence device_boot_id is invalid.' };
  }
  if (expected.deviceBootId && env.device_boot_id !== expected.deviceBootId) {
    return { valid: false, reason: 'biometric_evidence device_boot_id mismatch.' };
  }
  if (!Number.isInteger(env.monotonic_seq) || (env.monotonic_seq as number) < 1) {
    return { valid: false, reason: 'biometric_evidence monotonic_seq must be a positive integer.' };
  }
  if (expected.monotonicSeq !== undefined && env.monotonic_seq !== expected.monotonicSeq) {
    return { valid: false, reason: 'biometric_evidence monotonic_seq mismatch.' };
  }
  if (typeof env.event_uid !== 'string' || env.event_uid !== expected.eventUid) {
    return { valid: false, reason: 'biometric_evidence event_uid does not match punch event_uid.' };
  }
  if (
    typeof env.employee_code !== 'string' ||
    env.employee_code.trim().toUpperCase() !== expected.employeeCode.trim().toUpperCase()
  ) {
    return { valid: false, reason: 'biometric_evidence employee_code does not match punch employee_code.' };
  }
  if (
    typeof env.punch_type !== 'string' ||
    env.punch_type.trim().toUpperCase() !== expected.punchType.trim().toUpperCase()
  ) {
    return { valid: false, reason: 'biometric_evidence punch_type does not match punch action.' };
  }
  if (typeof env.captured_at_utc !== 'string' || env.captured_at_utc !== expected.capturedAtUtc) {
    return { valid: false, reason: 'biometric_evidence captured_at_utc does not match replay timestamp.' };
  }
  if (typeof env.evidence_hash !== 'string' || !/^[a-f0-9]{64}$/i.test(env.evidence_hash)) {
    return { valid: false, reason: 'biometric_evidence evidence_hash must be a valid SHA-256 hex digest.' };
  }
  if (typeof env.capture_nonce !== 'string' || env.capture_nonce.length < 8) {
    return { valid: false, reason: 'biometric_evidence capture_nonce is invalid.' };
  }
  if (typeof env.attestation_hmac !== 'string' || !/^[a-f0-9]{64}$/i.test(env.attestation_hmac)) {
    return { valid: false, reason: 'biometric_evidence attestation_hmac must be a 64-char hex HMAC.' };
  }

  const expectedHmac = computeBindingHmac(apiToken, {
    capture_device_id: env.capture_device_id,
    device_boot_id: env.device_boot_id,
    monotonic_seq: env.monotonic_seq as number,
    event_uid: env.event_uid,
    employee_code: env.employee_code,
    punch_type: env.punch_type,
    captured_at_utc: env.captured_at_utc,
    evidence_hash: env.evidence_hash,
    capture_nonce: env.capture_nonce,
    liveness_verified: Boolean(env.liveness_verified),
    match_verified: Boolean(env.match_verified),
  });

  const a = Buffer.from(env.attestation_hmac.toLowerCase(), 'utf8');
  const b = Buffer.from(expectedHmac.toLowerCase(), 'utf8');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return { valid: false, reason: 'biometric_evidence attestation_hmac verification failed (tampered or rebound payload).' };
  }

  return { valid: true, evidenceHash: env.evidence_hash };
}

// ============================================================================
// DURABLE ENCRYPTED ON-DISK KIOSK OFFLINE QUEUE (AES-256-GCM + ATOMIC RENAME)
// ============================================================================
export interface QueuedKioskEvent {
  event_uid: string;
  monotonic_seq: number;
  device_boot_id: string;
  employee_code: string;
  punch_type: AttendanceAction;
  device_timestamp: string;
  offline_replay: boolean;
  biometric_evidence: BiometricEvidenceEnvelope;
  queued_at_utc: string;
  retry_count: number;
  last_error: string | null;
}

export interface DeadLetterKioskEvent {
  event: QueuedKioskEvent;
  outcome: string;
  code: string;
  message: string;
  settled_at_utc: string;
}

interface PersistedQueueState {
  version: 1;
  device_id: number;
  device_name: string;
  device_boot_id: string;
  next_monotonic_seq: number;
  last_sync_utc: string | null;
  last_sync_error: string;
  items: QueuedKioskEvent[];
  dead_letters: DeadLetterKioskEvent[];
}

interface EncryptedQueueFileEnvelope {
  format: 'savage-kiosk-queue-aes256gcm-v1';
  salt_hex: string;
  iv_hex: string;
  tag_hex: string;
  ciphertext_b64: string;
}

export interface EncryptedKioskQueueOptions {
  queueFilePath: string;
  encryptionKey: string;
  deviceId: number;
  deviceName: string;
  apiToken: string;
  deviceBootId?: string;
  /** When true, forces a new boot_id while preserving monotonic_seq and queued items from disk (simulating reboot) */
  newBootSession?: boolean;
  nowProvider?: () => number;
}

export class EncryptedKioskQueue {
  private readonly filePath: string;
  private readonly encryptionKey: string;
  private readonly apiToken: string;
  private readonly getNowMs: () => number;
  private state: PersistedQueueState;

  constructor(options: EncryptedKioskQueueOptions) {
    if (!options.encryptionKey || options.encryptionKey.length < 16) {
      throw new Error('EncryptedKioskQueue requires an encryptionKey of at least 16 characters.');
    }
    this.filePath = path.resolve(options.queueFilePath);
    this.encryptionKey = options.encryptionKey;
    this.apiToken = options.apiToken;
    this.getNowMs = options.nowProvider ?? (() => Date.now());

    const loaded = this.loadFromDisk();
    if (loaded) {
      this.state = {
        ...loaded,
        device_id: options.deviceId,
        device_name: options.deviceName,
        device_boot_id: options.newBootSession
          ? options.deviceBootId ?? `boot-${crypto.randomBytes(6).toString('hex')}`
          : loaded.device_boot_id,
      };
      if (options.newBootSession) {
        this.saveToDisk();
      }
    } else {
      this.state = {
        version: 1,
        device_id: options.deviceId,
        device_name: options.deviceName,
        device_boot_id: options.deviceBootId ?? `boot-${crypto.randomBytes(6).toString('hex')}`,
        next_monotonic_seq: 1,
        last_sync_utc: null,
        last_sync_error: '',
        items: [],
        dead_letters: [],
      };
      this.saveToDisk();
    }
  }

  private deriveAesKey(salt: Buffer): Buffer {
    return crypto.scryptSync(this.encryptionKey, salt, 32);
  }

  private loadFromDisk(): PersistedQueueState | null {
    if (!fs.existsSync(this.filePath)) return null;
    const raw = fs.readFileSync(this.filePath, 'utf8');
    const env = JSON.parse(raw) as EncryptedQueueFileEnvelope;
    if (env.format !== 'savage-kiosk-queue-aes256gcm-v1') {
      throw new Error(`Unsupported kiosk queue format: ${String(env.format)}`);
    }
    const salt = Buffer.from(env.salt_hex, 'hex');
    const iv = Buffer.from(env.iv_hex, 'hex');
    const tag = Buffer.from(env.tag_hex, 'hex');
    const ciphertext = Buffer.from(env.ciphertext_b64, 'base64');

    const key = this.deriveAesKey(salt);
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(tag);
    const plaintext = Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
    return JSON.parse(plaintext) as PersistedQueueState;
  }

  private saveToDisk(): void {
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    const salt = crypto.randomBytes(16);
    const iv = crypto.randomBytes(12);
    const key = this.deriveAesKey(salt);
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
    const plaintext = Buffer.from(JSON.stringify(this.state), 'utf8');
    const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
    const tag = cipher.getAuthTag();

    const envelope: EncryptedQueueFileEnvelope = {
      format: 'savage-kiosk-queue-aes256gcm-v1',
      salt_hex: salt.toString('hex'),
      iv_hex: iv.toString('hex'),
      tag_hex: tag.toString('hex'),
      ciphertext_b64: ciphertext.toString('base64'),
    };

    const tmpPath = `${this.filePath}.tmp.${process.pid}.${crypto.randomBytes(4).toString('hex')}`;
    const fd = fs.openSync(tmpPath, 'w', 0o600);
    try {
      fs.writeSync(fd, JSON.stringify(envelope), 0, 'utf8');
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }
    fs.renameSync(tmpPath, this.filePath);
  }

  getDeviceBootId(): string {
    return this.state.device_boot_id;
  }

  getLastMonotonicSeq(): number {
    return Math.max(0, this.state.next_monotonic_seq - 1);
  }

  getPendingCount(): number {
    return this.state.items.length;
  }

  getPendingEvents(): QueuedKioskEvent[] {
    return this.state.items.map((item) => ({ ...item }));
  }

  getDeadLetters(): DeadLetterKioskEvent[] {
    return this.state.dead_letters.map((d) => ({ ...d }));
  }

  getLastSyncError(): string {
    return this.state.last_sync_error;
  }

  getLastSyncUtc(): string | null {
    return this.state.last_sync_utc;
  }

  enqueuePunch(params: {
    employeeCode: string;
    punchType: AttendanceAction;
    capturedAtUtc?: string;
    offlineReplay?: boolean;
    eventUid?: string;
    biometricTemplateHash?: string;
  }): QueuedKioskEvent {
    const seq = this.state.next_monotonic_seq;
    this.state.next_monotonic_seq += 1;

    const capturedAtUtc = params.capturedAtUtc ?? new Date(this.getNowMs()).toISOString();
    const eventUid =
      params.eventUid ??
      `ksk-${this.state.device_id}-${this.state.device_boot_id}-seq${seq}-${crypto.randomBytes(4).toString('hex')}`;

    const biometricEvidence = createBiometricEvidenceEnvelope({
      apiToken: this.apiToken,
      deviceId: this.state.device_id,
      deviceBootId: this.state.device_boot_id,
      monotonicSeq: seq,
      eventUid,
      employeeCode: params.employeeCode,
      punchType: params.punchType,
      capturedAtUtc,
      biometricTemplateHash: params.biometricTemplateHash,
      // Explicitly false in BUILD 10 until BUILD 09 real liveness & neural matcher are integrated
      livenessVerified: false,
      matchVerified: false,
    });

    const item: QueuedKioskEvent = {
      event_uid: eventUid,
      monotonic_seq: seq,
      device_boot_id: this.state.device_boot_id,
      employee_code: params.employeeCode.trim(),
      punch_type: params.punchType,
      device_timestamp: capturedAtUtc,
      offline_replay: params.offlineReplay ?? true,
      biometric_evidence: biometricEvidence,
      queued_at_utc: new Date(this.getNowMs()).toISOString(),
      retry_count: 0,
      last_error: null,
    };

    this.state.items.push(item);
    this.saveToDisk();
    return item;
  }

  acknowledgeEvents(
    settled: Array<{ event_uid: string; outcome: string; code: string; message?: string }>,
    syncTimestampUtc: string
  ): void {
    const settledMap = new Map(settled.map((s) => [s.event_uid, s]));
    const remaining: QueuedKioskEvent[] = [];

    for (const item of this.state.items) {
      const ack = settledMap.get(item.event_uid);
      if (!ack) {
        remaining.push(item);
        continue;
      }
      if (ack.outcome !== 'ACCEPTED' && ack.outcome !== 'DUPLICATE_IGNORED') {
        this.state.dead_letters.push({
          event: item,
          outcome: ack.outcome,
          code: ack.code,
          message: ack.message ?? '',
          settled_at_utc: syncTimestampUtc,
        });
      }
    }

    this.state.items = remaining;
    this.state.last_sync_utc = syncTimestampUtc;
    this.state.last_sync_error = '';
    this.saveToDisk();
  }

  recordRetryFailure(eventUids: string[], errorText: string): void {
    const set = new Set(eventUids);
    for (const item of this.state.items) {
      if (set.has(item.event_uid)) {
        item.retry_count += 1;
        item.last_error = errorText;
      }
    }
    this.state.last_sync_error = errorText;
    this.saveToDisk();
  }
}

// ============================================================================
// KIOSK SYNC CLIENT (EXPONENTIAL BACKOFF + JITTER + AUTO-RECONNECT)
// ============================================================================
export interface KioskSyncClientOptions {
  baseUrl: string;
  apiToken: string;
  queue: EncryptedKioskQueue;
  maxBatchSize?: number;
  baseBackoffMs?: number;
  maxBackoffMs?: number;
  jitterRatio?: number;
  nowProvider?: () => number;
  fetchImpl?: typeof fetch;
}

export interface KioskSyncFlushResult {
  ok: boolean;
  revoked: boolean;
  networkError: boolean;
  httpStatus?: number;
  batchUid?: string;
  processedCount: number;
  remainingQueueCount: number;
  nextRetryDelayMs: number;
  error?: string;
  results?: Array<{
    event_uid: string;
    monotonic_seq: number;
    outcome: string;
    code: string;
    status_code: number;
    message?: string;
  }>;
}

export function computeBackoffWithJitterMs(
  attempt: number,
  baseMs = 1_000,
  maxMs = 60_000,
  jitterRatio = 0.25,
  rng: () => number = Math.random
): number {
  const safeAttempt = Math.max(0, Math.floor(attempt));
  const exp = Math.min(maxMs, baseMs * Math.pow(2, safeAttempt));
  const spread = exp * Math.max(0, Math.min(0.5, jitterRatio));
  const delta = (rng() * 2 - 1) * spread;
  return Math.max(100, Math.round(exp + delta));
}

export class KioskSyncClient {
  private readonly baseUrl: string;
  private readonly apiToken: string;
  private readonly queue: EncryptedKioskQueue;
  private readonly maxBatchSize: number;
  private readonly baseBackoffMs: number;
  private readonly maxBackoffMs: number;
  private readonly jitterRatio: number;
  private readonly getNowMs: () => number;
  private readonly fetchImpl: typeof fetch;
  private consecutiveFailures = 0;
  private revoked = false;

  constructor(options: KioskSyncClientOptions) {
    this.baseUrl = options.baseUrl.replace(/\/+$/, '');
    this.apiToken = options.apiToken;
    this.queue = options.queue;
    this.maxBatchSize = Math.max(1, Math.min(100, options.maxBatchSize ?? 50));
    this.baseBackoffMs = options.baseBackoffMs ?? 1_000;
    this.maxBackoffMs = options.maxBackoffMs ?? 60_000;
    this.jitterRatio = options.jitterRatio ?? 0.25;
    this.getNowMs = options.nowProvider ?? (() => Date.now());
    this.fetchImpl = options.fetchImpl ?? fetch;
  }

  isRevoked(): boolean {
    return this.revoked;
  }

  getConsecutiveFailures(): number {
    return this.consecutiveFailures;
  }

  async sendHeartbeat(): Promise<{
    ok: boolean;
    revoked: boolean;
    httpStatus?: number;
    body?: Record<string, unknown>;
    error?: string;
  }> {
    try {
      const res = await this.fetchImpl(`${this.baseUrl}/api/kiosk/heartbeat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-kiosk-token': this.apiToken,
        },
        body: JSON.stringify({
          device_timestamp: new Date(this.getNowMs()).toISOString(),
          device_boot_id: this.queue.getDeviceBootId(),
          pending_queue_count: this.queue.getPendingCount(),
          last_monotonic_seq: this.queue.getLastMonotonicSeq(),
          last_sync_error: this.queue.getLastSyncError(),
        }),
      });
      const body = (await res.json().catch(() => ({}))) as Record<string, unknown>;
      if (res.status === 401 || res.status === 403) {
        if (body.code === 'DEVICE_REVOKED' || res.status === 403) {
          this.revoked = true;
        }
        return {
          ok: false,
          revoked: this.revoked,
          httpStatus: res.status,
          body,
          error: String(body.error || `Heartbeat rejected (${res.status})`),
        };
      }
      if (!res.ok) {
        return {
          ok: false,
          revoked: false,
          httpStatus: res.status,
          body,
          error: String(body.error || `Heartbeat HTTP ${res.status}`),
        };
      }
      this.revoked = false;
      return { ok: true, revoked: false, httpStatus: res.status, body };
    } catch (err) {
      return {
        ok: false,
        revoked: false,
        error: err instanceof Error ? err.message : 'Network error during heartbeat',
      };
    }
  }

  async flushQueue(overrideBatch?: QueuedKioskEvent[]): Promise<KioskSyncFlushResult> {
    const pending = overrideBatch ?? this.queue.getPendingEvents();
    if (pending.length === 0) {
      return {
        ok: true,
        revoked: this.revoked,
        networkError: false,
        processedCount: 0,
        remainingQueueCount: 0,
        nextRetryDelayMs: 0,
        results: [],
      };
    }

    const slice = pending.slice(0, this.maxBatchSize);
    const batchUid = `batch-${this.queue.getDeviceBootId()}-${this.getNowMs()}-${crypto.randomBytes(4).toString('hex')}`;

    try {
      const res = await this.fetchImpl(`${this.baseUrl}/api/kiosk/sync`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-kiosk-token': this.apiToken,
        },
        body: JSON.stringify({
          batch_uid: batchUid,
          device_boot_id: this.queue.getDeviceBootId(),
          device_timestamp: new Date(this.getNowMs()).toISOString(),
          pending_queue_count: Math.max(0, this.queue.getPendingCount() - slice.length),
          events: slice.map((item) => ({
            event_uid: item.event_uid,
            monotonic_seq: item.monotonic_seq,
            device_boot_id: item.device_boot_id,
            employee_code: item.employee_code,
            punch_type: item.punch_type,
            device_timestamp: item.device_timestamp,
            offline_replay: item.offline_replay,
            biometric_evidence: item.biometric_evidence,
          })),
        }),
      });

      const body = (await res.json().catch(() => ({}))) as Record<string, unknown>;

      if (res.status === 401 || res.status === 403) {
        this.revoked = true;
        const errMsg = String(body.error || 'Kiosk device credentials revoked or invalid.');
        this.queue.recordRetryFailure(
          slice.map((s) => s.event_uid),
          errMsg
        );
        return {
          ok: false,
          revoked: true,
          networkError: false,
          httpStatus: res.status,
          batchUid,
          processedCount: 0,
          remainingQueueCount: this.queue.getPendingCount(),
          nextRetryDelayMs: 0,
          error: errMsg,
        };
      }

      if (!res.ok) {
        this.consecutiveFailures += 1;
        const errMsg = String(body.error || `Sync HTTP ${res.status}`);
        this.queue.recordRetryFailure(
          slice.map((s) => s.event_uid),
          errMsg
        );
        return {
          ok: false,
          revoked: false,
          networkError: res.status >= 500,
          httpStatus: res.status,
          batchUid,
          processedCount: 0,
          remainingQueueCount: this.queue.getPendingCount(),
          nextRetryDelayMs: computeBackoffWithJitterMs(
            this.consecutiveFailures - 1,
            this.baseBackoffMs,
            this.maxBackoffMs,
            this.jitterRatio
          ),
          error: errMsg,
        };
      }

      const results = Array.isArray(body.results)
        ? (body.results as Array<{
            event_uid: string;
            monotonic_seq: number;
            outcome: string;
            code: string;
            status_code: number;
            message?: string;
          }>)
        : [];

      const syncTs =
        typeof body.received_at_utc === 'string'
          ? body.received_at_utc
          : new Date(this.getNowMs()).toISOString();

      this.queue.acknowledgeEvents(results, syncTs);
      this.consecutiveFailures = 0;

      return {
        ok: true,
        revoked: false,
        networkError: false,
        httpStatus: res.status,
        batchUid,
        processedCount: results.length,
        remainingQueueCount: this.queue.getPendingCount(),
        nextRetryDelayMs: 0,
        results,
      };
    } catch (err) {
      this.consecutiveFailures += 1;
      const errMsg = err instanceof Error ? err.message : 'Network error during kiosk sync';
      this.queue.recordRetryFailure(
        slice.map((s) => s.event_uid),
        errMsg
      );
      return {
        ok: false,
        revoked: false,
        networkError: true,
        batchUid,
        processedCount: 0,
        remainingQueueCount: this.queue.getPendingCount(),
        nextRetryDelayMs: computeBackoffWithJitterMs(
          this.consecutiveFailures - 1,
          this.baseBackoffMs,
          this.maxBackoffMs,
          this.jitterRatio
        ),
        error: errMsg,
      };
    }
  }
}
