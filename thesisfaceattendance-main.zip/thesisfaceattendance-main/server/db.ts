import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { hashPassword } from './auth.ts';
import { validatePasswordStrength, type AppMode } from './env.ts';
import { CANONICAL_PERMISSIONS, CANONICAL_ROLES, ROLE_PERMISSION_MATRIX } from './rbac.ts';
import { addDaysIso, getManilaDateString } from './attendanceEngine.ts';
import {
  backfillAuditLogHashChain,
  logAudit,
  redactSensitiveValue,
  verifyAuditLogChain,
} from './auditHelpers.ts';

export { logAudit, redactSensitiveValue, verifyAuditLogChain };

export const CURRENT_SCHEMA_VERSION = '011';

export const CANONICAL_BUSINESS_TABLES = [
  'users',
  'roles',
  'permissions',
  'role_permissions',
  'user_sessions',
  'departments',
  'positions',
  'shifts',
  'holidays',
  'employees',
  'attendance_records',
  'attendance_events',
  'corrections',
  'correction_audit_log',
  'leaves',
  'leave_policies',
  'leave_day_allocations',
  'leave_audit_log',
  'payroll_policies',
  'payroll_runs',
  'payroll_items',
  'payroll_audit_log',
  'dtr_signoffs',
  'devices',
  'kiosk_sync_batches',
  'kiosk_face_templates',
  'web_kiosk_sessions',
  'web_kiosk_challenges',
  'audit_logs',
  'notifications',
  'settings',
  'backup_history',
  'retention_jobs',
  'schema_migrations',
] as const;

export class InitialAdminCredentialsMissingError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InitialAdminCredentialsMissingError';
  }
}

export class DatabaseUnavailableError extends Error {
  code: string;
  constructor(message: string, code = 'DATABASE_UNAVAILABLE') {
    super(message);
    this.name = 'DatabaseUnavailableError';
    this.code = code;
  }
}

export class DatabaseMigrationError extends Error {
  version: string;
  constructor(version: string, message: string) {
    super(message);
    this.name = 'DatabaseMigrationError';
    this.version = version;
  }
}

export class DemoSeedForbiddenError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'DemoSeedForbiddenError';
  }
}

export interface InitDatabaseOptions {
  /**
   * Explicitly seed sample campus entities ONLY when true in non-production modes
   * (e.g., isolated test fixtures or explicit `APP_MODE=demo` sandbox).
   * Defaults to false so production deployments NEVER silently seed demo data.
   */
  seedDemoData?: boolean;
  /** Operational mode: production | demo | test (defaults to production unless NODE_ENV=test). */
  mode?: AppMode;
  /** SQLite busy_timeout in ms (default: 5000). */
  busyTimeoutMs?: number;
  /** SQLite wal_autocheckpoint page count (default: 1000). */
  walAutocheckpoint?: number;
  /** Skip initial admin bootstrap check (used only by read-only inspection/migration tools). */
  skipAdminBootstrap?: boolean;
  /** Optional explicit bootstrap credentials override (primarily for tests). */
  initialAdmin?: {
    username: string;
    email: string;
    password: string;
  };
}

export interface WalCheckpointResult {
  mode: 'PASSIVE' | 'FULL' | 'RESTART' | 'TRUNCATE';
  busy: number;
  log: number;
  checkpointed: number;
}

export interface DatabaseStatusReport {
  connected: boolean;
  databasePath: string;
  isMemory: boolean;
  journalMode: string;
  synchronous: number;
  foreignKeys: boolean;
  busyTimeoutMs: number;
  walAutocheckpoint: number;
  schemaVersion: string;
  appliedMigrations: Array<{ version: string; name: string; applied_at: string }>;
  integrityCheck: string;
  foreignKeyViolations: number;
  dbFileBytes: number;
  walFileBytes: number;
  shmFileBytes: number;
  tableCounts: Record<string, number>;
}

function formatIsoDate(date: Date): string {
  return getManilaDateString(date);
}

/**
 * Returns the current calendar date (YYYY-MM-DD) in Philippines Standard Time (Asia/Manila, UTC+08:00),
 * never relying on blind host-OS local timezone.
 */
export function getTodayDateString(now: Date | number = Date.now()): string {
  return getManilaDateString(now);
}

export function isDatabaseUnavailableError(err: unknown): boolean {
  if (!err) return false;
  if (err instanceof DatabaseUnavailableError) return true;
  const anyErr = err as { code?: string; message?: string };
  const code = String(anyErr.code || '').toUpperCase();
  const msg = String(anyErr.message || '').toLowerCase();
  return (
    code.startsWith('SQLITE_CANTOPEN') ||
    code.startsWith('SQLITE_IOERR') ||
    code.startsWith('SQLITE_CORRUPT') ||
    code.startsWith('SQLITE_NOTADB') ||
    code.startsWith('SQLITE_READONLY') ||
    code.startsWith('SQLITE_BUSY') ||
    code.startsWith('SQLITE_LOCKED') ||
    msg.includes('database connection is not open') ||
    msg.includes('unable to open database') ||
    msg.includes('database is locked') ||
    msg.includes('disk i/o error')
  );
}

function tableHasColumn(db: Database.Database, table: string, column: string): boolean {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
  return cols.some((c) => c.name === column);
}

export function runMigrations(db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );
  `);

  const hasMigration = (version: string): boolean =>
    Boolean(db.prepare('SELECT 1 FROM schema_migrations WHERE version = ?').get(version));
  const recordMigration = (version: string, name: string): void => {
    db.prepare('INSERT OR IGNORE INTO schema_migrations (version, name) VALUES (?, ?)').run(version, name);
  };

  // -------------------------------------------------------------------------
  // Migration 001: Baseline 15 core campus tables (non-destructive IF NOT EXISTS)
  // -------------------------------------------------------------------------
  try {
    const apply001 = db.transaction(() => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL UNIQUE,
          email TEXT NOT NULL UNIQUE,
          full_name TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'Administrator',
          password_hash TEXT NOT NULL,
          salt TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS departments (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          code TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          head_name TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS positions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          code TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          type TEXT NOT NULL DEFAULT 'Regular',
          base_salary REAL NOT NULL DEFAULT 25000,
          allowance REAL NOT NULL DEFAULT 2000,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS shifts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL UNIQUE,
          time_in TEXT NOT NULL,
          time_out TEXT NOT NULL,
          grace_minutes INTEGER NOT NULL DEFAULT 15,
          status TEXT NOT NULL DEFAULT 'Active',
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS holidays (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          date TEXT NOT NULL,
          name TEXT NOT NULL,
          type TEXT NOT NULL DEFAULT 'Regular',
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS employees (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          employee_code TEXT NOT NULL UNIQUE,
          full_name TEXT NOT NULL,
          email TEXT NOT NULL DEFAULT '',
          department_id INTEGER NOT NULL,
          position_id INTEGER NOT NULL,
          shift_id INTEGER NOT NULL,
          status TEXT NOT NULL DEFAULT 'Active',
          hired_date TEXT NOT NULL DEFAULT '2024-01-15',
          monthly_salary REAL NOT NULL DEFAULT 25000,
          monthly_allowance REAL NOT NULL DEFAULT 2000,
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE RESTRICT,
          FOREIGN KEY (position_id) REFERENCES positions(id) ON DELETE RESTRICT,
          FOREIGN KEY (shift_id) REFERENCES shifts(id) ON DELETE RESTRICT
        );

        CREATE TABLE IF NOT EXISTS attendance_records (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          employee_id INTEGER NOT NULL,
          date TEXT NOT NULL,
          time_in TEXT,
          time_out TEXT,
          work_hours TEXT NOT NULL DEFAULT '-',
          status TEXT NOT NULL DEFAULT 'Present',
          device_name TEXT NOT NULL DEFAULT 'Kiosk - Main Entrance',
          remarks TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          UNIQUE(employee_id, date),
          FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS corrections (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          employee_id INTEGER NOT NULL,
          attendance_date TEXT NOT NULL,
          request_type TEXT NOT NULL DEFAULT 'Time In',
          requested_time TEXT NOT NULL,
          reason TEXT NOT NULL DEFAULT '',
          status TEXT NOT NULL DEFAULT 'Pending',
          reviewed_by TEXT,
          reviewed_at TEXT,
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS leaves (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          employee_id INTEGER NOT NULL,
          leave_type TEXT NOT NULL,
          start_date TEXT NOT NULL,
          end_date TEXT NOT NULL,
          days_count INTEGER NOT NULL DEFAULT 1,
          reason TEXT NOT NULL DEFAULT '',
          status TEXT NOT NULL DEFAULT 'Pending',
          reviewed_by TEXT,
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS payroll_runs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          period_label TEXT NOT NULL,
          start_date TEXT NOT NULL,
          end_date TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'Computed',
          total_basic_pay REAL NOT NULL DEFAULT 0,
          total_allowances REAL NOT NULL DEFAULT 0,
          total_deductions REAL NOT NULL DEFAULT 0,
          total_net_pay REAL NOT NULL DEFAULT 0,
          employee_count INTEGER NOT NULL DEFAULT 0,
          created_by TEXT NOT NULL DEFAULT 'admin',
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          finalized_at TEXT,
          released_at TEXT
        );

        CREATE TABLE IF NOT EXISTS payroll_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          payroll_run_id INTEGER NOT NULL,
          employee_id INTEGER NOT NULL,
          days_present INTEGER NOT NULL DEFAULT 0,
          days_late INTEGER NOT NULL DEFAULT 0,
          days_absent INTEGER NOT NULL DEFAULT 0,
          basic_pay REAL NOT NULL DEFAULT 0,
          allowances REAL NOT NULL DEFAULT 0,
          deductions REAL NOT NULL DEFAULT 0,
          net_pay REAL NOT NULL DEFAULT 0,
          FOREIGN KEY (payroll_run_id) REFERENCES payroll_runs(id) ON DELETE CASCADE,
          FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS devices (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL UNIQUE,
          device_type TEXT NOT NULL DEFAULT 'Raspberry Pi',
          model_info TEXT NOT NULL DEFAULT 'Raspberry Pi 3B',
          ip_address TEXT NOT NULL,
          location TEXT NOT NULL DEFAULT 'Main Gate',
          api_token TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'Online',
          last_heartbeat TEXT NOT NULL DEFAULT (datetime('now')),
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS audit_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          timestamp TEXT NOT NULL DEFAULT (datetime('now')),
          username TEXT NOT NULL,
          activity TEXT NOT NULL,
          module TEXT NOT NULL DEFAULT 'System',
          status TEXT NOT NULL DEFAULT 'Success',
          ip_address TEXT NOT NULL DEFAULT '127.0.0.1'
        );

        CREATE TABLE IF NOT EXISTS notifications (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          message TEXT NOT NULL,
          category TEXT NOT NULL DEFAULT 'System Notices',
          priority TEXT NOT NULL DEFAULT 'Medium',
          is_read INTEGER NOT NULL DEFAULT 0,
          action_module TEXT,
          action_entity_id INTEGER,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS settings (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL,
          category TEXT NOT NULL DEFAULT 'general',
          updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
      `);
      if (!hasMigration('001')) {
        recordMigration('001', 'baseline_15_tables');
      }
    });
    apply001();
  } catch (err) {
    throw new DatabaseMigrationError('001', err instanceof Error ? err.message : String(err));
  }

  // -------------------------------------------------------------------------
  // Migration 002: RBAC roles/permissions, revocable server-side sessions, lockout & scoping
  // -------------------------------------------------------------------------
  try {
    const apply002 = db.transaction(() => {
      if (!tableHasColumn(db, 'users', 'must_change_password')) {
        db.exec('ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0');
      }
      if (!tableHasColumn(db, 'users', 'is_active')) {
        db.exec('ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1');
      }
      if (!tableHasColumn(db, 'users', 'department_id')) {
        db.exec('ALTER TABLE users ADD COLUMN department_id INTEGER REFERENCES departments(id) ON DELETE SET NULL');
      }
      if (!tableHasColumn(db, 'users', 'employee_id')) {
        db.exec('ALTER TABLE users ADD COLUMN employee_id INTEGER REFERENCES employees(id) ON DELETE SET NULL');
      }
      if (!tableHasColumn(db, 'users', 'failed_login_attempts')) {
        db.exec('ALTER TABLE users ADD COLUMN failed_login_attempts INTEGER NOT NULL DEFAULT 0');
      }
      if (!tableHasColumn(db, 'users', 'locked_until')) {
        db.exec('ALTER TABLE users ADD COLUMN locked_until TEXT');
      }
      if (!tableHasColumn(db, 'users', 'password_changed_at')) {
        db.exec('ALTER TABLE users ADD COLUMN password_changed_at TEXT');
      }

      db.exec(`
        CREATE TABLE IF NOT EXISTS roles (
          name TEXT PRIMARY KEY,
          description TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
        );

        CREATE TABLE IF NOT EXISTS permissions (
          code TEXT PRIMARY KEY,
          resource TEXT NOT NULL,
          action TEXT NOT NULL,
          description TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS role_permissions (
          role_name TEXT NOT NULL,
          permission_code TEXT NOT NULL,
          PRIMARY KEY (role_name, permission_code),
          FOREIGN KEY (role_name) REFERENCES roles(name) ON DELETE CASCADE,
          FOREIGN KEY (permission_code) REFERENCES permissions(code) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS user_sessions (
          sid TEXT PRIMARY KEY,
          user_id INTEGER NOT NULL,
          csrf_token TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
          expires_at INTEGER NOT NULL,
          revoked_at TEXT,
          revoked_reason TEXT,
          ip_address TEXT NOT NULL DEFAULT '',
          user_agent TEXT NOT NULL DEFAULT '',
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions(user_id);
        CREATE INDEX IF NOT EXISTS idx_user_sessions_expires_at ON user_sessions(expires_at);
      `);

      const upsertRole = db.prepare(
        'INSERT INTO roles (name, description) VALUES (?, ?) ON CONFLICT(name) DO UPDATE SET description = excluded.description'
      );
      for (const r of CANONICAL_ROLES) {
        upsertRole.run(r.name, r.description);
      }

      const upsertPerm = db.prepare(
        `INSERT INTO permissions (code, resource, action, description)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(code) DO UPDATE SET resource = excluded.resource, action = excluded.action, description = excluded.description`
      );
      for (const p of CANONICAL_PERMISSIONS) {
        upsertPerm.run(p.code, p.resource, p.action, p.description);
      }

      db.prepare('DELETE FROM role_permissions').run();
      const insertRp = db.prepare('INSERT INTO role_permissions (role_name, permission_code) VALUES (?, ?)');
      for (const [roleName, perms] of Object.entries(ROLE_PERMISSION_MATRIX)) {
        for (const perm of perms) {
          insertRp.run(roleName, perm);
        }
      }

      recordMigration('002', 'rbac_permissions_and_revocable_sessions');
    });
    apply002();
  } catch (err) {
    throw new DatabaseMigrationError('002', err instanceof Error ? err.message : String(err));
  }

  // -------------------------------------------------------------------------
  // Migration 003: Attendance event identity, backup history, unique indexes & DB input constraints
  // -------------------------------------------------------------------------
  try {
    const apply003 = db.transaction(() => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS attendance_events (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          event_uid TEXT NOT NULL UNIQUE,
          employee_id INTEGER NOT NULL,
          device_id INTEGER,
          attendance_date TEXT NOT NULL,
          punch_type TEXT NOT NULL CHECK (punch_type IN ('time_in', 'time_out', 'manual', 'correction')),
          punch_time TEXT NOT NULL,
          source TEXT NOT NULL DEFAULT 'kiosk',
          recorded_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
          UNIQUE(employee_id, attendance_date, punch_type, punch_time),
          FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
          FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS backup_history (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          backup_id TEXT NOT NULL UNIQUE,
          file_name TEXT NOT NULL,
          manifest_file TEXT NOT NULL DEFAULT '',
          encrypted_file TEXT NOT NULL DEFAULT '',
          sha256 TEXT NOT NULL,
          size_bytes INTEGER NOT NULL DEFAULT 0,
          encrypted INTEGER NOT NULL DEFAULT 0,
          integrity_status TEXT NOT NULL DEFAULT 'ok',
          foreign_key_violations INTEGER NOT NULL DEFAULT 0,
          schema_version TEXT NOT NULL DEFAULT '003',
          table_counts_json TEXT NOT NULL DEFAULT '{}',
          operation_type TEXT NOT NULL DEFAULT 'backup' CHECK (operation_type IN ('backup', 'restore_drill', 'restore', 'checkpoint')),
          created_by TEXT NOT NULL DEFAULT 'system',
          created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
        );

        CREATE UNIQUE INDEX IF NOT EXISTS idx_holidays_date_name ON holidays(date, name);
        CREATE UNIQUE INDEX IF NOT EXISTS idx_payroll_items_run_emp ON payroll_items(payroll_run_id, employee_id);
        CREATE UNIQUE INDEX IF NOT EXISTS idx_devices_api_token ON devices(api_token);

        CREATE INDEX IF NOT EXISTS idx_attendance_events_emp_date ON attendance_events(employee_id, attendance_date);
        CREATE INDEX IF NOT EXISTS idx_attendance_date_status ON attendance_records(date, status);
        CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp);
        CREATE INDEX IF NOT EXISTS idx_corrections_emp_date ON corrections(employee_id, attendance_date);
        CREATE INDEX IF NOT EXISTS idx_leaves_emp_dates ON leaves(employee_id, start_date, end_date);
        CREATE INDEX IF NOT EXISTS idx_backup_history_created_at ON backup_history(created_at);

        CREATE TRIGGER IF NOT EXISTS trg_emp_salary_nonneg_ins
        BEFORE INSERT ON employees
        WHEN NEW.monthly_salary < 0 OR NEW.monthly_allowance < 0
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: employee salary and allowance must be non-negative');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_emp_salary_nonneg_upd
        BEFORE UPDATE ON employees
        WHEN NEW.monthly_salary < 0 OR NEW.monthly_allowance < 0
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: employee salary and allowance must be non-negative');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_emp_status_valid_ins
        BEFORE INSERT ON employees
        WHEN NEW.status NOT IN ('Active', 'Inactive')
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: employee status must be Active or Inactive');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_emp_status_valid_upd
        BEFORE UPDATE ON employees
        WHEN NEW.status NOT IN ('Active', 'Inactive')
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: employee status must be Active or Inactive');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_att_status_valid_ins
        BEFORE INSERT ON attendance_records
        WHEN NEW.status NOT IN ('Present', 'Late', 'Absent', 'On Leave')
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: invalid attendance status');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_att_status_valid_upd
        BEFORE UPDATE ON attendance_records
        WHEN NEW.status NOT IN ('Present', 'Late', 'Absent', 'On Leave')
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: invalid attendance status');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_leaves_dates_valid_ins
        BEFORE INSERT ON leaves
        WHEN NEW.end_date < NEW.start_date OR NEW.days_count < 1
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: leave end_date must be >= start_date and days_count >= 1');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_leaves_dates_valid_upd
        BEFORE UPDATE ON leaves
        WHEN NEW.end_date < NEW.start_date OR NEW.days_count < 1
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: leave end_date must be >= start_date and days_count >= 1');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_payroll_dates_valid_ins
        BEFORE INSERT ON payroll_runs
        WHEN NEW.end_date < NEW.start_date
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: payroll end_date must be >= start_date');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_payroll_dates_valid_upd
        BEFORE UPDATE ON payroll_runs
        WHEN NEW.end_date < NEW.start_date
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: payroll end_date must be >= start_date');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_devices_status_valid_ins
        BEFORE INSERT ON devices
        WHEN NEW.status NOT IN ('Online', 'Offline')
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: device status must be Online or Offline');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_devices_status_valid_upd
        BEFORE UPDATE ON devices
        WHEN NEW.status NOT IN ('Online', 'Offline')
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: device status must be Online or Offline');
        END;
      `);

      recordMigration('003', 'build06_event_identity_and_integrity_constraints');
    });
    apply003();
  } catch (err) {
    throw new DatabaseMigrationError('003', err instanceof Error ? err.message : String(err));
  }

  // -------------------------------------------------------------------------
  // Migration 004: BUILD 08 Formalized Attendance Policy, Extended Statuses & Immutable Punch History
  // -------------------------------------------------------------------------
  try {
    const apply004 = db.transaction(() => {
      if (!tableHasColumn(db, 'shifts', 'rest_days')) {
        db.exec("ALTER TABLE shifts ADD COLUMN rest_days TEXT NOT NULL DEFAULT ''");
      }

      const attRecordAdditions: Array<[string, string]> = [
        ['break_out', 'TEXT'],
        ['break_in', 'TEXT'],
        ['overtime_out', 'TEXT'],
        ['time_in_utc', 'TEXT'],
        ['break_out_utc', 'TEXT'],
        ['break_in_utc', 'TEXT'],
        ['time_out_utc', 'TEXT'],
        ['overtime_out_utc', 'TEXT'],
        ['late_minutes', 'INTEGER NOT NULL DEFAULT 0'],
        ['undertime_minutes', 'INTEGER NOT NULL DEFAULT 0'],
        ['overtime_minutes', 'INTEGER NOT NULL DEFAULT 0'],
        ['reconciled_at', 'TEXT'],
      ];
      for (const [col, def] of attRecordAdditions) {
        if (!tableHasColumn(db, 'attendance_records', col)) {
          db.exec(`ALTER TABLE attendance_records ADD COLUMN ${col} ${def}`);
        }
      }

      // Upgrade status constraint triggers to allow all 10 approved BUILD 08 attendance statuses
      db.exec(`
        DROP TRIGGER IF EXISTS trg_att_status_valid_ins;
        DROP TRIGGER IF EXISTS trg_att_status_valid_upd;

        CREATE TRIGGER trg_att_status_valid_ins
        BEFORE INSERT ON attendance_records
        WHEN NEW.status NOT IN (
          'Present', 'Late', 'Absent', 'Undertime', 'On Leave',
          'OB', 'Rest Day', 'Holiday', 'Missing Time Out', 'No Schedule'
        )
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: invalid attendance status');
        END;

        CREATE TRIGGER trg_att_status_valid_upd
        BEFORE UPDATE ON attendance_records
        WHEN NEW.status NOT IN (
          'Present', 'Late', 'Absent', 'Undertime', 'On Leave',
          'OB', 'Rest Day', 'Holiday', 'Missing Time Out', 'No Schedule'
        )
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: invalid attendance status');
        END;
      `);

      // Non-destructively rebuild attendance_events to support all approved actions, forensic timestamps,
      // decisions, partial unique accepted-action enforcement, and strict SQLite immutability triggers.
      if (!hasMigration('004') || !tableHasColumn(db, 'attendance_events', 'server_timestamp_utc')) {
        db.exec(`
          DROP TRIGGER IF EXISTS trg_att_events_immutable_upd;
          DROP TRIGGER IF EXISTS trg_att_events_immutable_del;

          CREATE TABLE attendance_events_v4 (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_uid TEXT NOT NULL UNIQUE,
            employee_id INTEGER NOT NULL,
            device_id INTEGER,
            device_name TEXT NOT NULL DEFAULT '',
            attendance_date TEXT NOT NULL,
            punch_type TEXT NOT NULL CHECK (
              punch_type IN (
                'TIME_IN', 'BREAK_OUT', 'BREAK_IN', 'TIME_OUT', 'OVERTIME_OUT',
                'time_in', 'time_out', 'manual', 'correction', 'reconcile'
              )
            ),
            punch_time TEXT NOT NULL,
            server_timestamp_utc TEXT NOT NULL DEFAULT '',
            manila_timestamp TEXT NOT NULL DEFAULT '',
            device_timestamp_utc TEXT,
            clock_drift_seconds INTEGER,
            offline_replay INTEGER NOT NULL DEFAULT 0,
            decision TEXT NOT NULL DEFAULT 'ACCEPTED' CHECK (
              decision IN ('ACCEPTED', 'DUPLICATE_IGNORED', 'REJECTED', 'ESCALATED')
            ),
            decision_code TEXT NOT NULL DEFAULT 'OK',
            decision_reason TEXT NOT NULL DEFAULT '',
            source TEXT NOT NULL DEFAULT 'kiosk',
            recorded_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE RESTRICT,
            FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE SET NULL
          );

          INSERT INTO attendance_events_v4
            (id, event_uid, employee_id, device_id, device_name, attendance_date, punch_type, punch_time,
             server_timestamp_utc, manila_timestamp, device_timestamp_utc, clock_drift_seconds,
             offline_replay, decision, decision_code, decision_reason, source, recorded_at)
          SELECT
            ae.id,
            ae.event_uid,
            ae.employee_id,
            ae.device_id,
            COALESCE(d.name, ''),
            ae.attendance_date,
            CASE ae.punch_type
              WHEN 'time_in' THEN 'TIME_IN'
              WHEN 'time_out' THEN 'TIME_OUT'
              ELSE ae.punch_type
            END,
            ae.punch_time,
            ae.recorded_at,
            ae.recorded_at,
            NULL,
            NULL,
            0,
            'ACCEPTED',
            'LEGACY_MIGRATED',
            'Migrated from BUILD 06 attendance_events',
            ae.source,
            ae.recorded_at
          FROM attendance_events ae
          LEFT JOIN devices d ON d.id = ae.device_id;

          DROP TABLE attendance_events;
          ALTER TABLE attendance_events_v4 RENAME TO attendance_events;
        `);
      }

      db.exec(`
        CREATE INDEX IF NOT EXISTS idx_attendance_events_emp_date ON attendance_events(employee_id, attendance_date);
        CREATE INDEX IF NOT EXISTS idx_attendance_events_decision ON attendance_events(decision, attendance_date);

        CREATE UNIQUE INDEX IF NOT EXISTS idx_att_events_accepted_unique
        ON attendance_events(employee_id, attendance_date, punch_type)
        WHERE decision = 'ACCEPTED'
          AND punch_type IN ('TIME_IN', 'BREAK_OUT', 'BREAK_IN', 'TIME_OUT', 'OVERTIME_OUT');

        CREATE TRIGGER IF NOT EXISTS trg_att_events_immutable_upd
        BEFORE UPDATE ON attendance_events
        BEGIN
          SELECT RAISE(ABORT, 'IMMUTABLE_AUDIT_VIOLATION: attendance_events rows cannot be modified');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_att_events_immutable_del
        BEFORE DELETE ON attendance_events
        BEGIN
          SELECT RAISE(ABORT, 'IMMUTABLE_AUDIT_VIOLATION: attendance_events rows cannot be deleted');
        END;
      `);

      recordMigration('004', 'build08_attendance_policy_and_immutable_events');
    });
    apply004();
  } catch (err) {
    throw new DatabaseMigrationError('004', err instanceof Error ? err.message : String(err));
  }

  // -------------------------------------------------------------------------
  // Migration 005: BUILD 10 Kiosk Offline Sync, Real Heartbeat Telemetry & Biometric Evidence Binding
  // -------------------------------------------------------------------------
  try {
    const apply005 = db.transaction(() => {
      const deviceAdditions: Array<[string, string]> = [
        ['last_heartbeat_utc', 'TEXT'],
        ['last_sync_utc', 'TEXT'],
        ['pending_queue_count', 'INTEGER NOT NULL DEFAULT 0'],
        ['last_clock_drift_seconds', 'INTEGER'],
        ['last_monotonic_seq', 'INTEGER NOT NULL DEFAULT 0'],
        ['last_sync_status', "TEXT NOT NULL DEFAULT 'Idle'"],
        ['last_sync_error', "TEXT NOT NULL DEFAULT ''"],
        ['is_revoked', 'INTEGER NOT NULL DEFAULT 0'],
        ['revoked_at', 'TEXT'],
        ['device_boot_id', "TEXT NOT NULL DEFAULT ''"],
      ];
      for (const [col, def] of deviceAdditions) {
        if (!tableHasColumn(db, 'devices', col)) {
          db.exec(`ALTER TABLE devices ADD COLUMN ${col} ${def}`);
        }
      }

      // Non-destructive append-only metadata columns on attendance_events (ALTER TABLE ADD COLUMN is safe with triggers)
      const eventAdditions: Array<[string, string]> = [
        ['monotonic_seq', 'INTEGER'],
        ['device_boot_id', 'TEXT'],
        ['biometric_evidence_hash', 'TEXT'],
        ['biometric_bound', 'INTEGER NOT NULL DEFAULT 0'],
        ['capture_metadata_json', 'TEXT'],
      ];
      for (const [col, def] of eventAdditions) {
        if (!tableHasColumn(db, 'attendance_events', col)) {
          db.exec(`ALTER TABLE attendance_events ADD COLUMN ${col} ${def}`);
        }
      }

      db.exec(`
        CREATE TABLE IF NOT EXISTS kiosk_sync_batches (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          batch_uid TEXT NOT NULL UNIQUE,
          device_id INTEGER,
          device_name TEXT NOT NULL DEFAULT '',
          device_boot_id TEXT NOT NULL DEFAULT '',
          received_at_utc TEXT NOT NULL,
          total_events INTEGER NOT NULL DEFAULT 0,
          accepted_count INTEGER NOT NULL DEFAULT 0,
          duplicate_count INTEGER NOT NULL DEFAULT 0,
          conflict_count INTEGER NOT NULL DEFAULT 0,
          rejected_count INTEGER NOT NULL DEFAULT 0,
          escalated_count INTEGER NOT NULL DEFAULT 0,
          error_summary TEXT NOT NULL DEFAULT '',
          FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE SET NULL
        );

        CREATE INDEX IF NOT EXISTS idx_kiosk_sync_batches_device
        ON kiosk_sync_batches(device_id, received_at_utc);
      `);

      recordMigration('005', 'build10_kiosk_sync_telemetry_and_biometric_binding');
    });
    apply005();
  } catch (err) {
    throw new DatabaseMigrationError('005', err instanceof Error ? err.message : String(err));
  }

  // -------------------------------------------------------------------------
  // Migration 006: BUILD 11 Audit-Safe Corrections, HR Leave Policies & Multi-Day Allocations
  // -------------------------------------------------------------------------
  try {
    const apply006 = db.transaction(() => {
      // 1. Extend corrections table with original vs requested vs approved snapshots, documentation, and reversal metadata
      const correctionAdditions: Array<[string, string]> = [
        ['requested_time_out', 'TEXT'],
        ['original_time_in', 'TEXT'],
        ['original_time_out', 'TEXT'],
        ['original_status', 'TEXT'],
        ['original_work_hours', 'TEXT'],
        ['original_device_name', 'TEXT'],
        ['original_remarks', 'TEXT'],
        ['approved_time', 'TEXT'],
        ['approved_time_out', 'TEXT'],
        ['reviewer_notes', "TEXT NOT NULL DEFAULT ''"],
        ['reviewed_by_user_id', 'INTEGER'],
        ['reviewed_at_utc', 'TEXT'],
        ['attachment_name', "TEXT NOT NULL DEFAULT ''"],
        ['attachment_mime', "TEXT NOT NULL DEFAULT ''"],
        ['attachment_data', "TEXT NOT NULL DEFAULT ''"],
        ['document_reference', "TEXT NOT NULL DEFAULT ''"],
        ['pre_snapshot_json', 'TEXT'],
        ['post_snapshot_json', 'TEXT'],
        ['reversed_by', 'TEXT'],
        ['reversed_at_utc', 'TEXT'],
        ['reversal_reason', "TEXT NOT NULL DEFAULT ''"],
        ['created_by_user_id', 'INTEGER'],
        ['created_by_username', "TEXT NOT NULL DEFAULT ''"],
      ];
      for (const [col, def] of correctionAdditions) {
        if (!tableHasColumn(db, 'corrections', col)) {
          db.exec(`ALTER TABLE corrections ADD COLUMN ${col} ${def}`);
        }
      }

      // 2. Extend leaves table with half-day portion, excluded/eligible dates, reviewer & cancellation audit fields, and documentation
      const leaveAdditions: Array<[string, string]> = [
        ['day_portion', "TEXT NOT NULL DEFAULT 'FULL'"],
        ['calendar_days', 'INTEGER NOT NULL DEFAULT 1'],
        ['excluded_days_json', "TEXT NOT NULL DEFAULT '[]'"],
        ['eligible_dates_json', "TEXT NOT NULL DEFAULT '[]'"],
        ['reviewed_by_user_id', 'INTEGER'],
        ['reviewed_at', 'TEXT'],
        ['reviewed_at_utc', 'TEXT'],
        ['reviewer_notes', "TEXT NOT NULL DEFAULT ''"],
        ['cancelled_by', 'TEXT'],
        ['cancelled_at_utc', 'TEXT'],
        ['cancel_reason', "TEXT NOT NULL DEFAULT ''"],
        ['attachment_name', "TEXT NOT NULL DEFAULT ''"],
        ['attachment_mime', "TEXT NOT NULL DEFAULT ''"],
        ['attachment_data', "TEXT NOT NULL DEFAULT ''"],
        ['document_reference', "TEXT NOT NULL DEFAULT ''"],
        ['created_by_user_id', 'INTEGER'],
        ['created_by_username', "TEXT NOT NULL DEFAULT ''"],
      ];
      for (const [col, def] of leaveAdditions) {
        if (!tableHasColumn(db, 'leaves', col)) {
          db.exec(`ALTER TABLE leaves ADD COLUMN ${col} ${def}`);
        }
      }

      // 3. Create configurable HR-approved leave policies, per-day allocations, and immutable audit logs
      db.exec(`
        CREATE TABLE IF NOT EXISTS leave_policies (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          leave_type TEXT NOT NULL UNIQUE,
          code TEXT NOT NULL UNIQUE,
          annual_entitlement REAL NOT NULL DEFAULT 15,
          track_balance INTEGER NOT NULL DEFAULT 1,
          allow_half_day INTEGER NOT NULL DEFAULT 1,
          exclude_weekends_rest_days INTEGER NOT NULL DEFAULT 1,
          exclude_holidays INTEGER NOT NULL DEFAULT 1,
          allow_negative_balance INTEGER NOT NULL DEFAULT 0,
          requires_document_after_days REAL NOT NULL DEFAULT 0,
          attendance_status TEXT NOT NULL DEFAULT 'On Leave',
          is_paid INTEGER NOT NULL DEFAULT 1,
          is_active INTEGER NOT NULL DEFAULT 1,
          updated_by TEXT NOT NULL DEFAULT 'system',
          updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS leave_day_allocations (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          leave_id INTEGER NOT NULL,
          employee_id INTEGER NOT NULL,
          leave_date TEXT NOT NULL,
          leave_year INTEGER NOT NULL,
          day_fraction REAL NOT NULL DEFAULT 1.0,
          day_portion TEXT NOT NULL DEFAULT 'FULL',
          attendance_applied INTEGER NOT NULL DEFAULT 0,
          conflict_preserved INTEGER NOT NULL DEFAULT 0,
          conflict_note TEXT NOT NULL DEFAULT '',
          pre_snapshot_json TEXT,
          UNIQUE(leave_id, leave_date),
          FOREIGN KEY (leave_id) REFERENCES leaves(id) ON DELETE CASCADE,
          FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_leave_alloc_emp_year
        ON leave_day_allocations(employee_id, leave_year, leave_date);

        CREATE INDEX IF NOT EXISTS idx_leave_alloc_emp_date
        ON leave_day_allocations(employee_id, leave_date);

        CREATE TABLE IF NOT EXISTS correction_audit_log (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          correction_id INTEGER NOT NULL,
          employee_id INTEGER NOT NULL,
          attendance_date TEXT NOT NULL,
          action TEXT NOT NULL,
          original_value TEXT NOT NULL DEFAULT '',
          requested_value TEXT NOT NULL DEFAULT '',
          approved_value TEXT NOT NULL DEFAULT '',
          reason TEXT NOT NULL DEFAULT '',
          document_ref TEXT NOT NULL DEFAULT '',
          reviewer_notes TEXT NOT NULL DEFAULT '',
          actor_user_id INTEGER,
          actor_username TEXT NOT NULL,
          actor_role TEXT NOT NULL DEFAULT '',
          acted_at_utc TEXT NOT NULL,
          acted_at_manila TEXT NOT NULL,
          ip_address TEXT NOT NULL DEFAULT '127.0.0.1'
        );

        CREATE INDEX IF NOT EXISTS idx_correction_audit_corr
        ON correction_audit_log(correction_id, id);

        CREATE TRIGGER IF NOT EXISTS trg_correction_audit_no_update
        BEFORE UPDATE ON correction_audit_log
        BEGIN
          SELECT RAISE(ABORT, 'IMMUTABLE_AUDIT_VIOLATION: correction_audit_log rows cannot be updated');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_correction_audit_no_delete
        BEFORE DELETE ON correction_audit_log
        BEGIN
          SELECT RAISE(ABORT, 'IMMUTABLE_AUDIT_VIOLATION: correction_audit_log rows cannot be deleted');
        END;

        CREATE TABLE IF NOT EXISTS leave_audit_log (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          leave_id INTEGER NOT NULL,
          employee_id INTEGER NOT NULL,
          action TEXT NOT NULL,
          previous_status TEXT NOT NULL DEFAULT '',
          new_status TEXT NOT NULL DEFAULT '',
          days_affected REAL NOT NULL DEFAULT 0,
          applied_dates_json TEXT NOT NULL DEFAULT '[]',
          reason TEXT NOT NULL DEFAULT '',
          notes TEXT NOT NULL DEFAULT '',
          actor_user_id INTEGER,
          actor_username TEXT NOT NULL,
          actor_role TEXT NOT NULL DEFAULT '',
          acted_at_utc TEXT NOT NULL,
          acted_at_manila TEXT NOT NULL,
          ip_address TEXT NOT NULL DEFAULT '127.0.0.1'
        );

        CREATE INDEX IF NOT EXISTS idx_leave_audit_leave
        ON leave_audit_log(leave_id, id);

        CREATE TRIGGER IF NOT EXISTS trg_leave_audit_no_update
        BEFORE UPDATE ON leave_audit_log
        BEGIN
          SELECT RAISE(ABORT, 'IMMUTABLE_AUDIT_VIOLATION: leave_audit_log rows cannot be updated');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_leave_audit_no_delete
        BEFORE DELETE ON leave_audit_log
        BEGIN
          SELECT RAISE(ABORT, 'IMMUTABLE_AUDIT_VIOLATION: leave_audit_log rows cannot be deleted');
        END;

        -- Upgrade attendance_records status triggers to support Missing Time In alongside all 10 BUILD 08 statuses
        DROP TRIGGER IF EXISTS trg_att_status_valid_ins;
        DROP TRIGGER IF EXISTS trg_att_status_valid_upd;

        CREATE TRIGGER trg_att_status_valid_ins
        BEFORE INSERT ON attendance_records
        WHEN NEW.status NOT IN ('Present', 'Late', 'Absent', 'Undertime', 'On Leave', 'OB', 'Rest Day', 'Holiday', 'Missing Time Out', 'Missing Time In', 'No Schedule')
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: invalid attendance status');
        END;

        CREATE TRIGGER trg_att_status_valid_upd
        BEFORE UPDATE ON attendance_records
        WHEN NEW.status NOT IN ('Present', 'Late', 'Absent', 'Undertime', 'On Leave', 'OB', 'Rest Day', 'Holiday', 'Missing Time Out', 'Missing Time In', 'No Schedule')
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: invalid attendance status');
        END;

        -- Upgrade leaves triggers to support 0.5 half-day increments and Cancelled status
        DROP TRIGGER IF EXISTS trg_leaves_dates_valid_ins;
        DROP TRIGGER IF EXISTS trg_leaves_dates_valid_upd;

        CREATE TRIGGER trg_leaves_dates_valid_ins
        BEFORE INSERT ON leaves
        WHEN NEW.end_date < NEW.start_date OR NEW.days_count <= 0 OR NEW.status NOT IN ('Pending', 'Approved', 'Rejected', 'Cancelled')
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: leave end_date must be >= start_date, days_count > 0, and status valid');
        END;

        CREATE TRIGGER trg_leaves_dates_valid_upd
        BEFORE UPDATE ON leaves
        WHEN NEW.end_date < NEW.start_date OR NEW.days_count <= 0 OR NEW.status NOT IN ('Pending', 'Approved', 'Rejected', 'Cancelled')
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: leave end_date must be >= start_date, days_count > 0, and status valid');
        END;
      `);

      // 4. Seed HR-approved configurable leave policies (INSERT OR IGNORE preserves admin edits)
      const insertPolicy = db.prepare(`
        INSERT OR IGNORE INTO leave_policies
          (leave_type, code, annual_entitlement, track_balance, allow_half_day,
           exclude_weekends_rest_days, exclude_holidays, allow_negative_balance,
           requires_document_after_days, attendance_status, is_paid, is_active, updated_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'system')
      `);
      const defaultPolicies: Array<[string, string, number, number, number, number, number, number, number, string, number]> = [
        ['Vacation Leave', 'VL', 15, 1, 1, 1, 1, 0, 0, 'On Leave', 1],
        ['Sick Leave', 'SL', 15, 1, 1, 1, 1, 0, 3, 'On Leave', 1],
        ['Emergency Leave', 'EL', 5, 1, 1, 1, 1, 0, 0, 'On Leave', 1],
        ['Official Business', 'OB', 0, 0, 1, 1, 1, 1, 0, 'OB', 1],
        ['Maternity/Paternity', 'MP', 105, 1, 0, 0, 0, 0, 1, 'On Leave', 1],
      ];
      for (const p of defaultPolicies) {
        insertPolicy.run(...p);
      }

      // 5. Non-destructively backfill per-day leave_day_allocations for any legacy Approved/Pending leaves missing allocations
      const legacyLeaves = db
        .prepare(
          `SELECT l.id, l.employee_id, l.start_date, l.end_date, l.days_count, l.day_portion, l.status
           FROM leaves l
           WHERE NOT EXISTS (SELECT 1 FROM leave_day_allocations a WHERE a.leave_id = l.id)`
        )
        .all() as Array<{
        id: number;
        employee_id: number;
        start_date: string;
        end_date: string;
        days_count: number;
        day_portion: string;
        status: string;
      }>;
      const insertAlloc = db.prepare(`
        INSERT OR IGNORE INTO leave_day_allocations
          (leave_id, employee_id, leave_date, leave_year, day_fraction, day_portion, attendance_applied, conflict_preserved, conflict_note)
        VALUES (?, ?, ?, ?, ?, ?, ?, 0, '')
      `);
      for (const lv of legacyLeaves) {
        const portion = lv.day_portion || 'FULL';
        const isHalf = portion === 'HALF_AM' || portion === 'HALF_PM';
        let cursor = lv.start_date;
        let guard = 0;
        while (cursor <= lv.end_date && guard < 370) {
          const yr = Number(cursor.slice(0, 4)) || 2026;
          insertAlloc.run(
            lv.id,
            lv.employee_id,
            cursor,
            yr,
            isHalf ? 0.5 : 1.0,
            portion,
            lv.status === 'Approved' ? 1 : 0
          );
          cursor = addDaysIso(cursor, 1);
          guard++;
        }
      }

      recordMigration('006', 'build11_corrections_leaves_policies_and_immutable_audit');
    });
    apply006();
  } catch (err) {
    throw new DatabaseMigrationError('006', err instanceof Error ? err.message : String(err));
  }

  // -------------------------------------------------------------------------
  // Migration 007: BUILD 12 Institutional Payroll Policies, Immutability Triggers,
  // Maker-Checker Controls, Snapshot Hashing & Immutable Payroll Audit Log
  // -------------------------------------------------------------------------
  try {
    const apply007 = db.transaction(() => {
      // 1. Institutional effective-dated payroll policies (NEVER auto-seeded as Finance-approved)
      db.exec(`
        CREATE TABLE IF NOT EXISTS payroll_policies (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          policy_code TEXT NOT NULL UNIQUE,
          policy_name TEXT NOT NULL,
          effective_from TEXT NOT NULL,
          effective_to TEXT,
          approval_status TEXT NOT NULL DEFAULT 'DRAFT_NOT_APPROVED' CHECK (
            approval_status IN ('DRAFT_NOT_APPROVED', 'APPROVED_BY_FINANCE', 'SUPERSEDED')
          ),
          approval_reference TEXT NOT NULL DEFAULT '',
          finance_approved_by TEXT,
          finance_approved_by_user_id INTEGER,
          finance_approved_at_utc TEXT,
          rules_json TEXT NOT NULL,
          notes TEXT NOT NULL DEFAULT '',
          created_by_user_id INTEGER,
          created_by TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          updated_by TEXT NOT NULL DEFAULT '',
          updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_payroll_policies_effective
        ON payroll_policies(approval_status, effective_from, effective_to);
      `);

      // 2. Extend payroll_runs with policy snapshot, versioning, SHA-256 hash, maker-checker & Finance sign-off metadata
      const payrollRunAdditions: Array<[string, string]> = [
        ['policy_id', 'INTEGER'],
        ['policy_code', "TEXT NOT NULL DEFAULT ''"],
        ['policy_approval_status', "TEXT NOT NULL DEFAULT 'DRAFT_NOT_APPROVED'"],
        ['is_production_approved', 'INTEGER NOT NULL DEFAULT 0'],
        ['calculation_engine_version', "TEXT NOT NULL DEFAULT 'BUILD12-v1.0'"],
        ['calculation_version', 'INTEGER NOT NULL DEFAULT 1'],
        ['snapshot_sha256', "TEXT NOT NULL DEFAULT ''"],
        ['policy_snapshot_json', 'TEXT'],
        ['reconciliation_summary_json', 'TEXT'],
        ['computed_by_user_id', 'INTEGER'],
        ['finalized_by_user_id', 'INTEGER'],
        ['finalized_by', 'TEXT'],
        ['finalized_at_utc', 'TEXT'],
        ['finance_signoff_by_user_id', 'INTEGER'],
        ['finance_signoff_by', 'TEXT'],
        ['finance_signoff_ref', "TEXT NOT NULL DEFAULT ''"],
        ['finance_signoff_at_utc', 'TEXT'],
        ['released_by_user_id', 'INTEGER'],
        ['released_by', 'TEXT'],
        ['released_at_utc', 'TEXT'],
        ['total_overtime_pay', 'REAL NOT NULL DEFAULT 0'],
        ['total_holiday_rest_pay', 'REAL NOT NULL DEFAULT 0'],
        ['total_gross_pay', 'REAL NOT NULL DEFAULT 0'],
        ['updated_at', 'TEXT'],
      ];
      for (const [col, def] of payrollRunAdditions) {
        if (!tableHasColumn(db, 'payroll_runs', col)) {
          db.exec(`ALTER TABLE payroll_runs ADD COLUMN ${col} ${def}`);
        }
      }

      // 3. Extend payroll_items with granular earnings, deductions, leave/holiday/OT/rest-day breakdown & snapshot JSON
      const payrollItemAdditions: Array<[string, string]> = [
        ['employee_type', "TEXT NOT NULL DEFAULT 'Regular'"],
        ['scheduled_working_days', 'REAL NOT NULL DEFAULT 0'],
        ['days_paid_leave', 'REAL NOT NULL DEFAULT 0'],
        ['days_unpaid_leave', 'REAL NOT NULL DEFAULT 0'],
        ['days_holiday', 'REAL NOT NULL DEFAULT 0'],
        ['days_rest_worked', 'REAL NOT NULL DEFAULT 0'],
        ['late_minutes', 'INTEGER NOT NULL DEFAULT 0'],
        ['undertime_minutes', 'INTEGER NOT NULL DEFAULT 0'],
        ['overtime_minutes', 'INTEGER NOT NULL DEFAULT 0'],
        ['prorated_basic_pay', 'REAL NOT NULL DEFAULT 0'],
        ['overtime_pay', 'REAL NOT NULL DEFAULT 0'],
        ['holiday_rest_pay', 'REAL NOT NULL DEFAULT 0'],
        ['late_deduction', 'REAL NOT NULL DEFAULT 0'],
        ['undertime_deduction', 'REAL NOT NULL DEFAULT 0'],
        ['absence_deduction', 'REAL NOT NULL DEFAULT 0'],
        ['unpaid_leave_deduction', 'REAL NOT NULL DEFAULT 0'],
        ['statutory_deductions', 'REAL NOT NULL DEFAULT 0'],
        ['tax_deduction', 'REAL NOT NULL DEFAULT 0'],
        ['other_deductions', 'REAL NOT NULL DEFAULT 0'],
        ['other_earnings', 'REAL NOT NULL DEFAULT 0'],
        ['gross_pay', 'REAL NOT NULL DEFAULT 0'],
        ['breakdown_json', "TEXT NOT NULL DEFAULT '{}'"],
      ];
      for (const [col, def] of payrollItemAdditions) {
        if (!tableHasColumn(db, 'payroll_items', col)) {
          db.exec(`ALTER TABLE payroll_items ADD COLUMN ${col} ${def}`);
        }
      }

      // 4. Period-based uniqueness index on payroll_runs (start_date, end_date)
      //    If legacy DB somehow contains duplicate non-locked test runs for identical dates, keep latest only?
      //    We NEVER silently delete data; unique index creates cleanly on valid data and enforces period uniqueness going forward.
      db.exec(`
        CREATE UNIQUE INDEX IF NOT EXISTS idx_payroll_runs_period_unique
        ON payroll_runs(start_date, end_date);
      `);

      // 5. Immutable payroll_audit_log (no ON DELETE CASCADE so immutability triggers never conflict)
      db.exec(`
        CREATE TABLE IF NOT EXISTS payroll_audit_log (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          payroll_run_id INTEGER,
          policy_id INTEGER,
          action TEXT NOT NULL,
          previous_status TEXT NOT NULL DEFAULT '',
          new_status TEXT NOT NULL DEFAULT '',
          calculation_version INTEGER NOT NULL DEFAULT 0,
          snapshot_sha256 TEXT NOT NULL DEFAULT '',
          reference_code TEXT NOT NULL DEFAULT '',
          details_json TEXT NOT NULL DEFAULT '{}',
          actor_user_id INTEGER,
          actor_username TEXT NOT NULL,
          actor_role TEXT NOT NULL DEFAULT '',
          acted_at_utc TEXT NOT NULL,
          acted_at_manila TEXT NOT NULL,
          ip_address TEXT NOT NULL DEFAULT '127.0.0.1'
        );

        CREATE INDEX IF NOT EXISTS idx_payroll_audit_run
        ON payroll_audit_log(payroll_run_id, id);

        CREATE TRIGGER IF NOT EXISTS trg_payroll_audit_no_update
        BEFORE UPDATE ON payroll_audit_log
        BEGIN
          SELECT RAISE(ABORT, 'IMMUTABLE_AUDIT_VIOLATION: payroll_audit_log rows cannot be updated');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_payroll_audit_no_delete
        BEFORE DELETE ON payroll_audit_log
        BEGIN
          SELECT RAISE(ABORT, 'IMMUTABLE_AUDIT_VIOLATION: payroll_audit_log rows cannot be deleted');
        END;
      `);

      // 6. Strict SQLite immutability & status-validity triggers on payroll_runs and payroll_items
      db.exec(`
        DROP TRIGGER IF EXISTS trg_payroll_runs_status_valid_ins;
        DROP TRIGGER IF EXISTS trg_payroll_runs_status_valid_upd;
        DROP TRIGGER IF EXISTS trg_payroll_runs_released_immutable_upd;
        DROP TRIGGER IF EXISTS trg_payroll_runs_finalized_immutable_upd;
        DROP TRIGGER IF EXISTS trg_payroll_runs_no_delete_locked;
        DROP TRIGGER IF EXISTS trg_payroll_items_locked_ins;
        DROP TRIGGER IF EXISTS trg_payroll_items_locked_upd;
        DROP TRIGGER IF EXISTS trg_payroll_items_locked_del;

        CREATE TRIGGER trg_payroll_runs_status_valid_ins
        BEFORE INSERT ON payroll_runs
        WHEN NEW.status NOT IN ('Computed', 'Finalized', 'Released')
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: invalid payroll run status');
        END;

        CREATE TRIGGER trg_payroll_runs_status_valid_upd
        BEFORE UPDATE ON payroll_runs
        WHEN NEW.status NOT IN ('Computed', 'Finalized', 'Released')
        BEGIN
          SELECT RAISE(ABORT, 'CHECK constraint failed: invalid payroll run status');
        END;

        CREATE TRIGGER trg_payroll_runs_released_immutable_upd
        BEFORE UPDATE ON payroll_runs
        WHEN OLD.status = 'Released'
        BEGIN
          SELECT RAISE(ABORT, 'PAYROLL_LOCKED_VIOLATION: Released payroll runs are strictly immutable');
        END;

        CREATE TRIGGER trg_payroll_runs_finalized_immutable_upd
        BEFORE UPDATE ON payroll_runs
        WHEN OLD.status = 'Finalized' AND (
          NEW.status NOT IN ('Finalized', 'Released')
          OR NEW.period_label != OLD.period_label
          OR NEW.start_date != OLD.start_date
          OR NEW.end_date != OLD.end_date
          OR NEW.total_basic_pay != OLD.total_basic_pay
          OR NEW.total_allowances != OLD.total_allowances
          OR NEW.total_deductions != OLD.total_deductions
          OR NEW.total_net_pay != OLD.total_net_pay
          OR NEW.total_overtime_pay != OLD.total_overtime_pay
          OR NEW.total_holiday_rest_pay != OLD.total_holiday_rest_pay
          OR NEW.total_gross_pay != OLD.total_gross_pay
          OR NEW.employee_count != OLD.employee_count
          OR COALESCE(NEW.policy_id, -1) != COALESCE(OLD.policy_id, -1)
          OR NEW.calculation_version != OLD.calculation_version
          OR NEW.snapshot_sha256 != OLD.snapshot_sha256
          OR COALESCE(NEW.policy_snapshot_json, '') != COALESCE(OLD.policy_snapshot_json, '')
        )
        BEGIN
          SELECT RAISE(ABORT, 'PAYROLL_LOCKED_VIOLATION: Finalized payroll figures and policy snapshot are immutable');
        END;

        CREATE TRIGGER trg_payroll_runs_no_delete_locked
        BEFORE DELETE ON payroll_runs
        WHEN OLD.status IN ('Finalized', 'Released')
        BEGIN
          SELECT RAISE(ABORT, 'PAYROLL_LOCKED_VIOLATION: Finalized or Released payroll runs cannot be deleted');
        END;

        CREATE TRIGGER trg_payroll_items_locked_ins
        BEFORE INSERT ON payroll_items
        WHEN (SELECT status FROM payroll_runs WHERE id = NEW.payroll_run_id) IN ('Finalized', 'Released')
        BEGIN
          SELECT RAISE(ABORT, 'PAYROLL_LOCKED_VIOLATION: Cannot insert items into a Finalized or Released payroll run');
        END;

        CREATE TRIGGER trg_payroll_items_locked_upd
        BEFORE UPDATE ON payroll_items
        WHEN (SELECT status FROM payroll_runs WHERE id = OLD.payroll_run_id) IN ('Finalized', 'Released')
        BEGIN
          SELECT RAISE(ABORT, 'PAYROLL_LOCKED_VIOLATION: Cannot modify items of a Finalized or Released payroll run');
        END;

        CREATE TRIGGER trg_payroll_items_locked_del
        BEFORE DELETE ON payroll_items
        WHEN (SELECT status FROM payroll_runs WHERE id = OLD.payroll_run_id) IN ('Finalized', 'Released')
        BEGIN
          SELECT RAISE(ABORT, 'PAYROLL_LOCKED_VIOLATION: Cannot delete items from a Finalized or Released payroll run');
        END;
      `);

      recordMigration('007', 'build12_payroll_policies_immutability_maker_checker_and_audit');
    });
    apply007();
  } catch (err) {
    throw new DatabaseMigrationError('007', err instanceof Error ? err.message : String(err));
  }

  // -------------------------------------------------------------------------
  // Migration 008: BUILD 13 Monthly DTR Verification & Sign-Off Metadata
  // -------------------------------------------------------------------------
  try {
    const apply008 = db.transaction(() => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS dtr_signoffs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          employee_id INTEGER NOT NULL,
          month TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'SIGNED' CHECK (status IN ('SIGNED', 'REVOKED')),
          employee_signed_by_user_id INTEGER,
          employee_signed_by TEXT,
          employee_signed_at_utc TEXT,
          supervisor_verified_by_user_id INTEGER,
          supervisor_verified_by TEXT,
          supervisor_verified_at_utc TEXT,
          campus_director_name TEXT NOT NULL DEFAULT '',
          dtr_snapshot_sha256 TEXT NOT NULL DEFAULT '',
          notes TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
          updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
          UNIQUE(employee_id, month),
          FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_dtr_signoffs_emp_month
        ON dtr_signoffs(employee_id, month);
      `);

      recordMigration('008', 'build13_dtr_signoffs_and_reporting_controls');
    });
    apply008();
  } catch (err) {
    throw new DatabaseMigrationError('008', err instanceof Error ? err.message : String(err));
  }

  // -------------------------------------------------------------------------
  // Migration 009: BUILD 14 Tamper-Evident Audit Chain, Device Secrets,
  //                Role-Targeted Notifications, and Data Retention Jobs
  // -------------------------------------------------------------------------
  try {
    const alreadyApplied009 = Boolean(
      db.prepare("SELECT 1 FROM schema_migrations WHERE version = '009'").get()
    );
    const apply009 = db.transaction(() => {
      // 1. Audit Logs structured metadata & SHA-256 hash chaining
      const auditAdditions: Array<[string, string]> = [
        ['action_type', "TEXT NOT NULL DEFAULT 'EVENT'"],
        ['target_type', "TEXT NOT NULL DEFAULT ''"],
        ['target_id', "TEXT NOT NULL DEFAULT ''"],
        ['before_json', "TEXT NOT NULL DEFAULT ''"],
        ['after_json', "TEXT NOT NULL DEFAULT ''"],
        ['prev_hash', "TEXT NOT NULL DEFAULT ''"],
        ['entry_hash', "TEXT NOT NULL DEFAULT ''"],
        ['is_security_event', 'INTEGER NOT NULL DEFAULT 0'],
      ];
      for (const [col, def] of auditAdditions) {
        if (!tableHasColumn(db, 'audit_logs', col)) {
          db.exec(`ALTER TABLE audit_logs ADD COLUMN ${col} ${def}`);
        }
      }

      if (!alreadyApplied009) {
        db.exec(`
          DROP TRIGGER IF EXISTS trg_audit_logs_no_update;
          DROP TRIGGER IF EXISTS trg_audit_logs_no_delete;
        `);
        backfillAuditLogHashChain(db);
      }

      db.exec(`
        CREATE INDEX IF NOT EXISTS idx_audit_logs_security
        ON audit_logs(is_security_event, id DESC);

        CREATE TRIGGER IF NOT EXISTS trg_audit_logs_no_update
        BEFORE UPDATE ON audit_logs
        BEGIN
          SELECT RAISE(ABORT, 'IMMUTABLE_AUDIT_VIOLATION: audit_logs entries are append-only and cannot be modified');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_audit_logs_no_delete
        BEFORE DELETE ON audit_logs
        BEGIN
          SELECT RAISE(ABORT, 'IMMUTABLE_AUDIT_VIOLATION: audit_logs entries are append-only and cannot be deleted');
        END;
      `);

      // 2. Notifications audience/role targeting & deduplication metadata
      const notifAdditions: Array<[string, string]> = [
        ['target_roles', "TEXT NOT NULL DEFAULT ''"],
        ['event_type', "TEXT NOT NULL DEFAULT 'general'"],
        ['dedupe_key', "TEXT NOT NULL DEFAULT ''"],
        ['metadata_json', "TEXT NOT NULL DEFAULT '{}'"],
      ];
      for (const [col, def] of notifAdditions) {
        if (!tableHasColumn(db, 'notifications', col)) {
          db.exec(`ALTER TABLE notifications ADD COLUMN ${col} ${def}`);
        }
      }
      db.exec(`
        CREATE INDEX IF NOT EXISTS idx_notifications_dedupe
        ON notifications(dedupe_key, is_read);
      `);

      // 3. Devices token hashing/masking & offline alert state tracking
      const deviceAdditions: Array<[string, string]> = [
        ['token_hash', "TEXT NOT NULL DEFAULT ''"],
        ['token_masked', "TEXT NOT NULL DEFAULT ''"],
        ['token_rotated_at', 'TEXT'],
        ['offline_alert_state', "TEXT NOT NULL DEFAULT 'NONE'"],
        ['last_alerted_at_utc', 'TEXT'],
      ];
      for (const [col, def] of deviceAdditions) {
        if (!tableHasColumn(db, 'devices', col)) {
          db.exec(`ALTER TABLE devices ADD COLUMN ${col} ${def}`);
        }
      }

      const unhashedDevices = db
        .prepare("SELECT id, api_token FROM devices WHERE token_hash = '' OR token_masked = ''")
        .all() as Array<{ id: number; api_token: string }>;
      const updDevice = db.prepare('UPDATE devices SET token_hash = ?, token_masked = ? WHERE id = ?');
      for (const dev of unhashedDevices) {
        const raw = String(dev.api_token || '');
        const tokenHash = raw ? crypto.createHash('sha256').update(raw).digest('hex') : '';
        const tokenMasked = raw.length >= 4 ? `••••••••${raw.slice(-4)}` : '••••••••';
        updDevice.run(tokenHash, tokenMasked, dev.id);
      }

      // 4. Data Retention Jobs Ledger
      db.exec(`
        CREATE TABLE IF NOT EXISTS retention_jobs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          job_uid TEXT UNIQUE NOT NULL,
          mode TEXT NOT NULL CHECK (mode IN ('DRY_RUN', 'EXECUTE')),
          attendance_retention_days INTEGER NOT NULL,
          audit_log_retention_days INTEGER NOT NULL,
          cutoff_attendance_date TEXT NOT NULL,
          cutoff_audit_date TEXT NOT NULL,
          deleted_counts_json TEXT NOT NULL DEFAULT '{}',
          skipped_counts_json TEXT NOT NULL DEFAULT '{}',
          total_deleted INTEGER NOT NULL DEFAULT 0,
          status TEXT NOT NULL DEFAULT 'Completed',
          executed_by TEXT NOT NULL,
          executed_at_utc TEXT NOT NULL,
          notes TEXT NOT NULL DEFAULT ''
        );

        CREATE INDEX IF NOT EXISTS idx_retention_jobs_executed
        ON retention_jobs(id DESC);
      `);

      recordMigration('009', 'build14_tamper_evident_audit_retention_notifications_and_device_secrets');
    });
    apply009();
  } catch (err) {
    throw new DatabaseMigrationError('009', err instanceof Error ? err.message : String(err));
  }
  // Migration 010: Server-side encrypted kiosk enrollment reference (never stores plaintext vectors).
  try {
    const apply010 = db.transaction(() => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS kiosk_face_templates (
          employee_id INTEGER PRIMARY KEY REFERENCES employees(id) ON DELETE CASCADE,
          template_sha256 TEXT NOT NULL,
          encrypted_embedding TEXT NOT NULL,
          iv_hex TEXT NOT NULL,
          tag_hex TEXT NOT NULL,
          device_id INTEGER REFERENCES devices(id) ON DELETE SET NULL,
          enrolled_at_utc TEXT NOT NULL,
          created_at_utc TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS idx_face_templates_device ON kiosk_face_templates(device_id);
      `);
      recordMigration('010', 'build18_encrypted_android_enrollment');
    });
    apply010();
  } catch (err) {
    throw new DatabaseMigrationError('010', err instanceof Error ? err.message : String(err));
  }

  // Per-user read tracking for employee self-service notifications (idempotent, additive)
  db.exec(`
    CREATE TABLE IF NOT EXISTS employee_notification_reads (
      user_id INTEGER NOT NULL,
      notification_key TEXT NOT NULL,
      read_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      PRIMARY KEY (user_id, notification_key),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_emp_notif_reads_user ON employee_notification_reads(user_id);
  `);

  // Migration 011: BUILD 36 Web Face Recognition Kiosk (HttpOnly sessions, single-use challenges, activation codes & persisted settings)
  try {
    const apply011 = db.transaction(() => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS web_kiosk_sessions (
          sid TEXT PRIMARY KEY,
          device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
          csrf_token TEXT NOT NULL,
          admin_unlocked_until INTEGER,
          admin_user_id INTEGER,
          admin_username TEXT NOT NULL DEFAULT '',
          created_at_utc TEXT NOT NULL,
          expires_at INTEGER NOT NULL,
          revoked_at TEXT,
          revoked_reason TEXT,
          ip_address TEXT NOT NULL DEFAULT '',
          user_agent TEXT NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_web_kiosk_sessions_device ON web_kiosk_sessions(device_id);
        CREATE INDEX IF NOT EXISTS idx_web_kiosk_sessions_expires ON web_kiosk_sessions(expires_at);

        CREATE TABLE IF NOT EXISTS web_kiosk_challenges (
          nonce TEXT PRIMARY KEY,
          device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
          action_scope TEXT NOT NULL CHECK (action_scope IN ('ATTENDANCE', 'ENROLLMENT')),
          created_at_ms INTEGER NOT NULL,
          expires_at_ms INTEGER NOT NULL,
          used_at_ms INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_web_kiosk_challenges_device ON web_kiosk_challenges(device_id);
        CREATE INDEX IF NOT EXISTS idx_web_kiosk_challenges_expires ON web_kiosk_challenges(expires_at_ms);
      `);

      const webKioskDeviceAdditions: Array<[string, string]> = [
        ['activation_code_hash', "TEXT NOT NULL DEFAULT ''"],
        ['activation_code_expires_at', 'TEXT'],
        ['activation_code_used_at', 'TEXT'],
        ['face_capture_enabled', 'INTEGER NOT NULL DEFAULT 1'],
        ['voice_prompt_enabled', 'INTEGER NOT NULL DEFAULT 1'],
        ['liveness_enforced', 'INTEGER NOT NULL DEFAULT 1'],
        ['camera_health', "TEXT NOT NULL DEFAULT 'unknown'"],
        ['model_readiness_json', "TEXT NOT NULL DEFAULT '{}'"],
        ['kiosk_app_version', "TEXT NOT NULL DEFAULT 'v5.0.0 (Web)'"],
      ];
      for (const [col, def] of webKioskDeviceAdditions) {
        if (!tableHasColumn(db, 'devices', col)) {
          db.exec(`ALTER TABLE devices ADD COLUMN ${col} ${def}`);
        }
      }

      recordMigration('011', 'build36_web_kiosk_sessions_activation_pin_settings_challenges');
    });
    apply011();
  } catch (err) {
    throw new DatabaseMigrationError('011', err instanceof Error ? err.message : String(err));
  }
}

function seedBaselineSettings(db: Database.Database): void {
  const insertSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value, category) VALUES (?, ?, ?)');
  const defaultSettings: Array<[string, string, string]> = [
    ['campus_name', 'Romblon State University – Cajidiocan Campus', 'general'],
    ['system_title', 'SAVAGE-RSUCAJ Smart Attendance System', 'general'],
    ['timezone', 'Asia/Manila', 'general'],
    ['campus_director_name', '', 'general'],
    ['cs_form_48_reference_verified', 'false', 'general'],
    ['cs_form_48_reference_note', 'Pending verified RSU-approved Civil Service Form 48 official reference', 'general'],
    ['default_grace_minutes', '15', 'general'],
    ['work_hours_per_day', '8', 'general'],
    ['next_day_timeout_cutoff', '03:00', 'general'],
    ['correction_require_document', 'false', 'general'],
    ['leave_weekend_days', 'Sat,Sun', 'general'],
    ['kiosk_api_endpoint', '/api/kiosk/punch', 'api'],
    ['kiosk_sync_endpoint', '/api/kiosk/sync', 'api'],
    ['kiosk_heartbeat_interval_sec', '30', 'api'],
    ['device_heartbeat_timeout_sec', '90', 'api'],
    ['device_stale_warning_sec', '60', 'api'],
    ['kiosk_sync_max_batch_size', '100', 'api'],
    ['kiosk_max_clock_drift_sec', '120', 'api'],
    ['kiosk_offline_replay_max_hours', '72', 'api'],
    ['require_kiosk_token', 'true', 'api'],
    ['session_timeout_hours', '12', 'security'],
    ['enforce_strong_passwords', 'true', 'security'],
    ['kiosk_admin_pin_hash', '', 'security'],
    ['kiosk_admin_pin_salt', '', 'security'],
    ['kiosk_admin_pin_failed_attempts', '0', 'security'],
    ['kiosk_admin_pin_locked_until', '', 'security'],
    ['kiosk_require_server_biometric_attestation', 'true', 'security'],
    ['attendance_retention_days', '1825', 'retention'],
    ['audit_log_retention_days', '730', 'retention'],
  ];
  for (const s of defaultSettings) insertSetting.run(...s);
}

function bootstrapInitialAdminIfNeeded(db: Database.Database, options: InitDatabaseOptions): void {
  if (options.skipAdminBootstrap) return;

  const userCount = (db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number }).c;
  if (userCount > 0) {
    // Existing database already has user account(s); preserve them intact without overwriting passwords.
    return;
  }

  const initialUsername = (options.initialAdmin?.username ?? process.env.ADMIN_INITIAL_USERNAME ?? '').trim();
  const initialEmail = (options.initialAdmin?.email ?? process.env.ADMIN_INITIAL_EMAIL ?? '').trim();
  const initialPass = (options.initialAdmin?.password ?? process.env.ADMIN_INITIAL_PASSWORD ?? '').trim();

  if (!initialUsername || !initialEmail || !initialPass) {
    throw new InitialAdminCredentialsMissingError(
      'Fresh database initialization refused: ADMIN_INITIAL_USERNAME, ADMIN_INITIAL_EMAIL, and ADMIN_INITIAL_PASSWORD must be configured in .env. Hardcoded default credentials are disabled.'
    );
  }

  const pwErr = validatePasswordStrength(initialPass);
  if (pwErr) {
    throw new InitialAdminCredentialsMissingError(`ADMIN_INITIAL_PASSWORD rejected: ${pwErr}`);
  }

  const { hash, salt } = hashPassword(initialPass);
  db.prepare(
    `INSERT INTO users (username, email, full_name, role, password_hash, salt, must_change_password, is_active)
     VALUES (?, ?, ?, 'Administrator', ?, ?, 1, 1)`
  ).run(initialUsername, initialEmail, 'System Administrator', hash, salt);

  logAudit(
    db,
    initialUsername,
    'Bootstrapped initial Administrator account (forced password change on first login)',
    'Security',
    'Success',
    '127.0.0.1'
  );
}

export function initDatabase(dbPath?: string, options: InitDatabaseOptions = {}): Database.Database {
  const effectiveNodeEnv = (process.env.NODE_ENV ?? 'development').trim();
  const effectiveMode: AppMode =
    options.mode ?? (effectiveNodeEnv === 'test' ? 'test' : ((process.env.APP_MODE as AppMode) || 'production'));

  if (options.seedDemoData === true && (effectiveNodeEnv === 'production' || effectiveMode === 'production')) {
    throw new DemoSeedForbiddenError(
      'Demo data seeding is strictly forbidden in production mode (NODE_ENV=production or APP_MODE=production).'
    );
  }

  const resolvedPath =
    dbPath || process.env.DATABASE_PATH || path.resolve(process.cwd(), 'data', 'savage_rsucaj.db');
  const isMemory = resolvedPath === ':memory:';

  if (!isMemory) {
    const dir = path.dirname(resolvedPath);
    try {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true, mode: 0o750 });
      }
      fs.accessSync(dir, fs.constants.R_OK | fs.constants.W_OK);
      if (fs.existsSync(resolvedPath)) {
        fs.accessSync(resolvedPath, fs.constants.R_OK | fs.constants.W_OK);
      }
    } catch (err) {
      throw new DatabaseUnavailableError(
        `Database storage path "${resolvedPath}" is not accessible/writable: ${err instanceof Error ? err.message : String(err)}`
      );
    }
  }

  let db: Database.Database;
  try {
    db = new Database(resolvedPath);
  } catch (err) {
    throw new DatabaseUnavailableError(
      `Failed to open SQLite database at "${resolvedPath}": ${err instanceof Error ? err.message : String(err)}`
    );
  }

  const busyTimeoutMs = options.busyTimeoutMs ?? (Number(process.env.SQLITE_BUSY_TIMEOUT_MS) || 5000);
  const walAutocheckpoint = options.walAutocheckpoint ?? (Number(process.env.SQLITE_WAL_AUTOCHECKPOINT) || 1000);

  try {
    db.pragma('foreign_keys = ON');
    db.pragma(`busy_timeout = ${Math.max(1000, Math.min(60000, busyTimeoutMs))}`);
    db.pragma('temp_store = MEMORY');
    if (!isMemory) {
      db.pragma('journal_mode = WAL');
      db.pragma('synchronous = FULL');
      db.pragma(`wal_autocheckpoint = ${Math.max(100, Math.min(10000, walAutocheckpoint))}`);
    }

    runMigrations(db);
    seedBaselineSettings(db);
    bootstrapInitialAdminIfNeeded(db, options);

    if (options.seedDemoData === true) {
      seedDemoDataExplicit(db, effectiveMode);
    }
    return db;
  } catch (err) {
    try {
      db.close();
    } catch {
      // ignore close error on failed init
    }
    throw err;
  }
}

export function checkpointWal(
  db: Database.Database,
  mode: 'PASSIVE' | 'FULL' | 'RESTART' | 'TRUNCATE' = 'TRUNCATE'
): WalCheckpointResult {
  const row = db.pragma(`wal_checkpoint(${mode})`, { simple: false }) as Array<{
    busy: number;
    log: number;
    checkpointed: number;
  }>;
  const first = row[0] ?? { busy: 0, log: 0, checkpointed: 0 };
  return {
    mode,
    busy: Number(first.busy ?? 0),
    log: Number(first.log ?? 0),
    checkpointed: Number(first.checkpointed ?? 0),
  };
}

export function closeDatabaseSafely(db: Database.Database): WalCheckpointResult | null {
  if (!db.open) return null;
  let result: WalCheckpointResult | null = null;
  try {
    if (!db.memory) {
      result = checkpointWal(db, 'TRUNCATE');
    }
  } catch {
    // Best-effort checkpoint during shutdown; still close handle cleanly
  }
  db.close();
  return result;
}

export function collectTableRowCounts(db: Database.Database): Record<string, number> {
  const existingTables = new Set(
    (
      db
        .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")
        .all() as Array<{ name: string }>
    ).map((r) => r.name)
  );
  const counts: Record<string, number> = {};
  for (const table of CANONICAL_BUSINESS_TABLES) {
    if (existingTables.has(table)) {
      counts[table] = (db.prepare(`SELECT COUNT(*) as c FROM ${table}`).get() as { c: number }).c;
    }
  }
  return counts;
}

export function getDatabaseStatus(db: Database.Database, dbPath?: string): DatabaseStatusReport {
  const resolvedPath = dbPath || db.name || ':memory:';
  const isMemory = db.memory || resolvedPath === ':memory:';

  if (!db.open) {
    throw new DatabaseUnavailableError('SQLite database connection is closed.');
  }

  const journalMode = String(db.pragma('journal_mode', { simple: true }));
  const synchronous = Number(db.pragma('synchronous', { simple: true }));
  const foreignKeys = Number(db.pragma('foreign_keys', { simple: true })) === 1;
  const busyTimeoutMs = Number(db.pragma('busy_timeout', { simple: true }));
  const walAutocheckpoint = Number(db.pragma('wal_autocheckpoint', { simple: true }));
  const integrityCheck = String(db.pragma('integrity_check', { simple: true }));
  const fkViolations = db.pragma('foreign_key_check', { simple: false }) as unknown[];

  const appliedMigrations = db
    .prepare('SELECT version, name, applied_at FROM schema_migrations ORDER BY version ASC')
    .all() as Array<{ version: string; name: string; applied_at: string }>;
  const schemaVersion =
    appliedMigrations.length > 0 ? appliedMigrations[appliedMigrations.length - 1].version : '000';

  const safeSize = (filePath: string): number => {
    if (isMemory) return 0;
    try {
      return fs.existsSync(filePath) ? fs.statSync(filePath).size : 0;
    } catch {
      return 0;
    }
  };

  return {
    connected: true,
    databasePath: isMemory ? ':memory:' : resolvedPath,
    isMemory,
    journalMode,
    synchronous,
    foreignKeys,
    busyTimeoutMs,
    walAutocheckpoint,
    schemaVersion,
    appliedMigrations,
    integrityCheck,
    foreignKeyViolations: fkViolations.length,
    dbFileBytes: safeSize(resolvedPath),
    walFileBytes: safeSize(`${resolvedPath}-wal`),
    shmFileBytes: safeSize(`${resolvedPath}-shm`),
    tableCounts: collectTableRowCounts(db),
  };
}

// logAudit is implemented in ./auditHelpers.ts and re-exported at the top of this module.

/**
 * Explicit admin account recovery/migration utility for operators maintaining an existing database.
 * Preserves user ID, role, employees, and historical records while safely rotating credentials
 * and revoking all active sessions.
 */
export function recoverAdminAccount(
  db: Database.Database,
  username: string,
  newPassword: string,
  options: { requireChangeOnNextLogin?: boolean } = {}
): { userId: number; username: string; revokedSessions: number } {
  const pwErr = validatePasswordStrength(newPassword);
  if (pwErr) {
    throw new Error(`Recovery password rejected: ${pwErr}`);
  }
  const user = db
    .prepare('SELECT id, username, role FROM users WHERE lower(username) = lower(?)')
    .get(username.trim()) as { id: number; username: string; role: string } | undefined;

  if (!user) {
    throw new Error(`User "${username}" not found in database.`);
  }

  const { hash, salt } = hashPassword(newPassword);
  const mustChange = options.requireChangeOnNextLogin ? 1 : 0;
  let revokedSessions = 0;

  const tx = db.transaction(() => {
    db.prepare(
      `UPDATE users
       SET password_hash = ?, salt = ?, must_change_password = ?, is_active = 1,
           failed_login_attempts = 0, locked_until = NULL,
           password_changed_at = datetime('now', 'localtime')
       WHERE id = ?`
    ).run(hash, salt, mustChange, user.id);

    const revoked = db
      .prepare(
        `UPDATE user_sessions
         SET revoked_at = datetime('now', 'localtime'), revoked_reason = 'admin_cli_recovery'
         WHERE user_id = ? AND revoked_at IS NULL`
      )
      .run(user.id);
    revokedSessions = revoked.changes;

    logAudit(
      db,
      user.username,
      `Administrator password rotated via local recovery CLI (${revokedSessions} session(s) revoked)`,
      'Security',
      'Warning',
      '127.0.0.1'
    );
  });
  tx();

  return { userId: user.id, username: user.username, revokedSessions };
}

/**
 * Explicit isolated demo/test-fixture seeder.
 * Strictly blocked when NODE_ENV=production or mode=production.
 * Never executed implicitly on production boot.
 */
export function seedDemoDataExplicit(db: Database.Database, mode: AppMode): { seeded: boolean } {
  const effectiveNodeEnv = (process.env.NODE_ENV ?? 'development').trim();
  if (effectiveNodeEnv === 'production' || mode === 'production') {
    throw new DemoSeedForbiddenError(
      'Refused to seed demo fixtures: demo seeding is strictly prohibited in production mode.'
    );
  }

  const deptCount = (db.prepare('SELECT COUNT(*) as c FROM departments').get() as { c: number }).c;
  if (deptCount > 0) return { seeded: false };

  const tx = db.transaction(() => {
    const insertDept = db.prepare('INSERT INTO departments (code, name, head_name) VALUES (?, ?, ?)');
    const depts = [
      ['ADMIN', 'Administration', 'Dr. Roberto M. Villanueva'],
      ['BSIT', 'BSIT', 'Engr. Maria S. Dela Cruz'],
      ['REG', 'Registrar', 'Anna L. Garcia'],
      ['LIB', 'Library', 'Luiza M. Reyes'],
      ['NSTP', 'NSTP', 'Mark D. Santos'],
      ['EDUC', 'Teacher Education', 'Dr. Elena R. Bautista'],
      ['FIN', 'Finance & Accounting', 'Carlo V. Mendoza'],
    ];
    for (const d of depts) insertDept.run(...d);

    const insertPos = db.prepare(
      'INSERT INTO positions (code, name, type, base_salary, allowance) VALUES (?, ?, ?, ?, ?)'
    );
    const positions = [
      ['INST', 'Instructor', 'Regular', 34500, 2500],
      ['ASST', 'Admin Staff', 'Regular', 24000, 2000],
      ['REGS', 'Registrar Staff', 'Regular', 25500, 2000],
      ['LIBR', 'Librarian', 'Regular', 27800, 2200],
      ['PCO', 'Program Coordinator', 'Regular', 42000, 3500],
      ['APROF', 'Assistant Professor', 'Regular', 46500, 3500],
      ['ACCT', 'Accounting Clerk', 'Contractual', 23000, 1800],
    ];
    for (const p of positions) insertPos.run(...p);

    const insertShift = db.prepare(
      'INSERT INTO shifts (name, time_in, time_out, grace_minutes, status) VALUES (?, ?, ?, ?, ?)'
    );
    const shifts = [
      ['Regular Shift', '08:00 AM', '05:00 PM', 15, 'Active'],
      ['Morning Shift', '07:00 AM', '04:00 PM', 15, 'Active'],
      ['Afternoon Shift', '01:00 PM', '10:00 PM', 15, 'Active'],
      ['Night Shift', '10:00 PM', '07:00 AM', 15, 'Active'],
    ];
    for (const s of shifts) insertShift.run(...s);

    const insertHoliday = db.prepare('INSERT INTO holidays (date, name, type) VALUES (?, ?, ?)');
    const year = new Date().getFullYear();
    const holidays = [
      [`${year}-01-01`, "New Year's Day", 'Regular'],
      [`${year}-02-25`, 'EDSA Revolution', 'Special Non-Working'],
      [`${year}-04-09`, 'Araw ng Kagitingan', 'Regular'],
      [`${year}-05-01`, 'Labor Day', 'Regular'],
      [`${year}-06-12`, 'Independence Day', 'Regular'],
      [`${year}-08-25`, 'National Heroes Day', 'Regular'],
      [`${year}-11-30`, 'Bonifacio Day', 'Regular'],
      [`${year}-12-25`, 'Christmas Day', 'Regular'],
    ];
    for (const h of holidays) insertHoliday.run(...h);

    const deptId = (code: string) =>
      (db.prepare('SELECT id FROM departments WHERE code = ?').get(code) as { id: number }).id;
    const posRow = (code: string) =>
      db.prepare('SELECT id, base_salary, allowance FROM positions WHERE code = ?').get(code) as {
        id: number;
        base_salary: number;
        allowance: number;
      };
    const shiftId = (name: string) =>
      (db.prepare('SELECT id FROM shifts WHERE name = ?').get(name) as { id: number }).id;

    const insertEmp = db.prepare(`
      INSERT INTO employees
        (employee_code, full_name, email, department_id, position_id, shift_id, status, hired_date, monthly_salary, monthly_allowance)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const empSeed: Array<[string, string, string, string, string, string, string, string]> = [
      ['EMP-2024-001', 'Dela Cruz, Maria S.', 'maria.delacruz@rsucaj.edu.ph', 'BSIT', 'INST', 'Regular Shift', 'Active', '2022-06-15'],
      ['EMP-2024-002', 'Ramos, John P.', 'john.ramos@rsucaj.edu.ph', 'ADMIN', 'ASST', 'Regular Shift', 'Active', '2023-02-01'],
      ['EMP-2024-003', 'Garcia, Anna L.', 'anna.garcia@rsucaj.edu.ph', 'REG', 'REGS', 'Regular Shift', 'Active', '2021-08-10'],
      ['EMP-2024-004', 'Santos, Mark D.', 'mark.santos@rsucaj.edu.ph', 'NSTP', 'PCO', 'Regular Shift', 'Active', '2020-09-01'],
      ['EMP-2024-005', 'Reyes, Luiza M.', 'luiza.reyes@rsucaj.edu.ph', 'LIB', 'LIBR', 'Morning Shift', 'Active', '2022-01-12'],
      ['EMP-2024-006', 'Bautista, Elena R.', 'elena.bautista@rsucaj.edu.ph', 'EDUC', 'APROF', 'Regular Shift', 'Active', '2019-06-03'],
      ['EMP-2024-007', 'Mendoza, Carlo V.', 'carlo.mendoza@rsucaj.edu.ph', 'FIN', 'ACCT', 'Regular Shift', 'Active', '2023-07-18'],
      ['EMP-2024-008', 'Villanueva, Roberto M.', 'roberto.villanueva@rsucaj.edu.ph', 'ADMIN', 'PCO', 'Regular Shift', 'Active', '2018-04-20'],
      ['EMP-2024-009', 'Fernandez, Paolo G.', 'paolo.fernandez@rsucaj.edu.ph', 'BSIT', 'INST', 'Regular Shift', 'Active', '2023-08-14'],
      ['EMP-2024-010', 'Aquino, Clarissa T.', 'clarissa.aquino@rsucaj.edu.ph', 'BSIT', 'APROF', 'Morning Shift', 'Active', '2020-11-05'],
      ['EMP-2024-011', 'Castillo, Jerome B.', 'jerome.castillo@rsucaj.edu.ph', 'REG', 'REGS', 'Regular Shift', 'Active', '2024-01-08'],
      ['EMP-2024-012', 'Navarro, Grace H.', 'grace.navarro@rsucaj.edu.ph', 'EDUC', 'INST', 'Regular Shift', 'Active', '2022-08-22'],
      ['EMP-2024-013', 'Morales, Kevin A.', 'kevin.morales@rsucaj.edu.ph', 'BSIT', 'INST', 'Afternoon Shift', 'Active', '2024-02-12'],
      ['EMP-2024-014', 'Tolentino, Sofia C.', 'sofia.tolentino@rsucaj.edu.ph', 'LIB', 'LIBR', 'Regular Shift', 'Active', '2021-05-19'],
      ['EMP-2024-015', 'Soriano, Miguel E.', 'miguel.soriano@rsucaj.edu.ph', 'NSTP', 'INST', 'Morning Shift', 'Active', '2023-03-06'],
      ['EMP-2024-016', 'Pascual, Angela K.', 'angela.pascual@rsucaj.edu.ph', 'FIN', 'ACCT', 'Regular Shift', 'Active', '2022-10-10'],
      ['EMP-2024-017', 'Diaz, Rafael N.', 'rafael.diaz@rsucaj.edu.ph', 'ADMIN', 'ASST', 'Night Shift', 'Active', '2023-05-15'],
      ['EMP-2024-018', 'Torres, Camille J.', 'camille.torres@rsucaj.edu.ph', 'EDUC', 'INST', 'Regular Shift', 'Active', '2024-03-01'],
    ];

    for (const [code, name, email, dCode, pCode, sName, status, hired] of empSeed) {
      const pos = posRow(pCode);
      insertEmp.run(code, name, email, deptId(dCode), pos.id, shiftId(sName), status, hired, pos.base_salary, pos.allowance);
    }

    // BUILD 10/14: Seeded fixture devices start Offline with NULL last_heartbeat_utc until a real verified heartbeat arrives
    const insertDevice = db.prepare(`
      INSERT INTO devices (name, device_type, model_info, ip_address, location, api_token, token_hash, token_masked, status, last_heartbeat, last_heartbeat_utc)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Offline', 'Never', NULL)
    `);
    const seedTok1 = 'ksk_main_' + crypto.randomBytes(16).toString('hex');
    insertDevice.run(
      'Kiosk - Main Entrance',
      'Raspberry Pi',
      'Raspberry Pi 3B',
      '192.168.1.101',
      'Main Campus Gate',
      seedTok1,
      crypto.createHash('sha256').update(seedTok1).digest('hex'),
      `••••••••${seedTok1.slice(-4)}`
    );
    const seedTok2 = 'ksk_fac_' + crypto.randomBytes(16).toString('hex');
    insertDevice.run(
      'Kiosk - Faculty Entrance',
      'Android',
      'Android Kiosk',
      '192.168.1.102',
      'Faculty Building Lobby',
      seedTok2,
      crypto.createHash('sha256').update(seedTok2).digest('hex'),
      `••••••••${seedTok2.slice(-4)}`
    );

    const allEmployees = db.prepare('SELECT id, employee_code FROM employees ORDER BY id ASC').all() as Array<{
      id: number;
      employee_code: string;
    }>;
    const insertAtt = db.prepare(`
      INSERT OR IGNORE INTO attendance_records
        (employee_id, date, time_in, time_out, work_hours, status, device_name, remarks)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const todayStr = getTodayDateString();
    for (let offset = 6; offset >= 0; offset--) {
      const dateStr = addDaysIso(todayStr, -offset);

      allEmployees.forEach((emp, idx) => {
        const mod = (idx + offset * 3) % 18;
        if (offset === 0) {
          if (idx === 2) {
            insertAtt.run(emp.id, dateStr, null, null, '-', 'Absent', '-', 'No check-in logged');
          } else if (idx === 15) {
            insertAtt.run(emp.id, dateStr, null, null, '-', 'Absent', '-', 'Unscheduled absence');
          } else if (idx === 4) {
            insertAtt.run(emp.id, dateStr, null, null, '-', 'On Leave', '-', 'Approved Sick Leave');
          } else if (idx === 6 || idx === 12) {
            insertAtt.run(
              emp.id,
              dateStr,
              '08:26 AM',
              '05:05 PM',
              '8h 39m',
              'Late',
              'Kiosk - Main Entrance',
              'Arrived past 15-min grace'
            );
          } else {
            const min = String(4 + (idx % 12)).padStart(2, '0');
            const outMin = String(2 + (idx % 9)).padStart(2, '0');
            insertAtt.run(
              emp.id,
              dateStr,
              `07:${String(48 + (idx % 10)).padStart(2, '0')} AM`,
              offset === 0 && idx < 4 ? null : `05:${outMin} PM`,
              offset === 0 && idx < 4 ? 'In Shift' : `8h ${40 + (idx % 15)}m`,
              'Present',
              idx % 2 === 0 ? 'Kiosk - Main Entrance' : 'Kiosk - Faculty Entrance',
              idx === 0 ? `Time In 08:${min} AM` : ''
            );
          }
        } else {
          if (mod === 0 || mod === 11) {
            insertAtt.run(emp.id, dateStr, null, null, '-', 'Absent', '-', 'No check-in');
          } else if (mod === 5) {
            insertAtt.run(emp.id, dateStr, null, null, '-', 'On Leave', '-', 'Approved leave');
          } else if (mod === 3 || mod === 14) {
            insertAtt.run(emp.id, dateStr, '08:24 AM', '05:04 PM', '8h 40m', 'Late', 'Kiosk - Main Entrance', '');
          } else {
            insertAtt.run(
              emp.id,
              dateStr,
              '07:52 AM',
              '05:03 PM',
              '8h 45m',
              'Present',
              idx % 2 === 0 ? 'Kiosk - Main Entrance' : 'Kiosk - Faculty Entrance',
              ''
            );
          }
        }
      });
    }

    const mariaId = allEmployees[0].id;
    const johnId = allEmployees[1].id;
    const luizaId = allEmployees[4].id;
    const markId = allEmployees[3].id;

    db.prepare(
      `UPDATE attendance_records SET time_in = '08:04 AM', time_out = '05:04 PM', work_hours = '8h 40m', status = 'Present', device_name = 'Kiosk - Main Entrance' WHERE employee_id = ? AND date = ?`
    ).run(mariaId, todayStr);
    db.prepare(
      `UPDATE attendance_records SET time_in = '08:02 AM', time_out = '05:02 PM', work_hours = '8h 40m', status = 'Present', device_name = 'Kiosk - Faculty Entrance' WHERE employee_id = ? AND date = ?`
    ).run(johnId, todayStr);

    const yesterdayStr = addDaysIso(todayStr, -1);
    const twoDaysAgoStr = addDaysIso(todayStr, -2);
    const threeDaysAgoStr = addDaysIso(todayStr, -3);

    const insertCorr = db.prepare(`
      INSERT INTO corrections (employee_id, attendance_date, request_type, requested_time, reason, status, reviewed_by, reviewed_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insertCorr.run(
      johnId,
      yesterdayStr,
      'Time In',
      '08:05 AM',
      'Biometric kiosk momentarily disconnected during morning queue.',
      'Pending',
      null,
      null
    );
    insertCorr.run(
      luizaId,
      twoDaysAgoStr,
      'Time Out',
      '05:10 PM',
      'Forgot to scan out after library inventory closing.',
      'Pending',
      null,
      null
    );
    insertCorr.run(
      markId,
      threeDaysAgoStr,
      'Time In',
      '07:58 AM',
      'Official campus flag ceremony coordination.',
      'Approved',
      'admin',
      twoDaysAgoStr
    );

    const nextWeekStartStr = addDaysIso(todayStr, 3);
    const nextWeekEndStr = addDaysIso(todayStr, 5);

    const insertLeave = db.prepare(`
      INSERT INTO leaves (employee_id, leave_type, start_date, end_date, days_count, reason, status, reviewed_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insertLeave.run(
      johnId,
      'Vacation Leave',
      nextWeekStartStr,
      nextWeekEndStr,
      3,
      'Scheduled family trip to Odiongan.',
      'Pending',
      null
    );
    insertLeave.run(
      luizaId,
      'Sick Leave',
      todayStr,
      todayStr,
      1,
      'Medical consultation and rest.',
      'Approved',
      'admin'
    );
    insertLeave.run(
      mariaId,
      'Vacation Leave',
      nextWeekStartStr,
      nextWeekEndStr,
      3,
      'Annual family leave filing.',
      'Pending',
      null
    );

    const [manilaY, manilaM] = todayStr.split('-').map(Number);
    const lastDayOfMonth = new Date(Date.UTC(manilaY, manilaM, 0)).getUTCDate();
    const monthStartStr = `${manilaY}-${String(manilaM).padStart(2, '0')}-01`;
    const monthEndStr = `${manilaY}-${String(manilaM).padStart(2, '0')}-${String(lastDayOfMonth).padStart(2, '0')}`;
    const periodLabel = new Date(Date.UTC(manilaY, manilaM - 1, 15)).toLocaleDateString('en-US', {
      month: 'long',
      year: 'numeric',
      timeZone: 'UTC',
    });

    const empRows = db
      .prepare('SELECT id, monthly_salary, monthly_allowance FROM employees WHERE status = ?')
      .all('Active') as Array<{ id: number; monthly_salary: number; monthly_allowance: number }>;

    let totalBasic = 0;
    let totalAllow = 0;
    let totalDeduct = 0;
    let totalNet = 0;

    const payrollRunInfo = db
      .prepare(
        `INSERT INTO payroll_runs (period_label, start_date, end_date, status, employee_count, created_by)
         VALUES (?, ?, ?, 'Computed', ?, 'admin')`
      )
      .run(periodLabel, monthStartStr, monthEndStr, empRows.length);

    const runId = Number(payrollRunInfo.lastInsertRowid);
    const insertPayrollItem = db.prepare(`
      INSERT INTO payroll_items
        (payroll_run_id, employee_id, days_present, days_late, days_absent, basic_pay, allowances, deductions, net_pay)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const e of empRows) {
      const basic = e.monthly_salary;
      const allow = e.monthly_allowance;
      const deductions = Math.round((basic * 0.115 + 200) * 100) / 100;
      const net = Math.round((basic + allow - deductions) * 100) / 100;
      totalBasic += basic;
      totalAllow += allow;
      totalDeduct += deductions;
      totalNet += net;
      insertPayrollItem.run(runId, e.id, 20, 1, 0, basic, allow, deductions, net);
    }

    db.prepare(
      `UPDATE payroll_runs SET total_basic_pay = ?, total_allowances = ?, total_deductions = ?, total_net_pay = ? WHERE id = ?`
    ).run(totalBasic, totalAllow, totalDeduct, totalNet, runId);

    const insertNotif = db.prepare(`
      INSERT INTO notifications (title, message, category, priority, is_read, action_module, action_entity_id, target_roles, event_type, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', 'localtime'))
    `);
    insertNotif.run(
      'New leave request submitted by Maria S. Dela Cruz',
      `Vacation Leave application (${nextWeekStartStr} – ${nextWeekEndStr}) is awaiting administrator review.`,
      'Attendance Alerts',
      'Medium',
      0,
      'leaves',
      3,
      'Administrator,HR Officer,Department Head',
      'leave_pending'
    );
    insertNotif.run(
      'Kiosk terminals provisioned and awaiting heartbeat',
      'Kiosk - Main Entrance and Kiosk - Faculty Entrance are registered in Offline state until live heartbeats arrive.',
      'Device Alerts',
      'Low',
      0,
      'devices',
      1,
      'Administrator',
      'device_provisioned'
    );
    insertNotif.run(
      `Payroll for ${periodLabel} is ready for review`,
      `${empRows.length} active campus personnel computed. Review deductions before finalizing and releasing.`,
      'System Notices',
      'Medium',
      0,
      'payroll',
      runId,
      'Administrator,Payroll Officer',
      'payroll_computed'
    );
    insertNotif.run(
      'Attendance correction pending approval',
      'John P. Ramos requested a Time In adjustment (08:05 AM) citing morning queue kiosk disconnect.',
      'Attendance Alerts',
      'High',
      0,
      'corrections',
      1,
      'Administrator,HR Officer,Department Head',
      'correction_pending'
    );
    insertNotif.run(
      'Late attendance alert for campus shift',
      '2 personnel arrived past the 15-minute Regular Shift grace period today.',
      'Attendance Alerts',
      'High',
      0,
      'attendance',
      null,
      'Administrator,HR Officer,Department Head',
      'attendance_exception'
    );
    insertNotif.run(
      'Daily DTR summary archived',
      'Automated end-of-day attendance snapshot successfully stored in local SQLite database.',
      'System Notices',
      'Low',
      1,
      'reports',
      null,
      'Administrator,HR Officer,Payroll Officer',
      'report_archived'
    );

    logAudit(db, 'system', `Seeded explicit isolated ${mode} fixture dataset (non-production)`, 'Database', 'Warning', '127.0.0.1');
  });
  tx();
  return { seeded: true };
}
