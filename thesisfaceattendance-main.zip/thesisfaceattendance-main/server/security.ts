import type { Request, Response, NextFunction } from 'express';

export interface RateLimitConfig {
  windowMs: number;
  maxRequests: number;
  message: string;
}

interface BucketEntry {
  timestamps: number[];
}

export class SlidingWindowRateLimiter {
  private readonly buckets = new Map<string, BucketEntry>();
  private readonly windowMs: number;
  private readonly maxRequests: number;
  private readonly message: string;

  constructor(config: RateLimitConfig) {
    this.windowMs = config.windowMs;
    this.maxRequests = config.maxRequests;
    this.message = config.message;
  }

  check(key: string, now = Date.now()): { allowed: boolean; retryAfterSec: number; remaining: number } {
    const cutoff = now - this.windowMs;
    const entry = this.buckets.get(key) ?? { timestamps: [] };
    entry.timestamps = entry.timestamps.filter((t) => t > cutoff);

    if (entry.timestamps.length >= this.maxRequests) {
      const oldest = entry.timestamps[0];
      const retryAfterSec = Math.max(1, Math.ceil((oldest + this.windowMs - now) / 1000));
      this.buckets.set(key, entry);
      return { allowed: false, retryAfterSec, remaining: 0 };
    }

    entry.timestamps.push(now);
    this.buckets.set(key, entry);
    return {
      allowed: true,
      retryAfterSec: 0,
      remaining: Math.max(0, this.maxRequests - entry.timestamps.length),
    };
  }

  reset(key?: string): void {
    if (key) {
      this.buckets.delete(key);
    } else {
      this.buckets.clear();
    }
  }

  middleware(keyFn: (req: Request) => string) {
    return (req: Request, res: Response, next: NextFunction): void => {
      const result = this.check(keyFn(req));
      res.setHeader('X-RateLimit-Limit', String(this.maxRequests));
      res.setHeader('X-RateLimit-Remaining', String(result.remaining));
      if (!result.allowed) {
        res.setHeader('Retry-After', String(result.retryAfterSec));
        res.status(429).json({
          error: this.message,
          code: 'RATE_LIMITED',
          retryAfterSeconds: result.retryAfterSec,
        });
        return;
      }
      next();
    };
  }
}

export function getClientIp(req: Request): string {
  const trustProxy = (process.env.TRUST_PROXY || '').trim().toLowerCase() === 'true';
  if (trustProxy) {
    const fwd = req.headers['x-forwarded-for'];
    if (typeof fwd === 'string' && fwd.trim()) {
      return fwd.split(',')[0].trim();
    }
  }
  return req.socket.remoteAddress || '127.0.0.1';
}

export function getConfiguredAllowedOrigins(): string[] {
  const raw = process.env.ALLOWED_ORIGINS?.trim();
  if (!raw) return [];
  const origins: string[] = [];
  for (const part of raw.split(',')) {
    const trimmed = part.trim();
    if (!trimmed) continue;
    try {
      origins.push(new URL(trimmed).origin);
    } catch {
      // ignore malformed entry (env validator catches on boot)
    }
  }
  return origins;
}

export function isRequestOriginAllowed(req: Request): boolean {
  const originHeader = req.headers.origin;
  const refererHeader = req.headers.referer;

  let candidateOrigin: string | null = null;
  if (typeof originHeader === 'string' && originHeader.trim() !== '') {
    try {
      candidateOrigin = new URL(originHeader.trim()).origin;
    } catch {
      return false;
    }
  } else if (typeof refererHeader === 'string' && refererHeader.trim() !== '') {
    try {
      candidateOrigin = new URL(refererHeader.trim()).origin;
    } catch {
      return false;
    }
  }

  // Non-browser / direct API client without Origin or Referer header
  if (!candidateOrigin) {
    return true;
  }

  const allowedOrigins = getConfiguredAllowedOrigins();
  if (allowedOrigins.length > 0) {
    return allowedOrigins.includes(candidateOrigin);
  }

  // Default same-origin verification against request Host / x-forwarded-host
  const trustProxy = (process.env.TRUST_PROXY || '').trim().toLowerCase() === 'true';
  const rawHost =
    (trustProxy && typeof req.headers['x-forwarded-host'] === 'string'
      ? req.headers['x-forwarded-host'].split(',')[0].trim()
      : req.headers.host) || '';

  if (!rawHost) return false;

  try {
    const parsedOrigin = new URL(candidateOrigin);
    return parsedOrigin.host.toLowerCase() === rawHost.toLowerCase();
  } catch {
    return false;
  }
}

export function securityHeadersMiddleware(req: Request, res: Response, next: NextFunction): void {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  const reqPath = (req.path || req.originalUrl || '').toLowerCase();
  const isKioskRoute = reqPath === '/kiosk' || reqPath.startsWith('/kiosk/');
  res.setHeader(
    'Permissions-Policy',
    isKioskRoute
      ? 'camera=(self), microphone=(), geolocation=()'
      : 'camera=(), microphone=(), geolocation=()'
  );
  res.setHeader('X-XSS-Protection', '0');
  next();
}

export function apiNoStoreMiddleware(_req: Request, res: Response, next: NextFunction): void {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.setHeader('Pragma', 'no-cache');
  next();
}

export function parsePositiveIntId(raw: string | undefined): number | null {
  if (!raw || !/^\d+$/.test(raw.trim())) return null;
  const parsed = Number(raw.trim());
  if (!Number.isSafeInteger(parsed) || parsed <= 0) return null;
  return parsed;
}

export function isIsoDateString(value: unknown): value is string {
  return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value.trim());
}
