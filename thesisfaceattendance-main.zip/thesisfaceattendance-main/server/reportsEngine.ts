import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type Database from 'better-sqlite3';
import type { Response } from 'express';
import PDFDocument from 'pdfkit';
import {
  addDaysIso,
  formatDurationMinutes,
  getManilaDateString,
  getManilaDayCodeForIsoDate,
  parseTimeToMinutes,
  toManilaParts,
} from './attendanceEngine.ts';
import { computeEmployeeLeaveBalances } from './correctionsLeavesEngine.ts';
import { logAudit } from './auditHelpers.ts';

export const REPORT_TYPES = ['attendance', 'dtr', 'leaves', 'payroll', 'employees', 'audit-logs'] as const;
export type ReportType = (typeof REPORT_TYPES)[number];

export interface ReportFilters {
  startDate?: string;
  endDate?: string;
  month?: string; // YYYY-MM
  empId?: number | null;
  deptId?: number | null;
  runId?: number | null;
  status?: string;
  module?: string;
  search?: string;
}

export interface ReportPagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export interface DtrUnresolvedBlocker {
  type: 'PENDING_CORRECTION' | 'PENDING_LEAVE' | 'MISSING_PUNCH' | 'ESCALATED_EVENT';
  date: string;
  detail: string;
  ref_id: number;
}

export interface DtrDayRow {
  day: number;
  date: string;
  day_code: string;
  employee_id: number;
  employee_code: string;
  employee_name: string;
  department_code: string;
  department_name: string;
  time_in: string | null;
  break_out: string | null;
  break_in: string | null;
  time_out: string | null;
  overtime_out: string | null;
  work_hours: string;
  worked_minutes: number;
  late_minutes: number;
  undertime_minutes: number;
  overtime_minutes: number;
  status: string;
  leave_label: string;
  holiday_label: string;
  overnight_note: string;
  device_name: string;
  remarks: string;
  has_unresolved_punch: boolean;
  has_pending_correction: boolean;
  has_pending_leave: boolean;
}

export interface DtrSignoffInfo {
  id: number;
  employee_id: number;
  month: string;
  status: 'SIGNED' | 'REVOKED';
  employee_signed_by_user_id: number | null;
  employee_signed_by: string | null;
  employee_signed_at_utc: string | null;
  supervisor_verified_by_user_id: number | null;
  supervisor_verified_by: string | null;
  supervisor_verified_at_utc: string | null;
  campus_director_name: string;
  dtr_snapshot_sha256: string;
  notes: string;
  hash_matches: boolean;
}

export interface MonthlyDtrEmployeeReport {
  month: string;
  month_label: string;
  days_in_month: number;
  is_leap_year: boolean;
  start_date: string;
  end_date: string;
  employee: {
    id: number;
    employee_code: string;
    full_name: string;
    email: string;
    department_id: number;
    department_code: string;
    department_name: string;
    department_head_name: string;
    position_name: string;
    employee_type: string;
    shift_id: number;
    shift_name: string;
    shift_time_in: string;
    shift_time_out: string;
    is_overnight_shift: boolean;
    rest_days: string;
    hired_date: string;
    status: string;
  };
  cs_form_48_reference_verified: boolean;
  cs_form_48_reference_note: string;
  dtr_state: 'DRAFT_UNRESOLVED' | 'READY_UNSIGNED' | 'SIGNED' | 'SIGNED_STALE';
  is_draft: boolean;
  is_signed: boolean;
  snapshot_sha256: string;
  unresolved_blockers: DtrUnresolvedBlocker[];
  signoff: DtrSignoffInfo | null;
  campus_director_name: string;
  totals: {
    days_present: number;
    days_late: number;
    days_undertime: number;
    days_absent: number;
    days_on_leave: number;
    days_ob: number;
    days_holiday: number;
    days_rest_day: number;
    days_missing_punch: number;
    days_no_schedule: number;
    days_unreconciled: number;
    total_late_minutes: number;
    total_undertime_minutes: number;
    total_overtime_minutes: number;
    total_worked_minutes: number;
    total_worked_hours_formatted: string;
    approved_corrections_count: number;
  };
  rows: DtrDayRow[];
}

export interface ReportQueryResult {
  title: string;
  type: ReportType;
  generatedAt: string;
  columns: string[];
  rows: Record<string, unknown>[];
  pagination: ReportPagination;
  summary: Record<string, unknown>;
  dtr_reports?: MonthlyDtrEmployeeReport[];
  leave_balances?: unknown[];
  cs_form_48_reference_verified?: boolean;
  cs_form_48_reference_note?: string;
}

export class ReportEngineError extends Error {
  statusCode: number;
  code: string;
  details?: unknown;
  constructor(statusCode: number, code: string, message: string, details?: unknown) {
    super(message);
    this.name = 'ReportEngineError';
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
  }
}

export function isValidReportType(raw: string): raw is ReportType {
  return (REPORT_TYPES as readonly string[]).includes(raw);
}

export function isValidIsoMonth(raw: string | undefined | null): raw is string {
  if (!raw || typeof raw !== 'string') return false;
  const m = raw.trim().match(/^(\d{4})-(\d{2})$/);
  if (!m) return false;
  const yr = Number(m[1]);
  const mo = Number(m[2]);
  return yr >= 1970 && yr <= 2100 && mo >= 1 && mo <= 12;
}

export function isValidIsoDate(raw: string | undefined | null): raw is string {
  if (!raw || typeof raw !== 'string') return false;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw.trim())) return false;
  const [y, m, d] = raw.trim().split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

export function getMonthCalendarMeta(monthStr: string): {
  month: string;
  year: number;
  monthNum: number;
  daysInMonth: number;
  isLeapYear: boolean;
  startDate: string;
  endDate: string;
  monthLabel: string;
} {
  if (!isValidIsoMonth(monthStr)) {
    throw new ReportEngineError(400, 'INVALID_MONTH', 'Month must be in YYYY-MM format (e.g. 2026-03).');
  }
  const [year, monthNum] = monthStr.trim().split('-').map(Number);
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  const daysInMonth = new Date(Date.UTC(year, monthNum, 0)).getUTCDate();
  const mm = String(monthNum).padStart(2, '0');
  const startDate = `${year}-${mm}-01`;
  const endDate = `${year}-${mm}-${String(daysInMonth).padStart(2, '0')}`;
  const monthLabel = new Date(Date.UTC(year, monthNum - 1, 15)).toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  });
  return { month: `${year}-${mm}`, year, monthNum, daysInMonth, isLeapYear, startDate, endDate, monthLabel };
}

/**
 * Neutralizes CSV formula-injection payloads (including after leading whitespace/tabs)
 * and safely RFC-4180 quotes cells containing commas, quotes, CR, or LF.
 */
export function escapeCsvCell(val: unknown): string {
  const raw = val === null || val === undefined ? '' : String(val);
  const trimmedLeading = raw.replace(/^[ \t\r\n]+/, '');
  const startsDangerous =
    /^[=+\-@\t\r]/.test(raw) || (trimmedLeading.length > 0 && /^[=+\-@\t\r]/.test(trimmedLeading));
  const safe = startsDangerous ? `'${raw}` : raw;
  if (safe.includes(',') || safe.includes('"') || safe.includes('\n') || safe.includes('\r')) {
    return `"${safe.replace(/"/g, '""')}"`;
  }
  return safe;
}

export function sanitizeFilenameToken(raw: string): string {
  return raw.replace(/[^a-zA-Z0-9._-]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 64) || 'export';
}

function readSetting(db: Database.Database, key: string, fallback = ''): string {
  try {
    const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as { value: string } | undefined;
    return row ? row.value : fallback;
  } catch {
    return fallback;
  }
}

function getDefaultWeekendSet(db: Database.Database): Set<string> {
  const raw = readSetting(db, 'leave_weekend_days', 'Sat,Sun') || 'Sat,Sun';
  return new Set(
    raw
      .split(/[,;\s]+/)
      .map((s) => s.trim().toLowerCase().slice(0, 3))
      .filter(Boolean)
  );
}

function parseShiftRestDaySet(restDaysRaw: string | null | undefined, defaultWeekends: Set<string>): Set<string> {
  if (!restDaysRaw || !restDaysRaw.trim()) return new Set(defaultWeekends);
  const tokens = restDaysRaw
    .split(/[,;\s]+/)
    .map((s) => s.trim().toLowerCase().slice(0, 3))
    .filter(Boolean);
  return tokens.length > 0 ? new Set(tokens) : new Set(defaultWeekends);
}

function parseWorkHoursToMinutes(workHours: string | null | undefined, timeIn: string | null, timeOut: string | null): number {
  if (workHours) {
    const m = workHours.trim().match(/^(\d+)h\s+(\d+)m$/i);
    if (m) return Number(m[1]) * 60 + Number(m[2]);
  }
  const inMin = parseTimeToMinutes(timeIn);
  const outMin = parseTimeToMinutes(timeOut);
  if (inMin === null || outMin === null) return 0;
  let diff = outMin - inMin;
  if (diff < 0) diff += 24 * 60;
  return Math.max(0, diff);
}

function getRsuEmblemPath(): string | null {
  const candidate = path.resolve(
    process.cwd(),
    'public',
    'assets',
    'aistudio',
    'SAVAGE-RSUCAJ_Smart_Attendance_Emblem_39488c28.png'
  );
  return fs.existsSync(candidate) ? candidate : null;
}

function formatPdfCurrency(val: unknown): string {
  const num = Number(val || 0);
  return `PHP ${num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function toPdfAsciiSafe(val: unknown): string {
  const str = val === null || val === undefined ? '-' : String(val);
  // Replace non-WinAnsi Peso symbol if present so standard Helvetica renders cleanly
  return str.replace(/₱/g, 'PHP ').replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"');
}

// ============================================================================
// MONTHLY DTR ENGINE (28/29/30/31-day Calendar, Overnight, Leaves, Corrections, Draft/Sign-off)
// ============================================================================

export function buildMonthlyDtrReports(
  db: Database.Database,
  options: {
    month: string;
    empId?: number | null;
    deptId?: number | null;
    serverNowUtc?: number;
  }
): {
  meta: ReturnType<typeof getMonthCalendarMeta>;
  reports: MonthlyDtrEmployeeReport[];
  campus_director_name: string;
  cs_form_48_reference_verified: boolean;
  cs_form_48_reference_note: string;
} {
  const meta = getMonthCalendarMeta(options.month);
  const nowMs = options.serverNowUtc ?? Date.now();
  const todayManila = getManilaDateString(nowMs);
  const defaultWeekends = getDefaultWeekendSet(db);

  const campusDirectorName = readSetting(db, 'campus_director_name', '').trim();
  const csRefVerified = readSetting(db, 'cs_form_48_reference_verified', 'false').trim().toLowerCase() === 'true';
  const csRefNote =
    readSetting(
      db,
      'cs_form_48_reference_note',
      'Pending verified RSU-approved Civil Service Form 48 official reference'
    ).trim() || 'Pending verified RSU-approved Civil Service Form 48 official reference';

  const empWhere: string[] = [];
  const empParams: unknown[] = [];
  if (options.empId) {
    empWhere.push('e.id = ?');
    empParams.push(options.empId);
  }
  if (options.deptId) {
    empWhere.push('e.department_id = ?');
    empParams.push(options.deptId);
  }
  const empWhereSql = empWhere.length ? `WHERE ${empWhere.join(' AND ')}` : '';

  const employees = db
    .prepare(
      `SELECT e.id, e.employee_code, e.full_name, e.email, e.department_id, e.hired_date, e.status,
              d.code as department_code, d.name as department_name, d.head_name as department_head_name,
              p.name as position_name, p.type as employee_type,
              s.id as shift_id, s.name as shift_name, s.time_in as shift_time_in, s.time_out as shift_time_out,
              COALESCE(s.rest_days, '') as rest_days, s.status as shift_status
       FROM employees e
       JOIN departments d ON e.department_id = d.id
       JOIN positions p ON e.position_id = p.id
       JOIN shifts s ON e.shift_id = s.id
       ${empWhereSql}
       ORDER BY e.employee_code ASC`
    )
    .all(...empParams) as Array<{
    id: number;
    employee_code: string;
    full_name: string;
    email: string;
    department_id: number;
    hired_date: string;
    status: string;
    department_code: string;
    department_name: string;
    department_head_name: string;
    position_name: string;
    employee_type: string;
    shift_id: number;
    shift_name: string;
    shift_time_in: string;
    shift_time_out: string;
    rest_days: string;
    shift_status: string;
  }>;

  const holidayRows = db
    .prepare('SELECT date, name, type FROM holidays WHERE date >= ? AND date <= ?')
    .all(meta.startDate, meta.endDate) as Array<{ date: string; name: string; type: string }>;
  const holidayMap = new Map<string, { name: string; type: string }>();
  for (const h of holidayRows) {
    holidayMap.set(h.date, { name: h.name, type: h.type });
  }

  const attStmt = db.prepare(
    `SELECT id, date, time_in, break_out, break_in, time_out, overtime_out, work_hours,
            COALESCE(late_minutes, 0) as late_minutes,
            COALESCE(undertime_minutes, 0) as undertime_minutes,
            COALESCE(overtime_minutes, 0) as overtime_minutes,
            status, COALESCE(device_name, '') as device_name, COALESCE(remarks, '') as remarks
     FROM attendance_records
     WHERE employee_id = ? AND date >= ? AND date <= ?`
  );

  const leaveAllocStmt = db.prepare(
    `SELECT a.leave_date, a.day_fraction, a.day_portion, l.id as leave_id, l.leave_type,
            COALESCE(lp.attendance_status, 'On Leave') as attendance_status
     FROM leave_day_allocations a
     JOIN leaves l ON a.leave_id = l.id
     LEFT JOIN leave_policies lp ON lp.leave_type = l.leave_type
     WHERE a.employee_id = ? AND a.leave_date >= ? AND a.leave_date <= ? AND l.status = 'Approved'`
  );

  const pendingLeaveStmt = db.prepare(
    `SELECT id, leave_type, start_date, end_date, day_portion
     FROM leaves
     WHERE employee_id = ? AND status = 'Pending' AND end_date >= ? AND start_date <= ?`
  );

  const corrStmt = db.prepare(
    `SELECT id, attendance_date, request_type, requested_time, status
     FROM corrections
     WHERE employee_id = ? AND attendance_date >= ? AND attendance_date <= ?`
  );

  const escalatedStmt = db.prepare(
    `SELECT id, attendance_date, punch_type, decision_reason
     FROM attendance_events
     WHERE employee_id = ? AND attendance_date >= ? AND attendance_date <= ? AND decision = 'ESCALATED'`
  );

  const signoffStmt = db.prepare('SELECT * FROM dtr_signoffs WHERE employee_id = ? AND month = ?');

  const reports: MonthlyDtrEmployeeReport[] = [];

  for (const emp of employees) {
    const shiftStartMin = parseTimeToMinutes(emp.shift_time_in) ?? 8 * 60;
    const shiftEndMin = parseTimeToMinutes(emp.shift_time_out) ?? 17 * 60;
    const isOvernightShift = shiftEndMin <= shiftStartMin;
    const restDaySet = parseShiftRestDaySet(emp.rest_days, defaultWeekends);

    const attMap = new Map<
      string,
      {
        id: number;
        date: string;
        time_in: string | null;
        break_out: string | null;
        break_in: string | null;
        time_out: string | null;
        overtime_out: string | null;
        work_hours: string;
        late_minutes: number;
        undertime_minutes: number;
        overtime_minutes: number;
        status: string;
        device_name: string;
        remarks: string;
      }
    >();
    for (const r of attStmt.all(emp.id, meta.startDate, meta.endDate) as Array<{
      id: number;
      date: string;
      time_in: string | null;
      break_out: string | null;
      break_in: string | null;
      time_out: string | null;
      overtime_out: string | null;
      work_hours: string;
      late_minutes: number;
      undertime_minutes: number;
      overtime_minutes: number;
      status: string;
      device_name: string;
      remarks: string;
    }>) {
      attMap.set(r.date, r);
    }

    const leaveByDate = new Map<
      string,
      Array<{ leave_id: number; leave_type: string; day_portion: string; day_fraction: number; attendance_status: string }>
    >();
    for (const lv of leaveAllocStmt.all(emp.id, meta.startDate, meta.endDate) as Array<{
      leave_date: string;
      day_fraction: number;
      day_portion: string;
      leave_id: number;
      leave_type: string;
      attendance_status: string;
    }>) {
      const list = leaveByDate.get(lv.leave_date) || [];
      list.push(lv);
      leaveByDate.set(lv.leave_date, list);
    }

    const pendingLeaves = pendingLeaveStmt.all(emp.id, meta.startDate, meta.endDate) as Array<{
      id: number;
      leave_type: string;
      start_date: string;
      end_date: string;
      day_portion: string;
    }>;

    const allCorrections = corrStmt.all(emp.id, meta.startDate, meta.endDate) as Array<{
      id: number;
      attendance_date: string;
      request_type: string;
      requested_time: string;
      status: string;
    }>;
    const pendingCorrectionDates = new Set<string>();
    let approvedCorrectionsCount = 0;

    const unresolvedBlockers: DtrUnresolvedBlocker[] = [];
    for (const c of allCorrections) {
      if (c.status === 'Pending') {
        pendingCorrectionDates.add(c.attendance_date);
        unresolvedBlockers.push({
          type: 'PENDING_CORRECTION',
          date: c.attendance_date,
          detail: `Pending ${c.request_type} correction (${c.requested_time})`,
          ref_id: c.id,
        });
      } else if (c.status === 'Approved') {
        approvedCorrectionsCount++;
      }
    }

    for (const lv of pendingLeaves) {
      unresolvedBlockers.push({
        type: 'PENDING_LEAVE',
        date: lv.start_date,
        detail: `Pending ${lv.leave_type} (${lv.start_date} to ${lv.end_date})`,
        ref_id: lv.id,
      });
    }

    const escalatedEvents = escalatedStmt.all(emp.id, meta.startDate, meta.endDate) as Array<{
      id: number;
      attendance_date: string;
      punch_type: string;
      decision_reason: string;
    }>;
    for (const ev of escalatedEvents) {
      unresolvedBlockers.push({
        type: 'ESCALATED_EVENT',
        date: ev.attendance_date,
        detail: `Escalated kiosk ${ev.punch_type} conflict: ${ev.decision_reason || 'Needs review'}`,
        ref_id: ev.id,
      });
    }

    const rows: DtrDayRow[] = [];
    let daysPresent = 0;
    let daysLate = 0;
    let daysUndertime = 0;
    let daysAbsent = 0;
    let daysOnLeave = 0;
    let daysOb = 0;
    let daysHoliday = 0;
    let daysRestDay = 0;
    let daysMissingPunch = 0;
    let daysNoSchedule = 0;
    let daysUnreconciled = 0;
    let totalLateMinutes = 0;
    let totalUndertimeMinutes = 0;
    let totalOvertimeMinutes = 0;
    let totalWorkedMinutes = 0;

    const mm = String(meta.monthNum).padStart(2, '0');
    for (let day = 1; day <= meta.daysInMonth; day++) {
      const isoDate = `${meta.year}-${mm}-${String(day).padStart(2, '0')}`;
      const dayCode = getManilaDayCodeForIsoDate(isoDate);
      const att = attMap.get(isoDate) || null;
      const hol = holidayMap.get(isoDate) || null;
      const approvedLeavesOnDay = leaveByDate.get(isoDate) || [];
      const isRestDay = restDaySet.has(dayCode.toLowerCase());

      const hasPendingLeaveOnDay = pendingLeaves.some((pl) => isoDate >= pl.start_date && isoDate <= pl.end_date);
      const hasPendingCorrOnDay = pendingCorrectionDates.has(isoDate);

      const leaveLabel = approvedLeavesOnDay
        .map((l) => (l.day_portion !== 'FULL' ? `${l.leave_type} (${l.day_portion})` : l.leave_type))
        .join('; ');
      const holidayLabel = hol ? `${hol.name} (${hol.type})` : '';

      let status = 'No Record';
      let timeIn: string | null = null;
      let breakOut: string | null = null;
      let breakIn: string | null = null;
      let timeOut: string | null = null;
      let overtimeOut: string | null = null;
      let workHours = '-';
      let workedMinutes = 0;
      let lateMinutes = 0;
      let undertimeMinutes = 0;
      let overtimeMinutes = 0;
      let overnightNote = '';
      let deviceName = '-';
      let remarks = '';
      let hasUnresolvedPunch = false;

      if (att) {
        // Use exact DB attendance record without ever silently fabricating missing punches
        status = att.status;
        timeIn = att.time_in;
        breakOut = att.break_out;
        breakIn = att.break_in;
        timeOut = att.time_out;
        overtimeOut = att.overtime_out;
        workHours = att.work_hours || '-';
        lateMinutes = Number(att.late_minutes || 0);
        undertimeMinutes = Number(att.undertime_minutes || 0);
        overtimeMinutes = Number(att.overtime_minutes || 0);
        deviceName = att.device_name || '-';
        remarks = att.remarks || '';
        workedMinutes = parseWorkHoursToMinutes(att.work_hours, att.time_in, att.time_out);

        if (isOvernightShift || /overnight|03:00|cutoff|next[- ]day/i.test(remarks)) {
          overnightNote = /03:00|cutoff/i.test(remarks)
            ? '03:00 Manila cutoff'
            : isOvernightShift
              ? `Overnight (${emp.shift_time_in}-${emp.shift_time_out})`
              : '';
        }

        const partialOrMissing =
          status === 'Missing Time In' ||
          status === 'Missing Time Out' ||
          Boolean(timeIn && !timeOut) ||
          Boolean(!timeIn && timeOut);

        if (partialOrMissing) {
          hasUnresolvedPunch = true;
          daysMissingPunch++;
          unresolvedBlockers.push({
            type: 'MISSING_PUNCH',
            date: isoDate,
            detail:
              status === 'Missing Time In' || (!timeIn && timeOut)
                ? `Missing Time In on ${isoDate} (Time Out: ${timeOut || '-'})`
                : `Missing Time Out on ${isoDate} (Time In: ${timeIn || '-'})`,
            ref_id: att.id,
          });
        }

        if (status === 'Present' || status === 'Late' || status === 'Undertime') {
          daysPresent++;
        }
        if (status === 'Late') {
          daysLate++;
        }
        if (status === 'Undertime' || undertimeMinutes > 0) {
          daysUndertime++;
        }
        if (status === 'Absent') {
          daysAbsent++;
        } else if (status === 'On Leave') {
          daysOnLeave++;
        } else if (status === 'OB') {
          daysOb++;
        } else if (status === 'Holiday') {
          daysHoliday++;
        } else if (status === 'Rest Day') {
          daysRestDay++;
        } else if (status === 'No Schedule') {
          daysNoSchedule++;
        }

        totalLateMinutes += lateMinutes;
        totalUndertimeMinutes += undertimeMinutes;
        totalOvertimeMinutes += overtimeMinutes;
        totalWorkedMinutes += workedMinutes;

        if (leaveLabel && !remarks.includes(leaveLabel)) {
          remarks = remarks ? `${remarks} | ${leaveLabel}` : leaveLabel;
        }
      } else {
        // Calendar-day fallback from Holidays, Approved Leaves, Rest Days, or Hire Date (never fabricates times)
        if (hol) {
          status = 'Holiday';
          remarks = holidayLabel;
          daysHoliday++;
        } else if (approvedLeavesOnDay.length > 0) {
          const primary = approvedLeavesOnDay[0];
          status = primary.attendance_status === 'OB' ? 'OB' : 'On Leave';
          remarks = leaveLabel;
          if (status === 'OB') daysOb++;
          else daysOnLeave++;
        } else if (isRestDay) {
          status = 'Rest Day';
          remarks = `Scheduled Rest Day (${dayCode})`;
          daysRestDay++;
        } else if (emp.hired_date && isoDate < emp.hired_date) {
          status = 'No Schedule';
          remarks = `Prior to hire date (${emp.hired_date})`;
          daysNoSchedule++;
        } else if (emp.shift_status !== 'Active') {
          status = 'No Schedule';
          remarks = 'Shift inactive';
          daysNoSchedule++;
        } else if (isoDate > todayManila) {
          status = 'Scheduled';
          remarks = 'Future scheduled workday';
        } else {
          status = 'No Record';
          remarks = 'No attendance punch or leave logged';
          daysUnreconciled++;
        }
      }

      rows.push({
        day,
        date: isoDate,
        day_code: dayCode,
        employee_id: emp.id,
        employee_code: emp.employee_code,
        employee_name: emp.full_name,
        department_code: emp.department_code,
        department_name: emp.department_name,
        time_in: timeIn,
        break_out: breakOut,
        break_in: breakIn,
        time_out: timeOut,
        overtime_out: overtimeOut,
        work_hours: workHours,
        worked_minutes: workedMinutes,
        late_minutes: lateMinutes,
        undertime_minutes: undertimeMinutes,
        overtime_minutes: overtimeMinutes,
        status,
        leave_label: leaveLabel,
        holiday_label: holidayLabel,
        overnight_note: overnightNote,
        device_name: deviceName,
        remarks,
        has_unresolved_punch: hasUnresolvedPunch,
        has_pending_correction: hasPendingCorrOnDay,
        has_pending_leave: hasPendingLeaveOnDay,
      });
    }

    const totals = {
      days_present: daysPresent,
      days_late: daysLate,
      days_undertime: daysUndertime,
      days_absent: daysAbsent,
      days_on_leave: daysOnLeave,
      days_ob: daysOb,
      days_holiday: daysHoliday,
      days_rest_day: daysRestDay,
      days_missing_punch: daysMissingPunch,
      days_no_schedule: daysNoSchedule,
      days_unreconciled: daysUnreconciled,
      total_late_minutes: totalLateMinutes,
      total_undertime_minutes: totalUndertimeMinutes,
      total_overtime_minutes: totalOvertimeMinutes,
      total_worked_minutes: totalWorkedMinutes,
      total_worked_hours_formatted: formatDurationMinutes(totalWorkedMinutes),
      approved_corrections_count: approvedCorrectionsCount,
    };

    const snapshotPayload = {
      employee_id: emp.id,
      month: meta.month,
      totals,
      rows: rows.map((r) => ({
        date: r.date,
        time_in: r.time_in,
        break_out: r.break_out,
        break_in: r.break_in,
        time_out: r.time_out,
        overtime_out: r.overtime_out,
        status: r.status,
        late_minutes: r.late_minutes,
        undertime_minutes: r.undertime_minutes,
        overtime_minutes: r.overtime_minutes,
      })),
    };
    const snapshotSha256 = crypto.createHash('sha256').update(JSON.stringify(snapshotPayload)).digest('hex');

    const storedSignoff = signoffStmt.get(emp.id, meta.month) as
      | {
          id: number;
          employee_id: number;
          month: string;
          status: 'SIGNED' | 'REVOKED';
          employee_signed_by_user_id: number | null;
          employee_signed_by: string | null;
          employee_signed_at_utc: string | null;
          supervisor_verified_by_user_id: number | null;
          supervisor_verified_by: string | null;
          supervisor_verified_at_utc: string | null;
          campus_director_name: string;
          dtr_snapshot_sha256: string;
          notes: string;
        }
      | undefined;

    const signoff: DtrSignoffInfo | null = storedSignoff
      ? {
          ...storedSignoff,
          hash_matches: storedSignoff.status === 'SIGNED' && storedSignoff.dtr_snapshot_sha256 === snapshotSha256,
        }
      : null;

    let dtrState: MonthlyDtrEmployeeReport['dtr_state'] = 'READY_UNSIGNED';
    if (unresolvedBlockers.length > 0) {
      dtrState = 'DRAFT_UNRESOLVED';
    } else if (signoff && signoff.status === 'SIGNED') {
      dtrState = signoff.hash_matches ? 'SIGNED' : 'SIGNED_STALE';
    }

    const isDraft = dtrState === 'DRAFT_UNRESOLVED' || dtrState === 'SIGNED_STALE';
    const isSigned = dtrState === 'SIGNED';

    reports.push({
      month: meta.month,
      month_label: meta.monthLabel,
      days_in_month: meta.daysInMonth,
      is_leap_year: meta.isLeapYear,
      start_date: meta.startDate,
      end_date: meta.endDate,
      employee: {
        id: emp.id,
        employee_code: emp.employee_code,
        full_name: emp.full_name,
        email: emp.email,
        department_id: emp.department_id,
        department_code: emp.department_code,
        department_name: emp.department_name,
        department_head_name: emp.department_head_name,
        position_name: emp.position_name,
        employee_type: emp.employee_type,
        shift_id: emp.shift_id,
        shift_name: emp.shift_name,
        shift_time_in: emp.shift_time_in,
        shift_time_out: emp.shift_time_out,
        is_overnight_shift: isOvernightShift,
        rest_days: emp.rest_days,
        hired_date: emp.hired_date,
        status: emp.status,
      },
      cs_form_48_reference_verified: csRefVerified,
      cs_form_48_reference_note: csRefNote,
      dtr_state: dtrState,
      is_draft: isDraft,
      is_signed: isSigned,
      snapshot_sha256: snapshotSha256,
      unresolved_blockers: unresolvedBlockers,
      signoff,
      campus_director_name: signoff?.campus_director_name || campusDirectorName,
      totals,
      rows,
    });
  }

  return {
    meta,
    reports,
    campus_director_name: campusDirectorName,
    cs_form_48_reference_verified: csRefVerified,
    cs_form_48_reference_note: csRefNote,
  };
}

export function signMonthlyDtr(
  db: Database.Database,
  input: {
    employeeId: number;
    month: string;
    roleAction: 'EMPLOYEE_SIGN' | 'SUPERVISOR_VERIFY' | 'BOTH';
    campusDirectorName?: string;
    notes?: string;
    actor: { userId: number; username: string; role: string; ipAddress: string };
  }
): MonthlyDtrEmployeeReport {
  const built = buildMonthlyDtrReports(db, { month: input.month, empId: input.employeeId });
  if (built.reports.length === 0) {
    throw new ReportEngineError(404, 'EMPLOYEE_NOT_FOUND', 'Employee not found for DTR sign-off.');
  }
  const report = built.reports[0];

  if (report.unresolved_blockers.length > 0) {
    throw new ReportEngineError(
      409,
      'DTR_UNRESOLVED_DRAFT',
      `Cannot sign DTR for ${report.employee.full_name} (${report.month}): ${report.unresolved_blockers.length} unresolved scan/correction/leave item(s) remain.`,
      { blockers: report.unresolved_blockers }
    );
  }

  const nowUtc = new Date().toISOString();
  const effectiveDirector =
    (input.campusDirectorName !== undefined ? input.campusDirectorName.trim() : '') ||
    report.campus_director_name ||
    '';

  const existing = db
    .prepare('SELECT * FROM dtr_signoffs WHERE employee_id = ? AND month = ?')
    .get(input.employeeId, report.month) as
    | {
        id: number;
        employee_signed_by_user_id: number | null;
        employee_signed_by: string | null;
        employee_signed_at_utc: string | null;
        supervisor_verified_by_user_id: number | null;
        supervisor_verified_by: string | null;
        supervisor_verified_at_utc: string | null;
      }
    | undefined;

  const empSignedUid =
    input.roleAction === 'EMPLOYEE_SIGN' || input.roleAction === 'BOTH'
      ? input.actor.userId
      : existing?.employee_signed_by_user_id ?? null;
  const empSignedBy =
    input.roleAction === 'EMPLOYEE_SIGN' || input.roleAction === 'BOTH'
      ? input.actor.username
      : existing?.employee_signed_by ?? null;
  const empSignedAt =
    input.roleAction === 'EMPLOYEE_SIGN' || input.roleAction === 'BOTH'
      ? nowUtc
      : existing?.employee_signed_at_utc ?? null;

  const supUid =
    input.roleAction === 'SUPERVISOR_VERIFY' || input.roleAction === 'BOTH'
      ? input.actor.userId
      : existing?.supervisor_verified_by_user_id ?? null;
  const supBy =
    input.roleAction === 'SUPERVISOR_VERIFY' || input.roleAction === 'BOTH'
      ? input.actor.username
      : existing?.supervisor_verified_by ?? null;
  const supAt =
    input.roleAction === 'SUPERVISOR_VERIFY' || input.roleAction === 'BOTH'
      ? nowUtc
      : existing?.supervisor_verified_at_utc ?? null;

  db.prepare(
    `INSERT INTO dtr_signoffs
       (employee_id, month, status, employee_signed_by_user_id, employee_signed_by, employee_signed_at_utc,
        supervisor_verified_by_user_id, supervisor_verified_by, supervisor_verified_at_utc,
        campus_director_name, dtr_snapshot_sha256, notes, updated_at)
     VALUES (?, ?, 'SIGNED', ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', 'localtime'))
     ON CONFLICT(employee_id, month) DO UPDATE SET
       status = 'SIGNED',
       employee_signed_by_user_id = excluded.employee_signed_by_user_id,
       employee_signed_by = excluded.employee_signed_by,
       employee_signed_at_utc = excluded.employee_signed_at_utc,
       supervisor_verified_by_user_id = excluded.supervisor_verified_by_user_id,
       supervisor_verified_by = excluded.supervisor_verified_by,
       supervisor_verified_at_utc = excluded.supervisor_verified_at_utc,
       campus_director_name = excluded.campus_director_name,
       dtr_snapshot_sha256 = excluded.dtr_snapshot_sha256,
       notes = excluded.notes,
       updated_at = datetime('now', 'localtime')`
  ).run(
    input.employeeId,
    report.month,
    empSignedUid,
    empSignedBy,
    empSignedAt,
    supUid,
    supBy,
    supAt,
    effectiveDirector,
    report.snapshot_sha256,
    (input.notes || '').trim()
  );

  logAudit(
    db,
    input.actor.username,
    `Signed DTR (${input.roleAction}) for ${report.employee.employee_code} (${report.month}, sha256=${report.snapshot_sha256.slice(0, 12)})`,
    'Reports',
    'Success',
    input.actor.ipAddress,
    { actionType: 'DTR_SIGNED', targetType: 'dtr_signoff', targetId: input.employeeId }
  );

  return buildMonthlyDtrReports(db, { month: report.month, empId: input.employeeId }).reports[0];
}

export function revokeMonthlyDtrSignoff(
  db: Database.Database,
  input: {
    employeeId: number;
    month: string;
    reason?: string;
    actor: { username: string; ipAddress: string };
  }
): MonthlyDtrEmployeeReport {
  const meta = getMonthCalendarMeta(input.month);
  db.prepare(
    `UPDATE dtr_signoffs
     SET status = 'REVOKED', notes = ?, updated_at = datetime('now', 'localtime')
     WHERE employee_id = ? AND month = ?`
  ).run((input.reason || 'Revoked by administrator/HR').trim(), input.employeeId, meta.month);

  logAudit(
    db,
    input.actor.username,
    `Revoked DTR sign-off for emp #${input.employeeId} (${meta.month})`,
    'Reports',
    'Warning',
    input.actor.ipAddress,
    { actionType: 'DTR_REVOKED', targetType: 'dtr_signoff', targetId: input.employeeId }
  );

  const built = buildMonthlyDtrReports(db, { month: meta.month, empId: input.employeeId });
  if (built.reports.length === 0) {
    throw new ReportEngineError(404, 'EMPLOYEE_NOT_FOUND', 'Employee not found.');
  }
  return built.reports[0];
}

// ============================================================================
// FULL-RANGE PAGINATED REPORT QUERIES (ZERO HARD TRUNCATION)
// ============================================================================

function buildReportQuerySpec(
  db: Database.Database,
  type: ReportType,
  filters: ReportFilters
): {
  title: string;
  columns: string[];
  selectSql: string;
  countSql: string;
  summarySql: string;
  params: unknown[];
} {
  let startDate = filters.startDate?.trim() || '';
  let endDate = filters.endDate?.trim() || '';
  if (filters.month && isValidIsoMonth(filters.month)) {
    const m = getMonthCalendarMeta(filters.month);
    if (!startDate) startDate = m.startDate;
    if (!endDate) endDate = m.endDate;
  }

  if (type === 'attendance') {
    const where: string[] = [];
    const params: unknown[] = [];
    if (startDate) {
      where.push('a.date >= ?');
      params.push(startDate);
    }
    if (endDate) {
      where.push('a.date <= ?');
      params.push(endDate);
    }
    if (filters.empId) {
      where.push('a.employee_id = ?');
      params.push(filters.empId);
    }
    if (filters.deptId) {
      where.push('e.department_id = ?');
      params.push(filters.deptId);
    }
    if (filters.status && filters.status !== 'All') {
      where.push('a.status = ?');
      params.push(filters.status);
    }
    const wSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    return {
      title: 'Campus Attendance Summary Report',
      columns: [
        'date',
        'employee_code',
        'employee_name',
        'department_code',
        'time_in',
        'break_out',
        'break_in',
        'time_out',
        'overtime_out',
        'work_hours',
        'late_minutes',
        'undertime_minutes',
        'overtime_minutes',
        'status',
        'device_name',
        'remarks',
      ],
      selectSql: `
        SELECT a.date, e.employee_code, e.full_name as employee_name, d.code as department_code,
               COALESCE(a.time_in, '-') as time_in,
               COALESCE(a.break_out, '-') as break_out,
               COALESCE(a.break_in, '-') as break_in,
               COALESCE(a.time_out, '-') as time_out,
               COALESCE(a.overtime_out, '-') as overtime_out,
               a.work_hours,
               COALESCE(a.late_minutes, 0) as late_minutes,
               COALESCE(a.undertime_minutes, 0) as undertime_minutes,
               COALESCE(a.overtime_minutes, 0) as overtime_minutes,
               a.status, COALESCE(a.device_name, '-') as device_name, COALESCE(a.remarks, '') as remarks
        FROM attendance_records a
        JOIN employees e ON a.employee_id = e.id
        JOIN departments d ON e.department_id = d.id
        ${wSql}
        ORDER BY a.date DESC, e.employee_code ASC`,
      countSql: `
        SELECT COUNT(*) as total
        FROM attendance_records a
        JOIN employees e ON a.employee_id = e.id
        ${wSql}`,
      summarySql: `
        SELECT COUNT(*) as total_records,
               SUM(CASE WHEN a.status IN ('Present', 'Late', 'Undertime') THEN 1 ELSE 0 END) as present_count,
               SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) as late_count,
               SUM(CASE WHEN a.status = 'Undertime' THEN 1 ELSE 0 END) as undertime_count,
               SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) as absent_count,
               SUM(CASE WHEN a.status = 'On Leave' THEN 1 ELSE 0 END) as on_leave_count,
               SUM(CASE WHEN a.status = 'OB' THEN 1 ELSE 0 END) as ob_count,
               SUM(CASE WHEN a.status IN ('Missing Time In', 'Missing Time Out') THEN 1 ELSE 0 END) as missing_punch_count,
               COALESCE(SUM(a.late_minutes), 0) as total_late_minutes,
               COALESCE(SUM(a.undertime_minutes), 0) as total_undertime_minutes,
               COALESCE(SUM(a.overtime_minutes), 0) as total_overtime_minutes
        FROM attendance_records a
        JOIN employees e ON a.employee_id = e.id
        ${wSql}`,
      params,
    };
  }

  if (type === 'leaves') {
    const where: string[] = [];
    const params: unknown[] = [];
    if (filters.deptId) {
      where.push('e.department_id = ?');
      params.push(filters.deptId);
    }
    if (filters.empId) {
      where.push('l.employee_id = ?');
      params.push(filters.empId);
    }
    if (filters.status && filters.status !== 'All') {
      where.push('l.status = ?');
      params.push(filters.status);
    }
    if (startDate) {
      where.push('l.end_date >= ?');
      params.push(startDate);
    }
    if (endDate) {
      where.push('l.start_date <= ?');
      params.push(endDate);
    }
    const wSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    return {
      title: 'Leave Applications & Balances Report',
      columns: [
        'employee_code',
        'employee_name',
        'department_code',
        'leave_type',
        'day_portion',
        'start_date',
        'end_date',
        'days_count',
        'status',
        'reviewed_by',
        'document_reference',
        'reason',
      ],
      selectSql: `
        SELECT e.employee_code, e.full_name as employee_name, d.code as department_code,
               l.leave_type, COALESCE(l.day_portion, 'FULL') as day_portion,
               l.start_date, l.end_date, l.days_count, l.status,
               COALESCE(l.reviewed_by, '-') as reviewed_by,
               COALESCE(l.document_reference, '') as document_reference,
               COALESCE(l.reason, '') as reason
        FROM leaves l
        JOIN employees e ON l.employee_id = e.id
        JOIN departments d ON e.department_id = d.id
        ${wSql}
        ORDER BY l.start_date DESC, e.employee_code ASC`,
      countSql: `
        SELECT COUNT(*) as total
        FROM leaves l
        JOIN employees e ON l.employee_id = e.id
        ${wSql}`,
      summarySql: `
        SELECT COUNT(*) as total_applications,
               SUM(CASE WHEN l.status = 'Approved' THEN 1 ELSE 0 END) as approved_count,
               SUM(CASE WHEN l.status = 'Pending' THEN 1 ELSE 0 END) as pending_count,
               SUM(CASE WHEN l.status = 'Rejected' THEN 1 ELSE 0 END) as rejected_count,
               SUM(CASE WHEN l.status = 'Cancelled' THEN 1 ELSE 0 END) as cancelled_count,
               COALESCE(SUM(CASE WHEN l.status = 'Approved' THEN l.days_count ELSE 0 END), 0) as total_approved_days,
               COALESCE(SUM(CASE WHEN l.status = 'Pending' THEN l.days_count ELSE 0 END), 0) as total_pending_days
        FROM leaves l
        JOIN employees e ON l.employee_id = e.id
        ${wSql}`,
      params,
    };
  }

  if (type === 'payroll') {
    const where: string[] = [];
    const params: unknown[] = [];
    if (filters.runId) {
      where.push('r.id = ?');
      params.push(filters.runId);
    }
    if (filters.deptId) {
      where.push('e.department_id = ?');
      params.push(filters.deptId);
    }
    if (filters.empId) {
      where.push('pi.employee_id = ?');
      params.push(filters.empId);
    }
    if (filters.status && filters.status !== 'All') {
      where.push('r.status = ?');
      params.push(filters.status);
    }
    if (startDate) {
      where.push('r.end_date >= ?');
      params.push(startDate);
    }
    if (endDate) {
      where.push('r.start_date <= ?');
      params.push(endDate);
    }
    const wSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    return {
      title: 'Payroll Ledger & Payslip Summary Report',
      columns: [
        'period_label',
        'start_date',
        'end_date',
        'calculation_version',
        'policy_code',
        'policy_approval_status',
        'employee_code',
        'employee_name',
        'department_code',
        'days_present',
        'days_late',
        'days_absent',
        'basic_pay',
        'overtime_pay',
        'holiday_rest_pay',
        'allowances',
        'gross_pay',
        'statutory_deductions',
        'tax_deduction',
        'deductions',
        'net_pay',
        'run_status',
      ],
      selectSql: `
        SELECT r.period_label, r.start_date, r.end_date,
               COALESCE(r.calculation_version, 1) as calculation_version,
               COALESCE(r.policy_code, '') as policy_code,
               COALESCE(r.policy_approval_status, 'DRAFT_NOT_APPROVED') as policy_approval_status,
               e.employee_code, e.full_name as employee_name, d.code as department_code,
               pi.days_present, pi.days_late, pi.days_absent,
               pi.basic_pay, COALESCE(pi.overtime_pay, 0) as overtime_pay,
               COALESCE(pi.holiday_rest_pay, 0) as holiday_rest_pay,
               pi.allowances, COALESCE(pi.gross_pay, pi.basic_pay + pi.allowances) as gross_pay,
               COALESCE(pi.statutory_deductions, 0) as statutory_deductions,
               COALESCE(pi.tax_deduction, 0) as tax_deduction,
               pi.deductions, pi.net_pay, r.status as run_status
        FROM payroll_items pi
        JOIN payroll_runs r ON pi.payroll_run_id = r.id
        JOIN employees e ON pi.employee_id = e.id
        JOIN departments d ON e.department_id = d.id
        ${wSql}
        ORDER BY r.id DESC, e.employee_code ASC`,
      countSql: `
        SELECT COUNT(*) as total
        FROM payroll_items pi
        JOIN payroll_runs r ON pi.payroll_run_id = r.id
        JOIN employees e ON pi.employee_id = e.id
        ${wSql}`,
      summarySql: `
        SELECT COUNT(*) as total_items,
               COUNT(DISTINCT r.id) as total_runs,
               ROUND(COALESCE(SUM(pi.basic_pay), 0), 2) as total_basic_pay,
               ROUND(COALESCE(SUM(pi.allowances), 0), 2) as total_allowances,
               ROUND(COALESCE(SUM(COALESCE(pi.overtime_pay, 0)), 0), 2) as total_overtime_pay,
               ROUND(COALESCE(SUM(COALESCE(pi.holiday_rest_pay, 0)), 0), 2) as total_holiday_rest_pay,
               ROUND(COALESCE(SUM(COALESCE(pi.gross_pay, pi.basic_pay + pi.allowances)), 0), 2) as total_gross_pay,
               ROUND(COALESCE(SUM(pi.deductions), 0), 2) as total_deductions,
               ROUND(COALESCE(SUM(pi.net_pay), 0), 2) as total_net_pay
        FROM payroll_items pi
        JOIN payroll_runs r ON pi.payroll_run_id = r.id
        JOIN employees e ON pi.employee_id = e.id
        ${wSql}`,
      params,
    };
  }

  if (type === 'employees') {
    const where: string[] = [];
    const params: unknown[] = [];
    if (filters.deptId) {
      where.push('e.department_id = ?');
      params.push(filters.deptId);
    }
    if (filters.empId) {
      where.push('e.id = ?');
      params.push(filters.empId);
    }
    if (filters.status && filters.status !== 'All') {
      where.push('e.status = ?');
      params.push(filters.status);
    }
    if (filters.search?.trim()) {
      const q = `%${filters.search.trim()}%`;
      where.push('(e.employee_code LIKE ? OR e.full_name LIKE ? OR e.email LIKE ?)');
      params.push(q, q, q);
    }
    const wSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    return {
      title: 'Campus Employee Masterlist',
      columns: [
        'employee_code',
        'full_name',
        'email',
        'department_code',
        'department_name',
        'position_name',
        'employee_type',
        'shift_name',
        'status',
        'hired_date',
      ],
      selectSql: `
        SELECT e.employee_code, e.full_name, e.email, d.code as department_code, d.name as department_name,
               p.name as position_name, p.type as employee_type, s.name as shift_name, e.status, e.hired_date
        FROM employees e
        JOIN departments d ON e.department_id = d.id
        JOIN positions p ON e.position_id = p.id
        JOIN shifts s ON e.shift_id = s.id
        ${wSql}
        ORDER BY e.employee_code ASC`,
      countSql: `SELECT COUNT(*) as total FROM employees e ${wSql}`,
      summarySql: `
        SELECT COUNT(*) as total_employees,
               SUM(CASE WHEN e.status = 'Active' THEN 1 ELSE 0 END) as active_count,
               SUM(CASE WHEN e.status != 'Active' THEN 1 ELSE 0 END) as inactive_count
        FROM employees e ${wSql}`,
      params,
    };
  }

  // audit-logs
  const where: string[] = [];
  const params: unknown[] = [];
  if (startDate) {
    where.push('date(timestamp) >= ?');
    params.push(startDate);
  }
  if (endDate) {
    where.push('date(timestamp) <= ?');
    params.push(endDate);
  }
  if (filters.module && filters.module !== 'All') {
    where.push('module = ?');
    params.push(filters.module);
  }
  if (filters.status && filters.status !== 'All') {
    where.push('status = ?');
    params.push(filters.status);
  }
  if (filters.search?.trim()) {
    const q = `%${filters.search.trim()}%`;
    where.push('(username LIKE ? OR activity LIKE ? OR module LIKE ?)');
    params.push(q, q, q);
  }
  const wSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  return {
    title: 'System Security & Audit Trail Report',
    columns: [
      'id',
      'timestamp',
      'username',
      'module',
      'action_type',
      'activity',
      'status',
      'ip_address',
      'entry_hash',
    ],
    selectSql: `SELECT id, timestamp, username, module, COALESCE(action_type, 'EVENT') as action_type, activity, status, ip_address, COALESCE(entry_hash, '') as entry_hash FROM audit_logs ${wSql} ORDER BY id DESC`,
    countSql: `SELECT COUNT(*) as total FROM audit_logs ${wSql}`,
    summarySql: `
      SELECT COUNT(*) as total_events,
             SUM(CASE WHEN status = 'Success' THEN 1 ELSE 0 END) as success_count,
             SUM(CASE WHEN status = 'Warning' THEN 1 ELSE 0 END) as warning_count,
             SUM(CASE WHEN status = 'Error' THEN 1 ELSE 0 END) as error_count
      FROM audit_logs ${wSql}`,
    params,
  };
}

export function queryReport(
  db: Database.Database,
  type: ReportType,
  filters: ReportFilters,
  options: { page?: number; limit?: number; serverNowUtc?: number } = {}
): ReportQueryResult {
  const page = Math.max(1, Number(options.page) || 1);
  const limit = Math.min(1000, Math.max(1, Number(options.limit) || 100));
  const nowUtc = options.serverNowUtc ?? Date.now();
  const generatedAt = new Date(nowUtc).toISOString();

  if (type === 'dtr') {
    const effectiveMonth =
      filters.month && isValidIsoMonth(filters.month)
        ? filters.month
        : filters.startDate && isValidIsoDate(filters.startDate)
          ? filters.startDate.slice(0, 7)
          : getManilaDateString(nowUtc).slice(0, 7);

    const built = buildMonthlyDtrReports(db, {
      month: effectiveMonth,
      empId: filters.empId ?? null,
      deptId: filters.deptId ?? null,
      serverNowUtc: nowUtc,
    });

    const allDayRows: Record<string, unknown>[] = [];
    for (const rep of built.reports) {
      for (const r of rep.rows) {
        allDayRows.push({
          date: r.date,
          day_code: r.day_code,
          employee_code: r.employee_code,
          employee_name: r.employee_name,
          department_code: r.department_code,
          time_in: r.time_in ?? '-',
          break_out: r.break_out ?? '-',
          break_in: r.break_in ?? '-',
          time_out: r.time_out ?? '-',
          overtime_out: r.overtime_out ?? '-',
          work_hours: r.work_hours,
          late_minutes: r.late_minutes,
          undertime_minutes: r.undertime_minutes,
          overtime_minutes: r.overtime_minutes,
          status: r.status,
          dtr_state: rep.dtr_state,
          remarks: r.remarks || r.overnight_note || '',
        });
      }
    }

    const total = allDayRows.length;
    const totalPages = Math.max(1, Math.ceil(total / limit));
    const offset = (page - 1) * limit;
    const pagedRows = allDayRows.slice(offset, offset + limit);

    const aggregateSummary = built.reports.reduce(
      (acc, rep) => {
        acc.employee_count += 1;
        if (rep.is_draft) acc.draft_count += 1;
        if (rep.is_signed) acc.signed_count += 1;
        acc.total_blockers += rep.unresolved_blockers.length;
        acc.days_present += rep.totals.days_present;
        acc.days_late += rep.totals.days_late;
        acc.days_absent += rep.totals.days_absent;
        acc.days_on_leave += rep.totals.days_on_leave;
        acc.days_ob += rep.totals.days_ob;
        acc.total_late_minutes += rep.totals.total_late_minutes;
        acc.total_undertime_minutes += rep.totals.total_undertime_minutes;
        acc.total_overtime_minutes += rep.totals.total_overtime_minutes;
        acc.total_worked_minutes += rep.totals.total_worked_minutes;
        return acc;
      },
      {
        month: built.meta.month,
        month_label: built.meta.monthLabel,
        days_in_month: built.meta.daysInMonth,
        is_leap_year: built.meta.isLeapYear,
        employee_count: 0,
        draft_count: 0,
        signed_count: 0,
        total_blockers: 0,
        days_present: 0,
        days_late: 0,
        days_absent: 0,
        days_on_leave: 0,
        days_ob: 0,
        total_late_minutes: 0,
        total_undertime_minutes: 0,
        total_overtime_minutes: 0,
        total_worked_minutes: 0,
      }
    );

    const title = built.cs_form_48_reference_verified
      ? `CS Form 48 — Daily Time Record (${built.meta.monthLabel})`
      : `Monthly Daily Time Record — Draft Format (${built.meta.monthLabel}; CS Form 48 Reference Pending RSU Approval)`;

    return {
      title,
      type: 'dtr',
      generatedAt,
      columns: [
        'date',
        'day_code',
        'employee_code',
        'employee_name',
        'department_code',
        'time_in',
        'break_out',
        'break_in',
        'time_out',
        'overtime_out',
        'work_hours',
        'late_minutes',
        'undertime_minutes',
        'overtime_minutes',
        'status',
        'dtr_state',
        'remarks',
      ],
      rows: pagedRows,
      pagination: { page, limit, total, totalPages },
      summary: aggregateSummary,
      dtr_reports: built.reports,
      cs_form_48_reference_verified: built.cs_form_48_reference_verified,
      cs_form_48_reference_note: built.cs_form_48_reference_note,
    };
  }

  const spec = buildReportQuerySpec(db, type, filters);
  const total = Number((db.prepare(spec.countSql).get(...spec.params) as { total: number }).total || 0);
  const totalPages = Math.max(1, Math.ceil(total / limit));
  const offset = (page - 1) * limit;
  const rows = db
    .prepare(`${spec.selectSql} LIMIT ? OFFSET ?`)
    .all(...spec.params, limit, offset) as Record<string, unknown>[];
  const summary = (db.prepare(spec.summarySql).get(...spec.params) as Record<string, unknown>) || {};

  let leaveBalances: unknown[] | undefined;
  if (type === 'leaves') {
    const targetYear =
      filters.month && isValidIsoMonth(filters.month)
        ? Number(filters.month.slice(0, 4))
        : filters.startDate && isValidIsoDate(filters.startDate)
          ? Number(filters.startDate.slice(0, 4))
          : Number(getManilaDateString(nowUtc).slice(0, 4));
    leaveBalances = computeEmployeeLeaveBalances(db, {
      year: targetYear,
      departmentId: filters.deptId ?? null,
      employeeId: filters.empId ?? null,
    });
  }

  return {
    title: spec.title,
    type,
    generatedAt,
    columns: spec.columns,
    rows,
    pagination: { page, limit, total, totalPages },
    summary,
    ...(leaveBalances !== undefined ? { leave_balances: leaveBalances } : {}),
  };
}

// ============================================================================
// STREAMING CSV EXPORT (UNCLIPPED FULL-RANGE, FORMULA-SAFE)
// ============================================================================

export function streamCsvReportResponse(
  db: Database.Database,
  res: Response,
  type: ReportType,
  filters: ReportFilters,
  options: { strict?: boolean; requireSigned?: boolean; serverNowUtc?: number } = {}
): { rowCount: number; filename: string } {
  const nowUtc = options.serverNowUtc ?? Date.now();
  const stamp = getManilaDateString(nowUtc);

  if (type === 'dtr') {
    const effectiveMonth =
      filters.month && isValidIsoMonth(filters.month)
        ? filters.month
        : filters.startDate && isValidIsoDate(filters.startDate)
          ? filters.startDate.slice(0, 7)
          : stamp.slice(0, 7);

    const built = buildMonthlyDtrReports(db, {
      month: effectiveMonth,
      empId: filters.empId ?? null,
      deptId: filters.deptId ?? null,
      serverNowUtc: nowUtc,
    });

    if (options.strict && built.reports.some((r) => r.unresolved_blockers.length > 0)) {
      const firstDraft = built.reports.find((r) => r.unresolved_blockers.length > 0)!;
      throw new ReportEngineError(
        409,
        'DTR_UNRESOLVED_DRAFT',
        `Strict DTR export blocked: ${firstDraft.employee.employee_code} has unresolved scan/correction/leave items.`,
        { blockers: firstDraft.unresolved_blockers }
      );
    }
    if (options.requireSigned && built.reports.some((r) => !r.is_signed)) {
      throw new ReportEngineError(
        409,
        'DTR_UNSIGNED',
        'Signed DTR required for this export; one or more employees have unsigned or stale DTRs.'
      );
    }

    const scopePart = filters.empId && built.reports[0] ? sanitizeFilenameToken(built.reports[0].employee.employee_code) : 'campus';
    const filename = `SAVAGE-RSUCAJ-DTR-${effectiveMonth}-${scopePart}.csv`;
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.setHeader('X-Content-Type-Options', 'nosniff');

    const columns = [
      'month',
      'date',
      'day_code',
      'employee_code',
      'employee_name',
      'department_code',
      'time_in',
      'break_out',
      'break_in',
      'time_out',
      'overtime_out',
      'work_hours',
      'late_minutes',
      'undertime_minutes',
      'overtime_minutes',
      'status',
      'dtr_state',
      'is_draft',
      'cs_form_48_status',
      'remarks',
    ];
    res.write(columns.map(escapeCsvCell).join(',') + '\r\n');

    let count = 0;
    for (const rep of built.reports) {
      const formStatus = rep.cs_form_48_reference_verified ? 'VERIFIED_RSU_CS_FORM_48' : 'DRAFT_CS48_REF_PENDING';
      for (const r of rep.rows) {
        const line = [
          rep.month,
          r.date,
          r.day_code,
          r.employee_code,
          r.employee_name,
          r.department_code,
          r.time_in ?? (r.has_unresolved_punch && r.status === 'Missing Time In' ? 'MISSING' : '-'),
          r.break_out ?? '-',
          r.break_in ?? '-',
          r.time_out ?? (r.has_unresolved_punch && r.status === 'Missing Time Out' ? 'MISSING' : '-'),
          r.overtime_out ?? '-',
          r.work_hours,
          r.late_minutes,
          r.undertime_minutes,
          r.overtime_minutes,
          r.status,
          rep.dtr_state,
          rep.is_draft ? 'YES' : 'NO',
          formStatus,
          r.remarks || r.overnight_note || '',
        ]
          .map(escapeCsvCell)
          .join(',');
        res.write(line + '\r\n');
        count++;
      }
    }
    res.end();
    return { rowCount: count, filename };
  }

  const spec = buildReportQuerySpec(db, type, filters);
  const filename = `SAVAGE-RSUCAJ-${sanitizeFilenameToken(type)}-${stamp}.csv`;
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.setHeader('X-Content-Type-Options', 'nosniff');

  res.write(spec.columns.map(escapeCsvCell).join(',') + '\r\n');

  const stmt = db.prepare(spec.selectSql);
  let rowCount = 0;
  let batch: string[] = [];
  for (const row of stmt.iterate(...spec.params) as IterableIterator<Record<string, unknown>>) {
    const line = spec.columns.map((c) => escapeCsvCell(row[c])).join(',');
    batch.push(line);
    rowCount++;
    if (batch.length >= 250) {
      res.write(batch.join('\r\n') + '\r\n');
      batch = [];
    }
  }
  if (batch.length > 0) {
    res.write(batch.join('\r\n') + '\r\n');
  }
  res.end();
  return { rowCount, filename };
}

// ============================================================================
// SERVER-SIDE A4 PORTRAIT PDF GENERATION (RSU LOGO, SIGNATURES, DRAFT WATERMARK)
// ============================================================================

export async function generateReportPdfBuffer(
  db: Database.Database,
  type: ReportType,
  filters: ReportFilters,
  options: { strict?: boolean; requireSigned?: boolean; generatedBy?: string; serverNowUtc?: number } = {}
): Promise<{ buffer: Buffer; filename: string; pageCount: number; rowCount: number }> {
  const nowUtc = options.serverNowUtc ?? Date.now();
  const manilaNow = toManilaParts(nowUtc);
  const emblemPath = getRsuEmblemPath();

  if (type === 'dtr') {
    const effectiveMonth =
      filters.month && isValidIsoMonth(filters.month)
        ? filters.month
        : filters.startDate && isValidIsoDate(filters.startDate)
          ? filters.startDate.slice(0, 7)
          : manilaNow.isoDate.slice(0, 7);

    const built = buildMonthlyDtrReports(db, {
      month: effectiveMonth,
      empId: filters.empId ?? null,
      deptId: filters.deptId ?? null,
      serverNowUtc: nowUtc,
    });

    if (built.reports.length === 0) {
      throw new ReportEngineError(404, 'NO_DTR_RECORDS', 'No employees found for the requested Monthly DTR filter.');
    }
    if (options.strict && built.reports.some((r) => r.unresolved_blockers.length > 0)) {
      const firstDraft = built.reports.find((r) => r.unresolved_blockers.length > 0)!;
      throw new ReportEngineError(
        409,
        'DTR_UNRESOLVED_DRAFT',
        `Official DTR PDF blocked: ${firstDraft.employee.employee_code} (${effectiveMonth}) has ${firstDraft.unresolved_blockers.length} unresolved item(s).`,
        { blockers: firstDraft.unresolved_blockers }
      );
    }
    if (options.requireSigned && built.reports.some((r) => !r.is_signed)) {
      throw new ReportEngineError(
        409,
        'DTR_UNSIGNED',
        'Signed DTR required for PDF export; one or more employees have unsigned or stale DTRs.'
      );
    }

    const scopePart =
      filters.empId && built.reports.length === 1 ? sanitizeFilenameToken(built.reports[0].employee.employee_code) : 'campus';
    const filename = `SAVAGE-RSUCAJ-DTR-${effectiveMonth}-${scopePart}.pdf`;

    const buffer = await renderDtrPdfBuffer(built.reports, emblemPath, manilaNow.isoTimestamp, options.generatedBy || 'system');
    const totalRows = built.reports.reduce((acc, r) => acc + r.rows.length, 0);
    return { buffer, filename, pageCount: built.reports.length, rowCount: totalRows };
  }

  // Tabular A4 Portrait PDF for Attendance, Leaves, Payroll, Employees, Audit Logs
  const spec = buildReportQuerySpec(db, type, filters);
  const MAX_PDF_ROWS = 5000;
  const rows = db.prepare(`${spec.selectSql} LIMIT ?`).all(...spec.params, MAX_PDF_ROWS + 1) as Record<string, unknown>[];
  const truncatedForPdf = rows.length > MAX_PDF_ROWS;
  const renderRows = truncatedForPdf ? rows.slice(0, MAX_PDF_ROWS) : rows;
  const summary = (db.prepare(spec.summarySql).get(...spec.params) as Record<string, unknown>) || {};
  const filename = `SAVAGE-RSUCAJ-${sanitizeFilenameToken(type)}-${manilaNow.isoDate}.pdf`;

  const result = await renderTabularPdfBuffer({
    title: spec.title,
    type,
    columns: spec.columns,
    rows: renderRows,
    summary,
    truncatedForPdf,
    emblemPath,
    manilaTimestamp: manilaNow.isoTimestamp,
    generatedBy: options.generatedBy || 'system',
  });

  return {
    buffer: result.buffer,
    filename,
    pageCount: result.pageCount,
    rowCount: renderRows.length,
  };
}

function renderDtrPdfBuffer(
  reports: MonthlyDtrEmployeeReport[],
  emblemPath: string | null,
  manilaTimestamp: string,
  generatedBy: string
): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: 'A4', // 595.28 x 841.89 pt Portrait
      layout: 'portrait',
      margin: 24,
      bufferPages: true,
      info: {
        Title: `SAVAGE-RSUCAJ Monthly DTR (${reports[0]?.month || ''})`,
        Author: 'Romblon State University - Cajidiocan Campus',
        Subject: 'Monthly Daily Time Record',
        Creator: 'SAVAGE-RSUCAJ Smart Attendance System BUILD 17',
      },
    });

    const chunks: Buffer[] = [];
    doc.on('data', (c: Buffer) => chunks.push(c));
    doc.on('error', reject);
    doc.on('end', () => resolve(Buffer.concat(chunks)));

    reports.forEach((rep, idx) => {
      if (idx > 0) doc.addPage();
      const pageW = 595.28;
      const pageH = 841.89;
      const left = 24;
      const right = pageW - 24;
      const contentW = right - left; // 547.28 pt

      // Top Header Banner
      let y = 22;
      if (emblemPath) {
        try {
          doc.image(emblemPath, left, y, { fit: [44, 44] });
        } catch {
          // ignore if emblem fails
        }
      }

      doc
        .fillColor('#07442B')
        .font('Helvetica-Bold')
        .fontSize(11)
        .text('ROMBLON STATE UNIVERSITY - CAJIDIOCAN CAMPUS', left + 52, y + 2, { width: contentW - 52 });
      doc
        .fillColor('#0B5537')
        .font('Helvetica-Bold')
        .fontSize(8.5)
        .text('SAVAGE-RSUCAJ SMART ATTENDANCE SYSTEM', left + 52, y + 16, { width: contentW - 52 });
      doc
        .fillColor('#334155')
        .font('Helvetica')
        .fontSize(7.5)
        .text(
          rep.cs_form_48_reference_verified
            ? 'OFFICIAL CIVIL SERVICE FORM NO. 48 - DAILY TIME RECORD'
            : 'MONTHLY DAILY TIME RECORD (DRAFT INSTITUTIONAL FORMAT - CS FORM 48 REFERENCE PENDING RSU APPROVAL)',
          left + 52,
          y + 28,
          { width: contentW - 52 }
        );

      y += 50;
      doc.moveTo(left, y).lineTo(right, y).lineWidth(1.2).strokeColor('#0B5537').stroke();
      y += 6;

      // Employee & Month Metadata Grid
      doc.roundedRect(left, y, contentW, 46, 4).fillAndStroke('#F4F8F6', '#CBD5E1');
      doc.fillColor('#0F172A').font('Helvetica-Bold').fontSize(8);
      doc.text(`Employee: ${toPdfAsciiSafe(rep.employee.full_name)} (${rep.employee.employee_code})`, left + 8, y + 6, {
        width: 310,
      });
      doc.text(
        `Period: ${rep.month_label} (${rep.days_in_month} days${rep.is_leap_year ? ', Leap Year' : ''})`,
        left + 325,
        y + 6,
        { width: contentW - 333 }
      );
      doc.font('Helvetica').fontSize(7.5).fillColor('#334155');
      doc.text(
        `Department: ${toPdfAsciiSafe(rep.employee.department_code)} - ${toPdfAsciiSafe(rep.employee.department_name)} | Position: ${toPdfAsciiSafe(rep.employee.position_name)}`,
        left + 8,
        y + 19,
        { width: 310 }
      );
      doc.text(
        `Shift: ${toPdfAsciiSafe(rep.employee.shift_name)} (${rep.employee.shift_time_in} - ${rep.employee.shift_time_out})`,
        left + 325,
        y + 19,
        { width: contentW - 333 }
      );

      const stateLabel =
        rep.dtr_state === 'SIGNED'
          ? 'VERIFIED & SIGNED'
          : rep.dtr_state === 'SIGNED_STALE'
            ? 'DRAFT (MODIFIED AFTER SIGN-OFF)'
            : rep.dtr_state === 'DRAFT_UNRESOLVED'
              ? `DRAFT - UNRESOLVED (${rep.unresolved_blockers.length} BLOCKER)`
              : 'READY (UNSIGNED)';

      doc
        .font('Helvetica-Bold')
        .fillColor(rep.is_draft ? '#B91C1C' : rep.is_signed ? '#047857' : '#92400E')
        .text(`Verification State: ${stateLabel}`, left + 8, y + 32, { width: 310 });
      doc
        .font('Helvetica')
        .fillColor('#475569')
        .text(`Snapshot SHA-256: ${rep.snapshot_sha256.slice(0, 16)}...`, left + 325, y + 32, {
          width: contentW - 333,
        });

      y += 52;

      // Optional Draft Warning Banner
      if (rep.is_draft) {
        const blockerSummary =
          rep.dtr_state === 'SIGNED_STALE'
            ? 'Attendance records changed after previous signature. Re-verification required.'
            : rep.unresolved_blockers
                .slice(0, 2)
                .map((b) => b.detail)
                .join(' | ');
        doc.roundedRect(left, y, contentW, 20, 3).fillAndStroke('#FEF2F2', '#FCA5A5');
        doc
          .fillColor('#991B1B')
          .font('Helvetica-Bold')
          .fontSize(7)
          .text(
            toPdfAsciiSafe(
              `DRAFT DTR NOTICE (Missing punches are NEVER fabricated): ${blockerSummary}${rep.unresolved_blockers.length > 2 ? ` (+${rep.unresolved_blockers.length - 2} more)` : ''}`
            ),
            left + 6,
            y + 6,
            { width: contentW - 12, ellipsis: true }
          );
        y += 24;
      }

      // 31-Day Calendar Table
      const colWidths = [24, 54, 46, 46, 46, 46, 44, 42, 28, 28, contentW - 404];
      const headers = ['Day', 'Date', 'Time In', 'Brk Out', 'Brk In', 'Time Out', 'OT Out', 'Work Hrs', 'Late', 'UT', 'Status / Remarks'];

      const drawHeaderRow = (ry: number) => {
        doc.rect(left, ry, contentW, 16).fill('#07442B');
        doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(6.6);
        let cx = left;
        headers.forEach((h, i) => {
          doc.text(h, cx + 2, ry + 5, {
            width: colWidths[i] - 4,
            align: i === 0 || i >= 8 && i <= 9 ? 'center' : 'left',
          });
          cx += colWidths[i];
        });
      };

      drawHeaderRow(y);
      y += 16;

      const rowH = 14;
      for (let i = 0; i < rep.rows.length; i++) {
        const r = rep.rows[i];
        const bg =
          r.has_unresolved_punch || r.has_pending_correction || r.has_pending_leave
            ? '#FEF2F2'
            : i % 2 === 1
              ? '#F8FAFC'
              : '#FFFFFF';
        doc.rect(left, y, contentW, rowH).fill(bg);
        doc
          .moveTo(left, y + rowH)
          .lineTo(right, y + rowH)
          .lineWidth(0.35)
          .strokeColor('#E2E8F0')
          .stroke();

        const tInStr = r.time_in ?? (r.has_unresolved_punch && r.status === 'Missing Time In' ? 'MISSING' : '-');
        const tOutStr = r.time_out ?? (r.has_unresolved_punch && r.status === 'Missing Time Out' ? 'MISSING' : '-');
        const statusRemark = [r.status, r.leave_label || r.holiday_label || r.overnight_note || '']
          .filter(Boolean)
          .join(' - ');

        const vals = [
          `${String(r.day).padStart(2, '0')} ${r.day_code}`,
          r.date,
          tInStr,
          r.break_out ?? '-',
          r.break_in ?? '-',
          tOutStr,
          r.overtime_out ?? '-',
          r.work_hours || '-',
          r.late_minutes > 0 ? `${r.late_minutes}m` : '0',
          r.undertime_minutes > 0 ? `${r.undertime_minutes}m` : '0',
          toPdfAsciiSafe(statusRemark),
        ];

        let cx = left;
        vals.forEach((v, cIdx) => {
          const isWarn = (cIdx === 2 || cIdx === 5) && v === 'MISSING';
          doc
            .fillColor(isWarn ? '#B91C1C' : '#1E293B')
            .font(cIdx === 0 || isWarn ? 'Helvetica-Bold' : 'Helvetica')
            .fontSize(6.4)
            .text(v, cx + 2, y + 4, {
              width: colWidths[cIdx] - 4,
              align: cIdx >= 8 && cIdx <= 9 ? 'center' : 'left',
              lineBreak: false,
              ellipsis: true,
            });
          cx += colWidths[cIdx];
        });
        y += rowH;
      }

      y += 6;

      // DB-Reconciled Totals Summary Box
      doc.roundedRect(left, y, contentW, 28, 3).fillAndStroke('#ECFDF5', '#A7F3D0');
      doc.fillColor('#07442B').font('Helvetica-Bold').fontSize(7.2);
      doc.text(
        `TOTALS: Present ${rep.totals.days_present}d | Late ${rep.totals.days_late}d (${rep.totals.total_late_minutes}m) | Undertime ${rep.totals.days_undertime}d (${rep.totals.total_undertime_minutes}m) | Absent ${rep.totals.days_absent}d | Leave ${rep.totals.days_on_leave}d | OB ${rep.totals.days_ob}d | Holiday ${rep.totals.days_holiday}d | Rest ${rep.totals.days_rest_day}d`,
        left + 6,
        y + 5,
        { width: contentW - 12 }
      );
      doc
        .font('Helvetica')
        .fontSize(7)
        .text(
          `Total Worked Hours: ${rep.totals.total_worked_hours_formatted} (${rep.totals.total_worked_minutes} min) | Overtime: ${rep.totals.total_overtime_minutes} min | Approved Corrections: ${rep.totals.approved_corrections_count} | Missing Punches: ${rep.totals.days_missing_punch}`,
          left + 6,
          y + 16,
          { width: contentW - 12 }
        );
      y += 34;

      // Certification & Signature Block (Employee + Campus Director)
      doc
        .fillColor('#334155')
        .font('Helvetica-Oblique')
        .fontSize(6.8)
        .text(
          'I certify on my honor that the above is a true and correct report of the hours of work performed, record of which was made daily at the time of arrival and departure from office.',
          left,
          y,
          { width: contentW }
        );
      y += 26;

      const sigW = 225;
      // Left: Employee Signature
      doc.moveTo(left + 10, y + 16).lineTo(left + 10 + sigW, y + 16).lineWidth(0.7).strokeColor('#0F172A').stroke();
      doc
        .fillColor('#0F172A')
        .font('Helvetica-Bold')
        .fontSize(7.5)
        .text(toPdfAsciiSafe(rep.employee.full_name.toUpperCase()), left + 10, y + 19, {
          width: sigW,
          align: 'center',
        });
      doc
        .fillColor('#475569')
        .font('Helvetica')
        .fontSize(6.8)
        .text(
          rep.signoff?.employee_signed_at_utc && rep.is_signed
            ? `Employee Signature (Signed: ${rep.signoff.employee_signed_by} @ ${rep.signoff.employee_signed_at_utc.slice(0, 16)})`
            : 'Employee Signature (Unsigned)',
          left + 10,
          y + 29,
          { width: sigW, align: 'center' }
        );

      // Right: Campus Director / In-Charge Signature
      const rightSigX = right - sigW - 10;
      doc.moveTo(rightSigX, y + 16).lineTo(rightSigX + sigW, y + 16).lineWidth(0.7).strokeColor('#0F172A').stroke();
      doc
        .fillColor('#0F172A')
        .font('Helvetica-Bold')
        .fontSize(7.5)
        .text(
          rep.campus_director_name ? toPdfAsciiSafe(rep.campus_director_name.toUpperCase()) : 'CAMPUS DIRECTOR',
          rightSigX,
          y + 19,
          { width: sigW, align: 'center' }
        );
      doc
        .fillColor('#475569')
        .font('Helvetica')
        .fontSize(6.8)
        .text(
          rep.signoff?.supervisor_verified_at_utc && rep.is_signed
            ? `Campus Director / Verified by ${rep.signoff.supervisor_verified_by}`
            : 'Campus Director / Authorized Official (RSU - Cajidiocan)',
          rightSigX,
          y + 29,
          { width: sigW, align: 'center' }
        );

      // Diagonal DRAFT Watermark if unresolved or unverified CS48
      if (rep.is_draft) {
        doc.save();
        doc.rotate(-32, { origin: [pageW / 2, pageH / 2] });
        doc
          .fillColor('#DC2626')
          .fillOpacity(0.14)
          .font('Helvetica-Bold')
          .fontSize(42)
          .text('DRAFT - UNRESOLVED', 90, pageH / 2 - 20, { align: 'center', width: 420 });
        doc.restore();
      }

      // Footer (inside safe printable margin so no extra blank page triggers)
      doc
        .fillOpacity(1)
        .fillColor('#64748B')
        .font('Helvetica')
        .fontSize(6.5)
        .text(
          `SAVAGE-RSUCAJ Smart Attendance System | Generated ${manilaTimestamp} by ${generatedBy} | Page ${idx + 1} of ${reports.length}`,
          left,
          pageH - 34,
          { width: contentW, align: 'center', lineBreak: false }
        );
    });

    doc.end();
  });
}

function renderTabularPdfBuffer(params: {
  title: string;
  type: ReportType;
  columns: string[];
  rows: Record<string, unknown>[];
  summary: Record<string, unknown>;
  truncatedForPdf: boolean;
  emblemPath: string | null;
  manilaTimestamp: string;
  generatedBy: string;
}): Promise<{ buffer: Buffer; pageCount: number }> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: 'A4',
      layout: 'portrait',
      margin: 24,
      bufferPages: true,
      info: {
        Title: params.title,
        Author: 'Romblon State University - Cajidiocan Campus',
        Creator: 'SAVAGE-RSUCAJ Smart Attendance System BUILD 17',
      },
    });

    const chunks: Buffer[] = [];
    let totalPagesRendered = 1;
    doc.on('data', (c: Buffer) => chunks.push(c));
    doc.on('error', reject);
    doc.on('end', () => resolve({ buffer: Buffer.concat(chunks), pageCount: totalPagesRendered }));

    const pageW = 595.28;
    const pageH = 841.89;
    const left = 24;
    const right = pageW - 24;
    const contentW = right - left;

    // Limit columns cleanly for A4 Portrait readability (select key columns if > 10)
    const displayCols =
      params.type === 'payroll'
        ? [
            'period_label',
            'employee_code',
            'employee_name',
            'department_code',
            'basic_pay',
            'allowances',
            'deductions',
            'net_pay',
            'run_status',
          ]
        : params.type === 'attendance'
          ? ['date', 'employee_code', 'employee_name', 'department_code', 'time_in', 'time_out', 'work_hours', 'late_minutes', 'status']
          : params.columns.slice(0, 9);

    const colW = contentW / displayCols.length;
    const currencyCols = new Set(['basic_pay', 'allowances', 'overtime_pay', 'holiday_rest_pay', 'gross_pay', 'deductions', 'net_pay']);

    const drawPageHeader = () => {
      let y = 22;
      if (params.emblemPath) {
        try {
          doc.image(params.emblemPath, left, y, { fit: [38, 38] });
        } catch {
          // ignore
        }
      }
      doc
        .fillColor('#07442B')
        .font('Helvetica-Bold')
        .fontSize(10.5)
        .text('ROMBLON STATE UNIVERSITY - CAJIDIOCAN CAMPUS', left + 46, y + 2, { width: contentW - 46 });
      doc
        .fillColor('#0B5537')
        .font('Helvetica-Bold')
        .fontSize(9)
        .text(toPdfAsciiSafe(params.title.toUpperCase()), left + 46, y + 15, { width: contentW - 46 });
      doc
        .fillColor('#475569')
        .font('Helvetica')
        .fontSize(7)
        .text(
          `Generated: ${params.manilaTimestamp} | Rows Included: ${params.rows.length}${params.truncatedForPdf ? ' (PDF capped at 5,000 rows; use CSV for full stream)' : ''}`,
          left + 46,
          y + 27,
          { width: contentW - 46 }
        );
      y += 44;
      doc.moveTo(left, y).lineTo(right, y).lineWidth(1).strokeColor('#0B5537').stroke();
      return y + 6;
    };

    const drawTableHeader = (y: number) => {
      doc.rect(left, y, contentW, 17).fill('#07442B');
      doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(6.5);
      displayCols.forEach((col, i) => {
        doc.text(col.replace(/_/g, ' ').toUpperCase(), left + i * colW + 2, y + 5, {
          width: colW - 4,
          lineBreak: false,
          ellipsis: true,
        });
      });
      return y + 17;
    };

    let y = drawPageHeader();
    // Summary bar on Page 1
    const summaryText = Object.entries(params.summary)
      .slice(0, 7)
      .map(([k, v]) => `${k.replace(/_/g, ' ')}: ${currencyCols.has(k) || k.includes('pay') || k.includes('deductions') ? formatPdfCurrency(v) : String(v ?? 0)}`)
      .join(' | ');
    if (summaryText) {
      doc.roundedRect(left, y, contentW, 20, 3).fillAndStroke('#F4F8F6', '#CBD5E1');
      doc
        .fillColor('#07442B')
        .font('Helvetica-Bold')
        .fontSize(6.8)
        .text(toPdfAsciiSafe(summaryText), left + 6, y + 6, { width: contentW - 12, ellipsis: true });
      y += 24;
    }

    y = drawTableHeader(y);
    const rowH = 15;

    if (params.rows.length === 0) {
      doc
        .fillColor('#64748B')
        .font('Helvetica')
        .fontSize(8)
        .text('No database records matched the selected report filters.', left, y + 12, {
          width: contentW,
          align: 'center',
        });
    } else {
      for (let rIdx = 0; rIdx < params.rows.length; rIdx++) {
        if (y + rowH > pageH - 36) {
          doc.addPage();
          y = drawPageHeader();
          y = drawTableHeader(y);
        }
        const row = params.rows[rIdx];
        if (rIdx % 2 === 1) {
          doc.rect(left, y, contentW, rowH).fill('#F8FAFC');
        }
        doc
          .moveTo(left, y + rowH)
          .lineTo(right, y + rowH)
          .lineWidth(0.3)
          .strokeColor('#E2E8F0')
          .stroke();

        doc.fillColor('#1E293B').font('Helvetica').fontSize(6.4);
        displayCols.forEach((col, cIdx) => {
          const rawVal = row[col];
          const textVal = currencyCols.has(col) ? formatPdfCurrency(rawVal) : toPdfAsciiSafe(rawVal);
          doc.text(textVal, left + cIdx * colW + 2, y + 4, {
            width: colW - 4,
            lineBreak: false,
            ellipsis: true,
          });
        });
        y += rowH;
      }
    }

    const range = doc.bufferedPageRange();
    totalPagesRendered = range.count;
    for (let i = 0; i < range.count; i++) {
      doc.switchToPage(i);
      doc
        .fillColor('#64748B')
        .font('Helvetica')
        .fontSize(6.5)
        .text(
          `SAVAGE-RSUCAJ Smart Attendance System | Generated by ${params.generatedBy} | Page ${i + 1} of ${range.count}`,
          left,
          pageH - 34,
          { width: contentW, align: 'center', lineBreak: false }
        );
    }

    doc.end();
  });
}
