# SAVAGE-RSUCAJ — BUILD 20 TFLite Model Integration Report

**Release decision: NO-GO for production.** Source integration completed, based on the actual **BUILD 19 full-source archive** and the three `.tflite` binaries supplied in the current conversation. This build does not claim an Android APK, device testing, calibrated biometric accuracy, or a live backend integration.

## 1. Overview

This increment includes the three uploaded trained model *candidates* without duplicating their alternate filenames. Their exact bytes passed TFL3-header and SHA-256 integrity tests against the user-supplied manifest. The models are **not certified** to detect photo/screen attacks, recognize people at any particular accuracy, comply with regulatory requirements, or hold commercial-use licensing.

| Role | Embedded filename | SHA-256 | Tensors in user-supplied structural audit |
|---|---|---|---|
| PAD MiniFASNetV1 | `anti_spoofing_pad.tflite` | `5d573d20b795a19d7b2a0f67cc4c1130ce8ec30d5f6aa06b2c788a344a49d4dd` | float `[1,80,80,3]` -> `[1,3]` |
| Passive liveness MiniFASNetV2 | `liveness_detection.tflite` | `4ff758f470b757d9005b418c9978693f09b8f2a5e7b7ee848c160db21208e1b2` | float `[1,3,80,80]` -> `[1,3]` |
| Face embedding MobileFaceNet | `face_recognition.tflite` | `be4bc7cfc53f7bc336d0f28b1ab92535f618c913a422b683210750f6b5354854` | float `[1,112,112,3]` -> `[1,192]` |

## 2. Architecture

Existing app and admin portal unchanged except for Android model pipeline and tests. The Android pipeline is **CameraX + ML Kit -> crop/resize -> model-specific tensor encoding -> TFLite interpreter -> validated PAD/liveness scores -> L2-normalized 192-dimensional recognition embedding -> encrypted enrolled templates -> attendance repository -> canonical Express backend**. No mock model is included in runtime code. Previous offline queue and administrator restrictions are retained as-is; their open production risks are **not** resolved in this build.

- PAD input: **RGB NHWC**; `(pixel/128)-1` normalization; `live_class=0` as stated in supplied audit.
- Passive liveness input: **BGR NCHW**; `pixel/255` normalization; `live_class=1`. This is **not** blink/action liveness.
- Recognition input: **RGB NHWC**; `(pixel/128)-1`; output **192** finite, nonzero embedding elements.
- The decoder preserves already-normalized probability vectors; logits are softmaxed with numerical stabilization; nonfinite, malformed or ambiguous outputs fail closed. Attack subtypes (photo vs screen replay) are not asserted without verified class mapping.
- The model loader pins **fixed SHA-256 fingerprints** against exact user-supplied binary bytes, checks tensor dtypes, exact shapes and output counts. Fingerprints do not validate training data, model licensing or measured performance.

## 3. UI/UX Design

The original UI, all Android XML resources, fonts, logo, icons, navigation and admin portal are left untouched. Byte-for-byte comparison of **22 Android resource files** against BUILD 19: **22/22 identical**. No physical Android screenshot or responsive layout comparison was performed.

## 4. Implementation — exact paths

Project root: `finalngfacerecogantion-main/`

| File | Work completed |
|---|---|
| `app/src/main/assets/models/anti_spoofing_pad.tflite` | Exact uploaded PAD model candidate |
| `app/src/main/assets/models/liveness_detection.tflite` | Exact uploaded passive liveness model candidate |
| `app/src/main/assets/models/face_recognition.tflite` | Exact uploaded face embedding model candidate |
| `app/src/main/java/com/example/kiosk/vision/BiometricTensorCodec.kt` | New pure Kotlin encoding, shape validation, safe score decoding, embedding validity |
| `app/src/main/java/com/example/kiosk/vision/FaceCropPreprocessor.kt` | Delegates RGB/NHWC or BGR/NCHW model-specific encoding to tensor codec |
| `app/src/main/java/com/example/kiosk/biometrics/TfliteBiometricEngine.kt` | Exact tensor model specs, separate class mapping, new score decoder, fail-closed output handling, 192D embeddings |
| `app/build.gradle.kts` | Pins uploaded model SHA-256 digests in build-time public BuildConfig fields |
| `app/src/test/java/com/example/TfliteBiometricEngineTest.kt` | Updates fake model fixtures and adds probability-decoding regression test |
| `app/src/test/java/com/example/EnrollmentAndTemplateStorageTest.kt` | Updates 3-pose fake interpreter fixtures for new model dimensions |
| `app/src/test/java/com/example/Build20TensorContractsTest.kt` | New JUnit tests for actual source codec and output score rules (not executed here via Android Gradle) |
| `tools/verify_build20_assets.py` | Reproducible checksum + TFL3 header + Gradle pin verifier |

**Admin portal:** `adminwebportal-imaw-na-ini-main/` unchanged from BUILD 19, including the BUILD 18 bridge, canonical attendance engine, and stored data migration code.

## 5. Error analysis

1. **Previous PAD normalization incorrect**: existing ZERO_TO_ONE replaced with uploaded model candidate's `(pixel/128)-1 RGB NHWC`.
2. **Previous passive liveness layout incorrect**: existing NHWC/96x96 /2-class assumption replaced with **NCHW/80x80/3-class BGR** with proper planar buffer ordering.
3. **Previous PAD live class incorrect**: previous class 1 used for both; PAD now uses class 0, passive liveness uses class 1 per supplied model audit.
4. **Previous double-softmax risk**: decoder preserves normalized output; valid logits receive stabilized softmax; invalid/ambiguous outputs fail closed.
5. **Previous recognition vector size too broad**: exact `[1,192]` output and finite nonzero vector enforced. Previously enrolled 128D templates **cannot be reused as 192D without re-enrollment**; no destructive migration/fake conversion attempted.
6. **Remaining risk**: The class mapping and normalization are sourced from the supplied audit, **not yet verified against measured real-camera output**. No threshold tuning, multi-person testing, lighting studies, or PAD acceptance evaluation. Cropping/alignment conditions may require adjustment following representative device testing.

## 6. Actual tests — executed in this environment

| Check | Result | Interpretation |
|---|---|---|
| File SHA-256, expected sizes, `TFL3` headers and static Gradle pins | **3/3 PASS** | Artifact integrity only |
| Pure Kotlin source `BiometricTensorCodec.kt` compiled with `kotlinc` and executable smoke suite | **11/11 PASS** | Array formatting, probability rules, input shapes, rejection paths |
| `TfliteBiometricEngine.kt` compiled with lightweight Android/TFLite/coroutine **stubs** and executed fake-interpreter smoke checks | **3/3 PASS** | Source compilation at stub contracts + fake tensor paths, **NOT actual TFLite inference** |
| `npm run test:build19` under admin | **9/9 PASS** | Existing bridge protocol, HMAC integrity and validator contract tests |
| All original Android UI resource file hashes vs BUILD 19 | **22/22 unchanged** | Source assets only |
| `gradlew assembleDebug` / JUnit Gradle / instrumentation test | **NOT RUN** | Gradle wrapper scripts/JAR and Android SDK unavailable here |
| Android/JNI interpreter loads actual binaries on Android | **NOT TESTED** | Requires target handset and TFLite runtime |
| True live-face versus photo/screen/3D mask accuracy | **NOT TESTED** | Requires approved representative real data and measurement |
| Live Admin ↔ Kiosk API/end-to-end online/offline | **NOT TESTED** | Requires staging backend, registered device, Android hardware |

The 11+3+9 tests are of separate scopes; they must not be described as 23 successful camera/device tests.

## 7. Deployment — operator steps (not executed)

1. On an authorized Windows development machine, extract the complete ZIP; do not overwrite any production SQLite DB. Open `finalngfacerecogantion-main` in Android Studio. Install the SDK / JDK versions required by the repository and restore a **verified official** Gradle wrapper (the original project contains `gradle/wrapper/gradle-wrapper.properties` but lacks wrapper scripts/JAR). Preserve the existing package name, signing configs and UI assets.
2. Verify the bundle before building:

   ```powershell
   python .\tools\verify_build20_assets.py
   ```

   The three model assets and pinned fingerprints are already included; there is no need to copy the alternate `anti_spoof.tflite`, `silentface.tflite` or `mobile_face_net.tflite` names again.
3. With a working Gradle wrapper + Android SDK, run from project root: `./gradlew.bat :app:testDebugUnitTest` and `./gradlew.bat :app:assembleDebug` in PowerShell; review failures, do not mark them passed without actual logs. Use approved signing-key procedures for release APK/AAB.
4. Enroll *consenting, authorized* test participants afresh. **Do not reuse legacy embeddings from a different model or vector size**. Calibrate PAD/liveness/recognition thresholds on supported cameras; test at least lighting, pose, glasses, printing, phone/tablet replay, false accept/reject, identical twins if relevant, repeat captures and latency. Record measured FAR/FRR and PAD APCER/BPCER where applicable.
5. Configure HTTPS backend URL and the correct provisioned kiosk identity/token; rotate the default admin PIN. Execute true Android time-in, time-out, duplicate, queued offline and reconnection cases and verify admin attendance records and downstream reports.
6. Independently gate backend enrollment approval, capture-time offline proof, security/privacy retention, backup migration, commercial model licenses, and complete release acceptance before real faculty/employee deployment.

## 8. Final status

**Completed in source:** trained candidate model assets; exact tensor adapters; checksum pinning; probability output handling; test updates; preserved original Android admin/UX. **Remaining:** Gradle+APK, Android runtime real model inference, camera-specific PAD and recognition validation, operator approval, legacy template migration/re-enrollment, offline attestation, live staging backend connection, licenses, security/privacy acceptance.

**BUILD 20 result: integrated source package for staging; NO-GO for production.**
