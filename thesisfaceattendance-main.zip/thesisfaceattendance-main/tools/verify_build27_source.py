#!/usr/bin/env python3
"""BUILD 27 structural gate (not an Android build, biometric test or live system test)."""
from pathlib import Path
import hashlib,json,sys,zipfile
root=Path(__file__).resolve().parents[2]
web=root/'adminwebportal-imaw-na-ini-main'
android=root/'finalngfacerecogantion-main'
manifest=root/'BUILD27_PRESERVED_ASSETS.json'
assert manifest.is_file(),'Missing BUILD27_PRESERVED_ASSETS.json'
assets=json.loads(manifest.read_text('utf8'))
checks=[]
for rel,expected in assets.items():
    p=root/rel
    checks.append((f'preserved binary asset: {rel}', p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected))
paths=[
 'server/employeeToday.ts', 'server/employeeAccounts.ts', 'server/realtimeHub.ts', 'server/androidBridge.ts',
 'src/lib/refreshCoalescer.ts', 'src/components/EmployeeMobilePortal.tsx', 'tests/build27-integration.test.mjs'
]
checks += [(f'web source: {x}',(web/x).is_file()) for x in paths]
checks += [('Android short-lived device cache',(android/'app/src/main/java/com/example/kiosk/data/VerifiedDeviceCache.kt').is_file())]
checks += [('Android cache smoke test',(android/'tools/jvm_smoke/Build27VerifiedDeviceCacheSmoke.kt').is_file())]
android_source=(android/'app/src/main/java/com/example/kiosk/data/AttendanceApiService.kt').read_text('utf8')
backend_source=(web/'server/androidBridge.ts').read_text('utf8')
checks += [('Cache is used by real attendance submission','verifiedDeviceCache.get(activeDeviceId, token)' in android_source and 'verifiedDeviceCache.remember(' in android_source)]
checks += [('Server-side attendance still verifies biometric proof','verifyBiometricEvidenceEnvelope' in backend_source)]
checks += [('Android department realtime event uses actual employee department','department_id: employee.department_id' in backend_source)]
checks += [('Employee has no manual punch controls','/api/attendance' not in (web/'src/components/EmployeeMobilePortal.tsx').read_text('utf8'))]
result={'build':27,'tests':len(checks),'passed':sum(bool(ok) for _,ok in checks),'failures':[name for name,ok in checks if not ok], 'NOTE':'Source/assets checks only; no APK, live device, web deployment, or facial accuracy certification.'}
print(json.dumps(result,indent=2))
sys.exit(0 if result['tests']==result['passed'] else 1)
