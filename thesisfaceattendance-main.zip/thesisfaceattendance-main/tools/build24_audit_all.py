"""File-by-file structural audit for the complete BUILD 24 source package.
This is not a full Android build, full TypeScript typecheck, or live-system test.
"""
from pathlib import Path
import hashlib, json, csv, xml.etree.ElementTree as ET, tomllib, re, subprocess, sys
ADMIN = Path(__file__).resolve().parents[1]
ROOT = ADMIN.parent
ANDROID = ROOT / 'finalngfacerecogantion-main'
OUT = ROOT / 'BUILD24_FILE_AUDIT.json'
rows=[]
issues=[]
for prj in (ADMIN,ANDROID):
    if not prj.exists():
        issues.append(f'Missing project: {prj.name}')
        continue
    for f in sorted(prj.rglob('*')):
        if not f.is_file() or any(c in f.parts for c in ('node_modules','build','.gradle','dist')): continue
        rel = str(f.relative_to(ROOT)).replace('\\','/')
        status='INVENTORIED'; check='Exists'; detail=''
        try:
            if f.suffix == '.json': json.loads(f.read_text('utf-8'));check='JSON parsed';status='PASS'
            elif f.suffix == '.xml': ET.parse(f);check='XML parsed';status='PASS'
            elif f.suffix == '.toml': tomllib.loads(f.read_text('utf-8'));check='TOML parsed';status='PASS'
            elif f.suffix == '.tflite':
                b=f.read_bytes(); check='TFLite TFL3 signature';status='PASS' if b[4:8]==b'TFL3' else 'FAIL'
                if status=='FAIL': detail='Invalid TFL3 file signature'
            elif f.suffix in ('.ts','.tsx','.kt','.kts','.mjs','.js','.ps1'):
                check='Source inventoried; language-specific compilation required';status='NOT_COMPILED'
            elif f.suffix in ('.png','.ttf','.webp','.jpg','.jpeg'):
                check='Binary asset preserved';status='INVENTORIED'
            if status=='FAIL':issues.append(f'{rel}: {detail}')
        except Exception as e:
            status='FAIL';detail=f'{type(e).__name__}: {e}';issues.append(f'{rel}: {detail}')
        rows.append({'file':rel,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'check':check,'status':status,'detail':detail})
# Explicit Android model pin checks
config=(ANDROID/'app/build.gradle.kts').read_text('utf-8')
models={'anti_spoofing_pad.tflite':'BIO_PAD_SHA256','liveness_detection.tflite':'BIO_LIVENESS_SHA256','face_recognition.tflite':'BIO_RECOGNITION_SHA256'}
for fname,key in models.items():
    f=ANDROID/'app/src/main/assets/models'/fname
    digest=hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None
    matches=re.findall(r'buildConfigField\("String", "'+key+r'", "\\"([a-f0-9]{64})\\""\)',config)
    if not digest or not matches or digest!=matches[0]: issues.append(f'Model pin mismatch: {fname}')
# Missing executable Gradle wrapper reported, not concealed
for n in ('gradlew','gradlew.bat','gradle/wrapper/gradle-wrapper.jar'):
    if not (ANDROID/n).exists(): issues.append(f'BUILD BLOCKER: Android wrapper missing: {n}')
res={'build':'24','scope':'all files of bundled Android and admin projects','total_files':len(rows),'status_counts':{v:sum(r['status']==v for r in rows) for v in sorted(set(r['status'] for r in rows))},'known_issues':issues,'files':rows,'notice':'PASS means JSON/XML/TOML parsed or TFLite signature valid; NOT a complete runtime/security verification.'}
OUT.write_text(json.dumps(res,indent=2)+'\n','utf-8')
with (ROOT/'BUILD24_FILE_AUDIT.csv').open('w',encoding='utf-8',newline='') as fp:
    w=csv.DictWriter(fp,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
print(json.dumps({k:v for k,v in res.items() if k!='files'}, indent=2))
sys.exit(1 if any(not i.startswith('BUILD BLOCKER') for i in issues) else 0)
