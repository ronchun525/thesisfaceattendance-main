#!/usr/bin/env python3
"""Structural verification only: does not certify a build or runtime."""
from pathlib import Path
import hashlib, json, re, sys
root=Path(__file__).resolve().parent.parent
checks={}
checks['mobile_portal']=(root/'src/components/EmployeeMobilePortal.tsx').exists()
checks['backend_link_guard']=(root/'server/employeeAccounts.ts').exists()
s=(root/'server/api.ts').read_text(encoding='utf-8')
checks['employee_profile_endpoint']="router.get('/employee/profile'" in s
checks['employee_month_endpoint']="router.get('/employee/attendance-month'" in s
checks['employee_link_validation']="resolveEmployeeAccountLink(db, employee_id)" in s
checks['employee_link_update_validation']="resolveEmployeeAccountLink(db, targetEmployeeId, id)" in s
checks['forced_first_login_rotation']="role === 'Employee' ? 1" in s
checks['self_month_query']="WHERE employee_id = ? AND date >= ? AND date < ?" in s
mobile=(root/'src/components/EmployeeMobilePortal.tsx').read_text(encoding='utf-8')
checks['mobile_bottom_nav']='env(safe-area-inset-bottom)' in mobile and 'grid-cols-5' in mobile
checks['no_employee_punch_api']='api/kiosk/punch' not in mobile and 'api/v1/kiosk/attendance' not in mobile
checks['real_self_service_api']=all(x in mobile for x in ['/api/employee/today-attendance','/api/employee/attendance-month','/api/payroll/my-payslips','/api/leaves','/api/corrections'])
checks['existing_auth_reused']='/api/auth/change-password' in mobile
app=(root/'src/App.tsx').read_text()
checks['employee_role_route']="if (user.role === 'Employee')" in app
checks['admin_account_create']="onClick={() => openCreateAccount(emp)}" in (root/'src/components/EmployeesView.tsx').read_text()
checks['server_realtime_events']="channels: ['attendance:updated']" in mobile
print(json.dumps({'checks':checks,'passed':sum(checks.values()),'total':len(checks),'all_passed':all(checks.values())},indent=2))
sys.exit(0 if all(checks.values()) else 1)
