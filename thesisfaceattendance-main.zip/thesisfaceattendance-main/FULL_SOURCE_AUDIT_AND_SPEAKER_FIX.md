# SAVAGE-RSUCAJ Web Kiosk — Full Source Audit and Offline Speaker Fix

**Basis:** User-uploaded `thesisfaceattendance-main.zip` (22 November 2026).  
**Disposition:** **NOT PRODUCTION READY**. The audio code path was repaired and unit tested. Real camera, browser UI, physical speaker, and production biometric attendance were **not** proven functional.

## 1. Overview

The source is a React/TypeScript Vite application with an Express/TypeScript API and SQLite database. The `/kiosk` route contains the Web Face Recognition Kiosk; the same active application also includes admin and employee portals. An older, archived admin portal is embedded as `adminwebportal-imaw-na-ini-main.zip`.

**Inventory:** 232 uploaded ZIP entries; 211 active and archived source/config items individually listed in `AUDIT_PER_FILE.csv`. Static syntax/JSON/import validation found no syntax errors or missing local imports in the inspected TypeScript, TSX, MJS and JSON sources. Eight Python source files (four active, four archived) also passed Python syntax parsing.

The per-file CSV is a **static-source audit** with paths and SHA-256 fingerprints, **not** a claim of executed functional acceptance of each function. This distinction is essential since full application dependencies were unavailable.

## 2. Architecture

- Browser frontend: React 19, Vite 8, TypeScript, CSS/Tailwind.
- Backend: Express, TypeScript, `better-sqlite3`, SQLite WAL, HTTP-only kiosk sessions, CSRF checks and role administration.
- Web kiosk: activation, admin PIN, employee enrollment, camera acquisition, liveness/PAD policies, attendance API and result screens.
- Browser speaker: local MP3 files in `public/audio/`, optional `speechSynthesis` fallback, browser audio permission on real gestures or managed kiosk autoplay at OS launch.

## 3. UI/UX design and behavior

Kept the approved existing emerald/gold kiosk screens and branding. Added just one non-voice **Test Speaker** row to the existing PIN-protected Kiosk Settings screen, without redesigning navigation or existing screen flows. Test Speaker plays a short diagnostic tone. **Thank you** plays only on backend-confirmed attendance success; **Try again** plays on attendance verification failure. Idle scanning and employee enrollment do not announce voice phrases.

## 4. Implementation — changed/new files

| File | Modification |
|---|---|
| `src/lib/kioskBiometrics.ts` | Offline MP3 attendance cues, 3.5s bounded `play()` wait, user-gesture media priming, failover to browser TTS, stop/pause cleanup, speaker test tone |
| `src/components/WebKioskPortal.tsx` | Prime browser sound on real attendance button clicks; wire settings diagnostic with clear success/error display; stop audio when unmounted |
| `src/components/kiosk/KioskScreens.tsx` | PIN-protected Test Speaker row and loading indication |
| `public/audio/thank-you.mp3` | Locally packaged English speech (no cloud TTS needed) |
| `public/audio/try-again.mp3` | Locally packaged English speech (no cloud TTS needed) |
| `public/audio/speaker-test.mp3` | Short diagnostic tone (never an attendance voice announcement) |
| `public/audio/prime.mp3` | Silent unlock/prime asset |
| `tests/kiosk-speaker-offline.test.mjs` | Five independent speech, muted policy, fallback, diagnostic and cleanup tests |
| `package.json` | Adds `npm run test:speaker` |
| `scripts/start-kiosk-pi.sh` | Managed Chromium fullscreen launcher with audio autoplay permission; no camera permission bypass |
| `scripts/start-kiosk-windows.ps1` | Windows Edge/Chrome fullscreen launcher with kiosk autoplay permission |
| `docs/KIOSK_SPEAKER_FULLSCREEN_GUIDE.md` | Hardware speaker setup, OS commands, kiosk instructions, troubleshooting |
| `AUDIT_PER_FILE.csv` | File-by-file static audit for active sources and nested legacy archive |

No live database rows were deliberately changed during this patch. The original included SQLite database and WAL files remain in this source package; they may contain personal data. **Do not publish the ZIP publicly.** The nested legacy admin portal archive was scanned but not silently replaced or changed.

## 5. Error analysis: root causes, remediation and remaining blockers

1. **Silence despite configured Voice Prompt.** Original `KioskVoiceController` used only `speechSynthesis` and swallowed failures. Linux Chromium may have no TTS voices installed; autoplay can block sound on auto-booted kiosk. **Fixed in source:** packaged speech MP3s with fallback, explicit gesture priming, kiosk launch flags, and a PIN-protected tone test. **Requires physical verification** on target OS audio output.
2. **Unattended fullscreen browser blocks media.** An automatic page load is not a legitimate user activation, so browsers may prevent `Audio.play()`. **Addressed:** managed Pi/Windows Chromium launcher uses `--autoplay-policy=no-user-gesture-required`. This is appropriate only for a physically controlled kiosk, not general-purpose browsing. OS speaker volume/mute/output sink must still be correct.
3. **Production face verification unavailable.** In `server/webKioskBiometrics.ts`, `serverInferenceAvailable` is explicitly `false`; no native TFLite interpreter/service is bundled. Three required pinned-hash `.tflite` model binaries are also absent. **Unfixed/blocked:** must integrate a real validated inference runtime and correctly licensed/verified model files; cannot set the boolean `true` or fake scores.
4. **Kiosk API biometric evidence incomplete.** `src/components/WebKioskPortal.tsx` calls `/api/kiosk/web/attendance` without a real `embedding`, `liveness_score`, `anti_spoof_score`, or verified multi-frame evidence. Server-side validation rejects unverified biometric evidence. Same end-to-end gap affects automatic enrollment. **Unfixed/blocked:** real camera-to-model inference, server attestation and secure evidence contract must be implemented and tested before enabling production biometric registration.
5. **Existing database needs runtime migrations.** Shipped SQLite database passed `PRAGMA integrity_check` but currently lacks `web_kiosk_sessions` table before starting the new server. Source migrations appear intended to add kiosk tables; migration was **not executed** in this environment. Backup the database first and run verified database migration/startup tests on a copy.
6. **Dependency reproducibility.** Root ZIP contains no `package-lock.json`. `npm install` could not complete because this sandbox could not resolve `registry.npmjs.org` (`EAI_AGAIN`), so no full runtime lint, build, DB migration or API/browser E2E could be run. **Unfixed:** run `npm install` on a network-enabled trusted development machine; retain the generated lockfile after verification.
7. **Browser / physical environment not available for reliable sound acceptance.** Headless Chromium smoke attempt timed out and logged a missing session D-Bus connection. It is not valid evidence of audible playback or of a functional app UI. Physical Pi or Windows speaker checks remain **blocked**.
8. **Original upstream legacy test failures.** The source's previous `TEST_RESULTS.md` itself documents schema baseline assertions and unavailable physical/AI models. Those claims were not adopted as fresh test results. The full regression suite must be rerun after restoring npm dependencies and model runtime.
9. **Distribution caution.** A live SQLite DB/WAL is inside the uploaded source and the ZIP also contains a nested older project. Exclude sensitive data and unused backups before sharing or uploading to a public repository. Confirm development Vite host policy and production HTTPS proxy configuration for the chosen deployment environment.

## 6. Testing — actual results in this audit

| Test | Method | Actual result |
|---|---|---|
| Per-file static parsing and local import resolution | TypeScript 5.8 parser and import path scan on active and nested archived files | **PASS:** 211 file rows; zero syntax or unresolved-local-import errors reported; non-code scripts are inventoried only |
| Python syntax | `ast.parse` active and archived `tools/*.py` | **PASS: 8/8** |
| SQLite database integrity | Read-only `PRAGMA integrity_check` on uploaded database | **PASS: `ok`** (34 tables; database migration not tested) |
| Audio playback controller unit tests | `node --experimental-strip-types --test tests/kiosk-speaker-offline.test.mjs` | **PASS: 5/5** |
| Packaged audio validity | `ffprobe` on four offline MP3s | **PASS: 4/4** valid MP3 containers |
| Pi kiosk launch shell script | `bash -n scripts/start-kiosk-pi.sh` | **PASS** |
| Full frontend build and TypeScript semantic typecheck | `npm install`, `npm run build`, `npm run lint` | **BLOCKED:** npm registry unavailable (DNS `EAI_AGAIN`); no dependencies installed; not claimed passed |
| Backend API, migration and original test suite | Full `npm test`, kiosk E2E | **NOT RUN** for same dependency blocker |
| Real-browser speaker output | Headless Chromium smoke attempt | **INCONCLUSIVE:** browser timed out; missing D-Bus session |
| Real OS speaker, camera and physical biometric trials | Raspberry Pi/Windows and physical camera | **NOT RUN** (not attached to runtime) |
| Three production TFLite models | Models directory in ZIP | **BLOCKED:** zero model binaries provided and no inference engine |

## 7. Deployment

See `docs/KIOSK_SPEAKER_FULLSCREEN_GUIDE.md` for copy/paste Raspberry Pi OS and Windows startup commands. Generic development sequence on a machine with internet and a correctly provisioned `.env`:

```powershell
npm install
npm run lint
npm run test:speaker
npm run build
npm run test:startup
npm test
npm run dev
```

The app serves the browser kiosk at `/kiosk`, e.g. `http://127.0.0.1:3000/kiosk` locally or via a verified **HTTPS** host. Audio MP3 files should be reachable at `/audio/*.mp3`. On a physical managed kiosk, launch Chromium/Edge using the supplied scripts. Test the OS speaker first, then use Kiosk Settings -> Test Speaker. First camera use requires permission for the trusted site. Do not deploy the included real database as a public web asset.

The production service needs valid environment secrets, backups, persistent writable database location, TLS and reverse proxy, pinned model files, actual TFLite interpreter and real biometric tests. The standalone speaker changes do not satisfy these requirements.

## 8. Final report

**Completed:** full static code/config inventory (including nested legacy archive), database integrity inspection, offline English voice cues, browser TTS fallback, bounded playback failure handling, user-gesture unlock, PIN-protected diagnostic tone, fullscreen OS launcher scripts, five passing audio controller tests, MP3 format verification and deployment guidance.

**Remaining:** actual npm dependency installation and complete regression testing; semantic typechecking and frontend build; live UI browser tests; physical speaker audibility; database migration tests; real liveness/PAD/face recognition model files + inference engine; protected biometric evidence contract; real hardware + institutional acceptance. **Do not certify this as production ready.**
